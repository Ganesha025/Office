<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Services\RiskRuleEngine;
use App\Models\StudentAcademicSummaryModel;

class RiskPredictionController extends BaseController
{
public function index()
{
    $model = model(\App\Models\StudentRiskPredictionModel::class);

    $data['predictions'] = $model
        ->select('id, student_id, risk_score, risk_level, ai_remarks')
        ->orderBy('risk_score', 'DESC')
        ->paginate(50); // 50 records per page

    $data['pager'] = $model->pager;

    return view('index', $data);
}




  public function run(){
        try {
            // Initialize your RiskRuleEngine
            $engine = new RiskRuleEngine();

            // Fetch all students data from the engine
            $studentsData = $engine->fetchAllStudentsData();

            // Return JSON response
            return $this->response->setJSON([
                'status'  => 'success',
                'message' => 'Student data fetched successfully',
                'data'    => $studentsData
            ]);

        } catch (\Throwable $e) {
            // Handle errors
            return $this->response->setStatusCode(500)->setJSON([
                'status'  => 'error',
                'message' => 'Failed to fetch student data',
                'error'   => $e->getMessage()
            ]);
        }
    }
}
