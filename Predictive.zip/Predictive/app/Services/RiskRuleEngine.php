<?php

namespace App\Services;

use App\Models\StudentAcademicSummaryModel;
use App\Models\StudentRiskPredictionModel;
use App\Models\StudentModel;

class RiskRuleEngine
{
    protected $academicModel;
    protected $studentModel;
    protected $predictionsModel;

    public function __construct()
    {
        $this->academicModel    = model(StudentAcademicSummaryModel::class);
        $this->studentModel     = model(StudentModel::class);
        $this->predictionsModel = model(StudentRiskPredictionModel::class);
    }
public function fetchAllStudentsData(){
    // 1. Fetch all academic records
    $students = $this->academicModel->findAll();

    $result = [];

    foreach ($students as $student) {
        // 2. Fetch student master data using student_id
        $studentMaster = $this->studentModel
            ->where('student_id', $student['student_id'])
            ->first();
              // 3. Calculate pending fee safely
            $departmentFee = $studentMaster['department_fees_amount'];
            
            $student['department_fees_amount']=$departmentFee; 
            $paidFee       = $student['fee_due_amount'];
        $student['pending_amount'] = $paidFee > 0 ? $departmentFee - $paidFee : 0;
            $riskScore = $this->calculateRisk($student);
            $remarks   = $this->generateRemarks($student);
            
            $level= $this->getRiskLevel($riskScore);
        // Data to insert (ONE ROW)
        $predictionData = [
            'student_id'       => $student['student_id'],
            'risk_score'       => $riskScore,   // fixed typo
            'risk_level'       => $level,
            'ai_remarks'       => $remarks,
            'prediction_date'  => date('Y-m-d'),
        ];

        // Save prediction
        if($riskScore!=0){
            
        $this->predictionsModel->save($predictionData);

        }
        // Collect for response
        $result[] = array_merge(['id' => $student['id']], $predictionData);
    }

    return $result;
}

    public function calculateAll(){
        // 1. Fetch all academic records
        $students = $this->academicModel->findAll();

        foreach ($students as $student) {

            // 2. Fetch student master data using student_id
            $studentMaster = $this->studentModel
                ->where('student_id', $student['student_id'])
                ->first();

            // 3. Calculate pending fee safely
            $departmentFee = $studentMaster['department_fees_amount'] ?? 0;
            $paidFee       = $student['fee_due_amount'] ?? 0;
            $pendingAmount = $departmentFee - $paidFee;

            // 4. Add pending amount to student array
            $student['pending_amount'] = $pendingAmount;

            // 5. Calculate risk
            $riskScore = $this->calculateRisk($student);
            $riskLevel = $this->getRiskLevel($riskScore);
            $remarks   = $this->generateRemarks($student);
        $this->predictionsModel->save([
    'student_id'      => $student['student_id'],
    'risk_score'      => $riskScore,
    'risk_level'      => $riskLevel,
    'ai_remarks'      => $remarks,
    'prediction_date' => date('Y-m-d')
]);

        }

        return true;
    }

private function calculateRisk(array $s): int
{
    $attendance = (float) ($s['attendance_percentage'] ?? 100);
    $marks = (float) ($s['avg_internal_marks'] ?? 50);
    $pending = (float) ($s['pending_amount'] ?? 0);
    $departmentFee = (float) ($s['department_fees_amount'] ?? 0);
    $incidents = (int) ($s['incident_count'] ?? 0);

    $risk = 0;

  if ($incidents >= 10) {
    $risk = 100;
} elseif ($incidents == 9) {
    $risk = 85;
    if ($marks < 20 || $attendance < 60) {
        $risk = 100;
    } elseif ($marks >= 35 && $attendance >= 85 && $pending == 0) {
        $risk = 70;
    } else {
        // compare marks with 50
        $risk += (int) round((50 - min($marks,50)) / 50 * 15);
    }
} elseif ($incidents == 8) {
    $risk = 75;
    if ($marks < 20) {
        $risk += 15;
    } elseif ($marks >= 30 && $attendance >= 80) {
        $risk -= 10;
    } else {
        $risk += (int) round((50 - min($marks,50)) / 50 * 12);
    }
} elseif ($incidents == 7) {
    $risk = 65;
    if ($marks < 20 || $attendance < 65) {
        $risk += 10;
    } elseif ($marks >= 35 && $attendance >= 85) {
        $risk -= 5;
    } else {
        $risk += (int) round((50 - min($marks,50)) / 50 * 10);
    }
} elseif ($incidents == 6) {
    $risk = 55;
    if ($marks < 20) {
        $risk += 10;
    } elseif ($marks >= 30 && $attendance >= 80) {
        $risk -= 5;
    } else {
        $risk += (int) round((50 - min($marks,50)) / 50 * 8);
    }
} elseif ($incidents == 5) {
    $risk = 50;
    if ($marks < 20 || $attendance < 65) {
        $risk += 10;
    } elseif ($marks >= 35 && $attendance >= 85) {
        $risk -= 5;
    } else {
        $risk += (int) round((50 - min($marks,50)) / 50 * 7);
    }
} elseif ($incidents == 4) {
    $risk = 40;
    if ($marks < 20) {
        $risk += 5;
    } else {
        $risk += (int) round((50 - min($marks,50)) / 50 * 5);
    }
} elseif ($incidents == 3) {
    $risk = 35;
    if ($marks < 20) {
        $risk += 5;
    } else {
        $risk += (int) round((50 - min($marks,50)) / 50 * 4);
    }
} elseif ($incidents == 2) {
    $risk = 20;
    if ($marks < 20) {
        $risk += 15;
    } else {
        $risk += (int) round((50 - min($marks,50)) / 50 * 2);
    }
} elseif ($incidents == 1) {
    $risk = 10;
    if ($marks >= 40) {
        $risk += 5;
    } else {
        $risk += (int) round((50 - min($marks,50)) / 50 * 1);
    }
} else {
    $risk = 0;
}


if ($marks < 20) {
    if ($incidents >= 5) {
        $risk += (int) round((50 - $marks) / 50 * 30); // scale proportionally to max 30 points
    } else {
        $risk += ($marks < 10 ? 25 : 15);
    }
} elseif ($marks < 30) {
    if ($incidents >= 5) {
        $risk += (int) round((50 - $marks) / 50 * 10); // small adjustment for mid-level incidents
    } else {
        $risk += 5;
    }
} elseif ($marks >= 40) {
    $risk -= 10;
}


    if ($pending == 0) {
        $risk += 0;
    } elseif ($pending > 0) {
        $pendingPercent = min(1.0, $pending / max(1, $departmentFee));
        $risk += (int) round($pendingPercent * 25);
    }

    if ($attendance < 50) {
        $risk += 20;
    } elseif ($attendance < 65) {
        $risk += 12;
    } elseif ($attendance <= 75) {
        $risk += 2;
    } elseif ($attendance >= 90) {
        $risk -= 5;
    }

    if ($incidents >= 7 && $risk < 50) {
        $risk = 50;
    }

    if ($marks < 20 && $attendance < 60) {
        $risk = max($risk, 75);
    }

    return max(0, min((int) round($risk), 100));
}


private function getRiskLevel(int $score): string{
        if ($score <= 40) {
            return 'LOW';
        } elseif ($score <= 70) {
            return 'MEDIUM';
        }
        return 'HIGH';
    }

private function generateRemarks(array $s): string{
    $remarks = [];

    $attendance = (float) ($s['attendance_percentage'] ?? 100);
    $marks      = (float) ($s['avg_internal_marks'] ?? 50);
    $pending    = (float) ($s['pending_amount'] ?? 0);
    $incidents  = (int)   ($s['incident_count'] ?? 0);

    if ($incidents >= 7) {
        $remarks[] = 'Severe behavioral issues (frequent incidents)';
    } elseif ($incidents >= 4) {
        $remarks[] = 'High behavioral concern';
    } elseif ($incidents >= 1) {
        $remarks[] = 'Behavioral warning';
    }

    if ($marks < 20) {
        if ($marks < 10) {
            $remarks[] = 'Critically low internal marks';
        } else {
            $remarks[] = 'Below pass mark in internal exams';
        }
    } elseif ($marks < 30 && $incidents >= 3) {
        $remarks[] = 'Academics weakening under behavioral stress';
    }

    if ($pending > 40000) {
        $remarks[] = 'Severe fee default';
    } elseif ($pending > 20000) {
        $remarks[] = 'High fee pending';
    } elseif ($pending > 0 && $incidents >= 4) {
        $remarks[] = 'Financial stress with disciplinary concerns';
    }

    if ($attendance < 60) {
        $remarks[] = 'Very poor attendance';
    } elseif ($attendance < 75 && ($marks < 20 || $incidents >= 3)) {
        $remarks[] = 'Attendance risk affecting performance';
    }

    return empty($remarks)
        ? 'No significant risk indicators detected'
        : implode(', ', $remarks);
}


}
