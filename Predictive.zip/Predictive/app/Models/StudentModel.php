<?php
namespace App\Models;
use CodeIgniter\Model;
class StudentModel extends Model{
    protected $table            = 'students';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'student_id',
        'department_name',
        'department_fees_amount',
        'updated_at','created_at'
    ];
    protected $useTimestamps    = true;
    protected $useSoftDeletes   = false;
}
