<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Risk Predictions</title>

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
        }

        .modal-content {
            background: #fff;
            width: 400px;
            margin: 10% auto;
            padding: 20px;
            border-radius: 5px;
        }

        .close {
            float: right;
            font-size: 20px;
            cursor: pointer;
            color: red;
        }

        .high { color: red; font-weight: bold; }
        .medium { color: orange; font-weight: bold; }
        .low { color: green; font-weight: bold; }

        button {
            padding: 5px 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<h2>Student Risk Predictions</h2>

<table id="riskTable" class="display">
    <thead>
        <tr>
            <th>ID</th>
            <th>Student ID</th>
            <th>Risk Score</th>
            <th>Risk Level</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($predictions as $row): ?>
            <tr 
                data-id="<?= esc($row['id']) ?>"
                data-student="<?= esc($row['student_id']) ?>"
                data-score="<?= esc($row['risk_score']) ?>"
                data-level="<?= esc($row['risk_level']) ?>"
                data-remarks="<?= esc($row['ai_remarks']) ?>"
            >
                <td><?= esc($row['id']) ?></td>
                <td><?= esc($row['student_id']) ?></td>
                <td><?= esc($row['risk_score']) ?></td>
                <td class="<?= strtolower($row['risk_level']) ?>">
                    <?= esc($row['risk_level']) ?>
                </td>
                <td>
                    <button class="viewBtn">View</button>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Modal -->
<div id="viewModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Risk Details</h3>
        <p><strong>ID:</strong> <span id="m_id"></span></p>
        <p><strong>Student ID:</strong> <span id="m_student"></span></p>
        <p><strong>Risk Score:</strong> <span id="m_score"></span></p>
        <p><strong>Risk Level:</strong> <span id="m_level"></span></p>
        <p><strong>AI Remarks:</strong></p>
        <p id="m_remarks"></p>
    </div>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
$(document).ready(function () {

    // Initialize DataTable
    $('#riskTable').DataTable({
        pageLength: 10
    });

    // Open modal
    $('.viewBtn').on('click', function () {
        let row = $(this).closest('tr');

        $('#m_id').text(row.data('id'));
        $('#m_student').text(row.data('student'));
        $('#m_score').text(row.data('score'));
        $('#m_level').text(row.data('level'));
        $('#m_remarks').text(row.data('remarks'));

        $('#viewModal').fadeIn();
    });

    // Close modal
    $('.close, .modal').on('click', function (e) {
        if (e.target !== this) return;
        $('#viewModal').fadeOut();
    });

});
</script>

</body>
</html>
