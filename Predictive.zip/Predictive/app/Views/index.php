<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Risk Predictions</title>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script> -->
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    ::-webkit-scrollbar {
    display: none; /* Completely hide the scrollbar */
}main{
    padding: 30px;
    margin-top: 30px;
    margin-bottom: 90px;
}*{
     font-family: 'Poppins', sans-serif;
     user-select: none;
}#sample_card{
    box-shadow: rgba(0, 0, 0, 0.07) 0px 1px 2px, rgba(0, 0, 0, 0.07) 0px 2px 4px, rgba(0, 0, 0, 0.07) 0px 4px 8px, rgba(0, 0, 0, 0.07) 0px 8px 16px, rgba(0, 0, 0, 0.07) 0px 16px 32px, rgba(0, 0, 0, 0.07) 0px 32px 64px;
}#sample_Charts div{
    box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
}#riskTable{width:100%;border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden}
#riskTable thead th{background:#1e35a3;color:#fff;font-weight:600;padding:12px 10px;border-bottom:2px solid #e5e7eb;white-space:nowrap;text-align:left}
#riskTable tbody td{padding:10px;border-bottom:1px solid #e5e7eb;color:#374151;font-size:14px}
#riskTable tbody tr:nth-child(even){background:#f9fafb}
#riskTable tbody tr:hover{background:#eef2ff;transition:.2s}
.low{color:#15803d;font-weight:600}
.medium{color:#ca8a04;font-weight:600}
.high{color:#dc2626;font-weight:700}
.dataTables_filter input,.dataTables_length select{border:1px solid #d1d5db;border-radius:6px;padding:6px 10px;outline:0}
.dataTables_filter input:focus{border-color:#1e35a3}
.dataTables_paginate .paginate_button{padding:6px 12px;margin:2px;border-radius:6px;border:1px solid #d1d5db;background:#fff;color:#1e35a3!important}
.dataTables_paginate .paginate_button:hover,.dataTables_paginate .paginate_button.current{background:#1e35a3!important;color:#fff!important;border-color:#1e35a3}
.dataTables_info{color:#4b5563;font-size:14px;margin-top:10px}

</style>
</head>
<body>
<header class="bg-white text-[#1e35a3] border-b border-gray-300 sticky top-0 z-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex items-center justify-between h-20 relative">
      <div class="flex-shrink-0">
        <img src="https://portal.kongunaducollege.ac.in//uploads/banner/logo.png" alt="Logo" class="h-12 w-auto">
      </div>
      <div class="absolute left-1/2 transform -translate-x-1/2 text-center max-w-xs sm:max-w-md md:max-w-lg lg:max-w-xl">
        <h1 class="text-lg sm:text-2xl font-bold leading-tight">Kongunadu Arts and Science College</h1>
        <p class="font-bold text-sm sm:text-base">(AUTONOMOUS)</p>
      </div>
      <nav class="relative flex-shrink-0">
        <button id="accountBtn" class="flex items-center space-x-2 sm:space-x-3 bg-white border border-[#1e35a3] px-2 sm:px-4 py-1 sm:py-2 rounded hover:bg-[#f0f0f0] focus:outline-none font-bold text-[#1e35a3] text-sm sm:text-base">
          <span class="material-icons text-base sm:text-lg">account_circle</span>
          <span class="hidden sm:inline">Account</span>
          <svg class="w-3 h-3 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
          </svg>
        </button>
        <div id="accountDropdown" class="hidden absolute right-0 mt-2 w-36 sm:w-44 bg-white text-[#1e35a3] rounded shadow-lg z-50">
          <a href="#" class="block px-4 py-2 hover:bg-gray-100 font-bold text-sm sm:text-base">Profile</a>
          <a href="#" class="block px-4 py-2 hover:bg-gray-100 font-bold text-sm sm:text-base">Settings</a>
          <form method="POST" action="/logout">
            <button type="submit" class="w-full text-left px-4 py-2 hover:bg-gray-100 font-bold text-sm sm:text-base">Logout</button>
          </form>
        </div>
      </nav>
    </div>
  </div>
</header>
<script>
const b=document.getElementById('accountBtn'),d=document.getElementById('accountDropdown');
b.onclick=()=>d.classList.toggle('hidden');
document.onclick=e=>{if(!b.contains(e.target)&&!d.contains(e.target))d.classList.add('hidden')};
</script>

<main>
<?php
$totalStudents = array_sum(array_column($students_by_department, 'total'));
$topDept = $topCount = 0;
foreach ($dropout_by_department as $d) if($d['total'] > $topCount) { $topCount = $d['total']; $topDept = $d['department_name']; }
$cards = [['title'=>'Total Students','value'=>$totalStudents,'sub'=>'All Departments','border'=>'border-blue-500','text'=>'text-blue-600']];
$cards = array_merge($cards, array_map(fn($i)=>['title'=>$i['risk_level'].' Risk','value'=>$i['COUNT(*)'],'sub'=>'Total Students','border'=>$i['risk_level']=='HIGH'?'border-red-500':'border-yellow-400','text'=>$i['risk_level']=='HIGH'?'text-red-600':'text-yellow-500'],$lowHigh));
$cards[] = ['title'=>'Highest Risk Department','value'=>$topCount,'sub'=>$topDept,'border'=>'border-red-600','text'=>'text-red-600'];
?>
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
<?php foreach($cards as $c): ?>
    <div id="sample_card" class="bg-white rounded-xl shadow-md p-6 border-1.3 border-black">
        <h3 class="text-sm font-semibold text-gray-600"><?= esc($c['title']) ?></h3>
        <p class="mt-2 text-4xl font-bold <?= $c['text'] ?>"><?= esc($c['value']) ?></p>
        <p class="text-sm text-gray-500 mt-1"><?= esc($c['sub']) ?></p>
    </div>
<?php endforeach; ?>
</div>
<div class="flex flex-col items-center mb-30 mt-20">
    <h2 class="text-xl font-semibold text-center">
        OverAll Data
    </h2>
    <span class="mt-2 h-1 w-16 bg-[#1e35a3] rounded-full"></span>
</div>
<div id="sample_Charts" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10 mt-20">
    <!-- <div id="myPieChart" class="bg-white rounded p-10 flex justify-center items-center h-64 md:h-72 lg:h-80"></div> -->
    <section id="myPieChart" class="h-auto"></section>
    <div class="bg-white rounded shadow p-4 flex justify-center items-center h-64 md:h-72 lg:h-80">
        <canvas id="deptBarChart" class="w-full h-full"></canvas>
    </div>
    <div class="bg-white rounded shadow p-4 flex justify-center items-center h-64 md:h-72 lg:h-80">
        <canvas id="incidentChart" class="w-full h-full"></canvas>
    </div>
</div>
<div class="bg-white p-4 rounded shadow mb-10 h-96 md:h-[500px] lg:h-[550px]">
    <div id="heatmap" class="w-full h-full"></div>
</div>
<script>
const incidentAnalysisData = <?php echo json_encode($incident_analysis); ?>;
const labels = incidentAnalysisData.map(i=>i.risk_level||i.department_name);
const totalIncidents = incidentAnalysisData.map(i=>i.total_incidents);
new Chart(document.getElementById('incidentChart'),{type:'bar',data:{labels,datasets:[{label:'Total Incidents',data:totalIncidents,backgroundColor:'#ecc598ff',borderColor:'#ecc598ff',borderWidth:1}]},options:{responsive:true,maintainAspectRatio:false,scales:{y:{beginAtZero:true,title:{display:true,text:'Incident Count'}},x:{title:{display:true,text:'Risk Level / Department'}}}}});
const students = <?= json_encode($students_risk_fee); ?>;
const riskScores = [...new Set(students.map(s=>s.risk_score))].sort((a,b)=>a-b);
const feeAmounts = [...new Set(students.map(s=>s.fee_due_amount))].sort((a,b)=>a-b);
const maxFee = Math.max(...students.map(s=>s.fee_due_amount));
const series = feeAmounts.map(fee=>({name:"₹"+fee,data:riskScores.map(risk=>{const s=students.find(s=>s.risk_score==risk&&s.fee_due_amount==fee);return{x:risk,y:fee,student:s?.student_name||"",fillColor:s?(fee==0?"#93ff93ff":"#FF4560"):"#FFFFFF"}})}));
new ApexCharts(document.querySelector("#heatmap"),{chart:{type:'heatmap'},series,dataLabels:{enabled:true,formatter:val=>val.student||"",style:{fontSize:'12px',colors:['#000']}},plotOptions:{heatmap:{colorScale:{ranges:[{from:0,to:0,color:"#00FF00"},{from:1,to:maxFee,color:"#FF0000"}]}}},title:{text:'Fee vs Risk Score'},xaxis:{title:{text:'Risk Score'},categories:riskScores},yaxis:{title:{text:'Fee Amount'},categories:feeAmounts.map(f=>"₹"+f)},tooltip:{y:{formatter:(val,opts)=>{const s=opts.w.config.series[opts.seriesIndex].data[opts.dataPointIndex].student||"No Student";const fee=opts.w.config.series[opts.seriesIndex].data[opts.dataPointIndex].y;const risk=opts.w.config.series[opts.seriesIndex].data[opts.dataPointIndex].x;return`Student: ${s}<br>Fee: ₹${fee}<br>Risk Score: ${risk}`}}}}).render();
const lowHighData = <?= json_encode($lowHigh); ?>;
new ApexCharts(document.querySelector("#myPieChart"),{chart:{type:'pie'},series:lowHighData.map(i=>+i["COUNT(*)"]),labels:lowHighData.map(i=>i.risk_level+" Level"),colors:['#c57012','#1e35a3'],legend:{position:'bottom'}}).render();
const deptData = <?= json_encode($dropout_by_department); ?>;
new Chart(document.getElementById('deptBarChart'),{type:'bar',data:{labels:deptData.map(d=>d.department_name),datasets:[{label:'High Risk Students',data:deptData.map(d=>+d.total),backgroundColor:'#1e35a3',borderColor:'#1e35a3',borderWidth:1}]},options:{responsive:true,maintainAspectRatio:false,scales:{y:{beginAtZero:true,title:{display:true,text:'Number of Students'}},x:{title:{display:true,text:'Department'}}},plugins:{legend:{display:true}}}});
</script>
<br><br><br><br>
<div class="flex flex-col items-center mb-6 mt-30">
    <h2 class="text-xl font-semibold text-center">
        Student Risk Predictions
    </h2>
    <span class="mt-2 h-1 w-16 bg-[#1e35a3] rounded-full"></span>
</div>
<br><br><br><br>


<div class="mb-4">
    <label for="department" class="mr-2 font-medium">Select Department:</label>
    <select id="department" class="border rounded px-2 py-1">
        <option value="">---Select---</option>
        <?php foreach($dropout_by_department as $d): ?>
            <option value="<?= esc($d['department_name']) ?>" <?= $d['department_name']==$defaultDept?'selected':'' ?>>
                <?= esc($d['department_name']) ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>

<div class="overflow-x-auto">
    <table id="riskTable" class="min-w-full border-collapse table-auto text-sm md:text-base">
        <thead class="bg-gray-100">
            <tr>
                <?php foreach(['Student ID','Student Name','Department','Attendance','Internal Marks','Fee Due','Incidents','Risk Score','Risk Level'] as $th): ?>
                    <th class="px-3 py-2 border text-left"><?= $th ?></th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach($predictions as $r): ?>
            <tr class="odd:bg-white even:bg-gray-50">
                <td class="px-3 py-2 border"><?= esc($r['roll_no']) ?></td>
                <td class="px-3 py-2 border"><?= esc($r['student_name']) ?></td>
                <td class="px-3 py-2 border"><?= esc($r['department_name']) ?></td>
                <td class="px-3 py-2 border"><?= esc($r['attendance_percentage']) ?></td>
                <td class="px-3 py-2 border"><?= esc($r['avg_internal_marks']) ?></td>
                <td class="px-3 py-2 border"><?= esc($r['fee_due_amount']) ?></td>
                <td class="px-3 py-2 border"><?= esc($r['incident_count']) ?></td>
                <td class="px-3 py-2 border"><?= esc($r['risk_score']) ?></td>
                <td class="px-3 py-2 border <?= strtolower($r['risk_level']) ?>"><?= esc($r['risk_level']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<canvas id="stackedBarChart" width="800" height="400"></canvas>

<h3 id="studentChartTitle"></h3>
<canvas id="studentChart" width="800" height="400"></canvas>
<canvas id="stackedBarChart" width="800" height="400"></canvas>

<h3 id="studentChartTitle"></h3>
<canvas id="studentChart" width="800" height="400"></canvas>

</main>
<script>
const stackedData = <?= json_encode($stacked_bar) ?>;
const labelsss = stackedData.map(d => d.department_name);
const paidData = stackedData.map(d => parseInt(d.paid_count));
const unpaidData = stackedData.map(d => parseInt(d.unpaid_count));
const ctx = document.getElementById('stackedBarChart').getContext('2d');
let studentChart = null; 
const stackedBarChart = new Chart(ctx, {
    type: 'bar',
    data: { labels: labelsss, datasets: [ { label: 'Paid', data: paidData, backgroundColor: 'rgba(75, 192, 192, 0.7)', }, { label: 'Unpaid', data: unpaidData, backgroundColor: 'rgba(255, 99, 132, 0.7)', }] },
    options: { indexAxis: 'y', responsive: true, plugins: { legend: { position: 'top' }, title: { display: true, text: 'Paid vs Unpaid Students per Department' }
        },scales: {  x: { stacked: true, beginAtZero: true },  y: { stacked: true }},
        onClick: (evt, elements) => {
            if (elements.length > 0) {
                const index = elements[0].index;
                const datasetIndex = elements[0].datasetIndex;
                const dept = stackedData[index];
                const datasetLabel = stackedBarChart.data.datasets[datasetIndex].label;
                const students = datasetLabel === 'Paid' ? dept.paid_students : dept.unpaid_students;
                showStudentChart(dept.department_name, datasetLabel, students);
}}}
});
function showStudentChart(deptName, category, students) {
    const title = document.getElementById('studentChartTitle');
    title.innerText = `${category} Students Fee Details in ${deptName}`;
    const studentCtx = document.getElementById('studentChart').getContext('2d');
if (studentChart) {
    studentChart.destroy();
    }let filteredStudents = [];
    if (category === 'Paid') {
        filteredStudents = students.filter(s => s.amount > 0); 
    }else {filteredStudents = students.filter(s => s.amount > 0);}const labels = filteredStudents.map(s => s.name);
    const data = filteredStudents.map(s => s.amount);
    studentChart = new Chart(studentCtx, {
        type: 'bar',
        data: { labels: labels, datasets: [{label: category + ' Amount',data: data,backgroundColor: category === 'Paid' ? 'rgba(75, 192, 192, 0.7)' : 'rgba(255, 99, 132, 0.7)'}]
        },options: {  indexAxis: 'y',  responsive: true,  plugins: {
                legend: { display: false },title: { display: true, text: `${category} Amount per Student in ${deptName}` }
            },scales: {  x: { beginAtZero: true },  y: { beginAtZero: true }
            }
        }});
}
</script>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
$(function() {
    const table = $('#riskTable').DataTable({ pageLength: 10 });
    $('#department').on('change', () => {
        const dept = $('#department').val();
        if (!dept) return table.clear().draw();
        $.post('getStudentsByDept', { department: dept }, res => {
            table.clear();
            res.forEach(r => table.row.add([r.roll_no,r.student_name,r.department_name,r.attendance_percentage,r.avg_internal_marks,r.fee_due_amount,r.incident_count,r.risk_score,
                `<span class="${r.risk_level.toLowerCase()}">${r.risk_level}</span>`
            ]));
            table.draw();}, 'json');});});
</script>

</body>
</html>