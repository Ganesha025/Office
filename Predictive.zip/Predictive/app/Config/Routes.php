<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'RiskPredictionController::index');
   // Route for AJAX fetching students by department
    $routes->post('getStudentsByDept', 'RiskPredictionController::getStudentsByDept');

// Optional: make risk dashboard the default page
// $routes->get('/dashboard', 'RiskPredictionController::index');

// Risk module routes
$routes->group('risk', function ($routes) {
    $routes->get('predict', 'RiskPredictionController::run');
});
