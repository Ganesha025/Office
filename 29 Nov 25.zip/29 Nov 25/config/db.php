<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "school_erp";

$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if(!$conn->query("CREATE DATABASE IF NOT EXISTS $dbname CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci")) die("DB Error: " . $conn->error);
$conn->select_db($dbname);

function safeQuery($conn, $sql){
    $result = $conn->query($sql);
    if($result === false) die("DB Error: ".$conn->error."<br>SQL: $sql");
    return $result;
}

// STUDENTS TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    roll_no INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    class INT NOT NULL,
    section VARCHAR(5) NOT NULL,
    email VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB");

// STAFF TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS staff (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    base_salary DECIMAL(10,2) DEFAULT 0,
    allowance DECIMAL(10,2) DEFAULT 0,
    deduction DECIMAL(10,2) DEFAULT 0,
    email VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB");

// SUBJECTS TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
) ENGINE=InnoDB");

// STUDENT_SUBJECTS TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS student_subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject_name VARCHAR(255) NOT NULL
) ENGINE=InnoDB");

// GRADES TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS grades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    average DECIMAL(5,2) DEFAULT 0,
    grade VARCHAR(2) DEFAULT ''
) ENGINE=InnoDB");

// ATTENDANCE TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    date DATE NOT NULL,
    status ENUM('P','A') NOT NULL
) ENGINE=InnoDB");

// TIMETABLE TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS timetable (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class INT NOT NULL,
    section VARCHAR(5) NOT NULL,
    day VARCHAR(20) NOT NULL,
    period VARCHAR(20) NOT NULL,
    subject VARCHAR(255) NOT NULL
) ENGINE=InnoDB");

// LIBRARY BOOKS TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS library_books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL
) ENGINE=InnoDB");

// ISSUED BOOKS TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS issued_books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    book_id INT NOT NULL,
    due_day INT NOT NULL,
    return_day INT NOT NULL,
    fine DECIMAL(10,2) DEFAULT 0
) ENGINE=InnoDB");

// HOLIDAYS TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS holidays (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    date DATE NOT NULL
) ENGINE=InnoDB");

// ADMIN TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
) ENGINE=InnoDB");

// FEEDBACK TABLE
safeQuery($conn, "CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    feedback TEXT NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB");

// DEFAULT ADMIN INSERT
$default_admin_email = "ModernAdmin@gmail.com";
$default_admin_pass = password_hash("S@vage#123", PASSWORD_DEFAULT);
$check = $conn->query("SELECT id FROM admin WHERE email='$default_admin_email'");
if($check && $check->num_rows == 0){
    safeQuery($conn, "INSERT INTO admin (email,password) VALUES ('$default_admin_email','$default_admin_pass')");
}

// DEFAULT SUBJECTS INSERT
$subjects_list = ['Math','English','Science','History','Geography','Computer','Physics','Chemistry'];
foreach($subjects_list as $sub){
    $check = $conn->query("SELECT id FROM subjects WHERE name='$sub'");
    if($check && $check->num_rows == 0){
        safeQuery($conn, "INSERT INTO subjects (name) VALUES ('$sub')");
    }
}
?>
