school_erp/
│
├── index.php                  <-- Login page (Admin/Student)
├── config/
│   └── db.php                 <-- Database connection
├── templates/
│   ├── header.php
│   └── footer.php
│
├── admin/                     <-- Admin module
│   ├── dashboard.php          <-- Admin main dashboard
│   ├── manage_students.php    <-- Add/Edit/Delete students (with class & section)
│   ├── manage_staff.php       <-- Add/Edit/Delete staff
│   ├── attendance.php         <-- Record/update attendance per class/section
│   ├── grades.php             <-- Assign grades per student & subject
│   ├── subjects.php           <-- Assign subjects per class/section
│   ├── timetable.php          <-- Create/edit timetable per class
│   ├── salary.php             <-- Staff salary calculation
│   ├── holidays.php           <-- Holiday calendar management
│   └── reports.php            <-- Generate reports per class/student
│   <!-- All functions embedded directly in these files -->
│
├── student/                   <-- Student module (view-only)
│   ├── dashboard.php          <-- Student dashboard
│   ├── profile.php            <-- View profile
│   ├── attendance.php         <-- View own attendance
│   ├── grades.php             <-- View own grades
│   ├── timetable.php          <-- View timetable for their class
│   ├── feedback.php           <-- Submit/view feedback
│   ├── sms.php                <-- View SMS notifications
│   └── fine.php               <-- View library fines
│   <!-- Functions embedded, read-only -->
│
├── css/
│   └── style.css
├── js/
│   └── script.js
└── README.md
