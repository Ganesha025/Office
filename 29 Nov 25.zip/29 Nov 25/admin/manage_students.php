<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}

require "../config/db.php";

function generateStudentID($conn){
    $prefix = "STD";
    $year = date('Y');
    $row = $conn->query("SELECT student_id FROM students ORDER BY id DESC LIMIT 1")->fetch_assoc();
    if($row && !empty($row['student_id'])){
        $lastNum = intval(substr($row['student_id'], 7));
        $next = $lastNum + 1;
    } else {
        $next = 1;
    }
    return $prefix . $year . str_pad($next, 3, '0', STR_PAD_LEFT);
}

$emailSent = false;
$emailTo = '';
$studentName = '';

if(isset($_POST['add_student'])){
    $name = trim($_POST['name']);
    $roll_no = trim($_POST['roll_no']);
    $class = trim($_POST['class']);
    $section = trim($_POST['section']);
    $dob = $_POST['dob'];
    $email = trim($_POST['email']);
    $mobile = trim($_POST['mobile']);
    $student_id = generateStudentID($conn);

    $check = $conn->prepare("SELECT id FROM students WHERE class=? AND section=? AND roll_no=?");
    $check->bind_param("ssi", $class, $section, $roll_no);
    $check->execute();
    $check->store_result();

    if($check->num_rows > 0){
        echo "<script>alert('Roll number already exists in this class and section!');</script>";
    } else if (!preg_match('/^[A-Za-z0-9._%+-]+@gmail\.com$/', $email)) {
        echo "<script>alert('Only @gmail.com email addresses are allowed.');</script>";
    } else {
        $stmt = $conn->prepare("INSERT INTO students (student_id, name, roll_no, class, section, dob, email, mobile) VALUES (?,?,?,?,?,?,?,?)");
        $stmt->bind_param("ssiissss", $student_id, $name, $roll_no, $class, $section, $dob, $email, $mobile);
        if($stmt->execute()){
            $emailSent = true;
            $emailTo = $email;
            $studentName = $name;
        } else {
            echo "<script>alert('Error: ".$stmt->error."');</script>";
        }
    }
}

if(isset($_POST['update_student'])){
    $id = intval($_POST['id']);
    $name = trim($_POST['name']);
    $roll_no = trim($_POST['roll_no']);
    $class = trim($_POST['class']);
    $section = trim($_POST['section']);
    $dob = $_POST['dob'];
    $email = trim($_POST['email']);
    $mobile = trim($_POST['mobile']);

    $check = $conn->prepare("SELECT id FROM students WHERE class=? AND section=? AND roll_no=? AND id!=?");
    $check->bind_param("ssii", $class, $section, $roll_no, $id);
    $check->execute();
    $check->store_result();

    if($check->num_rows > 0){
        echo "<script>alert('Roll number already exists in this class and section!');</script>";
    } else {
        $stmt = $conn->prepare("UPDATE students SET name=?, roll_no=?, class=?, section=?, dob=?, email=?, mobile=? WHERE id=?");
        $stmt->bind_param("ssiisssi", $name, $roll_no, $class, $section, $dob, $email, $mobile, $id);
        if($stmt->execute()){
            $emailSent = true;
            $emailTo = $email;
            $studentName = $name;
        }
    }
}

if(isset($_GET['delete_id'])){
    $id = intval($_GET['delete_id']);
    $conn->query("DELETE FROM students WHERE id=$id");
    header("Location: manage_students.php");
    exit;
}

$editData = null;
if(isset($_GET['edit_id'])){
    $eid = intval($_GET['edit_id']);
    $editData = $conn->query("SELECT * FROM students WHERE id=$eid")->fetch_assoc();
}

$students = $conn->query("SELECT * FROM students ORDER BY class ASC, section ASC, roll_no ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Students - Admin</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
body{font-family:'Inter',sans-serif;}
</style>
<script>
(function(){
    emailjs.init("JOI7aiTqIdULejz3K");
})();

function sendMail(email, name, action) {
    emailjs.send("service_btk93pf", "template_u9vblac", {
        name: name,
        title: "Student " + action,
        email: email,
        message: "Your student record has been " + action.toLowerCase() + " successfully."
    }).then(function(response) {
        spawnUniquePopup("Success",'Student ' + action.toLowerCase() + ' successfully and email notification sent!');
        window.location.href = 'manage_students.php';
    }, function(error) {
        spawnUniquePopup("Success",'Student ' + action.toLowerCase() + ' successfully but email notification failed.');
        window.location.href = 'manage_students.php';
    });
}

<?php if($emailSent): ?>
window.onload = function() {
    sendMail('<?php echo addslashes($emailTo); ?>', '<?php echo addslashes($studentName); ?>', '<?php echo isset($_POST['add_student']) ? "Added" : "Updated"; ?>');
};
<?php endif; ?>
</script>
<link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-gray-50 min-h-screen">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>

<?php include '../templates/header.php'?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 mb-8">
        <div class="px-6 py-4 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900"><?php echo $editData ? 'Edit Student' : 'Add New Student'; ?></h2>
        </div>
        
        <form method="POST" class="p-6">
            <?php if($editData): ?>
            <input type="hidden" name="id" value="<?php echo $editData['id']; ?>">
            <?php endif; ?>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
        <input type="text" id="FocusInput" name="name" placeholder="Enter full name" 
        class="val-username w-full px-4 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
        value="<?php echo $editData ? $editData['name'] : ''; ?>" required>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Roll Number</label>
        <input type="number" name="roll_no" placeholder="Enter roll number"
        class="val-mark w-full px-4 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
        value="<?php echo $editData ? $editData['roll_no'] : ''; ?>" required>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Class</label>
        <select name="class"
        class="w-full px-4 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all bg-white" required>
            <?php if(!$editData): ?>
            <option value="" disabled selected>Select class</option>
            <?php endif; ?>
            <?php for($i=1;$i<=12;$i++): ?>
                <option value="<?php echo $i; ?>" <?php if($editData && $editData['class']==$i) echo 'selected'; ?>><?php echo $i; ?></option>
            <?php endfor; ?>
        </select>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Section</label>
        <select name="section"
        class="w-full px-4 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all bg-white" required>
            <?php if(!$editData): ?>
            <option value="" disabled selected>Select section</option>
            <?php endif; ?>
            <?php foreach(['A','B','C','D'] as $sec): ?>
                <option value="<?php echo $sec; ?>" <?php if($editData && $editData['section']==$sec) echo 'selected'; ?>><?php echo $sec; ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Date of Birth</label>
        <input type="date" name="dob" placeholder="Select date of birth"
        class="val-dobs w-full px-4 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
        value="<?php echo $editData ? $editData['dob'] : ''; ?>" required>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
        <input type="email" name="email" placeholder="Enter email address"
        class="val-email w-full px-4 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
        value="<?php echo $editData ? $editData['email'] : ''; ?>">
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Mobile Number</label>
        <input type="text" name="mobile" placeholder="Enter mobile number"
        class="val-mobile w-full px-4 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
        value="<?php echo $editData ? $editData['mobile'] : ''; ?>" required>
    </div>

</div>

            
            <div class="mt-6 flex items-center justify-end space-x-3">
                <?php if($editData): ?>
                <a href="manage_students.php" class="px-5 py-2.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 transition-colors">Cancel</a>
                <input type="submit" name="update_student" value="Update Student" class="px-5 py-2.5 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 transition-colors cursor-pointer">
                <?php else: ?>
                <input type="submit" name="add_student" value="Add Student" class="px-5 py-2.5 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 transition-colors cursor-pointer">
                <?php endif; ?>
            </div>
        </form>
    </div>

    <div class="bg-white rounded-lg shadow-sm border border-gray-200">
        <div class="px-6 py-4 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900">Student Records</h2>
        </div>
        
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Roll No</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Section</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">DOB</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mobile</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php while($row = $students->fetch_assoc()): ?>
                    <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo $row['student_id']; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo $row['name']; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo $row['roll_no']; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo $row['class']; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo $row['section']; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo $row['dob']; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo $row['email']; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo $row['mobile']; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                            <a href="manage_students.php?edit_id=<?php echo $row['id']; ?>" class="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                                <svg class="w-3.5 h-3.5 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                Edit
                            </a>
                            <a href="manage_students.php?delete_id=<?php echo $row['id']; ?>" onclick="return confirm('Delete this student?')" class="inline-flex items-center px-3 py-1.5 border border-red-300 text-xs font-medium rounded text-red-700 bg-white hover:bg-red-50 transition-colors">
                                <svg class="w-3.5 h-3.5 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                Delete
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php include "../templates/footer.php"?>
<script src="./valid.js"></script>
<script>
    $(document).ready(function(){
    $("#FocusInput").focus();

    })
</script>
</body>
</html>