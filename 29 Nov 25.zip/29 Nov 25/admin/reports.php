<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}
require "../config/db.php";

$classes = [];
$result = $conn->query("SELECT DISTINCT class FROM students ORDER BY class ASC");
while($row = $result->fetch_assoc()){
    $classes[] = $row['class'];
}
$sections = ['A','B','C','D'];

$students = [];
$selected_class = $_POST['class'] ?? '';
$selected_section = $_POST['section'] ?? '';

if($selected_class && $selected_section){
    $stmt = $conn->prepare("SELECT * FROM students WHERE class=? AND section=? ORDER BY roll_no ASC");
    $stmt->bind_param("is", $selected_class, $selected_section);
    $stmt->execute();
    $students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getAttendancePercentage($conn, $student_id){
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM attendance WHERE student_id=?");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $total = $res['total'] ?? 0;

    $stmt = $conn->prepare("SELECT COUNT(*) as present FROM attendance WHERE student_id=? AND status='P'");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $present = $res['present'] ?? 0;

    if($total==0) return 0;
    return round(($present/$total)*100,2);
}

function getAverageGrade($conn, $student_id){
    $stmt = $conn->prepare("SELECT marks FROM grades WHERE student_id=?");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $marks = [];
    while($row = $res->fetch_assoc()){
        $marks[] = $row['marks'];
    }
    if(count($marks)==0) return ['average'=>0,'grade'=>'N/A'];
    $average = array_sum($marks)/count($marks);
    if($average > 90) $g = 'A';
    elseif($average >= 80) $g = 'B';
    elseif($average >= 70) $g = 'C';
    elseif($average >= 60) $g = 'D';
    else $g = 'F';
    return ['average'=>round($average,2), 'grade'=>$g];
}

function getSubjects($conn, $student_id){
    $stmt = $conn->prepare("SELECT s.name FROM grades g JOIN subjects s ON g.subject_id=s.id WHERE g.student_id=?");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $subs = [];
    while($row = $res->fetch_assoc()){
        $subs[] = $row['name'];
    }
    return implode(", ", $subs);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Reports - Admin</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
* { font-family: 'Inter', sans-serif; }
body { background: #f8fafc; }
.material-icons { vertical-align: middle; }
</style>
</head>
<body class="min-h-screen">
<?php include "../templates/header.php"?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
<div class="mb-8">
<div class="flex items-center gap-3 mb-2">
<span class="material-icons text-3xl text-slate-700">assessment</span>
<h1 class="text-3xl font-semibold text-slate-800">Student Reports</h1>
</div>
<p class="text-slate-600 ml-11">Generate comprehensive academic performance reports</p>
</div>

<div class="bg-white rounded-lg shadow-sm border border-slate-200 p-6 mb-6">
<form method="POST" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 items-end">
<div>
<label class="block text-sm font-medium text-slate-700 mb-2">
<span class="material-icons text-sm">school</span> Class
</label>
<select name="class" required class="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-white text-slate-700">
<option value="">Select Class</option>
<?php foreach($classes as $c): ?>
<option value="<?php echo $c; ?>" <?php if($selected_class==$c) echo 'selected'; ?>><?php echo $c; ?></option>
<?php endforeach; ?>
</select>
</div>

<div>
<label class="block text-sm font-medium text-slate-700 mb-2">
<span class="material-icons text-sm">class</span> Section
</label>
<select name="section" required class="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-white text-slate-700">
<option value="">Select Section</option>
<?php foreach($sections as $s): ?>
<option value="<?php echo $s; ?>" <?php if($selected_section==$s) echo 'selected'; ?>><?php echo $s; ?></option>
<?php endforeach; ?>
</select>
</div>

<div>
<button type="submit" name="filter_students" class="w-full px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors flex items-center justify-center gap-2">
<span class="material-icons text-sm">search</span>
Generate Report
</button>
</div>
</form>
</div>

<?php if($students): ?>
<div class="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
<div class="overflow-x-auto">
<table class="w-full">
<thead>
<tr class="bg-slate-50 border-b border-slate-200">
<th class="px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Roll No</th>
<th class="px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Student Name</th>
<th class="px-6 py-4 text-center text-xs font-semibold text-slate-700 uppercase tracking-wider">Attendance</th>
<th class="px-6 py-4 text-center text-xs font-semibold text-slate-700 uppercase tracking-wider">Average</th>
<th class="px-6 py-4 text-center text-xs font-semibold text-slate-700 uppercase tracking-wider">Grade</th>
<th class="px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Subjects</th>
</tr>
</thead>
<tbody class="divide-y divide-slate-200">
<?php foreach($students as $stu): 
$attendance = getAttendancePercentage($conn, $stu['id']);
$grade = getAverageGrade($conn, $stu['id']);
$subjects = getSubjects($conn, $stu['id']);
$attendanceColor = $attendance >= 75 ? 'text-green-600 bg-green-50' : ($attendance >= 50 ? 'text-yellow-600 bg-yellow-50' : 'text-red-600 bg-red-50');
$gradeColor = in_array($grade['grade'], ['A','B']) ? 'text-green-700 bg-green-100' : (in_array($grade['grade'], ['C','D']) ? 'text-yellow-700 bg-yellow-100' : 'text-red-700 bg-red-100');
?>
<tr class="hover:bg-slate-50 transition-colors">
<td class="px-6 py-4 text-sm font-medium text-slate-900"><?php echo $stu['roll_no']; ?></td>
<td class="px-6 py-4 text-sm text-slate-700"><?php echo htmlspecialchars($stu['name']); ?></td>
<td class="px-6 py-4 text-center">
<span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium <?php echo $attendanceColor; ?>">
<?php echo $attendance; ?>%
</span>
</td>
<td class="px-6 py-4 text-center text-sm font-medium text-slate-900"><?php echo $grade['average']; ?></td>
<td class="px-6 py-4 text-center">
<span class="inline-flex items-center justify-center w-10 h-10 rounded-lg text-sm font-bold <?php echo $gradeColor; ?>">
<?php echo $grade['grade']; ?>
</span>
</td>
<td class="px-6 py-4 text-sm text-slate-600"><?php echo $subjects; ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>

<div class="px-6 py-4 bg-slate-50 border-t border-slate-200 text-sm text-slate-600">
<span class="material-icons text-sm">info</span>
Showing <?php echo count($students); ?> student(s) from Class <?php echo $selected_class; ?> Section <?php echo $selected_section; ?>
</div>
</div>
<?php endif; ?>

<div class="mt-6">
</div>
</div>

<?php include "../templates/footer.php"?>
<script src="./valid.js"></script>
</body>
</html>