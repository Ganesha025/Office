<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}

require "../config/db.php";

function calculateFine($due_day, $return_day) {
    $fine_per_day = 2;
    if($return_day <= $due_day) return 0;
    return ($return_day - $due_day) * $fine_per_day;
}

if(isset($_POST['add_book'])){
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $conn->query("INSERT INTO library_books (title, author) VALUES ('$title', '$author')");
    echo "<script>alert('Book added successfully'); window.location.href='library.php';</script>";
}

if(isset($_POST['issue_book'])){
    $student_id = intval($_POST['student_id']);
    $book_id = intval($_POST['book_id']);
    $due_day = intval($_POST['due_day']);
    $return_day = intval($_POST['return_day']);
    $fine = calculateFine($due_day, $return_day);

    $stmt = $conn->prepare("INSERT INTO issued_books (student_id, book_id, due_day, return_day, fine) VALUES (?,?,?,?,?)");
    $stmt->bind_param("iiiii", $student_id, $book_id, $due_day, $return_day, $fine);
    $stmt->execute();

    echo "<script>alert('Book issued successfully. Fine: ₹$fine'); window.location.href='library.php';</script>";
}

if(isset($_POST['update_issued'])){
    foreach($_POST['id'] as $i => $id){
        $due_day = intval($_POST['due_day'][$i]);
        $return_day = intval($_POST['return_day'][$i]);
        $fine = calculateFine($due_day, $return_day);
        $stmt = $conn->prepare("UPDATE issued_books SET due_day=?, return_day=?, fine=? WHERE id=?");
        $stmt->bind_param("iiii", $due_day, $return_day, $fine, $id);
        $stmt->execute();
    }
    echo "<script>alert('Issued books updated successfully'); window.location.href='library.php';</script>";
}

$books = $conn->query("SELECT * FROM library_books ORDER BY id DESC");
$students = $conn->query("SELECT * FROM students ORDER BY class ASC, roll_no ASC");
$issued = $conn->query("SELECT ib.*, s.name AS student_name, lb.title AS book_title 
                        FROM issued_books ib
                        JOIN students s ON ib.student_id = s.id
                        JOIN library_books lb ON ib.book_id = lb.id
                        ORDER BY ib.id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library Management - Admin</title>
<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
* { font-family: 'Inter', sans-serif; }
body { background: #f8f9fa; }
.card-shadow { box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
.card-shadow:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.1); transition: all 0.3s ease; }
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button { opacity: 1; }
</style>
</head>
<body class="bg-gray-50">

<?php include "../templates/header.php"?>

<div class="min-h-screen py-6 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto">
        

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            
            <div class="bg-white rounded-xl card-shadow border border-gray-200">
                <div class="border-b border-gray-200 px-6 py-4 bg-gray-50 rounded-t-xl">
                    <h2 class="text-lg font-semibold text-gray-800 flex items-center gap-2">
                        <span class="material-icons text-green-600">add_circle</span>
                        Add New Book
                    </h2>
                </div>
                <form method="POST" class="p-6 space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Book Title</label>
                        <input type="text" name="title" placeholder="Enter book title" id="FocusInput" required 
                               class="val-com-name w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Author Name</label>
                        <input type="text" name="author" placeholder="Enter author name" required 
                               class="val-username w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm">
                    </div>
                    <button type="submit" name="add_book" 
                            class="val-com-name w-full inline-flex items-center justify-center gap-2 px-5 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium text-sm">
                        <span class="material-icons text-lg">library_add</span>
                        Add Book to Library
                    </button>
                </form>
            </div>

            <div class="bg-white rounded-xl card-shadow border border-gray-200">
                <div class="border-b border-gray-200 px-6 py-4 bg-gray-50 rounded-t-xl">
                    <h2 class="text-lg font-semibold text-gray-800 flex items-center gap-2">
                        <span class="material-icons text-blue-600">assignment</span>
                        Issue Book to Student
                    </h2>
                </div>
                <form method="POST" class="p-6 space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-1">
                            <span class="material-icons text-lg">person</span>
                            Select Student
                        </label>
                        <select name="student_id" required 
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm bg-white">
                            <option value="">-- Choose a student --</option>
                            <?php while($stu = $students->fetch_assoc()): ?>
                            <option value="<?php echo $stu['id']; ?>">
                                Class <?php echo $stu['class']."-".$stu['section']." | ".$stu['name']." (Roll ".$stu['roll_no'].")"; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-1">
                            <span class="material-icons text-lg">menu_book</span>
                            Select Book
                        </label>
                        <select name="book_id" required 
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm bg-white">
                            <option value="">-- Choose a book --</option>
                            <?php $books->data_seek(0); while($book = $books->fetch_assoc()): ?>
                            <option value="<?php echo $book['id']; ?>"><?php echo $book['title']." by ".$book['author']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Due Day</label>
                            <input type="number" name="due_day" required placeholder="10" 
                                   class="val-mark w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm">
                            <span></span>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Return Day</label>
                            <input type="number" name="return_day" required placeholder="15" 
                                   class="val-mark w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm">
                            <span></span>
                        </div>
                    </div>

                    <button type="submit" name="issue_book" 
                            class="w-full inline-flex items-center justify-center gap-2 px-5 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm">
                        <span class="material-icons text-lg">assignment_turned_in</span>
                        Issue Book
                    </button>
                    <span></span>
                </form>
            </div>
        </div>

        <div class="bg-white rounded-xl card-shadow border border-gray-200">
            <div class="border-b border-gray-200 px-6 py-4 bg-gray-50 rounded-t-xl">
                <h2 class="text-lg font-semibold text-gray-800 flex items-center gap-2">
                    <span class="material-icons text-orange-600">list_alt</span>
                    Issued Books Records
                </h2>
            </div>
            <form method="POST">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="bg-gray-50 border-b border-gray-200">
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">ID</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Student Name</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Book Title</th>
                                <th class="px-6 py-4 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">Due Day</th>
                                <th class="px-6 py-4 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">Return Day</th>
                                <th class="px-6 py-4 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">Fine (₹)</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php while($row = $issued->fetch_assoc()): ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="px-6 py-4 text-sm font-medium text-gray-900">
                                    <input type="hidden" name="id[]" value="<?php echo $row['id']; ?>">
                                    #<?php echo $row['id']; ?>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-700">
                                    <div class="flex items-center gap-2">
                                        <span class="material-icons text-gray-400 text-lg">person</span>
                                        <?php echo htmlspecialchars($row['student_name']); ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-700">
                                    <div class="flex items-center gap-2">
                                        <span class="material-icons text-gray-400 text-lg">book</span>
                                        <?php echo htmlspecialchars($row['book_title']); ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <input type="number" name="due_day[]" value="<?php echo $row['due_day']; ?>" 
                                           class="val-mark w-20 px-3 py-1.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none text-sm text-center">
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <input type="number" name="return_day[]" value="<?php echo $row['return_day']; ?>" 
                                           class="val-mark w-20 px-3 py-1.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none text-sm text-center">
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium <?php echo $row['fine'] > 0 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                                        ₹<?php echo $row['fine']; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <div class="px-6 py-4 bg-gray-50 border-t border-gray-200 rounded-b-xl">
                    <button type="submit" name="update_issued" 
                            class="inline-flex items-center gap-2 px-6 py-2.5 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-medium text-sm">
                        <span class="material-icons text-lg">update</span>
                        Update All Records
                    </button>
                </div>
            </form>
        </div>

    </div>
</div>

<?php include "../templates/footer.php"?>
<script src="./valid.js"></script>
<script>
    $(document).ready(function(){
    $("#FocusInput").focus();

    })
</script>
</body>
</html>