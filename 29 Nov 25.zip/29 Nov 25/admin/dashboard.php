<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}
require "../config/db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - School ERP</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        *{font-family:'Inter',sans-serif}body{background:#f8fafc;min-height:100vh}
        .glass{backdrop-filter:blur(20px);background:rgba(255,255,255,0.9);border:1px solid rgba(0,0,0,0.05);box-shadow:0 8px 32px rgba(0,0,0,0.1)}
        .card-hover{transform:translateY(-8px);box-shadow:0 25px 50px -12px rgba(0,0,0,0.15)}
        @keyframes float{0%,100%{transform:translateY(0px)}50%{transform:translateY(-10px)}}
        .float{animation:float 6s ease-in-out infinite}
    </style>
</head>
<body class="min-h-screen p-4 sm:p-8">
    <?php include '../templates/header.php';?>

    <main class="max-w-7xl mx-auto">
        <div class="text-center mb-16">
            <h1 class="text-5xl sm:text-6xl lg:text-7xl font-bold text-gray-900 mb-4 drop-shadow-2xl">School ERP</h1>
            <p class="text-xl text-gray-600 font-medium max-w-2xl mx-auto leading-relaxed">Modern admin dashboard for seamless school management</p>
        </div>

        <div class="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6">
            <a href="manage_students.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-blue-50/50">
                <div class="w-16 h-16 bg-blue-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-blue-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-blue-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Students</h3>
                <p class="text-gray-600 text-sm font-medium">Manage records</p>
            </a>

            <a href="manage_staff.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-emerald-50/50">
                <div class="w-16 h-16 bg-emerald-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-emerald-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-emerald-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Staff</h3>
                <p class="text-gray-600 text-sm font-medium">Manage members</p>
            </a>

            <a href="attendance.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-purple-50/50">
                <div class="w-16 h-16 bg-purple-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-purple-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-purple-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Attendance</h3>
                <p class="text-gray-600 text-sm font-medium">Track presence</p>
            </a>

            <a href="grades.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-amber-50/50">
                <div class="w-16 h-16 bg-amber-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-amber-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-amber-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Grades</h3>
                <p class="text-gray-600 text-sm font-medium">Performance data</p>
            </a>

            <a href="subjects.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-rose-50/50">
                <div class="w-16 h-16 bg-rose-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-rose-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-rose-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Subjects</h3>
                <p class="text-gray-600 text-sm font-medium">Curriculum mgmt</p>
            </a>

            <a href="timetable.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-indigo-50/50">
                <div class="w-16 h-16 bg-indigo-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-indigo-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-indigo-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Timetable</h3>
                <p class="text-gray-600 text-sm font-medium">Class schedules</p>
            </a>

            <a href="library.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-teal-50/50">
                <div class="w-16 h-16 bg-teal-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-teal-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-teal-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Library</h3>
                <p class="text-gray-600 text-sm font-medium">Book management</p>
            </a>

            <a href="holidays.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-pink-50/50">
                <div class="w-16 h-16 bg-pink-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-pink-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-pink-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Holidays</h3>
                <p class="text-gray-600 text-sm font-medium">Calendar events</p>
            </a>

            <a href="reports.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-orange-50/50">
                <div class="w-16 h-16 bg-orange-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-orange-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-orange-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Reports</h3>
                <p class="text-gray-600 text-sm font-medium">Analytics data</p>
            </a>

            <a href="email.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-cyan-50/50">
                <div class="w-16 h-16 bg-cyan-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-cyan-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-cyan-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Emails</h3>
                <p class="text-gray-600 text-sm font-medium">Communication</p>
            </a>

            <a href="salary.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-emerald-50/50">
                <div class="w-16 h-16 bg-emerald-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-emerald-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-emerald-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Salary</h3>
                <p class="text-gray-600 text-sm font-medium">Payroll system</p>
            </a>

            <a href="feedback.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-violet-50/50">
                <div class="w-16 h-16 bg-violet-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-violet-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-violet-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Feedback</h3>
                <p class="text-gray-600 text-sm font-medium">User reviews</p>
            </a>

            <a href="credient.php" class="group glass rounded-3xl p-8 text-center transition-all duration-500 hover:card-hover hover:scale-105 float relative overflow-hidden bg-slate-50/50">
                <div class="w-16 h-16 bg-slate-100/80 backdrop-blur-xl rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-slate-200/70 transition-all duration-500">
                    <svg class="w-8 h-8 text-slate-600 drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2 drop-shadow-lg">Credentials</h3>
                <p class="text-gray-600 text-sm font-medium">Access control</p>
            </a>
        </div>
    </main>

    <?php include '../templates/footer.php';?>
</body>
</html>
