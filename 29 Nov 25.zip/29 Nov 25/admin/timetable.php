<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}

require "../config/db.php";

$days = ['Monday','Tuesday','Wednesday','Thursday','Friday'];
$periods = ['Period 1','Period 2','Period 3','Period 4','Period 5','Period 6'];

$classes = [];
$res = $conn->query("SELECT DISTINCT class FROM students ORDER BY class ASC");
while($row = $res->fetch_assoc()){
    $classes[] = $row['class'];
}

$subjects = [];
$res = $conn->query("SELECT name FROM subjects ORDER BY name ASC");
while($row = $res->fetch_assoc()){
    $subjects[] = $row['name'];
}

$selected_class = $_POST['class'] ?? '';
$selected_section = $_POST['section'] ?? '';
$sections = ['A','B','C','D'];

if(isset($_POST['save_timetable'])){
    $tt_data = $_POST['timetable'];

    $conn->query("DELETE FROM timetable WHERE class=$selected_class AND section='$selected_section'");

    foreach($tt_data as $day => $periods_arr){
        foreach($periods_arr as $period => $subject){
            $stmt = $conn->prepare("INSERT INTO timetable (class, section, day, period, subject) VALUES (?,?,?,?,?)");
            $stmt->bind_param("issss", $selected_class, $selected_section, $day, $period, $subject);
            $stmt->execute();
        }
    }
    echo "<script>alert('Timetable saved successfully');</script>";
}

$existing_tt = [];
if($selected_class && $selected_section){
    $res = $conn->query("SELECT * FROM timetable WHERE class=$selected_class AND section='$selected_section'");
    while($row = $res->fetch_assoc()){
        $existing_tt[$row['day']][$row['period']] = $row['subject'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class Timetable - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        body {
            background: #f8fafc;
        }
        .select-custom {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236b7280'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 1.25rem;
            padding-right: 2.5rem;
        }
        .table-cell-select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236b7280'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 0.5rem center;
            background-size: 1rem;
            padding-right: 2rem;
        }
    </style>
</head>
<body class="bg-slate-50">
<?php include "../templates/header.php"?>

<div class="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto">
        

        <div class="bg-white rounded-xl shadow-sm border border-slate-200 mb-6">
            <div class="px-6 py-4 border-b border-slate-200">
                <div class="flex items-center">
                    <span class="material-icons text-slate-700 mr-2">filter_alt</span>
                    <h2 class="text-lg font-semibold text-slate-900">Select Class & Section</h2>
                </div>
            </div>
            <div class="p-6">
                <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-2">
                            <span class="flex items-center">
                                <span class="material-icons text-sm mr-1">school</span>
                                Class
                            </span>
                        </label>
                        <select name="class" required onchange="this.form.submit()" class="select-custom w-full px-4 py-3 bg-white border border-slate-300 rounded-lg text-slate-900 focus:ring-2 focus:ring-slate-500 focus:border-transparent transition-all duration-200">
                            <option value="">Select Class</option>
                            <?php foreach($classes as $c): ?>
                            <option value="<?php echo $c; ?>" <?php if($selected_class==$c) echo 'selected'; ?>>Class <?php echo $c; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-2">
                            <span class="flex items-center">
                                <span class="material-icons text-sm mr-1">group</span>
                                Section
                            </span>
                        </label>
                        <select name="section" required onchange="this.form.submit()" class="select-custom w-full px-4 py-3 bg-white border border-slate-300 rounded-lg text-slate-900 focus:ring-2 focus:ring-slate-500 focus:border-transparent transition-all duration-200">
                            <option value="">Select Section</option>
                            <?php foreach($sections as $s): ?>
                            <option value="<?php echo $s; ?>" <?php if($selected_section==$s) echo 'selected'; ?>>Section <?php echo $s; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>
            </div>
        </div>

        <?php if($selected_class && $selected_section): ?>
        <div class="bg-white rounded-xl shadow-sm border border-slate-200">
            <div class="px-6 py-4 border-b border-slate-200 bg-slate-50">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <span class="material-icons text-slate-700 mr-2">calendar_month</span>
                        <h2 class="text-lg font-semibold text-slate-900">Weekly Schedule - Class <?php echo $selected_class; ?> Section <?php echo $selected_section; ?></h2>
                    </div>
                    <div class="flex items-center text-sm text-slate-600">
                        <span class="material-icons text-sm mr-1">info</span>
                        <span>Configure subjects for each period</span>
                    </div>
                </div>
            </div>
            
            <div class="p-6">
                <form method="POST">
                    <input type="hidden" name="class" value="<?php echo $selected_class; ?>">
                    <input type="hidden" name="section" value="<?php echo $selected_section; ?>">

                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse">
                            <thead>
                                <tr class="bg-slate-800">
                                    <th class="px-4 py-4 text-left text-xs font-semibold text-white uppercase tracking-wider border border-slate-700">
                                        <div class="flex items-center">
                                            <span class="material-icons text-sm mr-2">today</span>
                                            Day / Period
                                        </div>
                                    </th>
                                    <?php foreach($periods as $p): ?>
                                    <th class="px-4 py-4 text-center text-xs font-semibold text-white uppercase tracking-wider border border-slate-700">
                                        <div class="flex items-center justify-center">
                                            <span class="material-icons text-sm mr-1">schedule</span>
                                            <?php echo $p; ?>
                                        </div>
                                    </th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody class="bg-white">
                                <?php foreach($days as $index => $day): ?>
                                <tr class="<?php echo $index % 2 == 0 ? 'bg-white' : 'bg-slate-50'; ?> hover:bg-slate-100 transition-colors duration-150">
                                    <td class="px-4 py-3 whitespace-nowrap text-sm font-medium text-slate-900 border border-slate-200">
                                        <div class="flex items-center">
                                            <span class="material-icons text-sm mr-2 text-slate-600">event</span>
                                            <?php echo $day; ?>
                                        </div>
                                    </td>
                                    <?php foreach($periods as $p): ?>
                                    <td class="px-3 py-3 border border-slate-200">
                                        <select name="timetable[<?php echo $day; ?>][<?php echo $p; ?>]" required class="table-cell-select w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md text-slate-900 focus:ring-2 focus:ring-slate-500 focus:border-transparent transition-all duration-200">
                                            <option value="">Select</option>
                                            <?php foreach($subjects as $sub): ?>
                                            <option value="<?php echo $sub; ?>" <?php if(($existing_tt[$day][$p]??'')==$sub) echo 'selected'; ?>><?php echo $sub; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    <?php endforeach; ?>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-6 flex items-center justify-end space-x-4">
                        <button type="button" onclick="window.location.reload()" class="inline-flex items-center px-5 py-2.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-sm font-medium rounded-lg transition-colors duration-200">
                            <span class="material-icons text-sm mr-2">refresh</span>
                            Reset
                        </button>
                        <button type="submit" name="save_timetable" class="inline-flex items-center px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-sm font-medium rounded-lg transition-colors duration-200 shadow-sm">
                            <span class="material-icons text-sm mr-2">save</span>
                            Save Timetable
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>

<?php include "../templates/footer.php"?>
<script src="./valid.js"></script>
</body>
</html>