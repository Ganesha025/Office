<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}

require "../config/db.php";

$current_year = date('Y');
$start_date = strtotime("$current_year-01-01");
$end_date = strtotime("$current_year-12-31");

for($date = $start_date; $date <= $end_date; $date = strtotime('+1 day', $date)){
    if(date('w', $date) == 0){
        $holiday_date = date('Y-m-d', $date);
        $exists = $conn->query("SELECT id FROM holidays WHERE holiday_date='$holiday_date'");
        if($exists->num_rows == 0){
            $stmt = $conn->prepare("INSERT INTO holidays (holiday_date, description) VALUES (?, ?)");
            $desc = "Sunday";
            $stmt->bind_param("ss", $holiday_date, $desc);
            $stmt->execute();
        }
    }
}

if(isset($_POST['save_holiday'])){
    $id = intval($_POST['id'] ?? 0);
    $holiday_date = $_POST['holiday_date'];
    $description = trim($_POST['description']);

    if($id > 0){
        $stmt = $conn->prepare("UPDATE holidays SET holiday_date=?, description=? WHERE id=?");
        $stmt->bind_param("ssi", $holiday_date, $description, $id);
        $stmt->execute();
    } else {
        $check = $conn->query("SELECT id FROM holidays WHERE holiday_date='$holiday_date'");
        if($check->num_rows == 0){
            $stmt = $conn->prepare("INSERT INTO holidays (holiday_date, description) VALUES (?, ?)");
            $stmt->bind_param("ss", $holiday_date, $description);
            $stmt->execute();
        }
    }
}

if(isset($_GET['delete_id'])){
    $id = intval($_GET['delete_id']);
    $conn->query("DELETE FROM holidays WHERE id=$id");
    header("Location: holidays.php");
    exit;
}

$holidays = $conn->query("SELECT * FROM holidays WHERE YEAR(holiday_date) BETWEEN YEAR(CURDATE())-5 AND YEAR(CURDATE())+5 ORDER BY holiday_date ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Holiday Management - ERP System</title>
<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
* {
    font-family: 'Inter', sans-serif;
}
body {
    background: #f8f9fa;
}
.material-icons {
    font-size: 20px;
    vertical-align: middle;
}
</style>
</head>
<body class="bg-gray-50">
<?php include "../templates/header.php"?>

<div class="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto">
        
        <div class="mb-8">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">Holiday Management</h1>
                    <p class="mt-1 text-sm text-gray-500">Manage school holidays and weekends</p>
                </div>
                <a href="dashboard.php" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                    <span class="material-icons mr-2 text-lg">arrow_back</span>
                    Back to Dashboard
                </a>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div class="flex items-center">
                    <div class="p-3 bg-blue-50 rounded-lg">
                        <span class="material-icons text-blue-600 text-3xl">event</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Total Holidays</p>
                        <p class="text-2xl font-bold text-gray-900"><?php echo $holidays->num_rows; ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div class="flex items-center">
                    <div class="p-3 bg-green-50 rounded-lg">
                        <span class="material-icons text-green-600 text-3xl">calendar_today</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Current Year</p>
                        <p class="text-2xl font-bold text-gray-900"><?php echo date('Y'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div class="flex items-center">
                    <div class="p-3 bg-purple-50 rounded-lg">
                        <span class="material-icons text-purple-600 text-3xl">schedule</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Auto Sundays</p>
                        <p class="text-2xl font-bold text-gray-900">Enabled</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-semibold text-gray-900 flex items-center">
                    <span class="material-icons mr-2">add_circle</span>
                    Add New Holiday
                </h2>
            </div>
            <div class="p-6">
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="id" value="">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                <span class="material-icons text-sm align-middle mr-1">event</span>
                                Holiday Date
                            </label>
                            <input type="date" name="holiday_date" required class="val-dobed w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                <span class="material-icons text-sm align-middle mr-1">description</span>
                                Holiday Description
                            </label>
                            <input type="text" name="description" id="Fo" placeholder="Enter holiday name or description" required class="val-com-name w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all">
                        </div>
                    </div>
                    <div class="flex justify-end">
                        <button type="submit" name="save_holiday" class="inline-flex items-center px-6 py-2.5 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors">
                            <span class="material-icons mr-2 text-lg">save</span>
                            Save Holiday
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm border border-gray-200">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-semibold text-gray-900 flex items-center">
                    <span class="material-icons mr-2">list</span>
                    Holiday List
                </h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">ID</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Date</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Description</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Day</th>
                            <th class="px-6 py-3 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php 
                        $holidays->data_seek(0);
                        while($row = $holidays->fetch_assoc()): 
                            $day_name = date('l', strtotime($row['holiday_date']));
                        ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo $row['id']; ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <span class="inline-flex items-center">
                                    <span class="material-icons text-gray-400 mr-2 text-sm">calendar_month</span>
                                    <?php echo date('d M Y', strtotime($row['holiday_date'])); ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-900"><?php echo htmlspecialchars($row['description']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    <?php echo $day_name; ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <a href="holidays.php?delete_id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this holiday?')" class="inline-flex items-center px-3 py-1.5 bg-red-50 text-red-600 text-sm font-medium rounded-lg hover:bg-red-100 transition-colors">
                                    <span class="material-icons text-sm mr-1">delete</span>
                                    Delete
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<?php include "../templates/footer.php"?>
<script src="./valid.js"></script>
<script>
    $(document).ready(function(){
    $("#FocusInput").focus();

    })
</script>
</body>
</html>