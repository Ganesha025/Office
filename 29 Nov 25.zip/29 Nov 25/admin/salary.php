<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role']!=='admin'){
    header("Location: ../index.php");
    exit;
}
require "../config/db.php";

function calculateSalary($base,$allowance,$deduction){
    return $base+$allowance-$deduction;
}

if(isset($_POST['save_salary'])){
    $staff_id = intval($_POST['staff_id']);
    $month_year = $_POST['month_year'];
    $base = floatval($_POST['base_salary']);
    $allowance = floatval($_POST['allowance']);
    $deduction = floatval($_POST['deduction']);
    $paid_date = $_POST['paid_date'];
    $final_salary = calculateSalary($base,$allowance,$deduction);

    $stmt = $conn->prepare("INSERT INTO staff_salary (staff_id, month_year, base_salary, allowance, deduction, final_salary, paid_date) 
                            VALUES (?,?,?,?,?,?,?)
                            ON DUPLICATE KEY UPDATE base_salary=?, allowance=?, deduction=?, final_salary=?, paid_date=?");

    $stmt->bind_param(
        "isddddsdddds",
        $staff_id, $month_year, $base, $allowance, $deduction, $final_salary, $paid_date,
        $base, $allowance, $deduction, $final_salary, $paid_date
    );
    $stmt->execute();
}

$staffs = $conn->query("SELECT * FROM staff ORDER BY id ASC");
$month_now = date('Y-m');
$paid_staff = $conn->query("SELECT ss.*, s.name, s.role FROM staff_salary ss JOIN staff s ON ss.staff_id=s.id WHERE ss.month_year='$month_now' ORDER BY ss.paid_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Monthly Salary - Admin</title>
<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
* { font-family: 'Inter', sans-serif; }
body { background: #f8f9fa; }
.material-icons { vertical-align: middle; }
</style>
</head>
<body class="bg-gray-50">
<?php include "../templates/header.php"?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">


<div class="bg-white rounded-xl shadow-sm border border-gray-200 mb-8 overflow-hidden">
<div class="bg-gray-50 px-6 py-4 border-b border-gray-200">
<h2 class="text-xl font-semibold text-gray-900 flex items-center gap-2">
<span class="material-icons text-gray-700">group</span>
Process Salary Payments
</h2>
</div>
<div class="overflow-x-auto">
<table class="w-full">
<thead class="bg-gray-50 border-b border-gray-200">
<tr>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">ID</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Name</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Role</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Month</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Base Salary</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Allowance</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Deduction</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Final Salary</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Paid Date</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Action</th>
</tr>
</thead>
<tbody class="bg-white divide-y divide-gray-200">
<?php while($row = $staffs->fetch_assoc()): ?>
<tr class="hover:bg-gray-50 transition-colors">
<form method="POST" class="contents">
<td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
<?php echo $row['id']; ?>
<input type="hidden" name="staff_id" value="<?php echo $row['id']; ?>">
</td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($row['name']); ?></td>
<td class="px-6 py-4 whitespace-nowrap">
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
<?php echo htmlspecialchars($row['role']); ?>
</span>
</td>
<td class="px-6 py-4 whitespace-nowrap">
<input type="month" name="month_year" required class="val-dobed px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
</td>
<td class="px-6 py-4 whitespace-nowrap">
<input type="number" step="0.01" name="base_salary" value="<?php echo $row['base_salary']; ?>" class="val-salary w-28 px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
</td>
<td class="px-6 py-4 whitespace-nowrap">
<input type="number" step="0.01" name="allowance" value="<?php echo $row['allowance']; ?>" class="val-salary w-28 px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
</td>
<td class="px-6 py-4 whitespace-nowrap">
<input type="number" step="0.01" name="deduction" value="<?php echo $row['deduction']; ?>" class="val-salary w-28 px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
</td>
<td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
₹<?php echo number_format(calculateSalary($row['base_salary'],$row['allowance'],$row['deduction']),2); ?>
</td>
<td class="px-6 py-4 whitespace-nowrap">
<input type="date" name="paid_date" required value="<?php echo date('Y-m-d'); ?>" class="val-dobed px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
</td>
<td class="px-6 py-4 whitespace-nowrap">
<button type="submit" name="save_salary" class="inline-flex items-center gap-1 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm">
<span class="material-icons text-lg">save</span>
Save
</button>
</td>
</form>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
<div class="bg-gray-50 px-6 py-4 border-b border-gray-200">
<h2 class="text-xl font-semibold text-gray-900 flex items-center gap-2">
<span class="material-icons text-gray-700">receipt_long</span>
This Month Paid Staff (<?php echo date('F Y'); ?>)
</h2>
</div>
<div class="overflow-x-auto">
<table class="w-full">
<thead class="bg-gray-50 border-b border-gray-200">
<tr>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">ID</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Name</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Role</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Month</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Base Salary</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Allowance</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Deduction</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Final Salary</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Paid Date</th>
</tr>
</thead>
<tbody class="bg-white divide-y divide-gray-200">
<?php while($p = $paid_staff->fetch_assoc()): ?>
<tr class="hover:bg-gray-50 transition-colors">
<td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo $p['staff_id']; ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($p['name']); ?></td>
<td class="px-6 py-4 whitespace-nowrap">
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
<?php echo htmlspecialchars($p['role']); ?>
</span>
</td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $p['month_year']; ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">₹<?php echo number_format($p['base_salary'],2); ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">₹<?php echo number_format($p['allowance'],2); ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-red-600">-₹<?php echo number_format($p['deduction'],2); ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">₹<?php echo number_format($p['final_salary'],2); ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 flex items-center gap-1">
<span class="material-icons text-sm text-gray-500">event</span>
<?php echo $p['paid_date']; ?>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>
</div>

<?php include "../templates/footer.php"?>
<script src="./valid.js"></script>
</body>
</html>