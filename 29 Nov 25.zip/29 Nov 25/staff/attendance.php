<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'staff'){
    header("Location: ../index.php");
    exit;
}

$staff_id = $_SESSION['staff_id'];

// FIX: Run query safely
$query = "SELECT date, status FROM staff_attendance WHERE staff_id = ? ORDER BY date DESC";
$stmt = $conn->prepare($query);

if(!$stmt){
    die("SQL ERROR: " . $conn->error);
}

$stmt->bind_param("i", $staff_id);
$stmt->execute();
$res = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
<title>Staff Attendance</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4 p-4 bg-white shadow rounded">
<h3>Your Attendance</h3>

<table class="table table-bordered mt-3">
<tr><th>Date</th><th>Status</th></tr>

<?php if($res->num_rows > 0): ?>
    <?php while($r = $res->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($r['date']) ?></td>
        <td><?= htmlspecialchars($r['status']) ?></td>
    </tr>
    <?php endwhile; ?>
<?php else: ?>
<tr>
    <td colspan="2" class="text-center text-muted">No attendance records found.</td>
</tr>
<?php endif; ?>

</table>

<a href="dashboard.php" class="btn btn-secondary">Back</a>
</div>
</body>
</html>
