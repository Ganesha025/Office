emailjs.init("JOI7aiTqIdULejz3K");
function sendMail (emails) {
  emailjs.send("service_btk93pf","template_u9vblac",{name:"savafe",title:"summa oru msg",email:emails})
    }