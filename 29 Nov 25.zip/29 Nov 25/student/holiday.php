<?php
session_start();
if(!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['student', 'parent'])){
    header("Location: ../index.php");
    exit;
}

require "../config/db.php";

$current_year = date('Y');
$holidays = $conn->query("SELECT * FROM holidays WHERE YEAR(holiday_date) = '$current_year' ORDER BY holiday_date ASC");

$upcoming_holidays = $conn->query("SELECT * FROM holidays WHERE holiday_date >= CURDATE() ORDER BY holiday_date ASC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>School Holidays - ERP System</title>
<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
* {
    font-family: 'Inter', sans-serif;
}
body {
    background: #f8f9fa;
}
.material-icons {
    font-size: 20px;
    vertical-align: middle;
}
.holiday-card {
    transition: all 0.2s ease-in-out;
}
.holiday-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
}
</style>
</head>
<body class="bg-gray-50">
<?php include "../templates/header.php"?>

<div class="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
    <div class="max-w-4xl mx-auto">
        
        <!-- Header -->
        <div class="mb-8">
            <div class="flex items-center justify-between flex-wrap gap-4">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">School Holidays</h1>
                    <p class="mt-1 text-sm text-gray-500"><?php echo date('Y'); ?> Academic Calendar</p>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <span class="material-icons text-xs mr-1">event</span>
                        <?php echo $holidays->num_rows; ?> Holidays
                    </span>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 holiday-card">
                <div class="flex items-center">
                    <div class="p-3 bg-blue-50 rounded-lg">
                        <span class="material-icons text-blue-600 text-2xl">today</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Total Holidays</p>
                        <p class="text-2xl font-bold text-gray-900"><?php echo $holidays->num_rows; ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 holiday-card">
                <div class="flex items-center">
                    <div class="p-3 bg-green-50 rounded-lg">
                        <span class="material-icons text-green-600 text-2xl">schedule</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Upcoming</p>
                        <p class="text-2xl font-bold text-gray-900"><?php $upcoming_holidays->data_seek(0); echo $upcoming_holidays->num_rows; ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 holiday-card">
                <div class="flex items-center">
                    <div class="p-3 bg-purple-50 rounded-lg">
                        <span class="material-icons text-purple-600 text-2xl">calendar_month</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Current Year</p>
                        <p class="text-2xl font-bold text-gray-900"><?php echo date('Y'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Upcoming Holidays -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 mb-8">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-semibold text-gray-900 flex items-center">
                    <span class="material-icons mr-2 text-blue-600">schedule</span>
                    Upcoming Holidays
                </h2>
            </div>
            <div class="p-6">
                <?php if($upcoming_holidays->num_rows > 0): ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <?php $upcoming_holidays->data_seek(0); while($row = $upcoming_holidays->fetch_assoc()): 
                            $days_away = floor((strtotime($row['holiday_date']) - time()) / (60*60*24));
                        ?>
                            <div class="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg border border-blue-100 holiday-card">
                                <div class="flex items-start justify-between">
                                    <div>
                                        <h4 class="font-semibold text-gray-900 text-lg"><?php echo htmlspecialchars($row['description']); ?></h4>
                                        <p class="text-sm text-gray-600 mt-1">
                                            <span class="material-icons text-gray-400 mr-1 text-sm">calendar_today</span>
                                            <?php echo date('d M Y', strtotime($row['holiday_date'])); ?>
                                        </p>
                                        <?php if($days_away > 0): ?>
                                            <p class="text-xs text-blue-600 font-medium mt-1">
                                                <span class="material-icons text-xs mr-1">access_time</span>
                                                <?php echo $days_away; ?> days away
                                            </p>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800 font-medium mt-1">
                                                <span class="material-icons text-xs mr-1">today</span>
                                                Today
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-right">
                                        <span class="material-icons text-2xl text-blue-500">event</span>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-12">
                        <span class="material-icons text-6xl text-gray-300 mb-4">event_busy</span>
                        <p class="text-lg text-gray-500">No upcoming holidays</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Full Holiday List -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-semibold text-gray-900 flex items-center">
                    <span class="material-icons mr-2">list</span>
                    Complete Holiday List (<?php echo date('Y'); ?>)
                </h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Date</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Description</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Day</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php $holidays->data_seek(0); 
                        if($holidays->num_rows > 0):
                            while($row = $holidays->fetch_assoc()):
                                $day_name = date('l', strtotime($row['holiday_date']));
                                $is_past = strtotime($row['holiday_date']) < time();
                        ?>
                            <tr class="hover:bg-gray-50 transition-colors holiday-card">
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                    <span class="inline-flex items-center">
                                        <span class="material-icons text-gray-400 mr-2 text-sm">calendar_month</span>
                                        <?php echo date('d M Y', strtotime($row['holiday_date'])); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-900 max-w-md">
                                    <?php echo htmlspecialchars($row['description']); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm">
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium 
                                        <?php echo $is_past ? 'bg-gray-100 text-gray-800' : 'bg-green-100 text-green-800'; ?>">
                                        <?php echo $day_name; ?>
                                    </span>
                                </td>
                            </tr>
                        <?php 
                            endwhile; 
                        else: ?>
                            <tr>
                                <td colspan="3" class="px-6 py-12 text-center text-gray-500">
                                    <span class="material-icons text-4xl block mb-2 mx-auto">event_busy</span>
                                    No holidays found for this year
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include "../templates/footer.php"?>
</body>
</html>
