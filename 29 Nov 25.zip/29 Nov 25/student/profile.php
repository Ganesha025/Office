<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'student'){
    header("Location: ../index.php");
    exit;
}
require "../config/db.php";

$student_id = $_SESSION['student_id'];
$student = $conn->query("SELECT * FROM students WHERE id=$student_id")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Profile</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<script src="https://cdn.tailwindcss.com"></script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
body { font-family: 'Inter', sans-serif; }
</style>
</head>
<body class="bg-slate-50 min-h-screen">
<?php include "../templates/header1.php"?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
<div class="mb-6">
<div class="flex items-center gap-3 mb-2">
<span class="material-symbols-outlined text-emerald-600 text-3xl">account_circle</span>
<h1 class="text-2xl sm:text-3xl font-semibold text-slate-800"><?= htmlspecialchars($student['name']) ?></h1>
</div>
<p class="text-slate-600 text-sm sm:text-base">View and manage your personal information</p>
</div>

<div class="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
<div class="bg-emerald-600 px-6 py-4">
<h2 class="text-white text-lg font-semibold flex items-center gap-2">
<span class="material-symbols-outlined text-xl">badge</span>
Student Information
</h2>
</div>

<div class="p-0">
<div class="grid grid-cols-1 divide-y divide-slate-200">
<div class="grid grid-cols-1 sm:grid-cols-3 px-6 py-4 hover:bg-slate-50 transition-colors">
<div class="flex items-center gap-2 text-slate-700 font-medium mb-2 sm:mb-0">
<span class="material-symbols-outlined text-emerald-600 text-xl">fingerprint</span>
<span>Student ID</span>
</div>
<div class="sm:col-span-2 text-slate-800 font-medium"><?= htmlspecialchars($student['student_id']) ?></div>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 px-6 py-4 hover:bg-slate-50 transition-colors">
<div class="flex items-center gap-2 text-slate-700 font-medium mb-2 sm:mb-0">
<span class="material-symbols-outlined text-emerald-600 text-xl">person</span>
<span>Name</span>
</div>
<div class="sm:col-span-2 text-slate-800 font-medium"><?= htmlspecialchars($student['name']) ?></div>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 px-6 py-4 hover:bg-slate-50 transition-colors">
<div class="flex items-center gap-2 text-slate-700 font-medium mb-2 sm:mb-0">
<span class="material-symbols-outlined text-emerald-600 text-xl">numbers</span>
<span>Roll Number</span>
</div>
<div class="sm:col-span-2 text-slate-800 font-medium"><?= htmlspecialchars($student['roll_no']) ?></div>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 px-6 py-4 hover:bg-slate-50 transition-colors">
<div class="flex items-center gap-2 text-slate-700 font-medium mb-2 sm:mb-0">
<span class="material-symbols-outlined text-emerald-600 text-xl">school</span>
<span>Class & Section</span>
</div>
<div class="sm:col-span-2 text-slate-800 font-medium"><?= htmlspecialchars($student['class'].'-'.$student['section']) ?></div>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 px-6 py-4 hover:bg-slate-50 transition-colors">
<div class="flex items-center gap-2 text-slate-700 font-medium mb-2 sm:mb-0">
<span class="material-symbols-outlined text-emerald-600 text-xl">cake</span>
<span>Date of Birth</span>
</div>
<div class="sm:col-span-2 text-slate-800 font-medium"><?= htmlspecialchars($student['dob']) ?></div>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 px-6 py-4 hover:bg-slate-50 transition-colors">
<div class="flex items-center gap-2 text-slate-700 font-medium mb-2 sm:mb-0">
<span class="material-symbols-outlined text-emerald-600 text-xl">mail</span>
<span>Email</span>
</div>
<div class="sm:col-span-2 text-slate-800 font-medium break-all"><?= htmlspecialchars($student['email']) ?></div>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 px-6 py-4 hover:bg-slate-50 transition-colors">
<div class="flex items-center gap-2 text-slate-700 font-medium mb-2 sm:mb-0">
<span class="material-symbols-outlined text-emerald-600 text-xl">phone</span>
<span>Mobile</span>
</div>
<div class="sm:col-span-2 text-slate-800 font-medium"><?= htmlspecialchars($student['mobile']) ?></div>
</div>
</div>
</div>
</div>

<div class="mt-6 flex flex-col sm:flex-row gap-3">
</div>
</div>

<?php include "../templates/footer1.php"?>
<script src="./valid.js"></script>
</body>
</html>