<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'student'){
    header("Location: ../index.php");
    exit;
}
require "../config/db.php";

$student_id = $_SESSION['student_id'];

$res = $conn->query("SELECT date, status FROM attendance WHERE student_id=$student_id ORDER BY date ASC");

$attendance = [];
$total_days = 0;
$present_days = 0;

if($res){
    while($row = $res->fetch_assoc()){
        $attendance[] = $row;
        $total_days++;
        if($row['status'] === 'P') $present_days++;
    }
}

$percentage = $total_days > 0 ? round(($present_days / $total_days) * 100, 2) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Attendance</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<script src="https://cdn.tailwindcss.com"></script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
body { font-family: 'Inter', sans-serif; }
.material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
</style>
</head>
<body class="bg-slate-50 min-h-screen">
<?php include "../templates/header1.php"?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">

<div class="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
<div class="bg-white rounded-lg shadow-sm border border-slate-200 p-5 sm:p-6 hover:shadow-md transition-shadow">
<div class="flex items-center justify-between mb-3">
<div class="bg-emerald-50 rounded-lg p-3">
<span class="material-symbols-outlined text-emerald-600 text-2xl">calendar_month</span>
</div>
<span class="text-3xl sm:text-4xl font-bold text-slate-800"><?= $total_days ?></span>
</div>
<h3 class="text-slate-600 text-sm font-medium">Total Days</h3>
</div>

<div class="bg-white rounded-lg shadow-sm border border-slate-200 p-5 sm:p-6 hover:shadow-md transition-shadow">
<div class="flex items-center justify-between mb-3">
<div class="bg-emerald-50 rounded-lg p-3">
<span class="material-symbols-outlined text-emerald-600 text-2xl">check_circle</span>
</div>
<span class="text-3xl sm:text-4xl font-bold text-emerald-600"><?= $present_days ?></span>
</div>
<h3 class="text-slate-600 text-sm font-medium">Present Days</h3>
</div>

<div class="bg-white rounded-lg shadow-sm border border-slate-200 p-5 sm:p-6 hover:shadow-md transition-shadow">
<div class="flex items-center justify-between mb-3">
<div class="bg-emerald-50 rounded-lg p-3">
<span class="material-symbols-outlined text-emerald-600 text-2xl">percent</span>
</div>
<span class="text-3xl sm:text-4xl font-bold text-slate-800"><?= $percentage ?>%</span>
</div>
<h3 class="text-slate-600 text-sm font-medium">Attendance Rate</h3>
<div class="mt-3 bg-slate-100 rounded-full h-2 overflow-hidden">
<div class="bg-emerald-600 h-full transition-all duration-500" style="width: <?= $percentage ?>%"></div>
</div>
</div>
</div>

<div class="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
<div class="px-4 sm:px-6 py-4 border-b border-slate-200 bg-slate-50">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-emerald-600">table_chart</span>
<h2 class="text-lg sm:text-xl font-semibold text-slate-800">Attendance Records</h2>
</div>
</div>

<div class="overflow-x-auto">
<table class="w-full">
<thead class="bg-slate-50 border-b border-slate-200">
<tr>
<th class="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">#</th>
<th class="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Date</th>
<th class="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Status</th>
</tr>
</thead>
<tbody class="divide-y divide-slate-200">
<?php if(empty($attendance)): ?>
<tr>
<td colspan="3" class="px-4 sm:px-6 py-8 text-center text-slate-500">
<span class="material-symbols-outlined text-5xl text-slate-300 mb-2">inbox</span>
<p class="text-sm">No attendance records found</p>
</td>
</tr>
<?php else: ?>
<?php $counter = 1; foreach($attendance as $att): ?>
<tr class="hover:bg-slate-50 transition-colors">
<td class="px-4 sm:px-6 py-4 text-sm text-slate-600 font-medium"><?= $counter++ ?></td>
<td class="px-4 sm:px-6 py-4 text-sm text-slate-800"><?= date('M d, Y', strtotime($att['date'])) ?></td>
<td class="px-4 sm:px-6 py-4 text-sm">
<?php if($att['status'] === 'P'): ?>
<span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
<span class="material-symbols-outlined text-base">check_circle</span>
Present
</span>
<?php else: ?>
<span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200">
<span class="material-symbols-outlined text-base">cancel</span>
Absent
</span>
<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
</div>
</div>
</div>

<?php include "../templates/footer1.php"?>
<script src="./valid.js"></script>
</body>
</html>