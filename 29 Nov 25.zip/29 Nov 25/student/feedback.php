<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'student'){
    header("Location: ../index.php");
    exit;
}
require "../config/db.php";

$feedback = "";
$result = null;

$student_id = $_SESSION['student_id'];

if(isset($_POST['submit'])){
    $feedback = trim($_POST['feedback']);
    $num_words = str_word_count($feedback);
    $num_chars = strlen($feedback);
    $num_lines = substr_count($feedback, "\n") + 1;

    $result = [
        'words' => $num_words,
        'characters' => $num_chars,
        'lines' => $num_lines
    ];

    $stmt = $conn->prepare("INSERT INTO feedback (student_id, feedback) VALUES (?, ?)");
    $stmt->bind_param("is", $student_id, $feedback);
    $stmt->execute();
    $stmt->close();
}

$all_feedback = [];
$res = $conn->query("SELECT feedback, submitted_at FROM feedback WHERE student_id=$student_id ORDER BY submitted_at DESC");
if($res){
    while($row = $res->fetch_assoc()){
        $all_feedback[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Submit Feedback</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<style>
body { font-family: 'Inter', sans-serif; }
</style>
</head>
<body class="bg-slate-50 min-h-screen">
<?php include "../templates/header1.php"?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
<div class="mb-6">
<div class="flex items-center gap-3 mb-2">
<span class="material-icons text-emerald-600 text-3xl">feedback</span>
<h1 class="text-2xl lg:text-3xl font-semibold text-slate-800">Submit Feedback</h1>
</div>
<p class="text-slate-600 text-sm lg:text-base ml-0 lg:ml-11">Share your thoughts and suggestions with us</p>
</div>

<div class="grid grid-cols-1 xl:grid-cols-3 gap-6">
<div class="xl:col-span-2">
<div class="bg-white rounded-lg shadow-sm border border-slate-200">
<div class="p-6 lg:p-8">
<form method="POST">
<div class="mb-6">
<label for="feedback" class="flex items-center gap-2 text-sm font-medium text-slate-700 mb-3">
<span class="material-icons text-emerald-600" style="font-size: 20px;">edit_note</span>
Your Feedback
</label>
<textarea name="feedback" id="feedback" class="val-address w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all resize-none text-slate-800" rows="8" placeholder="Enter your feedback here..." required><?= htmlspecialchars($feedback) ?></textarea>
</div>
<button type="submit" name="submit" class="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-medium px-6 py-3 rounded-lg transition-all shadow-sm hover:shadow">
<span class="material-icons" style="font-size: 20px;">send</span>
Submit Feedback
</button>
</form>
</div>
</div>

<?php if($result): ?>
<div class="bg-emerald-50 rounded-lg border border-emerald-200 shadow-sm mt-6">
<div class="p-6 lg:p-8">
<div class="flex items-center gap-2 mb-4">
<span class="material-icons text-emerald-600">analytics</span>
<h3 class="text-lg font-semibold text-slate-800">Feedback Analysis</h3>
</div>
<div class="grid grid-cols-3 gap-4">
<div class="bg-white rounded-lg p-4 border border-emerald-100">
<div class="flex items-center gap-2 mb-2">
<span class="material-icons text-emerald-600" style="font-size: 20px;">text_fields</span>
<span class="text-xs font-medium text-slate-600 uppercase tracking-wide">Words</span>
</div>
<p class="text-2xl font-bold text-slate-800"><?= $result['words'] ?></p>
</div>
<div class="bg-white rounded-lg p-4 border border-emerald-100">
<div class="flex items-center gap-2 mb-2">
<span class="material-icons text-emerald-600" style="font-size: 20px;">notes</span>
<span class="text-xs font-medium text-slate-600 uppercase tracking-wide">Characters</span>
</div>
<p class="text-2xl font-bold text-slate-800"><?= $result['characters'] ?></p>
</div>
<div class="bg-white rounded-lg p-4 border border-emerald-100">
<div class="flex items-center gap-2 mb-2">
<span class="material-icons text-emerald-600" style="font-size: 20px;">view_stream</span>
<span class="text-xs font-medium text-slate-600 uppercase tracking-wide">Lines</span>
</div>
<p class="text-2xl font-bold text-slate-800"><?= $result['lines'] ?></p>
</div>
</div>
</div>
</div>
<?php endif; ?>
</div>

<div class="xl:col-span-1">
<div class="bg-white rounded-lg shadow-sm border border-slate-200 sticky top-6">
<div class="p-6">
<div class="flex items-center gap-2 mb-4">
<span class="material-icons text-emerald-600">info</span>
<h3 class="text-lg font-semibold text-slate-800">Guidelines</h3>
</div>
<ul class="space-y-3 text-sm text-slate-600">
<li class="flex items-start gap-2">
<span class="material-icons text-emerald-600 mt-0.5" style="font-size: 18px;">check_circle</span>
<span>Be specific and constructive in your feedback</span>
</li>
<li class="flex items-start gap-2">
<span class="material-icons text-emerald-600 mt-0.5" style="font-size: 18px;">check_circle</span>
<span>Include relevant details and examples</span>
</li>
<li class="flex items-start gap-2">
<span class="material-icons text-emerald-600 mt-0.5" style="font-size: 18px;">check_circle</span>
<span>Keep feedback professional and respectful</span>
</li>
<li class="flex items-start gap-2">
<span class="material-icons text-emerald-600 mt-0.5" style="font-size: 18px;">check_circle</span>
<span>Focus on actionable suggestions</span>
</li>
</ul>
</div>
</div>
</div>
</div>

<div class="mt-8">
<div class="bg-white rounded-lg shadow-sm border border-slate-200">
<div class="p-6 lg:p-8">
<div class="flex items-center gap-2 mb-6">
<span class="material-icons text-emerald-600">history</span>
<h2 class="text-xl font-semibold text-slate-800">Previous Feedback</h2>
</div>

<div class="overflow-x-auto">
<table class="w-full">
<thead>
<tr class="border-b border-slate-200">
<th class="text-left py-3 px-4 text-xs font-semibold text-slate-600 uppercase tracking-wide bg-slate-50">#</th>
<th class="text-left py-3 px-4 text-xs font-semibold text-slate-600 uppercase tracking-wide bg-slate-50">Feedback</th>
<th class="text-left py-3 px-4 text-xs font-semibold text-slate-600 uppercase tracking-wide bg-slate-50 whitespace-nowrap">Submitted At</th>
</tr>
</thead>
<tbody class="divide-y divide-slate-200">
<?php if(empty($all_feedback)): ?>
<tr>
<td colspan="3" class="py-8 px-4 text-center text-slate-500">
<span class="material-icons text-slate-300 text-5xl mb-2">inbox</span>
<p>No feedback submitted yet</p>
</td>
</tr>
<?php else: ?>
<?php $counter=1; foreach($all_feedback as $fb): ?>
<tr class="hover:bg-slate-50 transition-colors">
<td class="py-4 px-4 text-sm font-medium text-slate-700"><?= $counter++ ?></td>
<td class="py-4 px-4 text-sm text-slate-800 max-w-xl"><?= nl2br(htmlspecialchars($fb['feedback'])) ?></td>
<td class="py-4 px-4 text-sm text-slate-600 whitespace-nowrap">
<div class="flex items-center gap-1">
<span class="material-icons text-slate-400" style="font-size: 16px;">schedule</span>
<?= date('M d, Y H:i', strtotime($fb['submitted_at'])) ?>
</div>
</td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
</div>
</div>
</div>
</div>

</div>

<?php include "../templates/footer1.php"?>
<script src="./valid.js"></script>
</body>
</html>