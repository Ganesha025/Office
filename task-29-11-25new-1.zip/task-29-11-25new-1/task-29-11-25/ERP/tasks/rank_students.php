<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Rank Students Based on Scores</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
body {
    background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
    font-family: "Inter", sans-serif;
    color: #2b2b2b;
    font-size: 18px;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}
.card {
    background: rgba(255, 255, 255, 0.55);
    backdrop-filter: blur(14px);
    border: 2px solid rgba(0,0,0,0.08);
    border-radius: 20px;
    padding: 32px;
    transition: .25s ease-in-out;
    max-width: 600px;
    margin: 0 auto;
}
.card:hover {
    transform: translateY(-5px);
    background: rgba(255, 255, 255, 0.70);
    border-color: rgba(0,0,0,0.20);
    box-shadow: 0 8px 22px rgba(0, 0, 0, 0.15);
}
input {
    width: 100%;
    padding: 0.8rem 1rem;
    padding-left: 1.5rem;
    font-size: 1rem;
    border-radius: 0.5rem;
    border: 1px solid #ccc;
    outline: none;
    height: 3rem;
    box-sizing: border-box;
}
input:focus {
    border-color: #7e22ce;
}
.result-box {
    background: #D8F3DC;
    border: 2px solid #95D5B2;
    border-radius: 14px;
    padding: 25px 30px;
    margin-top: 20px;
    white-space: pre-line;
    font-family: monospace;
    font-size: 18px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    text-align: center; /* center content */
}
.error {
    color: #d90429;
    font-size: 16px;
    margin-top: 4px;
}
button {
    cursor: pointer;
}
button:disabled {
    background-color: #9ca3af;
    cursor: not-allowed;
}
.student-row {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
    flex-wrap: wrap;
    align-items: flex-end;
}
.student-row .field {
    display: flex;
    flex-direction: column;
}
/* Original widths */
.student-row .field.name-field {
    flex: 0 0 350px; /* original width for name */
}
.student-row .field.score-field {
    flex: 1; /* original width for score */
    min-width: 150px;
}
.student-row label {
    margin-bottom: 4px;
    font-weight: 600;
}
@media (max-width: 640px) {
    .student-row {
        flex-direction: column;
    }
    .student-row .field.name-field,
    .student-row .field.score-field {
        flex: 1 1 100%;
    }
}
 /* Hide number input arrows */
        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { 
            -webkit-appearance: none; 
            margin: 0; 
        }
        input[type=number] {
            -moz-appearance: textfield;
        }
        .error-star{
            color:red;
        }
#name, #score{
    padding:30px;
}
</style>
</head>
<body>

<header class="py-10 text-center">
<h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
Task 9 - Rank 5 Students Based on Scores
</h1>
<p class="text-gray-700 mt-3 text-xl">Enter names and scores of 5 students</p>
<a href="../index.php" class="text-blue-800 underline mt-3 inline-block text-lg font-semibold">
    ← Back to Dashboard
</a>
</header>

<div class="card shadow-lg">
<form id="rankForm" autocomplete="off" novalidate>

<div id="studentsContainer"></div>

<div class="text-center mt-6">
<button type="submit" id="submitBtn" class="px-8 py-4 rounded-xl bg-purple-600 text-white text-xl font-semibold hover:bg-purple-700 transition" disabled>
Generate Ranks
</button>
</div>

</form>

<div id="result" class="result-box" style="display:none;"></div>
</div>

<script>
$(document).ready(function(){

    $("#rankForm")[0].reset();
    $("#result").hide();
    $("#submitBtn").prop("disabled", true);

    // Create 5 student rows
    for(let i=1;i<=5;i++){
        $("#studentsContainer").append(`
            <div class="student-row">
                <div class="field name-field">
                    <label>Student ${i} Name <span class="error-star">*</span></label>
                    <input type="text" class="studentName" id="name" placeholder="Enter student name">
                    <p class="nameError error"></p>
                </div>
                <div class="field score-field">
                    <label>Score (0-100) <span class="error-star">*</span></label>
                    <input type="number" class="studentScore" id="score" placeholder="Score" min="0" max="100">
                    <p class="scoreError error"></p>
                </div>
            </div>
        `);
    }

    $(".studentName").first().focus();

    function toggleButton(){
        let enable = true;
        $(".studentName").each(function(){
            if($(this).val().trim() === '' || !/^[A-Za-z ]+$/.test($(this).val().trim())){
                enable = false;
            }
        });
        $(".studentScore").each(function(){
            let val = $(this).val().trim();
            if(val === '' || isNaN(val) || Number(val)<0 || Number(val)>100){
                enable = false;
            }
        });
        $("#submitBtn").prop("disabled", !enable);
    }

    $(document).on("input", ".studentName", function(){
        let val = $(this).val().replace(/[^A-Za-z ]/g,'');
        if(val.length>30) val=val.substring(0,30);
        $(this).val(val);
        $(this).siblings(".nameError").text('');
        toggleButton();
    });

    $(document).on("input", ".studentScore", function(){
        let val = $(this).val();
        if(val !== '' && (isNaN(val) || Number(val) < 0)){
            val = '';
        }
        if(Number(val) > 100) val = 100; // enforce max 100
        $(this).val(val);
        $(this).siblings(".scoreError").text('');
        toggleButton();
    });

    $("#rankForm").submit(function(e){
        e.preventDefault();
        $(".error").text('');
        $("#result").hide();

        let studentData = [];
        let valid = true;

        $(".studentName").each(function(index){
            let name = $(this).val().trim();
            if(name===''){ $(this).siblings(".nameError").text("Name is required."); valid=false; }
            studentData[index] = {name: name};
        });
        $(".studentScore").each(function(index){
            let score = $(this).val().trim();
            if(score === '' || isNaN(score) || Number(score)<0 || Number(score)>100){
                $(this).siblings(".scoreError").text("Score must be 0-100."); valid=false;
            } else {
                studentData[index].score = Number(score);
            }
        });

        if(!valid) return;

        // Sort by score descending
        studentData.sort((a,b)=>b.score - a.score);

        let resultText = '🏆 Student Ranks 🏆\n──────────────────────────────\n';
        studentData.forEach((s,i)=>{
            resultText += `Rank ${i+1} : ${s.name} — Score: ${s.score}\n`;
        });
        resultText += '──────────────────────────────';
        $("#result").text(resultText).fadeIn();
    });

});
</script>

</body>
</html>
