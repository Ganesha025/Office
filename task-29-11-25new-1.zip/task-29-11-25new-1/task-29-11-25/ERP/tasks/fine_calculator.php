<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Library Fine Calculator</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
body {
    background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
    font-family: "Inter", sans-serif;
    font-size: 18px;
    color: #2b2b2b;
}
.card {
    background: rgba(255,255,255,0.55);
    border-radius: 20px;
    padding: 40px;
    max-width: 650px;
    margin: 0 auto;
    border: 2px solid rgba(0,0,0,0.08);
    backdrop-filter: blur(14px);
}
.card:hover {
    background: rgba(255,255,255,0.7);
    transform: translateY(-5px);
}
input {
    width: 100%;
    padding-left:30px;
    border-radius: 10px;
    border: 1px solid #ccc;
    height: 3.3rem;
    font-size: 18px;
}
#bookName,#returnDate,#dueDate{
    padding-left:30px;
}
label {
    margin-bottom: 6px;
    display: inline-block;
}
.error {
    color: red;
    font-size: 15px;
    margin-top: 6px;
}
.result-box {
    background: #D8F3DC;
    padding: 30px;
    border-radius: 14px;
    margin-top: 28px;
    border: 2px solid #95D5B2;
    font-family: monospace;
    white-space: pre-line;
    text-align: center;
}
.error-star { color: red; }
</style>
</head>

<body>

<header class="py-10 text-center">
    <h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 
        text-transparent bg-clip-text">
        Library Fine Calculator
    </h1>
    <p class="text-gray-700 mt-4 text-xl">Calculate the fine for late book return</p>
    <a href="../index.php" class="text-blue-800 underline mt-4 inline-block text-lg font-semibold">
        ← Back to Dashboard
    </a>
</header>

<div class="card mt-8">
<form id="fineForm" autocomplete="off">

    <!-- Book Name -->
    <div class="mt-2">
        <label class="font-semibold">Book Name <span class="error-star">*</span></label>
        <input type="text" id="bookName" placeholder="Enter book name">
        <p class="error" id="bookError"></p>
    </div>

    <!-- Due Date -->
    <div class="mt-6">
        <label class="font-semibold">Due Date <span class="error-star">*</span></label>
        <input type="date" id="dueDate">
        <p class="error" id="dueError"></p>
    </div>

    <!-- Return Date -->
    <div class="mt-6">
        <label class="font-semibold">Return Date <span class="error-star">*</span></label>
        <input type="date" id="returnDate">
        <p class="error" id="returnError"></p>
    </div>

    <div class="text-center mt-10">
        <button type="submit" class="px-10 py-4 rounded-xl bg-purple-600 text-white
            text-xl font-semibold hover:bg-purple-700 transition">
            Calculate Fine
        </button>
    </div>

</form>

<div id="result" class="result-box" style="display:none;"></div>
</div>

<script>
$(document).ready(function () {

    $("#fineForm")[0].reset();
    $("#result").hide();
    $(".error").text("");

    $("#bookName").focus();

    let today = new Date();

    function format(d){
        let m = (d.getMonth()+1).toString().padStart(2,"0");
        let day = d.getDate().toString().padStart(2,"0");
        return `${d.getFullYear()}-${m}-${day}`;
    }

    let dueMin = new Date();
    dueMin.setDate(today.getDate() - 30);
    $("#dueDate").attr("min", format(dueMin));
    $("#dueDate").attr("max", format(today));

    let retMin = new Date();
    retMin.setDate(today.getDate() - 30);
    let retMax = new Date();
    retMax.setDate(today.getDate() + 30);
    $("#returnDate").attr("min", format(retMin));
    $("#returnDate").attr("max", format(retMax));

    // ----------------------------
    // BOOK NAME VALIDATION
    // ----------------------------
    function validateBook() {
        let name = $("#bookName").val().trim();

        if (name === "") {
            $("#bookError").text("This field is required");
            return false;
        }
        if (!/^[A-Za-z0-9 ]+$/.test(name)) {
            $("#bookError").text("Only letters and numbers allowed");
            return false;
        }
        if (name.length > 25) {
            $("#bookError").text("Max 25 characters allowed");
            return false;
        }
        if (/^[0-9]+$/.test(name)) {
            $("#bookError").text("Enter valid book name");
            return false;
        }

        $("#bookError").text("");
        return true;
    }

    $("#bookName").on("input", function () {
        let val = $(this).val();

        val = val.replace(/[^A-Za-z0-9 ]/g, "");
        if (val.length > 25) val = val.substring(0, 25);

        $(this).val(val);

        validateBook();
    });

    // ----------------------------
    // FIX ADDED HERE ✔
    // Clear error on valid date
    // ----------------------------
    $("#dueDate").on("change", validateDue);
    $("#returnDate").on("change", validateReturn);

    function validateDue() {
        let d = $("#dueDate").val();
        if(d === "") {
            $("#dueError").text("This field is required");
            return false;
        }
        $("#dueError").text("");
        return true;
    }

    function validateReturn() {
        let d = $("#returnDate").val();
        if(d === "") {
            $("#returnError").text("This field is required");
            return false;
        }
        $("#returnError").text("");
        return true;
    }

    function convertToDays(dateStr){
        let parts = dateStr.split("-");
        let y = Number(parts[0]);
        let m = Number(parts[1]);
        let d = Number(parts[2]);
        return (y * 365) + (m * 30) + d;
    }

    function calculateFine(due, ret){
        let finePerDay = 2;
        if(ret <= due) return 0;
        return (ret - due) * finePerDay;
    }

    $("#fineForm").submit(function(e){
        e.preventDefault();

        let validBook = validateBook();
        let validDue = validateDue();
        let validReturn = validateReturn();

        if(!validBook || !validDue || !validReturn){
            $("#result").hide();
            return;
        }

        let book = $("#bookName").val().trim();
        let due = $("#dueDate").val();
        let ret = $("#returnDate").val();

        let dueDays = convertToDays(due);
        let retDays = convertToDays(ret);

        let fine = calculateFine(dueDays, retDays);

        let output =
`📚 Library Fine Calculation
──────────────────────────
Book: ${book}
Due Date: ${due}
Return Date: ${ret}
Fine: ₹${fine}
──────────────────────────`;

        $("#result").text(output).fadeIn();
    });

});
</script>

</body>
</html>
