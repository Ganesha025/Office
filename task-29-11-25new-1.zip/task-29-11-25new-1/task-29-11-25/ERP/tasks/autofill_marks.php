<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Auto-Fill Internal Marks</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
body {
    background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
    font-family: "Inter", sans-serif;
    font-size: 18px;
    color: #2b2b2b;
}
.card {
    background: rgba(255,255,255,0.55);
    border-radius: 20px;
    padding: 40px;
    max-width: 650px;
    margin: 0 auto;
    border: 2px solid rgba(0,0,0,0.08);
    backdrop-filter: blur(14px);
}
.card:hover {
    background: rgba(255,255,255,0.7);
    transform: translateY(-5px);
}
input, select {
    width: 100%;
    padding: 1rem 1.2rem;
    border-radius: 10px;
    border: 1px solid #ccc;
    height: 3.3rem;
    font-size: 18px;
}
label {
    margin-bottom: 6px;
    display: inline-block;
}
.error {
    color: red;
    font-size: 15px;
    margin-top: 6px;
}
.result-box {
    background: #D8F3DC;
    padding: 30px;
    border-radius: 14px;
    margin-top: 28px;
    border: 2px solid #95D5B2;
    font-family: monospace;
    white-space: pre-line;
    text-align: center;
}
.error-star { color: red; }
#studentName, #attendance{
    padding:30px;
}
</style>
</head>

<body>

<header class="py-10 text-center">
    <h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 
        text-transparent bg-clip-text">
        Task 11 - Auto-Fill Internal Marks
    </h1>
    <p class="text-gray-700 mt-4 text-xl">Marks auto-calculated from attendance & assignments</p>

    <a href="../index.php" class="text-blue-800 underline mt-4 inline-block text-lg font-semibold">
        ← Back to Dashboard
    </a>
</header>

<div class="card mt-8">
<form id="marksForm" autocomplete="off">

    <div class="mt-2">
        <label class="font-semibold">Student Name <span class="error-star">*</span></label>
        <input type="text" id="studentName" placeholder="Enter student name">
        <p class="error" id="nameError"></p>
    </div>

    <div class="mt-6">
        <label class="font-semibold">Attendance (%) <span class="error-star">*</span></label>
        <input type="text" id="attendance" placeholder="Enter attendance % (1–100)">
        <p class="error" id="attendanceError"></p>
    </div>

    <div class="mt-6">
        <label class="font-semibold">Assignments Submitted? <span class="error-star">*</span></label>
        <select id="assignStatus">
            <option value="" >Select</option>
            <option value="yes">Yes, all submitted</option>
            <option value="no">No</option>
        </select>
        <p class="error" id="assignError"></p>
    </div>

    <div class="text-center mt-10">
        <button type="submit" id="submitBtn" class="px-10 py-4 rounded-xl bg-purple-600 text-white
            text-xl font-semibold hover:bg-purple-700 transition">
            Calculate Internal Marks
        </button>
    </div>

</form>

<div id="result" class="result-box" style="display:none;"></div>
</div>

<script>
$(document).ready(function () {

    $('#studentName').focus();

    // ---------------------------
    // FIELD VALIDATION FUNCTIONS
    // ---------------------------
    function validateName() {
        let name = $("#studentName").val().trim();
        if (name === "") {
            $("#nameError").text("This field is required");
            return false;
        } else if (!/^[A-Za-z ]+$/.test(name)) {
            $("#nameError").text("Enter letters only");
            return false;
        } else if (name.length > 15) {
            $("#nameError").text("Maximum 15 characters allowed");
            return false;
        } else {
            $("#nameError").text("");
            return true;
        }
    }

    function validateAttendance() {
        let att = $("#attendance").val().trim();
        if (att === "") {
            $("#attendanceError").text("This field is required");
            return false;
        } 
        let num = Number(att);
        if (isNaN(num) || num < 1 || num > 100) {
            $("#attendanceError").text("Enter a number between 1–100");
            return false;
        } else {
            $("#attendanceError").text("");
            return true;
        }
    }

    function validateAssignment() {
        let assign = $("#assignStatus").val();
        if (assign === "") {
            $("#assignError").text("This field is required");
            return false;
        } else {
            $("#assignError").text("");
            return true;
        }
    }

    // ---------------------------
    // FIELD EVENTS TO CLEAR ERRORS & RESTRICT INPUT
    // ---------------------------
    $("#studentName").on("input", function() {
        let val = $(this).val().replace(/[^A-Za-z ]/g, "");
        if (val.length > 15) val = val.substring(0,15);
        $(this).val(val);
        validateName();
    });

    $("#attendance").on("input", function() {
        let val = $(this).val().replace(/\D/g,''); // remove non-digit
        if (Number(val) > 100) val = "100";
        if (val === "0") val = ""; // prevent 0
        $(this).val(val);
        validateAttendance();
    });

    $("#assignStatus").on("change", validateAssignment);

    // ---------------------------
    // FORM SUBMIT
    // ---------------------------
    $("#marksForm").submit(function(e){
        e.preventDefault();

        let validName = validateName();
        let validAttendance = validateAttendance();
        let validAssign = validateAssignment();

        if (!validName || !validAttendance || !validAssign) {
            $("#result").hide();
            return;
        }

        let name = $("#studentName").val().trim();
        let attendance = Number($("#attendance").val());
        let assign = $("#assignStatus").val();

        let totalMarks = 0;
        if (attendance === 100) totalMarks += 3;
        else if (attendance >= 80) totalMarks += 2;
        else if (attendance >= 60) totalMarks += 1;
        if (assign === "yes") totalMarks += 2;

        let resultText = 
`📘 Internal Marks Calculation
──────────────────────────
Student: ${name}
Attendance: ${attendance}%
Assignments: ${assign === "yes" ? "Submitted" : "Not Submitted"}

🎯 Final Internal Marks: ${totalMarks} / 5
──────────────────────────`;

        $("#result").text(resultText).fadeIn();
    });

});
</script>

</body>
</html>
