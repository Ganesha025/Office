<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Holiday Calendar Highlighter</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
body {
    background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
    font-family: "Inter", sans-serif;
    color: #2b2b2b;
    font-size: 18px;
}
.card {
    background: rgba(255, 255, 255, 0.55);
    backdrop-filter: blur(14px);
    border: 2px solid rgba(0,0,0,0.08);
    border-radius: 20px;
    padding: 32px;
    transition: .25s ease-in-out;
}
.card:hover {
    transform: translateY(-5px);
    background: rgba(255, 255, 255, 0.70);
    border-color: rgba(0,0,0,0.20);
    box-shadow: 0 8px 22px rgba(0, 0, 0, 0.15);
}
input[type="date"] {
    width: 100%;
    padding: 1rem 1.5rem;
    font-size: 1.1rem;
    border-radius: 0.5rem;
    border: 1px solid #ccc;
    outline: none;
    height: 3.5rem;
    box-sizing: border-box;
}
input:focus {
    border-color: #7e22ce;
}
.result-box {
    background: #D8F3DC;
    border: 2px solid #95D5B2;
    border-radius: 14px;
    padding: 25px 30px;
    margin-top: 20px;
    white-space: pre-line;
    font-family: monospace;
    font-size: 18px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}
.error {
    color: #d90429;
    font-size: 16px;
    margin-top: 4px;
}
button {
    cursor: pointer;
}
button:disabled {
    background-color: #9ca3af;
    cursor: not-allowed;
    pointer-events: none;
}
</style>
</head>
<body>

<header class="py-10 text-center">
<h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
Task 8 - Holiday Calendar Highlighter
</h1>
<p class="text-gray-700 mt-3 text-xl">Select a date to check if it is a holiday</p>
<a href="../index.php" class="text-blue-800 underline mt-3 inline-block text-lg font-semibold">
    ← Back to Dashboard
</a>
</header>

<div class="max-w-4xl mx-auto px-6 pb-20">
<div class="card shadow-lg">
<form id="holidayForm" autocomplete="off" novalidate>

<label class="block mb-2 font-semibold text-gray-900 text-lg">
Select Date <span class="error-star">*</span>
</label>
<input type="date" id="holidayDate">
<p id="dateError" class="error"></p>

<div class="text-center mt-6">
<button type="submit" id="submitBtn" class="px-8 py-4 rounded-xl bg-purple-600 text-white text-xl font-semibold hover:bg-purple-700 transition" disabled>
Check Holiday
</button>
</div>

</form>

<div id="result" class="result-box" style="display:none;"></div>
</div>
</div>

<script>
$(document).ready(function(){

    // Focus on date field
    $("#holidayDate").focus();

    // Disable past dates
    const today = new Date().toISOString().split('T')[0];
    $("#holidayDate").attr('min', today);

    // Reset form and result on page load
    $("#holidayForm")[0].reset();
    $("#result").hide();
    $("#submitBtn").prop("disabled", true);

    // Predefined array of holidays (YYYY-MM-DD format)
    const holidays = [
        "2025-11-30", // Example Holiday
        "2025-12-07",
        "2025-12-14",
        "2025-12-21",
        "2025-12-25", // Christmas
        "2025-12-28"  
    ];

    // Enable button only if a date is selected
    $("#holidayDate").on("input", function(){
        if($(this).val() !== ''){
            $("#submitBtn").prop("disabled", false);
            $("#dateError").text('');
        } else {
            $("#submitBtn").prop("disabled", true);
        }
    });

    // On form submit
    $("#holidayForm").submit(function(e){
        e.preventDefault();
        $("#dateError").text('');
        $("#result").hide();

        let selectedDate = $("#holidayDate").val();

        // Validation
        if(selectedDate === ''){
            $("#dateError").text('Please select a date.');
            return;
        }

        // Check if selected date is in holidays array
        let isHoliday = holidays.includes(selectedDate);
        let displayText = `📅 Selected Date: ${selectedDate}\n──────────────────────────────\n`;

        if(isHoliday){
            displayText += "🎉 This date is a HOLIDAY!";
        } else {
            displayText += "✅ This date is NOT a holiday.";
        }

        $("#result").text(displayText).fadeIn();
    });
});
</script>

</body>
</html>
