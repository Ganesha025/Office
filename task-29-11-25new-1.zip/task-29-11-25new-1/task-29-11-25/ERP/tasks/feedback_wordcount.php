<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Feedback</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
body {
    background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
    font-family: "Inter", sans-serif;
    color: #2b2b2b;
    font-size: 18px;
}
.card {
    background: rgba(255, 255, 255, 0.55);
    backdrop-filter: blur(14px);
    border: 2px solid rgba(0,0,0,0.08);
    border-radius: 20px;
    padding: 32px;
    transition: .25s ease-in-out;
}
.card:hover {
    transform: translateY(-5px);
    background: rgba(255, 255, 255, 0.70);
    border-color: rgba(0,0,0,0.20);
    box-shadow: 0 8px 22px rgba(0, 0, 0, 0.15);
}
textarea {
    width: 100%;
    padding: 1rem 1.5rem;
    font-size: 1.1rem;
    border-radius: 0.5rem;
    border: 1px solid #ccc;
    outline: none;
    min-height: 150px;
    box-sizing: border-box;
}
textarea:focus {
    border-color: #7e22ce;
}
.result-box {
    background: #D8F3DC;
    border: 2px solid #95D5B2;
    border-radius: 14px;
    padding: 25px 30px;
    margin-top: 20px;
    white-space: pre-line;
    font-family: monospace;
    font-size: 18px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}
.error {
    color: #d90429;
    font-size: 16px;
    margin-top: 4px;
}
.error-star{
    color:red;
}
button {
    cursor: pointer;
}
button:disabled {
    background-color: #9ca3af; /* Disabled gray */
    cursor: not-allowed;
}
#feedback{
    padding:30px;
}
</style>
</head>
<body>

<header class="py-10 text-center">
<h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
Task 7 - Student Feedback Collector
</h1>
<p class="text-gray-700 mt-3 text-xl">Enter your feedback below</p>
<a href="../index.php" class="text-blue-800 underline mt-3 inline-block text-lg font-semibold">
    ← Back to Dashboard
</a>
</header>

<div class="max-w-4xl mx-auto px-6 pb-20">
<div class="card shadow-lg">
<form id="feedbackForm" autocomplete="off" novalidate>

<label class="block mb-2 font-semibold text-gray-900 text-lg">
Feedback <span class="error-star">*</span>
</label>
<textarea id="feedback" placeholder="Write your feedback here..."></textarea>
<p id="feedbackError" class="error"></p>

<div class="text-center mt-6">
<button type="submit" id="submitBtn" class="px-8 py-4 rounded-xl bg-purple-600 text-white text-xl font-semibold hover:bg-purple-700 transition" disabled>
Analyze Feedback
</button>
</div>

</form>

<div id="result" class="result-box" style="display:none;"></div>
</div>
</div>

<script>
$(document).ready(function(){

    // Focus on feedback field
    $("#feedback").focus();

    // Reset form and result on page load
    $("#feedbackForm")[0].reset();
    $("#result").hide();
    $("#submitBtn").prop("disabled", true);

    // Enable button only if textarea has content
    $("#feedback").on("input", function(){
        let val = $(this).val();

        // Restrict max 260 characters
        if(val.length > 260){
            val = val.substring(0,260);
            $(this).val(val);
        }

        if(val.trim().length >= 20){
            $("#submitBtn").prop("disabled", false);
            $("#feedbackError").text('');
        } else {
            $("#submitBtn").prop("disabled", true);
        }
    });

    // On form submit
    $("#feedbackForm").submit(function(e){
        e.preventDefault();
        $("#feedbackError").text('');
        $("#result").hide();

        let feedbackText = $("#feedback").val().trim();

        // Validation
        if(feedbackText.length < 20){
            $("#feedbackError").text('Feedback must be at least 20 characters.');
            return;
        }

        if(feedbackText.length > 260){
            $("#feedbackError").text('Feedback cannot exceed 260 characters.');
            return;
        }

        // Must contain at least one letter
        if(!/[A-Za-z]/.test(feedbackText)){
            $("#feedbackError").text('Feedback must contain at least one letter.');
            return;
        }

        // Count words, characters, lines
        let words = feedbackText.split(/\s+/).filter(w => w.length > 0).length;
        let chars = feedbackText.replace(/\s/g,'').length;
        let lines = feedbackText.split(/\n/).length;

        let resultText = 
`📊 Feedback Analysis 📊
──────────────────────────────
📝 Total Words      : ${words}
🔤 Total Characters : ${chars}
📄 Total Lines      : ${lines}
──────────────────────────────
Thank you for your feedback!`;

        $("#result").text(resultText).fadeIn();
    });
});
</script>

</body>
</html>
