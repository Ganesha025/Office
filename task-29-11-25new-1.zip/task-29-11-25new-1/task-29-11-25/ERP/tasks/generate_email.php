<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Task 3 - Generate College Email ID</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        body {
            background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
            font-family: "Inter", sans-serif;
            color: #2b2b2b;
            font-size: 18px;
        }
        .card {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(14px);
            border: 2px solid rgba(0,0,0,0.08);
            border-radius: 20px;
            padding: 32px;
            transition: .25s ease-in-out;
        }
        .card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.70);
            border-color: rgba(0,0,0,0.20);
            box-shadow: 0 8px 22px rgba(0, 0, 0, 0.15);
        }
        .result-box {
            background: #D8F3DC;
            border: 2px solid #95D5B2;
            border-radius: 14px;
        }
        .error {
            color: #d90429;
            font-size: 16px;
            margin-top: 4px;
        }
        .required-star {
            color: red;
            font-weight: bold;
        }
        /* Hide number input arrows */
        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { 
            -webkit-appearance: none; 
            margin: 0; 
        }
        input[type=number] {
            -moz-appearance: textfield;
        }
    </style>
</head>
<body>

    <!-- HEADER -->
    <header class="py-10 text-center">
        <h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
            Task 3 — Generate College Email ID
        </h1>
        <p class="text-gray-700 mt-3 text-xl">Enter student name and roll number to generate email</p>

        <a href="../index.php" class="text-blue-800 underline mt-3 inline-block text-lg font-semibold">
            ← Back to Dashboard
        </a>
    </header>

    <!-- MAIN CONTAINER -->
    <div class="max-w-2xl mx-auto px-6 pb-20">
        <div class="card shadow-lg">

            <!-- FORM -->
            <form id="emailForm" method="POST" autocomplete="off" novalidate>

                <!-- Student Name -->
                <label class="block mb-2 font-semibold text-gray-900 text-lg">
                    Student Name <span class="required-star">*</span>
                </label>
                <input type="text" id="student_name" name="student_name" 
                       placeholder="Enter student name" 
                       class="w-full px-5 py-3 rounded-lg border border-gray-500 shadow-sm outline-none focus:border-purple-600 mb-1" autofocus>
                <p id="nameError" class="error"></p>

                <!-- Roll Number -->
                <label class="block mb-2 font-semibold text-gray-900 text-lg mt-4">
                    Roll Number <span class="required-star">*</span>
                </label>
                <input type="number" id="roll_number" name="roll_number" 
                       placeholder="Enter roll number" 
                       class="w-full px-5 py-3 rounded-lg border border-gray-500 shadow-sm outline-none focus:border-purple-600 mb-1" min="1" max="99999">
                <p id="rollError" class="error"></p>

                <button type="submit" 
                        class="mt-6 px-8 py-4 rounded-xl bg-purple-600 text-white text-xl font-semibold hover:bg-purple-700 transition">
                    Generate Email
                </button>
            </form>

            <!-- RESULT -->
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $name = strtolower(trim($_POST["student_name"]));
                $roll = trim($_POST["roll_number"]);

                // Sanitize: only letters for name
                $name = preg_replace("/[^a-z]/", "", $name);

                $email = $name . $roll . "@vcw.com";

                echo "
                <div class='result-box mt-8 p-6'>
                    <h3 class='text-xl font-bold text-green-900'>Generated Email:</h3>
                    <p class='mt-3 text-green-800 text-lg'>
                        <span class='font-extrabold text-purple-700 text-2xl'>{$email}</span>
                    </p>
                </div>";
            }
            ?>

        </div>
    </div>

<script>
$(document).ready(function() {

    // Reset form and prevent result on refresh
    $("#emailForm")[0].reset();
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }

    // ----------- Name validation -----------
    $("#student_name").on("input", function () {
        let value = $(this).val();
        value = value.replace(/[^A-Za-z]/g,''); // only letters
        if (value.length > 15) value = value.substring(0,15);
        $(this).val(value);
        if (value.length > 0) $("#nameError").text('');
    });

    // ----------- Roll number validation -----------
    $("#roll_number").on("input", function () {
        let val = $(this).val();
        val = val.replace(/[^0-9]/g,''); // numbers only
        if (val.length > 5) val = val.substring(0,5);
        $(this).val(val);
        if (val.length > 0) $("#rollError").text('');
    });

    // ----------- Form submission validation -----------
    $("#emailForm").submit(function(e) {
        let isValid = true;
        $(".error").text("");

        let name = $("#student_name").val().trim();
        let roll = $("#roll_number").val().trim();

        if (name === "") {
            $("#nameError").text("Student name is required.");
            isValid = false;
        }
        if (roll === "" || isNaN(roll) || roll < 1 || roll > 99999) {
            $("#rollError").text("Enter a valid roll number (1-99999).");
            isValid = false;
        }

        if (!isValid) e.preventDefault();
    });

});
</script>

</body>
</html>
