<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Task 6 - Staff Salary Slip Generator</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
body {
    background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
    font-family: "Inter", sans-serif;
    color: #2b2b2b;
    font-size: 18px;
}
.card {
    background: rgba(255, 255, 255, 0.55);
    backdrop-filter: blur(14px);
    border: 2px solid rgba(0,0,0,0.08);
    border-radius: 20px;
    padding: 32px;
    transition: .25s ease-in-out;
}
.card:hover {
    transform: translateY(-5px);
    background: rgba(255, 255, 255, 0.70);
    border-color: rgba(0,0,0,0.20);
    box-shadow: 0 8px 22px rgba(0, 0, 0, 0.15);
}
.result-box {
    background: #D8F3DC;
    border: 2px solid #95D5B2;
    border-radius: 14px;
    padding: 25px 30px;
    margin-top: 20px;
    white-space: pre-line;
    font-family: monospace;
    font-size: 18px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}
.error {
    color: #d90429;
    font-size: 16px;
    margin-top: 4px;
}
.required-star {
    color: red;
    font-weight: bold;
    margin-left: 3px;
}
input {
    width: 100%;
    padding: 1rem 1.5rem;
    padding-left: 2rem;
    font-size: 1.1rem;
    border-radius: 0.5rem;
    border: 1px solid #ccc;
    outline: none;
    height: 3.5rem;
    box-sizing: border-box;
}
input:focus {
    border-color: #7e22ce;
}
button {
    cursor: pointer;
}
button:disabled {
    background-color: #9ca3af;
    cursor: not-allowed;
    pointer-events: none; 
}
#staff_name, #base_salary, #allowances, #deductions{
    padding: 30px;
}
</style>
</head>
<body>

<header class="py-10 text-center">
<h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
Task 6 — Staff Salary Slip Generator
</h1>
<p class="text-gray-700 mt-3 text-xl">Enter staff salary details</p>
<a href="../index.php" class="text-blue-800 underline mt-3 inline-block text-lg font-semibold">
    ← Back to Dashboard
</a>
</header>

<div class="max-w-4xl mx-auto px-6 pb-20">
<div class="card shadow-lg">
<form id="salaryForm" autocomplete="off" novalidate>

<label class="block mb-2 font-semibold text-gray-900 text-lg">
Staff Name <span class="required-star">*</span>
</label>
<input type="text" id="staff_name" placeholder="Enter staff name">
<p id="nameError" class="error"></p>

<label class="block mt-4 mb-2 font-semibold text-gray-900 text-lg">
Base Salary (10000 - 100000) <span class="required-star">*</span>
</label>
<input type="text" id="base_salary" placeholder="Enter base salary">
<p id="baseError" class="error"></p>

<label class="block mt-4 mb-2 font-semibold text-gray-900 text-lg">
Allowances (100 - 10000) <span class="required-star">*</span>
</label>
<input type="text" id="allowances" placeholder="Enter total allowances">
<p id="allowError" class="error"></p>

<label class="block mt-4 mb-2 font-semibold text-gray-900 text-lg">
Deductions (100 - 10000) <span class="required-star">*</span>
</label>
<input type="text" id="deductions" placeholder="Enter total deductions">
<p id="deductError" class="error"></p>

<div class="text-center mt-6">
<button type="submit" id="generateBtn" class="px-8 py-4 rounded-xl bg-purple-600 text-white text-xl font-semibold hover:bg-purple-700 transition" disabled>
Generate Salary Slip
</button>
</div>

</form>

<div id="result" class="result-box" style="display:none;"></div>
</div>
</div>

<script>
$(document).ready(function(){
    $("#salaryForm")[0].reset();
    $("#staff_name").focus();

    function toggleButton() {
        let staffName = $("#staff_name").val().trim();
        let base = $("#base_salary").val().trim();
        let allow = $("#allowances").val().trim();
        let deduct = $("#deductions").val().trim();
        if(staffName && base && allow && deduct) {
            $("#generateBtn").prop("disabled", false);
        } else {
            $("#generateBtn").prop("disabled", true);
        }
    }

    $("#staff_name").on("input", function(){
        let value = $(this).val().replace(/[^A-Za-z ]/g,'');
        if(value.length > 30) value = value.substring(0,30);
        $(this).val(value);
        $("#nameError").text('');
        toggleButton();
    });

    // function allowOnlyNumbers(inputId, min, max){
    //     const maxLength = max.toString().length;

    //     $("#" + inputId).on("input", function(){
    //         let val = $(this).val().replace(/\D/g,'');
    //         if(val.length > maxLength) val = val.substring(0, maxLength);
    //         $(this).val(val);
    //         toggleButton();
    //     });

    //     $("#" + inputId).on("blur", function(){
    //         let val = Number($(this).val());

    //         if(val < min) $(this).val(min);
    //         else if(val > max) $(this).val(max);

    //         toggleButton();
    //     });
    // }

    function allowOnlyNumbers(inputId, min, max){

    const maxLength = max.toString().length;

    $("#" + inputId).on("input", function(){
        let val = $(this).val().replace(/\D/g,'');

        if(val.length > maxLength) val = val.substring(0, maxLength);

        $(this).val(val);
        toggleButton();
    });

    $("#" + inputId).on("blur", function(){
        let raw = $(this).val().trim();

        // Keep empty fields empty
        if(raw === "") return;

        let val = Number(raw);

        if(val < min) val = min;
        if(val > max) val = max;

        $(this).val(val);
        toggleButton();
    });
}


    allowOnlyNumbers("base_salary", 10000, 100000);
    allowOnlyNumbers("allowances", 100, 10000);
    allowOnlyNumbers("deductions", 100, 10000);

    $("#salaryForm").submit(function(e){
        e.preventDefault();
        $(".error").text('');
        $("#result").hide();

        let staffName = $("#staff_name").val().trim();
        let base = Number($("#base_salary").val());
        let allow = Number($("#allowances").val());
        let deduct = Number($("#deductions").val());

        let isValid = true;

        if(staffName === "") { $("#nameError").text("This field is required."); isValid=false; }
        if(isNaN(base)) { $("#baseError").text("This field is required."); isValid=false; }
        if(isNaN(allow)) { $("#allowError").text("This field is required."); isValid=false; }
        if(isNaN(deduct)) { $("#deductError").text("This field is required."); isValid=false; }

        if(isValid){
            let finalSalary = base + allow - deduct;
            let resultText = 
`🎉 Staff Salary Slip 🎉
──────────────────────────────
👤 Staff Name   : ${staffName}
💰 Base Salary  : ₹${base.toFixed(2)}
🟢 Allowances   : ₹${allow.toFixed(2)}
🔴 Deductions   : ₹${deduct.toFixed(2)}
──────────────────────────────
✨ Final Salary : ₹${finalSalary.toFixed(2)}
──────────────────────────────
Generated on: ${new Date().toLocaleString()}`;
            $("#result").text(resultText).fadeIn();
        }
    });
});
</script>

</body>
</html>