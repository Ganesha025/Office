<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Faculty Teaching Hours Checker</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<style>
body {
    background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
    font-family: "Inter", sans-serif;
    color: #2b2b2b;
    font-size: 18px;
}
.card {
    background: rgba(255, 255, 255, 0.55);
    backdrop-filter: blur(14px);
    border: 2px solid rgba(0,0,0,0.08);
    border-radius: 20px;
    padding: 32px;
    transition: .25s ease-in-out;
    max-width: 570px;
    margin: 40px auto;
}
.card:hover {
    transform: translateY(-5px);
    background: rgba(255, 255, 255, 0.70);
    border-color: rgba(0,0,0,0.20);
    box-shadow: 0 8px 22px rgba(0, 0, 0, 0.15);
}
h1 {
    text-align:center;
    font-size:2.5rem;
    font-weight:800;
    background: linear-gradient(90deg, #f43f5e, #9333ea, #14b8a6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 25px;
}
label {
    font-weight:600;
    margin-bottom:6px;
}
select, input {
    width:100%;
    padding:1rem 1.5rem;
    font-size:1.1rem;
    border-radius:0.5rem;
    border:1px solid #ccc;
    outline:none;
    height:3.5rem;
    box-sizing:border-box;
}
select:focus, input:focus {
    border-color:#7e22ce;
}
.required-star {
    color:red;
    font-weight:bold;
    margin-left:3px;
}
.error {
    color:#d90429;
    font-size:16px;
    min-height:20px; /* reserve space to keep alignment */
    margin-top:4px;
}
.btn {
    width:100%;
    padding:12px;
    background:#9333ea;
    color:white;
    border:none;
    border-radius:12px;
    margin-top:25px;
    font-size:1.2rem;
    font-weight:600;
    cursor:pointer;
    transition:.25s;
}
.btn:hover {
    background:#7e22ce;
}
.result-box {
    background: #D8F3DC;
    border: 2px solid #95D5B2;
    border-radius: 14px;
    padding:25px 30px;
    margin-top:20px;
    white-space: pre-line;
    font-family: monospace;
    font-size: 18px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    display:none;
}
/* Flex rows */
.flex-row {
    display: flex;
    gap: 15px;
    margin-top: 15px;
}
.flex-row .day-block {
    flex: 1;
    display: flex;
    flex-direction: column;
}
.header-text-center {
    text-align: center;
}
.header-text-center a {
    display: inline-block; /* keep proper spacing */
    margin-top: 8px;       /* small spacing from the text */
}

</style>
</head>
<body>

<div class="header-text-center">
<header class="py-10 text-center">
<h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
Task 14 - Faculty Teaching Hours Checker
</h1>
<p class="text-gray-700 text-xl mt-3">Checking Teaching Hours of Faculty</p>
<a href="../index.php" class="text-blue-800 underline mt-3 inline-block text-lg font-semibold ">← Back to Dashboard</a>
</header>
</div>


<div class="card">


    <form id="hoursForm" autocomplete="off">

        <!-- Staff Name -->
        <label>Staff Name <span class="required-star">*</span></label>
        <input type="text" id="staff_name" name="staff_name" placeholder="Enter staff name" autofocus>
        <div id="nameError" class="error"></div>

        <script>
            const days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
        </script>

        <div id="daysContainer"></div>

        <button type="submit" class="btn">Check Hours</button>
    </form>

    <div id="result" class="result-box"></div>
</div>

<script>
$(document).ready(function(){

    // Create two rows of 3 dropdowns each
    let firstRow = $('<div class="flex-row"></div>');
    let secondRow = $('<div class="flex-row"></div>');

    days.forEach((day,index)=>{
        let html = `<div class="day-block">
                        <label>${day} Hours <span class="required-star">*</span></label>
                        <select id="${day.toLowerCase()}" name="${day.toLowerCase()}">
                            <option value="">Select Hours</option>`;
        for(let i=0;i<=5;i++){
            html += `<option value="${i}">${i}</option>`;
        }
        html += `</select>
                 <div id="${day.toLowerCase()}Error" class="error"></div>
                 </div>`;
        if(index<3) firstRow.append(html);
        else secondRow.append(html);
    });
    $("#daysContainer").append(firstRow).append(secondRow);

    // Reset form
    $("#hoursForm")[0].reset();
    $("#result").hide();
    $(".error").text("");
    $("#staff_name").focus();

    // Staff name validation
    $("#staff_name").on("input", function(){
        let val = $(this).val().replace(/[^A-Za-z ]/g,'');
        if(val.length>30) val = val.substring(0,30);
        $(this).val(val);
        $("#nameError").text('');
    });

    // Select change validation
    $("select").on("change", function(){
        let id = $(this).attr("id");
        if($(this).val() !== "") $("#"+id+"Error").text('');
    });

    // Form submission
    $("#hoursForm").submit(function(e){
        e.preventDefault();
        let valid = true;
        $(".error").text('');
        $("#result").hide();

        let staffName = $("#staff_name").val().trim();
        if(staffName === ""){
            $("#nameError").text("Staff name is required.");
            valid = false;
        }

        let totalHours = 0;
        days.forEach(day=>{
            let val = parseInt($("#"+day.toLowerCase()).val());
            if(isNaN(val)){
                $("#"+day.toLowerCase()+"Error").text("This field is required");
                valid = false;
            } else {
                totalHours += val;
            }
        });

        if(valid){
            let limit = 20;
            let status = (totalHours>limit) ? "❌ Limit Exceeded!" : "✔️ Within Limit";
            let output = `Staff: ${staffName}\nWeekly Hours: ${totalHours}\n${status}`;
            $("#result").text(output).fadeIn();
        }
    });
});
</script>

</body>
</html>
