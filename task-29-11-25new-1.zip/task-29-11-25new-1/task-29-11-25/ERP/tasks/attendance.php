<?php
// Start the session to store result temporarily
session_start();

// Initialize variables
$name = "";
$percentage = null;

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["student_name"]);
    $attendanceArray = [];

    for ($i = 1; $i <= 7; $i++) {
        $attendanceArray[] = $_POST["day$i"];
    }

    function calculateAttendance($arr) {
        $total = count($arr);
        $present = array_count_values($arr)["P"] ?? 0;
        return round(($present / $total) * 100, 2);
    }

    $percentage = calculateAttendance($attendanceArray);

    // Store result in session and redirect to clear POST
    $_SESSION['result'] = [
        'name' => $name,
        'percentage' => $percentage
    ];

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Retrieve result if exists and clear session
if (isset($_SESSION['result'])) {
    $result = $_SESSION['result'];
    unset($_SESSION['result']);
} else {
    $result = null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Task 1 - Student Attendance Percentage</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        body {
            background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
            font-family: "Inter", sans-serif;
            color: #2b2b2b;
            font-size: 18px;
        }

        .card {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(14px);
            border: 2px solid rgba(0,0,0,0.08);
            border-radius: 20px;
            padding: 32px;
            transition: .25s ease-in-out;
        }

        .card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.70);
            border-color: rgba(0,0,0,0.20);
            box-shadow: 0 8px 22px rgba(0, 0, 0, 0.15);
        }

        .result-box {
            background: #D8F3DC;
            border: 2px solid #95D5B2;
            border-radius: 14px;
        }

        .error {
            color: #d90429;
            font-size: 16px;
            margin-top: 4px;
        }

        .required-star {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

<header class="py-10 text-center">
    <h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
        Task 1 — Student Attendance Percentage
    </h1>
    <p class="text-gray-700 mt-3 text-xl">Mark attendance for 7 days using P/A</p>

    <a href="../index.php" class="text-blue-800 underline mt-3 inline-block text-lg font-semibold">
        ← Back to Dashboard
    </a>
</header>

<div class="max-w-2xl mx-auto px-6 pb-20">
    <div class="card shadow-lg">
        <form id="attendanceForm" method="POST" autocomplete="off" novalidate>
            <label class="block mb-2 font-semibold text-gray-900 text-lg">
                Student Name <span class="required-star">*</span>
            </label>
            <input id="student_name" name="student_name" placeholder="Enter student name" class="w-full val-username px-5 py-3 rounded-lg border border-gray-500 shadow-sm outline-none focus:border-purple-600 mb-1">
            <p id="nameError" class="error"></p>

            <h3 class="font-bold mb-4 text-gray-900 text-xl mt-6">
                Mark Attendance for 7 Days <span class="required-star">*</span>
            </h3>

            <?php 
            for ($i = 1; $i <= 7; $i++) {
                echo "
                <div class='mb-4'>
                    <label class='font-semibold text-gray-900'>Day $i <span class=\"required-star\">*</span>:</label>
                    <label class='ml-6 text-lg'>
                        <input type='radio' name='day$i' value='P' class='day-radio'>
                        <span class='ml-1 font-medium text-green-700'>Present (P)</span>
                    </label>
                    <label class='ml-6 text-lg'>
                        <input type='radio' name='day$i' value='A' class='day-radio'>
                        <span class='ml-1 font-medium text-red-700'>Absent (A)</span>
                    </label>
                    <p id='day{$i}Error' class='error'></p>
                </div>";
            }
            ?>

            <button type="submit" class="mt-6 px-8 py-4 rounded-xl bg-purple-600 text-white text-xl font-semibold hover:bg-purple-700 transition">
                Calculate Attendance
            </button>
        </form>

        <!-- RESULT -->
        <?php if ($result): ?>
            <div class='result-box mt-8 p-6'>
                <h3 class='text-xl font-bold text-green-900'>
                    Result for <span class='text-purple-700'><?= htmlspecialchars($result['name']) ?></span>:
                </h3>
                <p class='mt-3 text-green-800 text-lg'>
                    Attendance Percentage:
                    <span class='font-extrabold text-green-900 text-2xl'><?= $result['percentage'] ?>%</span>
                </p>
            </div>
        <?php endif; ?>

    </div>
</div>

<script>
$(document).ready(function () {

    $("#student_name").focus();
    // Reset form on page load
    $("#attendanceForm")[0].reset();

    // Live clear name error
    $("#student_name").on("input", function () {
    let value = $(this).val();

    // Remove any characters that are not letters or spaces
    value = value.replace(/[^A-Za-z ]/g, '');

    // Limit to 15 characters
    if (value.length > 15) {
        value = value.substring(0, 15);
    }

    $(this).val(value);

    // Clear error if valid
    if (value.length > 0) {
        $("#nameError").text("");
    }
});


    // Live clear radio errors
    $("input[type=radio]").on("change", function () {
        let dayName = $(this).attr("name");
        let dayNumber = dayName.replace("day", "");
        $("#day" + dayNumber + "Error").text("");
    });

    // Form validation
    $("#attendanceForm").submit(function (e) {
        let isValid = true;
        $(".error").text("");

        let name = $("#student_name").val().trim();
        let regex = /^[A-Za-z ]+$/;
        if (name === "") {
            $("#nameError").text("Student name is required.");
            isValid = false;
        } else if (!regex.test(name)) {
            $("#nameError").text("Name can only contain letters and spaces.");
            isValid = false;
        }

        for (let i = 1; i <= 7; i++) {
            if (!$(`input[name='day${i}']:checked`).val()) {
                $(`#day${i}Error`).text("Please select attendance for Day " + i);
                isValid = false;
            }
        }

        if (!isValid) e.preventDefault();
    });
});
</script>

</body>
</html>
