<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SMS Template Formatter</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
body {
    background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
    font-family: "Inter", sans-serif;
    font-size: 18px;
    color: #2b2b2b;
}
.card {
    background: rgba(255,255,255,0.55);
    border-radius: 20px;
    padding: 40px;
    max-width: 650px;
    margin: 0 auto;
    border: 2px solid rgba(0,0,0,0.08);
    backdrop-filter: blur(14px);
}
.card:hover {
    background: rgba(255,255,255,0.7);
    transform: translateY(-5px);
}
input {
    width: 100%;
    padding-left:30px;
    border-radius: 10px;
    border: 1px solid #ccc;
    height: 3.3rem;
    font-size: 18px;
}
#name,#amount{
    padding-left:30px;
}
label {
    margin-bottom: 6px;
    display: inline-block;
}
.error {
    color: red;
    font-size: 15px;
    margin-top: 6px;
}
.result-box {
    background: #D8F3DC;
    padding: 30px;
    border-radius: 14px;
    margin-top: 28px;
    border: 2px solid #95D5B2;
    font-family: monospace;
    white-space: pre-line;
    text-align: center;
}
.error-star { color: red; }
</style>
</head>

<body>

<header class="py-10 text-center">
    <h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 
        text-transparent bg-clip-text">
        SMS Template Formatter
    </h1>
    <p class="text-gray-700 mt-4 text-xl">Generate SMS with actual values</p>
    <a href="../index.php" class="text-blue-800 underline mt-4 inline-block text-lg font-semibold">
        ← Back to Dashboard
    </a>
</header>

<div class="card mt-8">
<form id="smsForm" autocomplete="off">

    <!-- Name -->
    <div class="mt-2">
        <label class="font-semibold">Name <span class="error-star">*</span></label>
        <input type="text" id="name" placeholder="Enter name" autofocus>
        <p class="error" id="nameError"></p>
    </div>

    <!-- Amount -->
    <div class="mt-6">
        <label class="font-semibold">Amount <span class="error-star">*</span></label>
        <input type="text" id="amount" placeholder="Enter amount">
        <p class="error" id="amountError"></p>
    </div>

    <div class="text-center mt-10">
        <button type="submit" class="px-10 py-4 rounded-xl bg-purple-600 text-white
            text-xl font-semibold hover:bg-purple-700 transition">
            Generate SMS
        </button>
    </div>

</form>

<div id="result" class="result-box" style="display:none;"></div>
</div>

<script>
$(document).ready(function(){

    // Reset form & result on page load
    $("#smsForm")[0].reset();
    $("#result").hide();
    $(".error").text("");

    // ----------------------------
    // VALIDATIONS
    // ----------------------------
    function validateName(){
        let name = $("#name").val().trim();

        if(name === ""){
            $("#nameError").text("This field is required");
            return false;
        }
        if(!/^[A-Za-z ]+$/.test(name)){
            $("#nameError").text("Only letters and spaces allowed");
            return false;
        }
        if(name.length > 15){
            $("#nameError").text("Max 15 characters allowed");
            return false;
        }

        $("#nameError").text("");
        return true;
    }

    function validateAmount(){
        let amt = $("#amount").val().trim();
        if(amt === ""){
            $("#amountError").text("This field is required");
            return false;
        }
        if(isNaN(amt) || Number(amt) < 1 || Number(amt) > 100000){
            $("#amountError").text("Enter amount between 1 and 100000");
            return false;
        }
        $("#amountError").text("");
        return true;
    }

    // Live input restrictions
    $("#name").on("input", function(){
        let val = $(this).val().replace(/[^A-Za-z ]/g, "");
        if(val.length > 15) val = val.substring(0,15);
        $(this).val(val);
        validateName();
    });

    $("#amount").on("input", function(){
        let val = $(this).val().replace(/[^0-9]/g,"");
        if(val !== "" && Number(val) > 100000) val = "100000";
        $(this).val(val);
        validateAmount();
    });

    // Clear error on valid input
    $("#name").on("input", validateName);
    $("#amount").on("input", validateAmount);

    // ----------------------------
    // FORM SUBMIT
    // ----------------------------
    $("#smsForm").submit(function(e){
        e.preventDefault();

        let validName = validateName();
        let validAmount = validateAmount();

        if(!validName || !validAmount){
            $("#result").hide();
            return;
        }

        let name = $("#name").val().trim();
        let amount = $("#amount").val().trim();

        // SMS template
        let template = "Hi {name}, your fee due is {amount}.";
        let sms = template.replace("{name}", name).replace("{amount}", amount);

        $("#result").text(sms).fadeIn();
    });

});
</script>

</body>
</html>
