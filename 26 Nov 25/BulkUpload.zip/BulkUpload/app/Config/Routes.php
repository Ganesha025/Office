<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
 $routes->get('/', 'StudentController::index');
 $routes->get('/reports', 'StudentController::indexes');
 $routes->post('students/upload', 'StudentController::uploadCSV');
 $routes->post('students/upload', 'StudentController::uploadCSV');
 $routes->post('uploadCSVUnique', 'StudentController::uploadCSVUniquePages');