<?php

namespace App\Controllers;

use App\Models\StudentModel;

class StudentController extends BaseController
{
    // 1️⃣ Show report page with students
    public function index(){
        $model = new StudentModel();
        $data['students'] = $model->findAll();
        return view('report',$data);
    }
public function indexes(){
        $model = new StudentModel();
        $data['students'] = $model->findAll();
        return view('task6',$data);
    }

    // 2️⃣ Handle CSV Upload
    public function uploadCSV()
    {
        $model = new StudentModel();
        $file = $this->request->getFile('csv_file');

        // 2a. Check if file exists
        if (!$file || !$file->isValid()) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'No file uploaded'
            ]);
        }

        // 2b. Check file type (must be CSV)
        if ($file->getClientExtension() !== 'csv') {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Invalid File Type. Only CSV allowed.'
            ]);
        }

        // 2c. Move file to writable/uploads
        $filePath = WRITEPATH . 'uploads/' . $file->store();

        $successCount = 0;
        $invalidRows = 0;
        $insertData = [];

        try {
            // 3️⃣ Open CSV
            if (($handle = fopen($filePath, "r")) !== FALSE) {
                $rowNumber = 0;

                while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                    $rowNumber++;

                    // Skip header
                    if ($rowNumber === 1) {
                        // Optional: normalize header
                        $header = array_map('strtolower', $data);
                        continue;
                    }

                    // Must have at least 3 columns
                    if (count($data) >= 3) {
                        $rowAssoc = array_combine($header, $data);

                        // Basic validation
                        if (!empty($rowAssoc['name']) && !empty($rowAssoc['email'])) {
                            $insertData[] = [
                                'name'  => $rowAssoc['name']??'' ,
                                'email' => $rowAssoc['email']??'' ,
                                'phone' => $rowAssoc['phone'] ?? 'nil',
                                'mark' => $rowAssoc['mark'] ?? 0 
                            ];
                            $successCount++;
                        } else {
                            $invalidRows++;
                        }
                    } else {
                        $invalidRows++;
                    }
                }
                fclose($handle);
            }

            // 4️⃣ Insert batch into database
            if (!empty($insertData)) {
                $model->insertBatch($insertData);
            }
            if (file_exists($filePath)) {
                unlink($filePath);
            }

            // 6️⃣ Return JSON response
            $message = "$successCount students uploaded successfully.";
            if ($invalidRows > 0) {
                $message .= " (Skipped $invalidRows invalid rows)";
            }

            return $this->response->setJSON([
                'status' => 'success',
                'message' => $message
            ]);

        } catch (\Exception $e) {
            // Catch any error and return JSON
            if (file_exists($filePath)) unlink($filePath);

            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Upload failed: ' . $e->getMessage(),
                'redirect'=> '/reports'
            ]);
        }
    }

    // 2️⃣b. Handle CSV Upload with Duplicate Prevention
// 2️⃣b. Handle CSV Upload with Duplicate Prevention
public function uploadCSVUnique(){
    $model = new StudentModel();
    $file = $this->request->getFile('csv_file');

    // Check if file exists
    if (!$file || !$file->isValid()) {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'No file uploaded'
        ]);
    }

    // Check file type (must be CSV)
    if ($file->getClientExtension() !== 'csv') {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Invalid File Type. Only CSV allowed.'
        ]);
    }

    // Move file to writable/uploads
    $filePath = WRITEPATH . 'uploads/' . $file->store();

    $successCount = 0;
    $invalidRows = 0;
    $duplicateRows = 0;
    $insertData = [];

    try {
        // Open CSV
        if (($handle = fopen($filePath, "r")) !== FALSE) {
            $rowNumber = 0;

            // Fetch existing emails from DB to prevent duplicates
            $existingEmails = $model->select('email')->findColumn('email');
            $existingEmails = array_map('strtolower', $existingEmails);

            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $rowNumber++;

                // Skip header
                if ($rowNumber === 1) {
                    $header = array_map('strtolower', $data);
                    continue;
                }

                if (count($data) >= 3) {
                    $rowAssoc = array_combine($header, $data);
                    $emailLower = strtolower($rowAssoc['email'] ?? '');

                    // Basic validation + duplicate check
                    if (!empty($rowAssoc['name']) && !empty($rowAssoc['email'])) {
                        if (!in_array($emailLower, $existingEmails)) {
                           $insertData[] = [
                    'name'  => trim($rowAssoc['name']),
                    'email' => $emailLower,
                    'phone' => trim($rowAssoc['phone'] ?? ''),
                    'mark'  => (int)($rowAssoc['mark'] ?? 0)
                ];
                            $existingEmails[] = $emailLower; // add to existing emails
                            $successCount++;
                        } else {
                            $duplicateRows++;
                        }
                    } else {
                        $invalidRows++;
                    }
                } else {
                    $invalidRows++;
                }
            }
            fclose($handle);
        }

        // Insert batch into DB
        if (!empty($insertData)) {
            $model->insertBatch($insertData);
        }
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Prepare message
        $message = "$successCount students uploaded successfully.";
        if ($duplicateRows > 0) {
            $message .= " (Skipped $duplicateRows duplicate email(s))";
        }
        if ($invalidRows > 0) {
            $message .= " (Skipped $invalidRows invalid row(s))";
        }

        return $this->response->setJSON([
            'status' => 'success',
            'message' => $message
        ]);

    } catch (\Exception $e) {
        if (file_exists($filePath)) unlink($filePath);

        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Upload failed: ' . $e->getMessage(),
            'redirect'=> '/reports'
        ]);
    }
}
public function uploadCSVUniquePages() {
    $model = new StudentModel();
    $file = $this->request->getFile('csv_file');

    if (!$file || !$file->isValid()) {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'No file uploaded'
        ]);
    }

    $ext = strtolower($file->getClientExtension());
    if ($ext !== 'csv') {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Invalid File Type. Only CSV allowed.'
        ]);
    }

    $filePath = WRITEPATH . 'uploads/' . $file->store();

    $successCount = 0;
    $updatedCount = 0;
    $invalidRows = 0;
    $insertData = [];

    try {
        if (($handle = fopen($filePath, "r")) !== FALSE) {
            $rowNumber = 0;

            // Fetch existing students from DB
            $existingRecords = $model->findAll();
            $existingEmails = [];
            foreach ($existingRecords as $rec) {
                $existingEmails[strtolower($rec['email'])] = $rec; // key=email
            }

            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $rowNumber++;

                if ($rowNumber === 1) {
                    $header = array_map('strtolower', $data);
                    continue;
                }

                if (count($data) < 2) {
                    $invalidRows++;
                    continue;
                }

                $rowAssoc = array_combine($header, $data);
                $name = trim($rowAssoc['name'] ?? '');
                $email = strtolower(trim($rowAssoc['email'] ?? ''));
                $mark = isset($rowAssoc['mark']) ? (int)$rowAssoc['mark'] : 0;

                if (empty($name) || empty($email)) {
                    $invalidRows++;
                    continue;
                }

                if (isset($existingEmails[$email])) {
                    // Update only the mark field if different
                    $existingRecord = $existingEmails[$email];
                    if ($existingRecord['mark'] != $mark) {
                        $model->update($existingRecord['id'], ['mark' => $mark]);
                        $updatedCount++;
                    }
                } else {
                    // New student record
                    $insertData[] = [
                        'name'  => $name,
                        'email' => $email,
                        'phone' => trim($rowAssoc['phone'] ?? ''),
                        'mark'  => $mark
                    ];
                    $successCount++;
                }
            }

            fclose($handle);
        }

        if (!empty($insertData)) {
            $model->insertBatch($insertData);
        }

        if (file_exists($filePath)) unlink($filePath);

        $message = "$successCount new students added successfully.";
        if ($updatedCount > 0) $message .= " ($updatedCount existing students' marks updated)";
        if ($invalidRows > 0) $message .= " ($invalidRows invalid row(s) skipped)";

        return $this->response->setJSON([
            'status' => 'success',
            'message' => $message
        ]);

    } catch (\Exception $e) {
        if (file_exists($filePath)) unlink($filePath);

        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Upload failed: ' . $e->getMessage(),
            'redirect' => '/reports'
        ]);
    }
}


}
