<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Report</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<style>
body{font-family:ui-sans-serif,system-ui,sans-serif}
.dataTables_wrapper .dataTables_length select{padding:4px 8px;border:1px solid #e5e7eb;border-radius:6px}
.dataTables_wrapper .dataTables_filter input{padding:6px 12px;border:1px solid #e5e7eb;border-radius:6px;margin-left:8px}
.dataTables_wrapper .dataTables_paginate .paginate_button{padding:6px 12px;margin:0 2px;border-radius:6px}
.dataTables_wrapper .dataTables_paginate .paginate_button.current{background:#1f2937;color:#fff!important}
#studentsTable{border-collapse:separate;border-spacing:0}
#studentsTable thead th{background:#1f2937;color:#fff;padding:16px;font-weight:600;text-align:left;border:none}
#studentsTable tbody td{padding:16px;border-bottom:1px solid #e5e7eb}
#studentsTable tbody tr:hover{background:#f9fafb}
.file-upload-wrapper{position:relative;overflow:hidden;display:inline-block;width:100%}
.file-upload-wrapper input[type=file]{position:absolute;left:-9999px}
.file-label{display:flex;align-items:center;justify-content:center;padding:48px;border:2px dashed #d1d5db;border-radius:12px;cursor:pointer;transition:all 0.3s;background:#fafafa}
.file-label:hover{border-color:#6b7280;background:#f3f4f6}
.file-label.active{border-color:#1f2937;background:#f9fafb}
</style>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
</head>
<body class="bg-gray-50 min-h-screen">

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
<div class="mb-8">
</div>

<div id="messageBox" class="hidden mb-6 p-4 rounded-lg text-white text-center font-medium"></div>

<div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sm:p-8 mb-8">
<h2 class="text-xl font-semibold text-gray-900 mb-6">Upload CSV File</h2>
<form id="uploadForm" enctype="multipart/form-data">
<div class="file-upload-wrapper mb-6">
<input type="file" name="csv_file" id="csv_file" required accept=".csv" >
<label for="csv_file" class="file-label" id="fileLabel">
<div class="text-center">
<svg class="mx-auto h-12 w-12 text-gray-400 mb-3" stroke="currentColor" fill="none" viewBox="0 0 48 48"><path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
<p class="text-sm font-medium text-gray-700 mb-1">Click to upload CSV file</p>
<p class="text-xs text-gray-500">or drag and drop</p>
</div>
</label>
</div>
<button type="submit" id="submitBtn" class="w-full sm:w-auto px-8 py-3 bg-gray-900 text-white font-medium rounded-lg hover:bg-gray-800 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed">Upload File</button>
</form>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sm:p-8">
<h3 class="text-xl font-semibold text-gray-900 mb-6">Student Records</h3>
<div class="overflow-x-auto">
<table id="studentsTable" class="display w-full">
<thead>
<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Phone</th>
</tr>
</thead>
<tbody id="studentsTableBody">
<?php if(!empty($students)):?>
<?php foreach($students as $student):?>
<tr>
<td><?=esc($student['id'])?></td>
<td><?=esc($student['name'])?></td>
<td><?=esc($student['email'])?></td>
<td><?=esc($student['phone'])?></td>
</tr>
<?php endforeach;?>
<?php else:?>
<tr>
<td colspan="4" class="text-center text-gray-500">No students found.</td>
</tr>
<?php endif;?>
</tbody>
</table>
</div>
</div>
</div>

<script>
$(document).ready(function(){
$('#studentsTable').DataTable({pageLength:10,lengthMenu:[5,10,25,50],ordering:true,searching:true,info:true});
});

const fileInput=document.getElementById('csv_file');
const fileLabel=document.getElementById('fileLabel');
fileInput.addEventListener('change',function(){
if(this.files.length>0){
fileLabel.innerHTML=`<div class="text-center"><svg class="mx-auto h-12 w-12 text-green-500 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg><p class="text-sm font-medium text-gray-700">${this.files[0].name}</p><p class="text-xs text-gray-500 mt-1">Ready to upload</p></div>`;
fileLabel.classList.add('active');
}
});

document.getElementById('uploadForm').addEventListener('submit',function(e){
e.preventDefault();
var formData=new FormData(this);
var messageBox=document.getElementById('messageBox');
var submitBtn=document.getElementById('submitBtn');
submitBtn.disabled=true;
submitBtn.innerText="Uploading...";
messageBox.classList.add('hidden');
fetch('<?=base_url("students/upload")?>',{method:'POST',body:formData})
.then(r=>r.json())
.then(d=>{
messageBox.classList.remove('hidden');
messageBox.innerText=d.message;
if(d.status==="success"){
messageBox.classList.add('bg-green-600');
messageBox.classList.remove('bg-red-600');
setTimeout(()=>window.location.reload(),2000);
}else{
messageBox.classList.add('bg-red-600');
messageBox.classList.remove('bg-green-600');
}
submitBtn.disabled=false;
submitBtn.innerText="Upload File";
})
.catch(()=>{
messageBox.classList.remove('hidden');
messageBox.classList.add('bg-red-600');
messageBox.classList.remove('bg-green-600');
messageBox.innerText="Upload failed";
submitBtn.disabled=false;
submitBtn.innerText="Upload File";
});
});
</script>

</body>
</html>
