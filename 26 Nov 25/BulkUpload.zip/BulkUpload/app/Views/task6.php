<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Upload (Unique)</title>

<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

<style>
body{font-family:ui-sans-serif,system-ui,sans-serif}
.dataTables_wrapper .dataTables_length select{padding:4px 8px;border:1px solid #e5e7eb;border-radius:6px}
.dataTables_wrapper .dataTables_filter input{padding:6px 12px;border:1px solid #e5e7eb;border-radius:6px;margin-left:8px}
.dataTables_wrapper .dataTables_paginate .paginate_button{padding:6px 12px;margin:0 2px;border-radius:6px}
.dataTables_wrapper .dataTables_paginate .paginate_button.current{background:#1f2937;color:#fff!important}
#studentsTable{border-collapse:separate;border-spacing:0}
#studentsTable thead th{background:#1f2937;color:#fff;padding:16px;font-weight:600;text-align:left;border:none}
#studentsTable tbody td{padding:16px;border-bottom:1px solid #e5e7eb}
#studentsTable tbody tr:hover{background:#f9fafb}
.file-upload-wrapper{position:relative;overflow:hidden;width:100%}
.file-upload-wrapper input[type=file]{position:absolute;left:-9999px}
.file-label{display:flex;align-items:center;justify-content:center;padding:48px;border:2px dashed #d1d5db;border-radius:12px;cursor:pointer;transition:.3s;background:#fafafa}
.file-label:hover{border-color:#6b7280;background:#f3f4f6}
.file-label.active{border-color:#1f2937}
</style>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/xlsx/dist/xlsx.full.min.js"></script>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
</head>

<body class="bg-gray-50 min-h-screen">

<div class="max-w-7xl mx-auto px-4 py-10">
<header class="flex items-center justify-between mb-10">

  <div>
    <h1 class="text-2xl font-semibold text-gray-900">Student Records</h1>
    <p class="text-sm text-gray-500 mt-1">Manage uploads and exports</p>
  </div>

  <div class="flex items-center gap-4">

    <!-- Download Template -->
    <div class="relative group">
      <a href="<?= base_url('template/template.xls')?>" download
         class="w-11 h-11 flex items-center justify-center rounded-xl border border-gray-300
                bg-white shadow-sm hover:shadow-md hover:border-gray-400 transition active:scale-95">
        <span class="material-icons-outlined text-gray-700">
          file_download
        </span>
      </a>
      <div class="absolute -top-10 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition
                  bg-gray-900 text-white text-xs px-3 py-1 rounded-lg whitespace-nowrap shadow-lg">
        Download Template
      </div>
    </div>

    <!-- Download Report -->
    <div class="relative group">
      <a href="<?= base_url('students/export/pdf') ?>"
         class="w-11 h-11 flex items-center justify-center rounded-xl border border-gray-300
                bg-white shadow-sm hover:shadow-md hover:border-gray-400 transition active:scale-95">
        <span class="material-icons-outlined text-gray-700">
          picture_as_pdf
        </span>
      </a>
      <div class="absolute -top-10 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition
                  bg-gray-900 text-white text-xs px-3 py-1 rounded-lg whitespace-nowrap shadow-lg">
        Download Report (PDF)
      </div>
    </div>

    <!-- Download History -->
    <div class="relative group">
      <a href="<?= base_url('students/download/history') ?>"
         class="w-11 h-11 flex items-center justify-center rounded-xl border border-gray-300
                bg-white shadow-sm hover:shadow-md hover:border-gray-400 transition active:scale-95">
        <span class="material-icons-outlined text-gray-700">
          history
        </span>
      </a>
      <div class="absolute -top-10 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition
                  bg-gray-900 text-white text-xs px-3 py-1 rounded-lg whitespace-nowrap shadow-lg">
        Download History
      </div>
    </div>

  </div>
</header>

<div id="messageBox" class="hidden mb-6 p-4 rounded-lg text-white text-center font-medium"></div>

<div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mb-10">
<h2 class="text-xl font-semibold text-gray-900 mb-6">Upload Unique Students CSV</h2>

<form id="uploadForm" enctype="multipart/form-data">
<div class="file-upload-wrapper mb-6">
<input type="file" name="csv_file" id="csv_file" required>
<label for="csv_file" class="file-label" id="fileLabel">
<div class="text-center">
<svg class="mx-auto h-12 w-12 text-gray-400 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M7 10l5-5 5 5M12 5v12"/>
</svg>
<p class="text-sm font-medium text-gray-700">Click to upload CSV</p>
<p class="text-xs text-gray-500">Duplicates will be skipped</p>
</div>
</label>
</div>

<button type="submit" id="submitBtn" class="px-8 py-3 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition disabled:opacity-50">
Upload File
</button>
</form>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
<h3 class="text-xl font-semibold text-gray-900 mb-6">Student Records</h3>

<div class="overflow-x-auto">
<table id="studentsTable" class="display w-full">
<thead>
<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Phone</th>
<th>mark</th>

</tr>
</thead>
<tbody>
<?php if(!empty($students)): ?>
<?php foreach($students as $s): ?>
<tr>
<td><?= esc($s['id']) ?></td>
<td><?= esc($s['name']) ?></td>
<td><?= esc($s['email']) ?></td>
<td><?= esc($s['phone']) ?></td>
<td><?= esc($s['mark']) ?></td>
</tr>
<?php endforeach ?>
<?php else: ?>
<tr>
<td colspan="4" class="text-center text-gray-500">No data available</td>
</tr>
<?php endif ?>
</tbody>
</table>
</div>
</div>

</div>
<script>
const fileInput = document.getElementById('csv_file');
const fileLabel = document.getElementById('fileLabel');

fileInput.addEventListener('change', () => {
  const file = fileInput.files[0];
  if (!file) return;

  const ext = file.name.split('.').pop().toLowerCase();

  if (ext === 'xls' || ext === 'xlsx') {
    const reader = new FileReader();

    reader.onload = e => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const csv = XLSX.utils.sheet_to_csv(worksheet);

      const csvBlob = new Blob([csv], { type: 'text/csv' });
      const csvFile = new File(
        [csvBlob],
        file.name.replace(/\.(xls|xlsx)$/i, '.csv'),
        { type: 'text/csv' }
      );

      const dt = new DataTransfer();
      dt.items.add(csvFile);
      fileInput.files = dt.files;

      fileLabel.innerHTML = `
        <div class="text-center">
          <p class="text-sm font-medium text-gray-700">${csvFile.name}</p>
          <p class="text-xs text-gray-500 mt-1">Converted from Excel</p>
        </div>
      `;
      fileLabel.classList.add('active');
    };

    reader.readAsArrayBuffer(file);
  } else {
    fileLabel.innerHTML = `
      <div class="text-center">
        <p class="text-sm font-medium text-gray-700">${file.name}</p>
        <p class="text-xs text-gray-500 mt-1">Ready to upload</p>
      </div>
    `;
    fileLabel.classList.add('active');
  }
});

$(document).ready(function () {
  $('#studentsTable').DataTable({
    pageLength: 10,
    lengthMenu: [5, 10, 25, 50]
  });
});

document.getElementById('uploadForm').addEventListener('submit', e => {
  e.preventDefault();

  const formData = new FormData(e.target);
  const msg = document.getElementById('messageBox');
  const btn = document.getElementById('submitBtn');

  btn.disabled = true;
  btn.innerText = 'Uploading...';
  msg.classList.add('hidden');

  fetch('<?= base_url("uploadCSVUnique") ?>', {
    method: 'POST',
    body: formData
  })
    .then(r => r.json())
    .then(d => {
      msg.classList.remove('hidden');
      msg.innerText = d.message;

      if (d.status === 'success') {
        msg.className = 'mb-6 p-4 rounded-lg text-white text-center bg-green-600';
        setTimeout(() => location.reload(), 5000);
      } else {
        msg.className = 'mb-6 p-4 rounded-lg text-white text-center bg-red-600';
      }

      btn.disabled = false;
      btn.innerText = 'Upload File';
    })
    .catch(() => {
      msg.className = 'mb-6 p-4 rounded-lg text-white text-center bg-red-600';
      msg.innerText = 'Upload failed';
      btn.disabled = false;
      btn.innerText = 'Upload File';
    });
});
</script>


</body>
</html>
