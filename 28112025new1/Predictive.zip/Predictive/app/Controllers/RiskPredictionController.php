<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Services\RiskRuleEngine;
use App\Models\StudentAcademicSummaryModel;
use App\Models\StudentModel;
use \App\Models\StudentRiskPredictionModel;
class RiskPredictionController extends BaseController
{
 public function index(){
        $riskModel = model(StudentRiskPredictionModel::class);
        $studentModel = model(StudentModel::class);

        // 1️⃣ Get high-risk count per department (for cards and dropdown)
        $data['dropout_by_department'] = $riskModel
            ->select('students.department_name, COUNT(student_risk_predictions.student_id) AS total')
            ->join('students', 'students.id = student_risk_predictions.student_id')
            ->where('student_risk_predictions.risk_level', 'HIGH')
            ->groupBy('students.department_name')->orderBy('total', 'DESC')
            ->findAll();
$data['students_by_department'] = $riskModel
    ->select('students.department_name, COUNT(students.id) AS total')
    ->join('students', 'students.id = student_risk_predictions.student_id', 'left')
    ->groupBy('students.department_name')
    ->orderBy('total', 'DESC')
    ->findAll();

        // 2️⃣ Determine default department (highest count)
        $defaultDept = '';
        if (!empty($data['dropout_by_department'])) {
            $totals = array_column($data['dropout_by_department'], 'total');
            $maxIndex = array_search(max($totals), $totals);
            $defaultDept = $data['dropout_by_department'][$maxIndex]['department_name'] ?? '';
        }
        $data['defaultDept'] = $defaultDept;

        // 3️⃣ Fetch students for default department
      $dept = $data['defaultDept'];
$data['students_risk_fee'] = $riskModel
    ->select('
        student_risk_predictions.student_id,
        student_academic_summary.student_name,
        student_academic_summary.fee_due_amount,
        student_risk_predictions.risk_score
    ')
    ->join('students', 'students.id = student_risk_predictions.student_id')
    ->join('student_academic_summary', 'student_academic_summary.student_id = students.student_id')
    // ->orderBy('student_risk_predictions.risk_score', 'ASC')
    ->findAll();

$data['predictions'] = $riskModel
    ->select('
        student_risk_predictions.id,
        students.student_id AS roll_no,
        student_academic_summary.student_name,
        students.department_name,
        student_academic_summary.avg_internal_marks,
        student_academic_summary.fee_due_amount,
        student_academic_summary.incident_count,
        student_academic_summary.attendance_percentage,
        student_risk_predictions.risk_score,
        student_risk_predictions.risk_level
    ')
    ->join('students', 'students.id = student_risk_predictions.student_id')
    ->join(
        'student_academic_summary',
        'student_academic_summary.student_id = students.student_id'
    )
    ->where('students.department_name', $dept)
    ->groupBy('student_risk_predictions.id')
    ->findAll();
$data['lowHigh'] = $riskModel
    ->select('risk_level, COUNT(*)')
    ->groupBy('risk_level')
    ->findAll();
     $data['incident_analysis'] = $riskModel
            ->select('students.department_name, SUM(student_academic_summary.incident_count) AS total_incidents')
            ->join('students', 'students.id = student_risk_predictions.student_id')
            ->join('student_academic_summary', 'student_academic_summary.student_id = students.student_id')
            ->groupBy('students.department_name')
            ->findAll();

// Get stacked data with students
$stackedData = $riskModel
    ->select('
        students.department_name,
        SUM(CASE WHEN student_academic_summary.fee_due_amount > 0 THEN 1 ELSE 0 END) AS unpaid_count,
        SUM(CASE WHEN student_academic_summary.fee_due_amount = 0 THEN 1 ELSE 0 END) AS paid_count
    ')
    ->join('students', 'students.id = student_risk_predictions.student_id')
    ->join('student_academic_summary', 'student_academic_summary.student_id = students.student_id')
    ->groupBy('students.department_name')
    ->findAll();

// Add student-level details with amounts
foreach ($stackedData as &$dept) {
    $students = $riskModel
        ->select('student_academic_summary.student_name, student_academic_summary.fee_due_amount, students.department_fees_amount')
        ->join('students', 'students.id = student_risk_predictions.student_id')
        ->join('student_academic_summary', 'student_academic_summary.student_id = students.student_id')
        ->where('students.department_name', $dept['department_name'])
        ->findAll();

    $dept['paid_students'] = [];
    $dept['unpaid_students'] = [];

    foreach ($students as $s) {
        $paidAmount = $s['department_fees_amount'] - $s['fee_due_amount'];
        $unpaidAmount = $s['fee_due_amount'];

        $dept['paid_students'][] = ['name'=>$s['student_name'], 'amount'=>$paidAmount];
        $dept['unpaid_students'][] = ['name'=>$s['student_name'], 'amount'=>$unpaidAmount];
    }
}

$data['stacked_bar'] = $stackedData;

        return view('index', $data);
    }

  // 4️⃣ AJAX endpoint to fetch students by department
public function getStudentsByDept()
{
    $dept = $this->request->getPost('department');

    if (!$dept) {
        return $this->response->setJSON([]);
    }

    $riskModel = model(StudentRiskPredictionModel::class);

    $students = $riskModel
        ->select('
            student_risk_predictions.id,
            students.student_id AS roll_no,
            student_academic_summary.student_name,
            students.department_name,
            student_academic_summary.avg_internal_marks,
            student_academic_summary.fee_due_amount,
            student_academic_summary.incident_count,
        student_academic_summary.attendance_percentage,
            student_risk_predictions.risk_score,
            student_risk_predictions.risk_level
        ')
        ->join(
            'students',
            'students.id = student_risk_predictions.student_id'
        )
        ->join(
            'student_academic_summary',
            'student_academic_summary.student_id = students.student_id'
        )
        ->where('students.department_name', $dept)
        ->groupBy('student_risk_predictions.id')
        ->orderBy('student_risk_predictions.risk_score', 'DESC')
        ->findAll();

    return $this->response->setJSON($students);
}



  public function run(){
        try {
            // Initialize your RiskRuleEngine
            $engine = new RiskRuleEngine();

            // Fetch all students data from the engine
            $studentsData = $engine->fetchAllStudentsData();

            // Return JSON response
            return $this->response->setJSON([
                'status'  => 'success',
                'message' => 'Student data fetched successfully',
                'data'    => $studentsData
            ]);

        } catch (\Throwable $e) {
            // Handle errors
            return $this->response->setStatusCode(500)->setJSON([
                'status'  => 'error',
                'message' => 'Failed to fetch student data',
                'error'   => $e->getMessage()
            ]);
        }
    }
}
