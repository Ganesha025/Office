<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>zen</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
body { overflow: hidden; }

.loader-wrapper {
    position: fixed;
    inset: 0;
    background: #0F172A;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    transition: opacity 0.5s ease, visibility 0.5s ease;
}

.loader-wrapper.hidden {
    opacity: 0;
    visibility: hidden;
}

.loader {
    width: 80px;
    height: 80px;
    position: relative;
}

.loader-circle {
    position: absolute;
    width: 100%;
    height: 100%;
    border: 4px solid transparent;
    border-top-color: #3B82F6;
    border-radius: 50%;
    animation: spin 1s cubic-bezier(0.68, -0.55, 0.265, 1.55) infinite;
}

.loader-circle:nth-child(2) {
    border-top-color: #F59E0B;
    animation-delay: 0.15s;
    width: 90%;
    height: 90%;
    top: 5%;
    left: 5%;
}

.loader-circle:nth-child(3) {
    border-top-color: #10B981;
    animation-delay: 0.3s;
    width: 80%;
    height: 80%;
    top: 10%;
    left: 10%;
}

@keyframes spin {
    0% { transform: rotate(0deg) scale(1); }
    50% { transform: rotate(180deg) scale(1.1); }
    100% { transform: rotate(360deg) scale(1); }
}

.wrapper {
    width: 100vw;
    height: 100vh;
    display: flex;
    position: relative;
    overflow: hidden;
}

.panel {
    width: 50%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px;
    flex-direction: column;
    position: relative;
    transition: transform 0.8s cubic-bezier(0.68, -0.55, 0.265, 1.55);
}

.left {
    background: #0F172A;
    color: #fff;
    z-index: 2;
}

.right {
    background: #FFFFFF;
    color: #0F172A;
    z-index: 1;
}

.wrapper.swap .left {
    transform: translateX(100%);
}

.wrapper.swap .right {
    transform: translateX(-100%);
}

.welcome-content {
    text-align: center;
    max-width: 500px;
    animation: fadeInUp 0.8s ease;
}

.welcome-title {
    font-size: 3.5rem;
    font-weight: 800;
    margin-bottom: 1.5rem;
    background: linear-gradient(135deg, #3B82F6, #10B981);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.welcome-subtitle {
    font-size: 1.25rem;
    opacity: 0.8;
    line-height: 1.8;
}

.form-container {
    width: 100%;
    max-width: 420px;
    animation: fadeInUp 0.8s ease;
}

.form-title {
    font-size: 2.5rem;
    font-weight: 800;
    margin-bottom: 2rem;
    color: #0F172A;
}

.alert {
    padding: 1rem;
    border-radius: 12px;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    animation: slideDown 0.4s ease;
}

.alert-error {
    background: #FEE2E2;
    border: 2px solid #EF4444;
    color: #991B1B;
}

.alert-success {
    background: #D1FAE5;
    border: 2px solid #10B981;
    color: #065F46;
}

.alert .material-icons {
    font-size: 24px;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.input-group {
    position: relative;
    margin-bottom: 1.25rem;
}

.input-group input,
.input-group select {
    width: 100%;
    padding: 1rem 1rem 1rem 3rem;
    border: 2px solid #E2E8F0;
    border-radius: 12px;
    outline: none;
    font-size: 1rem;
    background: #F8FAFC;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.input-group input:focus,
.input-group select:focus {
    border-color: #3B82F6;
    background: #FFFFFF;
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.15);
}

.input-group .material-icons {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: #64748B;
    transition: color 0.3s ease;
}

.input-group input:focus ~ .material-icons,
.input-group select:focus ~ .material-icons {
    color: #3B82F6;
}

.btn {
    width: 100%;
    padding: 1rem;
    border: none;
    border-radius: 12px;
    font-size: 1.05rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
}

.btn::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.3);
    transform: translate(-50%, -50%);
    transition: width 0.6s ease, height 0.6s ease;
}

.btn:hover::before {
    width: 300px;
    height: 300px;
}

.btn-primary {
    background: #3B82F6;
    color: white;
    margin-top: 0.5rem;
}

.btn-primary:hover {
    background: #2563EB;
    transform: translateY(-2px);
    box-shadow: 0 15px 35px rgba(59, 130, 246, 0.3);
}

#sellerFields {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.5s cubic-bezier(0.4, 0, 0.2, 1);
}

#sellerFields.show {
    max-height: 600px;
}

.floating-shapes {
    position: absolute;
    inset: 0;
    overflow: hidden;
    pointer-events: none;
}

.shape {
    position: absolute;
    border-radius: 50%;
    opacity: 0.1;
    animation: float 20s infinite ease-in-out;
}

.shape:nth-child(1) {
    width: 300px;
    height: 300px;
    background: #3B82F6;
    top: -150px;
    left: -150px;
    animation-delay: 0s;
}

.shape:nth-child(2) {
    width: 200px;
    height: 200px;
    background: #10B981;
    bottom: -100px;
    right: -100px;
    animation-delay: 5s;
}

.shape:nth-child(3) {
    width: 250px;
    height: 250px;
    background: #F59E0B;
    top: 50%;
    right: -125px;
    animation-delay: 10s;
}

@keyframes float {
    0%, 100% { transform: translate(0, 0) rotate(0deg); }
    25% { transform: translate(30px, -30px) rotate(90deg); }
    50% { transform: translate(-20px, 20px) rotate(180deg); }
    75% { transform: translate(20px, 30px) rotate(270deg); }
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.form-transition {
    animation: formSlide 0.5s ease;
}

@keyframes formSlide {
    0% {
        opacity: 0;
        transform: translateX(-30px);
    }
    100% {
        opacity: 1;
        transform: translateX(0);
    }
}
</style>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>
<body>

<div class="loader-wrapper" id="loader">
    <div class="loader">
        <div class="loader-circle"></div>
        <div class="loader-circle"></div>
        <div class="loader-circle"></div>
    </div>
</div>

<div class="wrapper" id="wrapper">
    <div class="panel left">
        <div class="floating-shapes">
            <div class="shape"></div>
            <div class="shape"></div>
            <div class="shape"></div>
        </div>
        <div class="welcome-content">
            <h1 class="welcome-title">Welcome Back!</h1>
            <p class="welcome-subtitle">Discover amazing products and exclusive deals. Join our community today and start shopping smarter.</p>
        </div>
    </div>
    
    <div class="panel right">
        <div class="floating-shapes">
            <div class="shape"></div>
            <div class="shape"></div>
            <div class="shape"></div>
        </div>
        
        <div id="loginForm" class="form-container">
            <h2 class="form-title">Sign In</h2>
            
            <?php if(session()->getFlashdata('error')): ?>
                <div class="alert alert-error">
                    <span class="material-icons">error</span>
                    <span><?= session()->getFlashdata('error') ?></span>
                </div>
            <?php endif; ?>
            
            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <span class="material-icons">check_circle</span>
                    <span><?= session()->getFlashdata('success') ?></span>
                </div>
            <?php endif; ?>
            
            <form method="post" action="<?= base_url('login') ?>">
                <input type="hidden" name="action" value="login">
                <div class="input-group">
                    <input type="email" name="usermail" placeholder="Email Address" autofocus class="val-alt-email" required>
                    <span class="material-icons">email</span>
                </div>
                <div class="input-group">
                    <input type="password" name="password" placeholder="Password" class="val-password" required>
                    <span class="material-icons">lock</span>
                </div>
                <button type="submit" class="btn btn-primary">Sign In</button>
            </form>
            <div class="flex items-center justify-center space-x-2 text-sm mt-2">
                <span class="text-gray-700">Don't Have Account?</span>
                <button class="swap-btn bg-gray-200 text-blue-600 border border-blue-600 px-2 py-1 rounded text-sm hover:bg-blue-50 hover:text-blue-700">
                    Signup
                </button>
            </div>
        </div>
        
        <div id="signupForm" class="form-container" style="display:none;">
            <h2 class="form-title">Sign Up</h2>
            
            <?php if(session()->getFlashdata('error')): ?>
                <div class="alert alert-error">
                    <span class="material-icons">error</span>
                    <span><?= session()->getFlashdata('error') ?></span>
                </div>
            <?php endif; ?>
            
            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <span class="material-icons">check_circle</span>
                    <span><?= session()->getFlashdata('success') ?></span>
                </div>
            <?php endif; ?>
            
            <form method="post" action="<?= base_url('newsignup') ?>">
                <input type="hidden" name="action" value="signup">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Full Name" class="val-username" required>
                    <span class="material-icons">person</span>
                </div>
                <div class="input-group">
                    <input type="email" name="usermail" placeholder="Email Address" class="val-alt-email" required>
                    <span class="material-icons">email</span>
                </div>
                <div class="input-group">
                    <input type="password" name="password" placeholder="Password" class="val-password" required>
                    <span class="material-icons">lock</span>
                </div>
                <div class="input-group">
                    <select name="role" id="role" required>
                        <option value="user">User</option>
                        <option value="seller">Seller</option>
                    </select>
                    <span class="material-icons">account_circle</span>
                </div>
                <div id="sellerFields" class="grid grid-cols-2 gap-4 mt-4">
                    <div class="relative">
                        <input type="text" name="shop_name" id="shop_name" placeholder="Shop Name" class="val-com-name w-full border border-gray-300 rounded-lg px-3 py-2 pr-10 focus:outline-none focus:border-blue-500" />
                        <span class="material-icons absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">store</span>
                    </div>
                    <div class="relative">
                        <input type="text" name="business_type" id="business_type" placeholder="Business Type" class="val-com-name w-full border border-gray-300 rounded-lg px-3 py-2 pr-10 focus:outline-none focus:border-blue-500" />
                        <span class="material-icons absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">business</span>
                    </div>
                    <div class="relative">
                        <input type="text" name="pan_number" id="pan_number" placeholder="PAN Number" class="val-pan w-full border border-gray-300 rounded-lg px-3 py-2 pr-10 focus:outline-none focus:border-blue-500" />
                        <span class="material-icons absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">badge</span>
                    </div>
                    <div class="relative">
                        <input type="text" name="bank_account" id="bank_account" placeholder="Bank Account" class="val-bank-account w-full border border-gray-300 rounded-lg px-3 py-2 pr-10 focus:outline-none focus:border-blue-500" />
                        <span class="material-icons absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">account_balance</span>
                    </div>
                    <div class="relative">
                        <input type="text" name="address" id="address" placeholder="Address" class="val-address w-full border border-gray-300 rounded-lg px-3 py-2 pr-10 focus:outline-none focus:border-blue-500" />
                        <span class="material-icons absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">location_on</span>
                    </div>
                    <div class="relative">
                        <input type="text" name="ifsc_code" id="ifsc_code" placeholder="IFSC Code" class="val-ifsc w-full border border-gray-300 rounded-lg px-3 py-2 pr-10 focus:outline-none focus:border-blue-500" />
                        <span class="material-icons absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">code</span>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Create Account</button>
            </form>
            <div class="flex items-center justify-center space-x-2 text-sm mt-2">
                <span class="text-gray-700">Already Have Account?</span>
                <button class="swap-btn bg-gray-200 text-blue-600 border border-blue-600 px-2 py-1 rounded text-sm hover:bg-blue-50 hover:text-blue-700">
                    Login
                </button>
            </div>
        </div>
    </div>
</div>

<script>
window.addEventListener('load', () => {
    setTimeout(() => {
        document.getElementById('loader').classList.add('hidden');
    }, 1500);
});

const roleSelect = document.getElementById('role');
const sellerContainer = document.getElementById('sellerFields');
const sellerFields = ['shop_name','business_type','pan_number','bank_account','address','ifsc_code'];

function toggleSellerFields() {
    const isSeller = roleSelect.value === 'seller';
    if(isSeller) {
        sellerContainer.classList.add('show');
        sellerFields.forEach(id => {
            document.getElementById(id).setAttribute('required','required');
        });
    } else {
        sellerContainer.classList.remove('show');
        sellerFields.forEach(id => {
            const field = document.getElementById(id);
            field.removeAttribute('required');
            field.value = '';
        });
    }
}

if(roleSelect) roleSelect.addEventListener('change', toggleSellerFields);
toggleSellerFields();

const wrapper = document.getElementById('wrapper');
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');
let loginOnRight = true;

document.querySelectorAll('.swap-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        wrapper.classList.toggle('swap');
        
        if(loginOnRight){
            loginForm.style.display = 'none';
            signupForm.style.display = 'block';
            signupForm.classList.add('form-transition');
            loginOnRight = false;
        } else {
            signupForm.style.display = 'none';
            loginForm.style.display = 'block';
            loginForm.classList.add('form-transition');
            loginOnRight = true;
        }
        
        setTimeout(() => {
            loginForm.classList.remove('form-transition');
            signupForm.classList.remove('form-transition');
        }, 500);
    });
});
</script>

</body>
</html>