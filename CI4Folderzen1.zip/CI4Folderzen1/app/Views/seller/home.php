<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Zen Seller</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<style>
body{background:#020617;color:#e5e7eb}
.card{
background:#020617;
border:1px solid #1e293b;
border-radius:18px;
box-shadow:0 25px 50px rgba(0,0,0,.6);
transition:.3s
}
.card:hover{transform:translateY(-4px)}
::-webkit-scrollbar{display:none}
</style>
</head>

<body class="p-4 md:p-6">
<?= view('seller/aside') ?>

<div id="loader" class="fixed inset-0 bg-[#020617] flex items-center justify-center z-50">
<span class="material-icons text-sky-400 text-6xl animate-bounce">shopping_cart</span>
<div class="absolute w-20 h-20 border-4 border-transparent border-t-sky-400 rounded-full animate-spin"></div>
</div>

<div id="app" class="hidden">

<?php
$month=date('m'); $year=date('Y');
$totalOrders=$totalRevenue=$pendingOrders=0;
$weeklyOrders=[0,0,0,0]; $weeklyRevenue=[0,0,0,0];

foreach($orderedproducts as $o){
$time=strtotime($o['ordered_date']);
if(date('m',$time)==$month && date('Y',$time)==$year){
$totalOrders++;
$totalRevenue+=($o['price']*$o['quantity']);
if($o['status']=='pending') $pendingOrders++;
$w=ceil(date('d',$time)/7)-1;
$weeklyOrders[$w]++;
$weeklyRevenue[$w]+=($o['price']*$o['quantity']);
}
}
?>

<div class="max-w-7xl mx-auto">
<br><br>
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">

<div class="card p-5">
<h2 class="text-lg font-semibold text-sky-400 mb-4">Summary</h2>
<table class="w-full text-sm">
<tbody class="divide-y divide-slate-800">
<tr>
<td class="py-3 text-slate-400">Total Orders</td>
<td class="py-3 text-right text-sky-400 font-semibold"><?= $totalOrders ?></td>
</tr>
<tr>
<td class="py-3 text-slate-400">Total Revenue</td>
<td class="py-3 text-right text-emerald-400 font-semibold">
₹<?= number_format($totalRevenue) ?>
</td>
</tr>
<tr>
<td class="py-3 text-slate-400">Pending Orders</td>
<td class="py-3 text-right text-yellow-400 font-semibold"><?= $pendingOrders ?></td>
</tr>
</tbody>
</table>
</div>

<div class="card p-5 h-[340px]">
<h2 class="text-lg font-semibold text-sky-400 mb-4">Weekly Orders & Revenue</h2>
<canvas id="chart"></canvas>
</div>

</div>

<div class="card p-5">
<h2 class="text-lg font-semibold text-sky-400 mb-4">All Orders</h2>

<div class="overflow-x-auto">
<table id="ordersTable" class="display w-full text-sm">
<thead>
<tr class="text-center">
<th>ID</th>
<th>Product</th>
<th>Buyer</th>
<th>Qty</th>
<th>Price</th>
<th>Status</th>
<th>Date</th>
</tr>
</thead>
<tbody>
<?php foreach($orderedproducts as $o): ?>
<tr class="text-center">
<td><?= $o['order_id'] ?></td>
<td><?= esc($o['product_name']) ?></td>
<td><?= esc($o['user_name']) ?></td>
<td><?= $o['quantity'] ?></td>
<td>₹<?= number_format($o['price']) ?></td>
<td class="capitalize"><?= $o['status'] ?></td>
<td><?= date('d M Y',strtotime($o['ordered_date'])) ?></td>
</tr>
<?php endforeach ?>
</tbody>
</table>
</div>
</div>

</div>
</div>

<script>
$(window).on('load',function(){
$('#loader').fadeOut(400,function(){
$('#app').fadeIn(400)
})
})

$('#ordersTable').DataTable({pageLength:10,responsive:true})

new Chart(document.getElementById('chart'),{
type:'bar',
data:{
labels:['Week 1','Week 2','Week 3','Week 4'],
datasets:[
{label:'Orders',data:<?= json_encode($weeklyOrders) ?>,backgroundColor:'#38bdf8'},
{label:'Revenue',data:<?= json_encode($weeklyRevenue) ?>,backgroundColor:'#34d399'}
]
},
options:{
responsive:true,
maintainAspectRatio:false,
plugins:{legend:{labels:{color:'#e5e7eb'}}},
scales:{
x:{ticks:{color:'#e5e7eb'}},
y:{ticks:{color:'#e5e7eb'}}
}
}
})
</script>

</body>
</html>
