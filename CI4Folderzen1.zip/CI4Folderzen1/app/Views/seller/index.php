<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Zen Products</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">  

<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@400;600&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<style>
html,body{height:100%}
body{background:#020617;color:#e5e7eb}
table.dataTable thead th{background:#020617;color:#38bdf8}
table.dataTable tbody tr{background:#020617;transition:all .4s cubic-bezier(.4,0,.2,1)}
table.dataTable tbody tr:hover{transform:scale(1.01)}
.dataTables_filter input,.dataTables_length select{background:#020617;color:#e5e7eb;border:1px solid #1e293b}
.edit{display:none}
.material-symbols-rounded{font-variation-settings:'FILL' 1,'wght' 600,'GRAD' 0,'opsz' 24}
.loader{position:fixed;inset:0;z-index:50;display:flex;align-items:center;justify-content:center;background:#020617}
.loader span{font-size:64px;color:#38bdf8;animation:pulse 1s ease-in-out infinite}
@keyframes pulse{50%{transform:scale(1.2)}}
.modal{position:fixed;inset:0;background:rgba(2,6,23,.92);display:none;align-items:center;justify-content:center;z-index:40}
.modal.show{display:flex;animation:scaleIn .45s ease}
@keyframes scaleIn{from{transform:scale(.9);opacity:0}to{transform:scale(1);opacity:1}}
.toast{background:#020617;border:1px solid #1e293b;color:#e5e7eb;padding:14px 18px;border-radius:14px;min-width:260px;display:flex;align-items:center;gap:12px;box-shadow:0 20px 40px rgba(0,0,0,.6);transform:translateX(120%);animation:toastIn .5s cubic-bezier(.4,0,.2,1) forwards}
.toast.success{border-left:4px solid #22c55e}
.toast.error{border-left:4px solid #ef4444}
.toast.hide{animation:toastOut .45s cubic-bezier(.4,0,.2,1) forwards}
@keyframes toastIn{to{transform:translateX(0)}}
@keyframes toastOut{to{opacity:0;transform:translateX(120%)}}
*{transition:background-color .35s cubic-bezier(.4,0,.2,1),color .35s cubic-bezier(.4,0,.2,1),transform .35s cubic-bezier(.4,0,.2,1),box-shadow .35s cubic-bezier(.4,0,.2,1),border-color .35s cubic-bezier(.4,0,.2,1)}
button:hover{transform:translateY(-2px) scale(1.04);box-shadow:0 14px 30px rgba(0,0,0,.45)}
input:hover,textarea:hover,select:hover{border-color:#38bdf8}
input:focus,textarea:focus,select:focus{outline:none;border-color:#38bdf8;box-shadow:0 0 0 1px #38bdf8}
img:hover{transform:scale(1.1)}
.material-symbols-rounded:hover{transform:scale(1.15)}
table.dataTable tbody tr:hover{background:#020617;box-shadow:inset 0 0 0 1px #1e293b}
.toast:hover{transform:translateX(-6px)}
button.disabled{
  opacity: 0.6;
  cursor: not-allowed;
}

</style>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ganesha025/Office@main/styles.css">

</head>

<body class="overflow-hidden">
<?= view('seller/aside') ?>

<div id="pageLoader" class="loader"><span class="material-symbols-rounded">shopping_cart</span></div>

<div id="toastWrap" class="fixed top-6 right-6 z-[999] space-y-3"></div>

<div class="h-full w-full p-6 overflow-auto">
<div class="max-w-7xl mx-auto">
<div class="flex items-center justify-between mb-6">
<h1 class="text-3xl font-bold text-sky-400 flex items-center gap-2">
<span class="material-symbols-rounded">
</h1>
<button id="openModal" class="px-5 py-2 rounded-lg bg-sky-400 text-slate-900 font-semibold flex items-center gap-2 hover:scale-105 transition">
<span class="material-symbols-rounded">add</span> Add Product
</button>
</div>

<div class="rounded-xl border p-10 border-slate-800 overflow-hidden shadow-2xl">
<table id="productTable" class="display w-full text-sm ">
<thead>
<tr>
<th>ID</th>
<th>Image</th>
<th>Name</th>
<th>Description</th>
<th>Price</th>
<th>Discount</th>
<th>Stock</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach($products as $p): ?>
<tr data-id="<?= $p['id'] ?>">
<td><?= $p['id'] ?></td>
<td><?php if($p['image']): ?><img src="<?= base_url('uploads/products/'.$p['image']) ?>" class="w-12 h-12 rounded-lg object-cover"><?php endif; ?></td>
<td><span class="view"><?= esc($p['product_name']) ?></span><input class="edit w-full bg-slate-900 border border-slate-700 rounded px-2 py-1" name="product_name" value="<?= esc($p['product_name']) ?>"></td>
<td class="max-w-xs truncate"><span class="view"><?= esc($p['description']) ?></span><textarea class="edit w-full bg-slate-900 border border-slate-700 rounded px-2 py-1" name="description"><?= esc($p['description']) ?></textarea></td>
<td><span class="view"><?= esc($p['price']) ?></span><input class="edit w-full bg-slate-900 border border-slate-700 rounded px-2 py-1" type="number" step="0.01" name="price" value="<?= esc($p['price']) ?>"></td>
<td><span class="view"><?= esc($p['allowed_discount']) ?></span><input class="edit w-full bg-slate-900 border border-slate-700 rounded px-2 py-1" type="number" name="allowed_discount" value="<?= esc($p['allowed_discount']) ?>"></td>
<td><span class="view"><?= esc($p['stock_count']) ?></span><input class="edit w-full bg-slate-900 border border-slate-700 rounded px-2 py-1" type="number" name="stock_count" value="<?= esc($p['stock_count']) ?>"></td>
<td class="flex gap-1">
<button class="editBtn bg-sky-400 text-slate-900 px-3 py-1 rounded"><span class="material-symbols-rounded">edit</span></button>
<button class="saveBtn bg-emerald-400 text-slate-900 px-3 py-1 rounded"><span class="material-symbols-rounded">check</span></button>
<button class="cancelBtn bg-slate-600 px-3 py-1 rounded"><span class="material-symbols-rounded">close</span></button>
<button class="deleteBtn bg-red-500 px-3 py-1 rounded"><span class="material-symbols-rounded">delete</span></button>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</div>
</div>

<div id="addProductModal" class="modal">
<div class="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl p-6 shadow-2xl">
<h2 class="text-xl font-semibold text-sky-400 mb-4 flex items-center gap-2">
<span class="material-symbols-rounded">add_box</span> Add Product
</h2>
<form id="addForm" enctype="multipart/form-data" class="grid grid-cols-2 gap-4">
<input type="text" name="product_name" placeholder="Product Name" class="col-span-2 bg-slate-950 border border-slate-700 rounded px-3 py-2" required>
<input type="number" name="price" step="0.01" placeholder="Price" class="bg-slate-950 border border-slate-700 rounded px-3 py-2" required>
<input type="number" name="allowed_discount" placeholder="Discount" value="0" class="bg-slate-950 border border-slate-700 rounded px-3 py-2">
<textarea name="description" placeholder="Description" class="col-span-2 bg-slate-950 border border-slate-700 rounded px-3 py-2" required></textarea>
<input type="number" name="stock_count" placeholder="Stock" class="bg-slate-950 border border-slate-700 rounded px-3 py-2" required>
<input type="file" name="image" class="bg-slate-950 border border-slate-700 rounded px-3 py-2" required>
<div class="col-span-2 flex justify-end gap-3">
<button type="button" id="closeModal" class="px-5 py-2 rounded bg-slate-700 flex items-center gap-2"><span class="material-symbols-rounded">close</span>Cancel</button>
<button type="submit" class="px-5 py-2 rounded bg-emerald-400 text-slate-900 font-semibold flex items-center gap-2" disabled><span class="material-symbols-rounded">check</span>Add</button>
</div>
</form>
</div>
</div>

<script>
$(function(){
 const f=$('#addForm'),b=f.find('button[type=submit]');
 const v=()=>b.prop('disabled',
  !$('input[name=product_name]').val() ||
  $('input[name=product_name]').val().length>50 ||
  $('input[name=price]').val()>9000000 ||
  $('input[name=allowed_discount]').val()>99 ||
  $('input[name=stock_count]').val()>9999 ||
  $('textarea[name=description]').val().length>255
 );

 $('input[name=product_name]').on('input',function(){
  this.value=this.value.replace(/[^a-zA-Z0-9 ]/g,'').slice(0,50);v()
 });

 $('input[name=price]').on('input',function(){this.value=Math.min(this.value,9000000);v()});
 $('input[name=allowed_discount]').on('input',function(){this.value=Math.min(this.value,99);v()});
 $('input[name=stock_count]').on('input',function(){this.value=Math.min(this.value,9999);v()});
 $('textarea[name=description]').on('input',function(){this.value=this.value.slice(0,255);v()});
});
</script>

<script>
$(window).on('load',()=>$('#pageLoader').fadeOut(600))
$('#productTable').DataTable()
$('.saveBtn,.cancelBtn').hide()
$('#openModal').click(()=>$('#addProductModal').addClass('show'))
$('#closeModal').click(()=>$('#addProductModal').removeClass('show'))

function toast(type,msg){
 let icon=type==='success'?'check_circle':'error'
 let t=$(`<div class="toast ${type}"><span class="material-symbols-rounded text-xl">${icon}</span><div class="text-sm font-medium">${msg}</div></div>`)
 $('#toastWrap').append(t)
 setTimeout(()=>t.addClass('hide'),2600)
 setTimeout(()=>t.remove(),3200)
}

$(document).on('click','.editBtn',function(){
 let r=$(this).closest('tr')
 r.find('.view').hide()
 r.find('.edit').show()
 r.find('.editBtn').hide()
 r.find('.saveBtn,.cancelBtn').show()
})

$(document).on('click','.cancelBtn',function(){
 let r=$(this).closest('tr')
 r.find('.edit').each(function(){$(this).val($(this).siblings('.view').text())})
 r.find('.edit').hide()
 r.find('.view').show()
 r.find('.saveBtn,.cancelBtn').hide()
 r.find('.editBtn').show()
})

$(document).on('click','.saveBtn',function(){
 let r=$(this).closest('tr')
 let data={product_id:r.data('id')}
 r.find('.edit').each(function(){data[$(this).attr('name')]=$(this).val()})
 $.post('<?= site_url("seller/update") ?>',data,res=>{
  if(res.status==='success'){
   r.find('.edit').each(function(){$(this).siblings('.view').text($(this).val())})
   r.find('.edit').hide()
   r.find('.view').show()
   r.find('.saveBtn,.cancelBtn').hide()
   r.find('.editBtn').show()
   toast('success',res.message)
  }else toast('error',res.message)
 },'json')
})

$(document).on('click','.deleteBtn',function(){
 if(!confirm('Delete this product?'))return
 let r=$(this).closest('tr')
 $.post('<?= site_url("seller/delete") ?>',{product_id:r.data('id')},res=>{
  if(res.status==='success'){
   $('#productTable').DataTable().row(r).remove().draw()
   toast('success',res.message)
  }else toast('error',res.message)
 },'json')
})

$('#addForm').on('input change',function(){
 let ok=true
 $('#addForm [required]').each(function(){if(!this.value)ok=false})
 $('#addForm button[type="submit"]').prop('disabled',!ok)
})

$('#addForm').submit(function(e){
 e.preventDefault()
 let fd=new FormData(this)
 $.ajax({
  url:'<?= site_url("seller/AddProduct") ?>',
  type:'POST',
  data:fd,
  processData:false,
  contentType:false,
  dataType:'json',
  success:r=>{
   if(r.status==='success'){toast('success','Product added');setTimeout(()=>location.reload(),600)}
   else toast('error',r.message)
  }
 })
})
</script>
</body>
</html>
