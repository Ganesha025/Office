<header class="bg-[#020617] border-b border-slate-800 p-4 flex items-center justify-between sticky top-0 z-50">

  <!-- Left: Logo -->
  <div class="flex items-center gap-3">
    <span class="material-icons text-sky-400 text-3xl">storefront</span>
    <h1 class="text-xl md:text-2xl font-bold text-sky-400">Zen Seller</h1>
  </div>

  <!-- Desktop Nav -->
  <nav class="hidden sm:flex items-center gap-6 text-sm font-medium relative">

    <a href="<?= base_url('seller/home') ?>" class="text-slate-400 hover:text-sky-400 transition">Dashboard</a>
    <a href="<?= base_url('seller/index') ?>" class="text-slate-400 hover:text-sky-400 transition">Products</a>
    <a href="<?= base_url('seller/orders') ?>" class="text-slate-400 hover:text-sky-400 transition">Orders</a>

    <!-- Account Dropdown -->
    <div class="relative group">
      <button class="flex items-center gap-2 px-3 py-1 rounded bg-slate-900 border border-slate-700 hover:bg-slate-800 transition">
        <span class="material-icons text-sky-400">account_circle</span>
        <span class="text-slate-200"><?= preg_replace('/[^a-zA-Z]/', '', strstr(session()->get('email'), '@', true)) ?></span>
        <span class="material-icons text-slate-400">expand_more</span>
      </button>
      <div class="absolute right-0 mt-2 w-40 bg-[#020617] border border-slate-800 rounded-xl shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-opacity">
        <a href="<?= base_url('logout') ?>" class="block px-4 py-2 text-red-400 hover:bg-red-500/10 rounded transition">Logout</a>
      </div>
    </div>

  </nav>

  <!-- Mobile Hamburger -->
  <button id="menuBtn" class="sm:hidden bg-slate-900 p-2 rounded-lg border border-slate-700">
    <span class="material-icons text-sky-400">menu</span>
  </button>

</header>

<!-- Mobile Menu -->
<div id="mobileMenu" class="fixed inset-0 bg-black/70 hidden z-50">
  <div class="bg-[#020617] w-64 h-full p-6 flex flex-col gap-4">
    <button id="closeMobileMenu" class="self-end bg-slate-700 p-1 rounded">
      <span class="material-icons text-red-400">close</span>
    </button>
    <a href="<?= base_url('seller/home') ?>" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-slate-800 hover:text-sky-400 text-slate-400 transition">Dashboard</a>
    <a href="<?= base_url('seller/index') ?>" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-slate-800 hover:text-sky-400 text-slate-400 transition">Products</a>
    <a href="<?= base_url('seller/orders') ?>" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-slate-800 hover:text-sky-400 text-slate-400 transition">Orders</a>

    <!-- Mobile Account Dropdown -->
    <div class="flex flex-col gap-2">
      <button id="mobileAccountBtn" class="flex items-center justify-between gap-2 px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-200">
        <div class="flex items-center gap-2">
          <span class="material-icons text-sky-400">account_circle</span>
          <span><?= preg_replace('/[^a-zA-Z]/', '', strstr(session()->get('email'), '@', true)) ?></span>
        </div>
        <span class="material-icons text-slate-400">expand_more</span>
      </button>
      <div id="mobileAccountDropdown" class="flex flex-col gap-2 pl-5 hidden">
        <a href="<?= base_url('logout') ?>" class="px-3 py-2 text-red-400 hover:bg-red-500/10 rounded transition">Logout</a>
      </div>
    </div>
  </div>
</div>

<script>
const menuBtn = document.getElementById('menuBtn');
const mobileMenu = document.getElementById('mobileMenu');
const closeMobileMenu = document.getElementById('closeMobileMenu');
const mobileAccountBtn = document.getElementById('mobileAccountBtn');
const mobileAccountDropdown = document.getElementById('mobileAccountDropdown');

menuBtn.addEventListener('click', () => mobileMenu.classList.remove('hidden'));
closeMobileMenu.addEventListener('click', () => mobileMenu.classList.add('hidden'));
mobileMenu.addEventListener('click', e => { if(e.target === mobileMenu) mobileMenu.classList.add('hidden'); });

// Mobile Account toggle
mobileAccountBtn.addEventListener('click', () => mobileAccountDropdown.classList.toggle('hidden'));
</script>
