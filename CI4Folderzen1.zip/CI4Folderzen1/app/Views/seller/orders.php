<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Seller Orders</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<style>
html{height:100%}
body{background:#020617;color:#e5e7eb}

/* cards */
.card{
background:#020617;
border:1px solid #1e293b;
border-radius:18px;
box-shadow:0 30px 60px rgba(0,0,0,.6);
transition:.4s
}
.card:hover{transform:translateY(-4px)}

/* tables */
table.dataTable tbody tr{transition:.3s}
table.dataTable tbody tr:hover{transform:scale(1.01)}
.table-wrap{overflow-x:auto}

/* loader */
.loader{
position:fixed;inset:0;
background:#020617;
display:flex;
align-items:center;
justify-content:center;
z-index:50
}
.cart{
font-size:64px;
color:#38bdf8;
animation:bounce 1.2s infinite
}
.spinner{
position:absolute;
width:80px;height:80px;
border:4px solid transparent;
border-top:4px solid #38bdf8;
border-radius:50%;
animation:spin 1s linear infinite
}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes bounce{50%{transform:translateY(-18px)}}

/* toast */
.toast{
position:fixed;
top:16px;right:-400px;
background:#020617;
border:1px solid #38bdf8;
padding:12px 16px;
border-radius:14px;
display:flex;
align-items:center;
gap:10px;
box-shadow:0 20px 40px rgba(0,0,0,.6);
transition:.6s;
z-index:60;
max-width:90%
}
.toast.show{right:16px}

/* buttons */
button{transition:.3s}
button:hover{transform:scale(1.05)}
/* Hide scrollbar for WebKit browsers */
::-webkit-scrollbar {
  display: none;
}

</style>
</head>

<body>
<?= view('seller/aside') ?>

<!-- Loader -->
<div id="loader" class="loader">
<span class="material-icons cart">shopping_cart</span>
<div class="spinner"></div>
</div>

<!-- Toast -->
<div id="toast" class="toast">
<span id="toastIcon" class="material-icons text-sky-400">check_circle</span>
<span id="toastMsg" class="text-sm"></span>
</div>

<div id="app" class="hidden p-4 md:p-6 overflow-auto">

<div class="max-w-7xl mx-auto">
<?php if(empty($orderedproducts)): ?>
<p class="text-slate-400">No orders yet.</p>
<?php else: ?>

<!-- Responsive grid -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">

<!-- Pending -->
<div class="card p-4">
<h2 class="text-lg font-semibold text-yellow-400 mb-3">
Pending Orders
</h2>
<div class="table-wrap">
<table id="pendingTable" class="display w-full text-sm">
<thead>
<tr class="text-center">
<th>ID</th>
<th>Product</th>
<th>Buyer</th>
<th>Qty</th>
<th>Price</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>
<tbody></tbody>
</table>
</div>
</div>

<!-- Approved -->
<div class="card p-4">
<h2 class="text-lg font-semibold text-emerald-400 mb-3">
Approved Orders
</h2>
<div class="table-wrap">
<table id="approvedTable" class="display w-full text-sm">
<thead>
<tr class="text-center">
<th>ID</th>
<th>Product</th>
<th>Buyer</th>
<th>Qty</th>
<th>Price</th>
<th>Status</th>
</tr>
</thead>
<tbody></tbody>
</table>
</div>
</div>

</div>

<!-- Delivered -->
<div class="card p-4">
<h2 class="text-lg font-semibold text-sky-400 mb-3">
Delivered Orders
</h2>
<div class="table-wrap">
<table id="deliveredTable" class="display w-full text-sm">
<thead>
<tr class="text-center">
<th>ID</th>
<th>Product</th>
<th>Buyer</th>
<th>Qty</th>
<th>Price</th>
<th>Status</th>
</tr>
</thead>
<tbody></tbody>
</table>
</div>
</div>

<?php endif; ?>
</div>
</div>

<script>
$(window).on('load',()=>{
$('#loader').fadeOut(500)
$('#app').fadeIn(500)
})

function toast(msg,icon='check_circle'){
$('#toastMsg').text(msg)
$('#toastIcon').text(icon)
$('#toast').addClass('show')
setTimeout(()=>$('#toast').removeClass('show'),2800)
}

$(function(){
let orders=<?= json_encode($orderedproducts) ?>;

function row(o,actions=false){
let r=`<tr class="text-center">
<td>${o.order_id}</td>
<td>${o.product_name}</td>
<td>${o.user_name}</td>
<td>${o.quantity}</td>
<td>$${o.price}</td>
<td>${o.status}</td>`;
if(actions){
r+=`<td class="space-x-1 flex flex-wrap justify-center gap-1">
<button class="approve-btn bg-emerald-400 text-slate-900 px-2 py-1 rounded"
data-id="${o.order_id}" data-status="approved">Approve</button>
<button class="reject-btn bg-red-500 px-2 py-1 rounded"
data-id="${o.order_id}" data-status="rejected">Reject</button>
</td>`;
}
return r+'</tr>';
}

orders.forEach(o=>{
if(o.status==='pending')$('#pendingTable tbody').append(row(o,true))
else if(o.status==='approved')$('#approvedTable tbody').append(row(o))
else $('#deliveredTable tbody').append(row(o))
})

$('#pendingTable,#approvedTable,#deliveredTable').DataTable({
pageLength:5,
responsive:true
})

$('#pendingTable').on('click','.approve-btn,.reject-btn',function(){
let id=$(this).data('id')
let status=$(this).data('status')
$('#loader').fadeIn(200)
$.post('<?= base_url('updateorderstatus') ?>',{order_id:id,status:status},res=>{
$('#loader').fadeOut(200)
if(res.success){
toast('Order '+status,'shopping_cart')
setTimeout(()=>location.reload(),900)
}else toast(res.message,'error')
},'json')
})

})
</script>

</body>
</html>
