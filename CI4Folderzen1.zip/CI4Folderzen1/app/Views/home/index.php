<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Zen Products - Shop</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@400;600&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
body {
  font-family: 'Inter', sans-serif;
  background-color: #f8fafc;
  color: #0f172a;
}
header {
  background: #ffffff;
  box-shadow: 0 4px 12px rgba(0,0,0,0.08);
  position: sticky;
  top: 0;
  z-index: 50;
}
.nav-link {
  transition: all 0.3s;
}
.nav-link:hover {
  color: #38bdf8;
}
.hero {
  background: linear-gradient(135deg, #38bdf8, #0ea5e9);
  color: white;
}
.hero h1 {
  font-weight: 700;
}
.product-card {
  transition: transform 0.3s, box-shadow 0.3s;
  border-radius: 1rem;
  overflow: hidden;
  background: #ffffff;
  box-shadow: 0 6px 16px rgba(0,0,0,0.08);
}
.product-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 12px 24px rgba(0,0,0,0.15);
}
.badge {
  background: #facc15;
  color: #0f172a;
  font-size: 0.75rem;
  padding: 0.25rem 0.5rem;
  border-radius:0.375rem;
  font-weight:600;
}
button {
  transition: all 0.3s;
}
button:hover {
  transform: translateY(-2px);
}/* Fullscreen cart loader */
#pageLoader {
  position: fixed;
  inset: 0;
  background: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  transition: opacity 0.4s ease, visibility 0.4s ease;
}

#pageLoader.hide {
  opacity: 0;
  visibility: hidden;
}


@keyframes spin {
  to { transform: rotate(360deg); }
}


</style>
</head>
<body class="min-h-screen">

<header class="py-4">
  <div class="max-w-7xl mx-auto flex justify-between items-center px-6">
    <h1 class="text-2xl font-bold text-sky-500 flex items-center gap-2">
      <span class="material-symbols-rounded">shopping_cart</span> Zen Products
    </h1>
    <nav class="flex items-center gap-6">
      <a href="/" class="nav-link font-medium text-slate-700 hover:text-sky-500">Home</a>
      <a href="#products" class="nav-link font-medium text-slate-700 hover:text-sky-500">Products</a>
<?php helper('cart'); $cartCount = getCartCount(); ?>

<div class="relative">
    <span class="material-symbols-rounded text-2xl">shopping_cart</span>
    <span id="cart-count"
          class="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-1.5 rounded-full
                 <?= $cartCount == 0 ? 'hidden' : '' ?>">
        <?= $cartCount ?>
    </span>
</div>


<div class="relative group inline-block"><a href="<?= session()->get('email') ? '/account' : '/openlogin' ?>" class="nav-link font-medium text-slate-700 hover:text-sky-500"><?= session()->get('email') ? 'Account' : 'Login' ?></a><?= session()->get('email') ? '<div class="absolute hidden group-hover:block right-0 mt-2 w-32 bg-white border rounded shadow-md"><a href="/logout" class="block px-4 py-2 text-sm hover:bg-slate-100">Logout</a></div>' : '' ?></div>

    </nav>
  </div>
</header>

<?php // In your view file
if (session()->getFlashdata('success')) {
    echo '<div class="alert alert-success">';
    echo session()->getFlashdata('success');
    echo '</div>';
}
 ?>
<section class="hero py-32 relative overflow-hidden">
  <div class="max-w-7xl mx-auto px-6 text-center relative z-10">
    <h1 class="text-5xl md:text-6xl mb-6 leading-tight">Shop Smart, Live Better</h1>
    <p class="text-lg md:text-xl text-sky-100 mb-8">Top products, fast delivery, and unbeatable deals in INR.</p>
    <a href="#products" class="bg-emerald-500 text-white font-semibold px-8 py-4 rounded-full shadow-lg inline-flex items-center gap-3 hover:bg-emerald-600 transition">
      <span class="material-symbols-rounded">shopping_bag</span> Shop Now
    </a>
  </div>
</section>

<section id="features" class="py-20 bg-slate-50">
  <div class="max-w-7xl mx-auto px-6 text-center mb-12">
    <h2 class="text-3xl font-bold text-sky-500 mb-6">Why Zen Products?</h2>
    <p class="text-slate-600 max-w-2xl mx-auto">High-quality products, amazing deals, and fast delivery. Shop confidently with Zen Products.</p>
  </div>
  <div class="max-w-7xl mx-auto px-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 text-center">
    <div class="p-6 bg-white rounded-2xl shadow-md hover:shadow-xl transition">
      <span class="material-symbols-rounded text-4xl text-sky-500 mb-4">flash_on</span>
      <h3 class="font-semibold text-lg mb-2">Fast Delivery</h3>
      <p class="text-slate-500 text-sm">Receive your products quickly anywhere in India.</p>
    </div>
    <div class="p-6 bg-white rounded-2xl shadow-md hover:shadow-xl transition">
      <span class="material-symbols-rounded text-4xl text-sky-500 mb-4">verified</span>
      <h3 class="font-semibold text-lg mb-2">Trusted Quality</h3>
      <p class="text-slate-500 text-sm">All products verified for quality and authenticity.</p>
    </div>
    <div class="p-6 bg-white rounded-2xl shadow-md hover:shadow-xl transition">
      <span class="material-symbols-rounded text-4xl text-sky-500 mb-4">discount</span>
      <h3 class="font-semibold text-lg mb-2">Great Deals</h3>
      <p class="text-slate-500 text-sm">Exclusive offers and discounts on top products.</p>
    </div>
    <div class="p-6 bg-white rounded-2xl shadow-md hover:shadow-xl transition">
      <span class="material-symbols-rounded text-4xl text-sky-500 mb-4">support_agent</span>
      <h3 class="font-semibold text-lg mb-2">24/7 Support</h3>
      <p class="text-slate-500 text-sm">We are always here to help with any query.</p>
    </div>
  </div>
</section>

<main class="py-20" id="products">
  <div class="max-w-7xl mx-auto px-6">
    <h3 class="text-3xl font-bold text-sky-500 mb-12 text-center">Explore Our Products</h3>
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
      <?php foreach($products as $p): 
        $discountedPrice = $p['price'] - ($p['price'] * $p['allowed_discount']/100);
      ?>
      <div class="product-card flex flex-col">
        <div class="relative">
          <?php if($p['image']): ?>
          <img src="<?= base_url('uploads/products/'.$p['image']) ?>" alt="<?= esc($p['product_name']) ?>" class="w-full h-56 object-cover">
          <?php endif; ?>
          <?php if($p['allowed_discount']>0): ?>
          <div class="badge absolute top-3 left-3">-<?= esc($p['allowed_discount']) ?>%</div>
          <?php endif; ?>
        </div>
        <div class="p-4 flex flex-col flex-grow bg-slate-50">
          <h4 class="text-lg font-semibold text-sky-500"><?= esc($p['product_name']) ?></h4>
          <p class="text-slate-600 text-sm mt-1 flex-grow line-clamp-3"><?= esc($p['description']) ?></p>
          <div class="mt-3 flex items-center gap-3">
            <?php if($p['allowed_discount']>0): ?>
              <span class="text-slate-400 line-through text-sm">₹<?= number_format($p['price'],2) ?></span>
              <span class="text-emerald-500 font-bold text-lg">₹<?= number_format($discountedPrice,2) ?></span>
            <?php else: ?>
              <span class="text-emerald-500 font-bold text-lg">₹<?= number_format($p['price'],2) ?></span>
            <?php endif; ?>
          </div>
          <div class="mt-1 text-slate-500 text-sm mb-3">
            Stock: <?= esc($p['stock_count']) ?>
          </div>
          <button class="add-to-cart-btn mt-auto bg-emerald-500 text-white font-semibold px-4 py-2 rounded-xl hover:bg-emerald-600 transition flex items-center justify-center gap-1 relative overflow-hidden" data-product-id="<?= $p['id'] ?>">
            <span class="material-symbols-rounded">add_shopping_cart</span>
            <span class="btn-text">Add to Cart</span>
            <span class="loader hidden absolute inset-0 flex items-center justify-center bg-white/50">
              <svg class="w-5 h-5 animate-spin text-emerald-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
              </svg>
            </span>
          </button>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</main>

<section id="cta" class="py-24 bg-gradient-to-r from-sky-400 to-sky-500 text-white text-center">
  <div class="max-w-7xl mx-auto px-6">
    <h2 class="text-4xl font-bold mb-4">Ready to Upgrade Your Shopping Experience?</h2>
    <p class="text-lg mb-8">Join thousands of satisfied customers and shop the best products online.</p>
    <a href="#products" class="bg-emerald-500 text-white font-semibold px-8 py-4 rounded-full shadow-lg inline-flex items-center gap-3 hover:bg-emerald-600 transition">
      <span class="material-symbols-rounded">shopping_bag</span> Start Shopping
    </a>
  </div>
</section>

<footer class="bg-slate-50 py-8 mt-16 shadow-inner">
  <div class="max-w-7xl mx-auto text-center text-slate-500 px-6">
    &copy; <?= date('Y') ?> Zen Products. All rights reserved.
  </div>
</footer>
<script>
window.addEventListener('load', () => {
  const loader = document.getElementById('pageLoader')

  setTimeout(() => {
    loader.classList.add('hide')
  }, 600)
})
</script>
<script>
$(document).on('click', '.add-to-cart-btn', function () {
    var product_id = $(this).data('product-id');
    $.ajax({
        url: 'PostCartItem',
        method: 'POST',
        data: { product_id: product_id },
        success: function(res) {
            if(res.status === 'success'){
                alert(res.message);
            } else if(res.status === 'error' && res.redirect) {
            }
        }
    });
});

</script>

</body>
<div id="pageLoader">
  <div class="flex flex-col items-center gap-4">
    <span class="material-symbols-rounded text-5xl text-sky-500">
      shopping_cart
    </span>
    <p class="text-slate-500 text-sm font-medium">
      Loading Zen Products…
    </p>
  </div>
</div>

</html>
