<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'UserController::index');
$routes->get('/seller/index', 'SellerController::index');
$routes->get('/seller/home', 'SellerOrderController::dashindex');
$routes->get('/openlogin', 'UserController::openlogin');
$routes->get('/openlogins', 'UserController::openlogin');

$routes->post('login','UserController::login');
$routes->get('login','UserController::login');
$routes->get('logout','UserController::logout');
$routes->post('newsignup','UserController::register');
$routes->post('seller/AddProduct', 'SellerController::AddProduct');
$routes->post('seller/delete', 'SellerController::delete');
$routes->post('seller/update', 'SellerController::update');
$routes->post('seller/getProductDetails', 'SellerController::getProductDetails');
$routes->post('seller/AddProduct', 'SellerController::AddProduct');

$routes->get('seller/orders', 'SellerOrderController::index');
$routes->post('updateorderstatus', 'SellerOrderController::updateorderstatus');


$routes->post('PostCartItem','CheckoutController::addtocart');
?>