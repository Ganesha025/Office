<?php
namespace App\Models;
use CodeIgniter\Model;

class UserModel extends Model {
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name','email','password','role','status'];
}

class SellerModel extends Model {
    protected $table = 'sellers';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id','shop_name','business_type','pan_number','address','bank_account','ifsc_code','approval_status'];
}

?>