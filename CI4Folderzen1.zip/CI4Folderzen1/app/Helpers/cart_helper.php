<?php

use App\Models\CartModel;

function getCartCount()
{
    $session = session();

    if (!$session->get('isLoggedIn')) {
        return 0;
    }

    $cart = model(CartModel::class);
    return $cart->where('user_id', $session->get('user_id'))->countAllResults();
}
