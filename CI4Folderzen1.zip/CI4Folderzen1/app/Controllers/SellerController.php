<?php
namespace App\Controllers;
use App\Models\ProductModel;
use App\Controllers\BaseController;
class SellerController extends BaseController{
    public function index() {
    $productModel = model(ProductModel::class);
    $usrid = session()->get('user_id');
    $data['products'] = $productModel->where('user_id', $usrid)->findAll();

    return view('seller/index', $data); 
}

    public function AddProduct() {
    $productModel = model(ProductModel::class);

    $image = $this->request->getFile('image');
    if($image && $image->isValid() && !$image->hasMoved()){
        $newName = $image->getRandomName(); // generate random filename
        $image->move(WRITEPATH . '../public/uploads/products/', $newName); // move file
    } else {
        $newName = null; 
    }

    $productData = [
        'user_id'          => session()->get('user_id'),
        'product_name'     => $this->request->getPost('product_name'),
        'description'      => $this->request->getPost('description'),
        'image'            => $newName,
        'price'            => $this->request->getPost('price'),
        'allowed_discount' => $this->request->getPost('allowed_discount') ?? 0,
        'stock_count'      => $this->request->getPost('stock_count'),
        'created_at'       => date('Y-m-d H:i:s'),
        'updated_at'       => date('Y-m-d H:i:s')
    ];

    try {
        $productModel->insert($productData);
        return $this->response->setJSON(['status'=>'success','message'=>'Product added successfully']);
    } catch (\Exception $e) {
        return $this->response->setJSON(['status'=>'error','message'=>$e->getMessage()]);
    }
}
public function delete(){
    $productModel = model(ProductModel::class);
    $productId = $this->request->getPost('product_id');

    try {
        $productModel->delete($productId);
        return $this->response->setJSON(['status'=>'success','message'=>'Product deleted successfully']);
    } catch (\Exception $e) {
        return $this->response->setJSON(['status'=>'error','message'=>$e->getMessage()]);
    }
}
// public function update(){
//     $productModel = model(ProductModel::class);
//     $productId = $this->request->getPost('product_id');

//     $productData = [
//         'product_name'     => $this->request->getPost('product_name'),
//         'description'      => $this->request->getPost('description'),
//         'price'            => $this->request->getPost('price'),
//         'allowed_discount' => $this->request->getPost('allowed_discount') ?? 0,
//         'stock_count'      => $this->request->getPost('stock_count'),
//         'updated_at'       => date('Y-m-d H:i:s')
//     ];

//     try {
//         $productModel->update($productId, $productData);
//         return $this->response->setJSON(['status'=>'success','message'=>'Product updated successfully']);
//     } catch (\Exception $e) {
//         return $this->response->setJSON(['status'=>'error','message'=>$e->getMessage()]);
//     }
// }
public function update(){
    $model=model(ProductModel::class);
    $id=$this->request->getPost('product_id');
    $data=[
        'product_name'=>$this->request->getPost('product_name'),
        'description'=>$this->request->getPost('description'),
        'price'=>$this->request->getPost('price'),
        'allowed_discount'=>$this->request->getPost('allowed_discount') ?? 0,
        'stock_count'=>$this->request->getPost('stock_count'),
        'updated_at'=>date('Y-m-d H:i:s')
    ];
    try{
        $model->update($id,$data);
        return $this->response->setJSON(['status'=>'success','message'=>'Product updated successfully']);
    }catch(\Exception $e){
        return $this->response->setJSON(['status'=>'error','message'=>$e->getMessage()]);
    }
}

public function getProductDetails(){
    $model=model(ProductModel::class);
    $id=$this->request->getPost('product_id');
    $product=$model->find($id);
    if($product){
        return $this->response->setJSON(['status'=>'success','product'=>$product]);
    }
    return $this->response->setJSON(['status'=>'error','message'=>'Product not found']);
}

}

?>