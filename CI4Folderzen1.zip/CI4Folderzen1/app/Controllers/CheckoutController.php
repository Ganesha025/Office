<?php
namespace App\Controllers;
use App\Models\UserModel;
use App\Models\OrderModel;
use App\Models\ProductModel;
use App\Models\CartModel;
use App\Controllers\BaseController;
class CheckoutController extends BaseController{

public function addtocart(){
    $session = session();
    $isLogged = $session->get('isLoggedIn');
    $usrId = $session->get('user_id');

    if (!$isLogged) {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Please login first',
            'redirect' => '/openlogin'
        ]);
    }

    $productID = $this->request->getPost('product_id');
    $cart = model(CartModel::class);
    $cart->insert([
        'user_id' => $usrId,
        'product_id' => $productID
    ]);
    $cartCount = $cart->where('user_id', $usrId)->countAllResults();  
    return $this->response->setJSON([
        'status' => 'success',
        'message' => 'Product added to cart',
        'redirect' => '/' 
    ]);
}
}