<?php
namespace App\Controllers;
use App\Models\UserModel;
use App\Controllers\BaseController;
use App\Models\SellerModel;
use App\Models\ProductModel;

class UserController extends BaseController{
    public function index(){
        $productModel = model(ProductModel::class);
        $products = $productModel->findAll();
        $data['products']=$products;
        return view('home/index',$data);
        // return view('login');
    }public function openlogin(){
        return view('login');
    }

public function register(){
        $userModel   = model(UserModel::class);
        $sellerModel = model(SellerModel::class);

        $role = $this->request->getVar('role') ?? 'user';
$userData = [
    'name'     => $this->request->getPost('username'),
    'email'    => $this->request->getPost('usermail'),
    'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),
    'role'     => $role,
    'status'   => 'active'
];

        $userModel->insert($userData);
        $userId = $userModel->getInsertID();
        if ($role === 'seller') {
            $sellerData = [
                'user_id'         => $userId,
                'shop_name'       => $this->request->getPost('shop_name'),
                'business_type'   => $this->request->getPost('business_type'),
                'pan_number'      => $this->request->getPost('pan_number'),
                'address'         => $this->request->getPost('address'),
                'bank_account'    => $this->request->getPost('bank_account'),
                'ifsc_code'       => $this->request->getPost('ifsc_code'),
                'approval_status' => 'pending'
            ];

            $sellerModel->insert($sellerData);
        }
        return redirect()->to('/login')->with('success', 'Registration successful');

}
public function login(){
    $model = new UserModel();
    $session = session();

    $useremail = $this->request->getPost('usermail');
    $password  = $this->request->getPost('password');
    $user = $model->where('email', $useremail)->first();

    if (!$user) {
        return redirect()->back()->with('error', 'Invalid email or password');
    }
    if (!password_verify($password, $user['password'])) {
        return redirect()->back()->with('error', 'Invalid email or password');
    }
    if ($user['role'] === 'seller') {
        $sellerModel = model(SellerModel::class);
        $seller = $sellerModel->where('user_id', $user['id'])->first();

        if (!$seller || $seller['approval_status'] !== 'approved') {
            return redirect()->back()->with('error', 'Seller account not approved yet');
        }
    }
    $session->set([
        'user_id' => $user['id'],
        'email'   => $user['email'],
        'role'    => $user['role'],
        'isLoggedIn' => true
    ]);
    if ($user['role'] === 'seller') {
        return redirect()->to('seller/index');
    }

        $productModel = model(ProductModel::class);
        $products = $productModel->findAll();
        $data['products']=$products;
        return view('home/index',$data);
}
public function logout(){
    $session = session();

    // Destroy entire session
    $session->destroy();

    return redirect()->to('/')->with('success', 'Logged out successfully');
}

}
?>