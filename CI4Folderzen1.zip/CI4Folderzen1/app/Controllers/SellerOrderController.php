<?php
namespace App\Controllers;
use App\Controllers\BaseController;
use App\Models\ProductModel;
use App\Models\OrderModel;
use App\Models\UserModel;
class SellerOrderController extends BaseController{
 public function index(){
    $usrid = session()->get('user_id');
    $orderModel = model(OrderModel::class);
    $productModel = model(ProductModel::class);
    $userModel = model(UserModel::class);

    $role = session()->get('role');
    if($role==='seller'){
        $sellerProducts = $productModel->where('user_id',$usrid)->findAll();
        $sellerProductIds = array_column($sellerProducts,'id');

        if(!empty($sellerProductIds)){
            $orders = $orderModel
    ->select('orders.id as order_id, orders.quantity, orders.price, orders.status, orders.created_at as ordered_date, products.product_name, products.description, products.image, users.name as user_name, users.address as user_address')
    ->join('products','products.id=orders.product_id')
    ->join('users','users.id=orders.user_id')
    ->whereIn('orders.product_id',$sellerProductIds)
    ->findAll();

        }else{
            $orders = [];
        }
        $data['orderedproducts']=$orders;
        return view('seller/orders',$data);
    }else{
        return redirect()->to('/');
    }
}
public function updateorderstatus(){
    $orderId = $this->request->getPost('order_id');
    $newStatus = $this->request->getPost('status');
    $orderModel = model(OrderModel::class);

    $updated = $orderModel->update($orderId, ['status' => $newStatus]);

    if($updated){
        return $this->response->setJSON(['success'=>true,'message'=>'Order status updated.']);
    } else {
        return $this->response->setJSON(['success'=>false,'message'=>'Order not found or not updated.']);
    }
}
public function dashindex(){
    $usrid = session()->get('user_id');
    $orderModel = model(OrderModel::class);
    $productModel = model(ProductModel::class);
    $userModel = model(UserModel::class);

    $role = session()->get('role');
    if($role==='seller'){
        $sellerProducts = $productModel->where('user_id',$usrid)->findAll();
        $sellerProductIds = array_column($sellerProducts,'id');

        if(!empty($sellerProductIds)){
            $orders = $orderModel
    ->select('orders.id as order_id, orders.quantity, orders.price, orders.status, orders.created_at as ordered_date, products.product_name, products.description, products.image, users.name as user_name, users.address as user_address')
    ->join('products','products.id=orders.product_id')
    ->join('users','users.id=orders.user_id')
    ->whereIn('orders.product_id',$sellerProductIds)
    ->findAll();

        }else{
            $orders = [];
        }
        $data['orderedproducts']=$orders;
        return view('seller/home',$data);
    }else{
        return redirect()->to('/');
    }
}

}