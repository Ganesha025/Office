<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "university_db";

$conn = mysqli_connect($host, $user, $pass);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS $db");
mysqli_select_db($conn, $db);

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Students (
    StudentID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    EnrollmentDate DATE,
    Major VARCHAR(50)
)");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Enrollments (
    EnrollmentID INT AUTO_INCREMENT PRIMARY KEY,
    StudentID INT,
    CourseName VARCHAR(50),
    EnrollmentDate DATE,
    Grade VARCHAR(2),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID)
)");

$countStudents = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM Students"));
$countEnrollments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM Enrollments"));

if($countStudents['total'] == 0 && $countEnrollments['total'] == 0) {

    mysqli_query($conn, "INSERT INTO Students (FirstName, LastName, EnrollmentDate, Major) VALUES
        ('John', 'Doe', '2023-01-10', 'CS'),
        ('Alice', 'Brown', '2023-02-15', 'Math'),
        ('Mike', 'Johnson', '2023-03-20', 'Physics'),
        ('Sarah', 'Williams', '2023-04-12', 'CS'),
        ('Emma', 'Davis', '2023-05-18', 'Math')
    ");

    mysqli_query($conn, "INSERT INTO Enrollments (StudentID, CourseName, EnrollmentDate, Grade) VALUES
        (1, 'CS101', '2023-01-15', 'A'),
        (1, 'Math101', '2023-02-01', 'B'),
        (1, 'Physics101', '2023-03-01', 'A'),
        (2, 'Math101', '2023-02-16', 'B'),
        (2, 'CS101', '2023-01-18', 'C'),
        (2, 'Physics101', '2023-03-05', 'B'),
        (2, 'Chem101', '2023-04-10', 'A'),
        (3, 'Physics101', '2023-03-21', 'A'),
        (3, 'CS101', '2023-01-22', 'B'),
        (4, 'CS101', '2023-04-15', 'A'),
        (4, 'Math101', '2023-05-10', 'B'),
        (5, 'Math101', '2023-05-20', 'C')
    ");
}
?>
