<?php include 'db.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>University Course Enrollment Analysis</title>
    <style>
        body { font-family: Arial; background: #eef2f3; padding: 20px; }
        h2 { text-align: center; color: #222; }
        table {
            width: 80%; margin: 20px auto; border-collapse: collapse;
            background: white; box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        th, td {
            padding: 12px; text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th { background: #007bff; color: white; font-size: 16px; }
        tr:nth-child(even) { background: #f5f5f5; }
        tr:hover { background: #dce7f9; transition: 0.3s ease; }
    </style>
</head>
<body>

<h2>University Course Enrollment Analysis</h2>

<?php

echo "<h3>1. Students and their enrolled courses</h3>";
$sql1 = "SELECT s.FirstName, s.LastName, e.CourseName
         FROM Students s
         LEFT JOIN Enrollments e ON s.StudentID = e.StudentID
         ORDER BY s.StudentID";
$result1 = $conn->query($sql1);

echo "<table>
<tr><th>Student Name</th><th>Course</th></tr>";
while($row = $result1->fetch_assoc()) {
    echo "<tr><td>".$row['FirstName']." ".$row['LastName']."</td><td>".$row['CourseName']."</td></tr>";
}
echo "</table>";


echo "<h3>2. Total number of students per course</h3>";
$sql2 = "SELECT CourseName, COUNT(StudentID) AS TotalStudents
         FROM Enrollments
         GROUP BY CourseName";
$result2 = $conn->query($sql2);

echo "<table>
<tr><th>Course</th><th>Total Students</th></tr>";
while($row = $result2->fetch_assoc()) {
    echo "<tr><td>".$row['CourseName']."</td><td>".$row['TotalStudents']."</td></tr>";
}
echo "</table>";

//  Average grade per course
// Let's assign grade points: A=4, B=3, C=2, D=1, F=0
echo "<h3>3. Average grade per course</h3>";
$sql3 = "SELECT CourseName, AVG(
    CASE Grade
        WHEN 'A' THEN 4
        WHEN 'B' THEN 3
        WHEN 'C' THEN 2
        WHEN 'D' THEN 1
        ELSE 0
    END) AS AvgGradePoint
    FROM Enrollments
    GROUP BY CourseName";
$result3 = $conn->query($sql3);

echo "<table>
<tr><th>Course</th><th>Average Grade Point</th></tr>";
while($row = $result3->fetch_assoc()) {
    echo "<tr><td>".$row['CourseName']."</td><td>".number_format($row['AvgGradePoint'],2)."</td></tr>";
}
echo "</table>";

echo "<h3>4. Students enrolled in more than 3 courses</h3>";
$sql4 = "SELECT s.FirstName, s.LastName, COUNT(e.CourseName) AS TotalCourses
         FROM Students s
         JOIN Enrollments e ON s.StudentID = e.StudentID
         GROUP BY s.StudentID
         HAVING TotalCourses > 3";
$result4 = $conn->query($sql4);

echo "<table>
<tr><th>Student Name</th><th>Total Courses</th></tr>";
while($row = $result4->fetch_assoc()) {
    echo "<tr><td>".$row['FirstName']." ".$row['LastName']."</td><td>".$row['TotalCourses']."</td></tr>";
}
echo "</table>";

//  Courses with average grade below 'B' (grade point < 3)
echo "<h3>5. Courses with average grade below B</h3>";
$sql5 = "SELECT CourseName, AVG(
    CASE Grade
        WHEN 'A' THEN 4
        WHEN 'B' THEN 3
        WHEN 'C' THEN 2
        WHEN 'D' THEN 1
        ELSE 0
    END) AS AvgGradePoint
    FROM Enrollments
    GROUP BY CourseName
    HAVING AvgGradePoint < 3";
$result5 = $conn->query($sql5);

echo "<table>
<tr><th>Course</th><th>Average Grade Point</th></tr>";
while($row = $result5->fetch_assoc()) {
    echo "<tr><td>".$row['CourseName']."</td><td>".number_format($row['AvgGradePoint'],2)."</td></tr>";
}
echo "</table>";

//  Total courses per student ordered descending
echo "<h3>6. Total courses per student (descending)</h3>";
$sql6 = "SELECT s.FirstName, s.LastName, COUNT(e.CourseName) AS TotalCourses
         FROM Students s
         JOIN Enrollments e ON s.StudentID = e.StudentID
         GROUP BY s.StudentID
         ORDER BY TotalCourses DESC";
$result6 = $conn->query($sql6);

echo "<table>
<tr><th>Student Name</th><th>Total Courses</th></tr>";
while($row = $result6->fetch_assoc()) {
    echo "<tr><td>".$row['FirstName']." ".$row['LastName']."</td><td>".$row['TotalCourses']."</td></tr>";
}
echo "</table>";

//  Students and total grade points (only completed >=4 courses)
echo "<h3>7. Students with total grade points (>=4 courses)</h3>";
$sql7 = "SELECT s.FirstName, s.LastName, SUM(
    CASE Grade
        WHEN 'A' THEN 4
        WHEN 'B' THEN 3
        WHEN 'C' THEN 2
        WHEN 'D' THEN 1
        ELSE 0
    END) AS TotalPoints, COUNT(e.CourseName) AS TotalCourses
    FROM Students s
    JOIN Enrollments e ON s.StudentID = e.StudentID
    GROUP BY s.StudentID
    HAVING TotalCourses >= 4";
$result7 = $conn->query($sql7);

echo "<table>
<tr><th>Student Name</th><th>Total Grade Points</th><th>Total Courses</th></tr>";
while($row = $result7->fetch_assoc()) {
    echo "<tr><td>".$row['FirstName']." ".$row['LastName']."</td><td>".$row['TotalPoints']."</td><td>".$row['TotalCourses']."</td></tr>";
}
echo "</table>";

// Students with highest total grade points
echo "<h3>8. Students with highest total grade points</h3>";
$sql8 = "SELECT s.FirstName, s.LastName, SUM(
    CASE Grade
        WHEN 'A' THEN 4
        WHEN 'B' THEN 3
        WHEN 'C' THEN 2
        WHEN 'D' THEN 1
        ELSE 0
    END) AS TotalPoints
    FROM Students s
    JOIN Enrollments e ON s.StudentID = e.StudentID
    GROUP BY s.StudentID
    ORDER BY TotalPoints DESC
    LIMIT 1";
$result8 = $conn->query($sql8);

echo "<table>
<tr><th>Student Name</th><th>Total Grade Points</th></tr>";
while($row = $result8->fetch_assoc()) {
    echo "<tr><td>".$row['FirstName']." ".$row['LastName']."</td><td>".$row['TotalPoints']."</td></tr>";
}
echo "</table>";

$conn->close();
?>

</body>
</html>
