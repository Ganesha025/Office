<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "product_sales_db";


$conn = mysqli_connect($host, $user, $pass);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS $db");
mysqli_select_db($conn, $db);


mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Products (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(25),
    ProductCategory VARCHAR(50),
    Price INT 
)");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Orders (
    OrderID INT AUTO_INCREMENT PRIMARY KEY,
    OrderDate DATE
)");


mysqli_query($conn, "CREATE TABLE IF NOT EXISTS OrderDetails (
    OrderDetailID INT AUTO_INCREMENT PRIMARY KEY,
    OrderID INT,
    ProductID INT,
    Quantity INT,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
)");


$count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM Products"));
if ($count['total'] == 0) {
    
    mysqli_query($conn, "INSERT INTO Products (ProductName, ProductCategory, Price) VALUES
        ('Laptop', 'Electronics', 45000),
        ('Smartphone', 'Electronics', 20000),
        ('Headphones', 'Electronics', 1500),
        ('T-Shirt', 'Clothing', 500),
        ('Jeans', 'Clothing', 1200),
        ('Shoes', 'Clothing', 2000),
        ('Notebook', 'Stationery', 50),
        ('Pen', 'Stationery', 10),
        ('Marker', 'Stationery', 20),
        ('Chair', 'Furniture', 2500),
        ('Table', 'Furniture', 5000)
    ");

    $currentYear = date("Y");

    
    mysqli_query($conn, "INSERT INTO Orders (OrderDate) VALUES
        ('$currentYear-01-10'),
        ('$currentYear-02-15'),
        ('$currentYear-03-20'),
        ('$currentYear-04-12'),
        ('2024-05-12'),
        ('2024-05-13')
    ");

    
    mysqli_query($conn, "INSERT INTO OrderDetails (OrderID, ProductID, Quantity) VALUES
        (1,1,2),(1,4,5),(1,7,10),
        (2,2,3),(2,5,2),(2,8,15),
        (3,3,4),(3,6,3),(3,9,20),
        (4,10,2),(4,11,1),(4,1,1)
    ");
}
?>
