<?php include 'db.php'; ?>

<?php
$sql = "
SELECT ProductCategory, COUNT(*) AS TotalProducts
FROM Products
GROUP BY ProductCategory
ORDER BY TotalProducts DESC;  -- Sorted by number of products
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Product Inventory Analysis</title>
    <style>
        body { background: #eef2f3; font-family: Arial; padding: 25px; }
        h2 { text-align: center; }
        table {
            width: 60%;
            margin: auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        th, td { padding: 12px; text-align: center; border-bottom: 1px solid #ddd; }
        th { background: #007bff; color: white; }
        tr:nth-child(even) { background: #f5f5f5; }
        tr:hover { background: #dce7f9; }
    </style>
</head>
<body>

<h2>Category-wise Product Count</h2>

<table>
    <tr>
        <th>Product Category</th>
        <th>Total Products</th>
    </tr>

    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>".$row['ProductCategory']."</td>
                      <td>".$row['TotalProducts']."</td></tr>";
        }
    } else {
        echo "<tr><td colspan='2'>No Data Found</td></tr>";
    }
    
    $conn->close();
    ?>
</table>

</body>
</html>
