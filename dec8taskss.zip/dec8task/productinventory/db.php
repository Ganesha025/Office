<?php
$host = "localhost";
$user = "root";
$pass = "";


$conn = mysqli_connect($host, $user, $pass);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS inventory_db");
mysqli_select_db($conn, "inventory_db");


$sql = "CREATE TABLE IF NOT EXISTS Products (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    ProductCategory VARCHAR(50) NOT NULL,
    Price DECIMAL(10,2)
)";
mysqli_query($conn, $sql);


$check = mysqli_query($conn, "SELECT COUNT(*) AS total FROM Products");
$count = mysqli_fetch_assoc($check)['total'];

if ($count == 0) {
    mysqli_query($conn, "INSERT INTO Products (ProductName, ProductCategory, Price) VALUES
        ('Laptop', 'Electronics', 45000.00),
        ('Smartphone', 'Electronics', 20000.00),
        ('Headphones', 'Electronics', 1500.00),
        ('T-Shirt', 'Clothing', 500.00),
        ('Jeans', 'Clothing', 1200.00),
        ('Shoes', 'Clothing', 2000.00),
        ('Notebook', 'Stationery', 50.00),
        ('Pen', 'Stationery', 10.00),
        ('Marker', 'Stationery', 20.00),
        ('Chair', 'Furniture', 2500.00),
        ('Table', 'Furniture', 5000.00)
    ");
}

?>
