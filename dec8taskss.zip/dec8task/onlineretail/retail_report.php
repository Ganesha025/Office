<?php include 'db.php'; ?>

<?php

$sql1 = "SELECT c.CustomerID, c.FirstName, c.LastName, p.Product, p.PurchaseDate, p.Amount
         FROM Customers c
         LEFT JOIN Purchases p ON c.CustomerID = p.CustomerID
         ORDER BY c.CustomerID, p.PurchaseDate";
$result1 = $conn->query($sql1);


$sql2 = "SELECT c.CustomerID, c.FirstName, c.LastName, SUM(p.Amount) AS TotalSpent
         FROM Customers c
         JOIN Purchases p ON c.CustomerID = p.CustomerID
         GROUP BY c.CustomerID";
$result2 = $conn->query($sql2);


$sql3 = "SELECT c.CustomerID, c.FirstName, c.LastName, AVG(p.Amount) AS AvgAmount
         FROM Customers c
         JOIN Purchases p ON c.CustomerID = p.CustomerID
         GROUP BY c.CustomerID";
$result3 = $conn->query($sql3);


$sql4 = "SELECT c.CustomerID, c.FirstName, c.LastName, SUM(p.Amount) AS TotalSpent
         FROM Customers c
         JOIN Purchases p ON c.CustomerID = p.CustomerID
         GROUP BY c.CustomerID
         HAVING SUM(p.Amount) > 1000";
$result4 = $conn->query($sql4);


$sql5 = "SELECT Product, COUNT(*) AS TotalPurchased
         FROM Purchases
         GROUP BY Product
         HAVING COUNT(*) > 10";
$result5 = $conn->query($sql5);


$sql6 = "SELECT c.CustomerID, c.FirstName, c.LastName, SUM(p.Amount) AS TotalSpent
         FROM Customers c
         JOIN Purchases p ON c.CustomerID = p.CustomerID
         GROUP BY c.CustomerID
         ORDER BY TotalSpent DESC";
$result6 = $conn->query($sql6);


$sql7 = "SELECT c.CustomerID, c.FirstName, c.LastName, SUM(p.Amount) AS TotalSpent, COUNT(p.PurchaseID) AS TotalPurchases
         FROM Customers c
         JOIN Purchases p ON c.CustomerID = p.CustomerID
         GROUP BY c.CustomerID
         HAVING COUNT(p.PurchaseID) >= 5";
$result7 = $conn->query($sql7);


$sql8 = "SELECT Product, SUM(Amount) AS TotalSales
         FROM Purchases
         GROUP BY Product
         ORDER BY TotalSales DESC
         LIMIT 1";
$result8 = $conn->query($sql8);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Online Retail Store Report</title>
    <style>
        body { font-family: Arial; background: #eef2f3; padding: 20px; }
        h2 { text-align: center; margin-top: 40px; }
        table { width: 70%; margin: auto; border-collapse: collapse; margin-bottom: 30px; background: white; box-shadow: 0 0 10px rgba(0,0,0,0.2);}
        th, td { padding: 12px; text-align: center; border-bottom: 1px solid #ddd; }
        th { background: #007bff; color: white; }
        tr:nth-child(even) { background: #f5f5f5; }
        tr:hover { background: #dce7f9; transition: 0.3s; }
    </style>
</head>
<body>

<h2>1. Customers and Their Purchases</h2>
<table>
<tr><th>ID</th><th>Name</th><th>Product</th><th>Purchase Date</th><th>Amount</th></tr>
<?php while($row = $result1->fetch_assoc()){
    echo "<tr><td>".$row['CustomerID']."</td><td>".$row['FirstName']." ".$row['LastName']."</td><td>".$row['Product']."</td><td>".$row['PurchaseDate']."</td><td>".number_format($row['Amount'],2)."</td></tr>";
} ?>
</table>

<h2>2. Total Amount Spent by Each Customer</h2>
<table>
<tr><th>ID</th><th>Name</th><th>Total Spent</th></tr>
<?php while($row = $result2->fetch_assoc()){
    echo "<tr><td>".$row['CustomerID']."</td><td>".$row['FirstName']." ".$row['LastName']."</td><td>".number_format($row['TotalSpent'],2)."</td></tr>";
} ?>
</table>

<h2>3. Average Amount per Purchase for Each Customer</h2>
<table>
<tr><th>ID</th><th>Name</th><th>Average Amount</th></tr>
<?php while($row = $result3->fetch_assoc()){
    echo "<tr><td>".$row['CustomerID']."</td><td>".$row['FirstName']." ".$row['LastName']."</td><td>".number_format($row['AvgAmount'],2)."</td></tr>";
} ?>
</table>

<h2>4. Customers Who Spent More Than 1000</h2>
<table>
<tr><th>ID</th><th>Name</th><th>Total Spent</th></tr>
<?php while($row = $result4->fetch_assoc()){
    echo "<tr><td>".$row['CustomerID']."</td><td>".$row['FirstName']." ".$row['LastName']."</td><td>".number_format($row['TotalSpent'],2)."</td></tr>";
} ?>
</table>

<h2>5. Products Purchased More Than 10 Times</h2>
<table>
<tr><th>Product</th><th>Times Purchased</th></tr>
<?php while($row = $result5->fetch_assoc()){
    echo "<tr><td>".$row['Product']."</td><td>".$row['TotalPurchased']."</td></tr>";
} ?>
</table>

<h2>6. Total Amount per Customer (Descending)</h2>
<table>
<tr><th>ID</th><th>Name</th><th>Total Spent</th></tr>
<?php while($row = $result6->fetch_assoc()){
    echo "<tr><td>".$row['CustomerID']."</td><td>".$row['FirstName']." ".$row['LastName']."</td><td>".number_format($row['TotalSpent'],2)."</td></tr>";
} ?>
</table>

<h2>7. Customers with at Least 5 Purchases</h2>
<table>
<tr><th>ID</th><th>Name</th><th>Total Spent</th><th>Total Purchases</th></tr>
<?php while($row = $result7->fetch_assoc()){
    echo "<tr><td>".$row['CustomerID']."</td><td>".$row['FirstName']." ".$row['LastName']."</td><td>".number_format($row['TotalSpent'],2)."</td><td>".$row['TotalPurchases']."</td></tr>";
} ?>
</table>

<h2>8. Product with Highest Total Sales</h2>
<table>
<tr><th>Product</th><th>Total Sales</th></tr>
<?php while($row = $result8->fetch_assoc()){
    echo "<tr><td>".$row['Product']."</td><td>".number_format($row['TotalSales'],2)."</td></tr>";
} ?>
</table>

</body>
</html>

<?php $conn->close(); ?>
