<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "online_retail_db";


$conn = mysqli_connect($host, $user, $pass);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS $db");
mysqli_select_db($conn, $db);


mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Customers (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(25),
    LastName VARCHAR(25),
    JoinDate DATE,
    Email VARCHAR(100)
)");


mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Purchases (
    PurchaseID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT,
    Product VARCHAR(50),
    PurchaseDate DATE,
    Amount INT,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
)");


$count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM Customers"));
if ($count['total'] == 0) {
    // Customers
    mysqli_query($conn, "INSERT INTO Customers (FirstName, LastName, JoinDate, Email) VALUES
        ('John', 'Doe', '2023-01-10', 'john@example.com'),
        ('Alice', 'Brown', '2023-02-15', 'alice@example.com'),
        ('Mike', 'Johnson', '2023-03-20', 'mike@example.com'),
        ('Sarah', 'Williams', '2023-04-12', 'sarah@example.com'),
        ('Emma', 'Davis', '2023-05-18', 'emma@example.com')
    ");

    // Purchases
    mysqli_query($conn, "INSERT INTO Purchases (CustomerID, Product, PurchaseDate, Amount) VALUES
        (1, 'Laptop', '2023-01-15', 1200),
        (1, 'Mouse', '2023-01-20', 50),
        (2, 'Keyboard', '2023-02-20', 80),
        (2, 'Laptop', '2023-03-01', 1300),
        (3, 'Monitor', '2023-03-22', 300),
        (3, 'Laptop', '2023-03-25', 1200),
        (3, 'Mouse', '2023-03-27', 60),
        (4, 'Laptop', '2023-04-15', 1500),
        (4, 'Keyboard', '2023-04-18', 90),
        (4, 'Mouse', '2023-04-20', 60),
        (4, 'Monitor', '2023-04-22', 350),
        (4, 'Printer', '2023-04-25', 200),
        (5, 'Laptop', '2023-05-20', 1400),
        (5, 'Mouse', '2023-05-22', 50),
        (5, 'Keyboard', '2023-05-25', 100)
    ");
}
?>
