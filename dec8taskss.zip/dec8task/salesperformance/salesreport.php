<?php include 'db.php'; ?>

<?php
$currentYear = date("Y"); // dynamic current year

$sql = "
SELECT e.sales_rep_id, e.sales_rep_name, SUM(s.amount) AS TotalRevenue
FROM Sales s
JOIN Employees e ON s.sales_rep_id = e.sales_rep_id
WHERE YEAR(s.sale_date) = '$currentYear'
GROUP BY e.sales_rep_id, e.sales_rep_name
ORDER BY TotalRevenue DESC
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sales Performance Report</title>
    <style>
        body { background: #eef2f3; font-family: Arial; padding: 30px; }
        h2 { text-align: center; }
        table {
            width: 70%; margin: auto; border-collapse: collapse;
            background: white; box-shadow: 0px 0px 10px rgba(0,0,0,0.3);
        }
        th, td { padding: 14px; text-align: center; border-bottom: 1px solid #ddd; }
        th { background: #28a745; color: white; font-size: 18px; }
        tr:nth-child(even) { background: #f2f2f2; }
        tr:hover { background: #d6f5d6; transition: 0.3s; }
    </style>
</head>
<body>

<h2>Sales Performance Analysis - <?= $currentYear ?></h2>

<table>
    <tr>
        <th>Sales Rep ID</th>
        <th>Sales Rep Name</th>
        <th>Total Sales Revenue (₹)</th>
    </tr>

    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>".$row['sales_rep_id']."</td>
                    <td>".$row['sales_rep_name']."</td>
                    <td>".number_format($row['TotalRevenue'], 2)."</td>
                </tr>";
        }
    } else {
        echo "<tr><td colspan='3'>No sales data found for $currentYear</td></tr>";
    }

    $conn->close();
    ?>
</table>

</body>
</html>
