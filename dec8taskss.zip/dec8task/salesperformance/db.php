<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "sales_analysis_db"; // new DB name

$conn = mysqli_connect($host, $user, $pass);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS $db");
mysqli_select_db($conn, $db);

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Employees (
    sales_rep_id INT AUTO_INCREMENT PRIMARY KEY,
    sales_rep_name VARCHAR(50) NOT NULL
)");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Sales (
    sale_id INT AUTO_INCREMENT PRIMARY KEY,
    sales_rep_id INT,
    sale_date DATE,
    amount DECIMAL(10,2),
    FOREIGN KEY (sales_rep_id) REFERENCES Employees(sales_rep_id)
)");


$count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM Employees"));
if ($count['total'] == 0) {

    mysqli_query($conn, "INSERT INTO Employees (sales_rep_name) VALUES
    ('John Doe'),
    ('Alice Brown'),
    ('Mike Johnson'),
    ('Sarah Williams')");

    $currentYear = date("Y");

    mysqli_query($conn, "INSERT INTO Sales (sales_rep_id, sale_date, amount) VALUES
    (1, '$currentYear-01-10', 2000),
    (1, '$currentYear-03-14', 1500),
    (2, '$currentYear-06-22', 5000),
    (2, '$currentYear-08-19', 2500),
    (3, '$currentYear-02-07', 3000),
    (4, '$currentYear-05-03', 4200),
    (1, '2024-12-15', 1800)  
    ");
}
?>
