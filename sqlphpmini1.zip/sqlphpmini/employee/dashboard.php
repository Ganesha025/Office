<?php
session_start();
require "../db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$message = "";

// Handle purchase form submission
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['product_id'], $_POST['quantity'])) {
    $product_id = (int)$_POST['product_id'];
    $quantity   = (int)$_POST['quantity'];

    if ($quantity < 1 || $quantity > 1000) {
        $message = "<div class='alert alert-danger'>Quantity must be between 1 and 1000</div>";
    } else {
        $stmt = $conn->prepare("SELECT product_name, price FROM products WHERE product_id=?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows > 0) {
            $product = $res->fetch_assoc();
            $total = $quantity * $product['price'];

            $stmt2 = $conn->prepare(
                "INSERT INTO purchases (user_id, product_id, quantity, total_amount, purchase_date)
                 VALUES (?, ?, ?, ?, CURDATE())"
            );
            $stmt2->bind_param("iiii", $user_id, $product_id, $quantity, $total);

            if ($stmt2->execute()) {
                $message = "<div class='alert alert-success'>Purchase successful: <b>{$product['product_name']}</b></div>";
            } else {
                $message = "<div class='alert alert-danger'>Purchase failed!</div>";
            }
        }
    }
}

$products = $conn->query("SELECT * FROM products ORDER BY product_name ASC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Employee Pantry | Office System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
body { background: linear-gradient(135deg, #f5f7fa, #e4ecf7); font-family: 'Segoe UI', sans-serif; padding-bottom: 90px; }
.navbar { background: #1f2937; padding: 12px 25px; }
.navbar-brand { color: #fff; font-weight: bold; font-size: 22px; }
.navbar-brand img { height: 40px; margin-right: 10px; }
.nav-link { color: #e5e7eb !important; }
.shelf { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 25px; }
.card { border-radius: 15px; overflow: hidden; border: none; background: rgba(255,255,255,0.85); backdrop-filter: blur(8px); transition: all 0.3s ease; }
.card:hover { transform: translateY(-8px); box-shadow: 0 15px 30px rgba(0,0,0,0.15); }
.card-img-top { height: 190px; object-fit: cover; }
.price-tag { position: absolute; top: 12px; left: 12px; background: #10b981; color: white; padding: 6px 12px; border-radius: 20px; font-size: 14px; font-weight: bold; }
.badge-expensive { position: absolute; top: 12px; right: 12px; background: #ef4444; color: white; padding: 6px 10px; border-radius: 20px; font-size: 12px; }
.card-body { display: flex; flex-direction: column; }
.total-box { font-weight: bold; background: #f1f5f9; }
footer { background: #1f2937; color: #d1d5db; text-align: center; padding: 15px; position: fixed; bottom: 0; width: 100%; }
input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
input[type=number] { -moz-appearance: textfield; }
</style>
</head>

<body>

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="#"><img src="../uploads/logo.jpg"> Office Pantry</a>
    <div class="ms-auto">
        <a href="purchase_history.php" class="btn btn-outline-light btn-sm me-2">My Purchases</a>
        <a href="../logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>
</nav>

<div class="container mt-4">
    <?= $message ?>
    <div class="shelf">
        <?php while($p = $products->fetch_assoc()){ ?>
        <div class="card position-relative">
            <span class="price-tag">₹<?= $p['price'] ?></span>
            <img src="../uploads/<?= $p['image'] ?>" class="card-img-top">
            <div class="card-body">
                <h5><?= $p['product_name'] ?></h5>
                <form method="POST">
                    <input type="hidden" name="product_id" value="<?= $p['product_id'] ?>">
                    <input type="number" name="quantity" class="form-control quantity mb-2"
                           data-price="<?= $p['price'] ?>" min="1" max="1000" placeholder="Quantity" required>
                    <input type="text" class="form-control total total-box mb-2" placeholder="Total ₹" readonly>
                    <button class="btn btn-primary w-100">Purchase</button>
                </form>
            </div>
        </div>
        <?php } ?>
    </div>
</div>

<footer>
    © <?= date('Y') ?> Office Pantry Monitoring System 
</footer>

<script>
$(".quantity").on("input", function(){
    let qty = parseInt($(this).val());
    let price = $(this).data("price");
    if(qty >= 1){
        let total = qty * price;
        $(this).closest("form").find(".total").val("₹" + total);

        // High-value purchase alert
        if(total > 1000){
            alert("High-value purchase – admin approval required.");
        }
    }
});
</script>

</body>
</html>
