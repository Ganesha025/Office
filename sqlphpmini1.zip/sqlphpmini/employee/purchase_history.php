<?php
session_start();
require "../db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Filter for **current month**
$month = date('m');
$year  = date('Y');

$sql = "SELECT p.purchase_id, pr.product_name, pr.image, p.quantity, p.total_amount, p.purchase_date
        FROM purchases p
        JOIN products pr ON p.product_id = pr.product_id
        WHERE p.user_id = ? AND MONTH(p.purchase_date)=? AND YEAR(p.purchase_date)=?
        ORDER BY p.purchase_date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $user_id, $month, $year);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
<title>My Purchases | Office Pantry</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg, #f5f7fa, #e4ecf7); font-family: 'Segoe UI', sans-serif; padding-bottom: 90px; }
.navbar { background: #1f2937; padding: 12px 25px; }
.navbar-brand { color: white; font-weight: bold; }
footer { background: #1f2937; color: #d1d5db; text-align: center; padding: 15px; position: fixed; bottom: 0; width: 100%; }
table img { border-radius: 8px; }
</style>
</head>

<body>
<nav class="navbar">
    <span class="navbar-brand">Office Pantry – Purchase History (This Month)</span>
    <div class="ms-auto">
        <a href="dashboard.php" class="btn btn-outline-light btn-sm me-2">Dashboard</a>
        <a href="../logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>
</nav>

<div class="container mt-4">
    <div class="card shadow-lg">
        <div class="card-body">
            <table class="table table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Product</th>
                        <th>Image</th>
                        <th>Qty</th>
                        <th>Total</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                <?php if($result->num_rows){ while($row = $result->fetch_assoc()){ ?>
                    <tr>
                        <td><?= $row['purchase_id'] ?></td>
                        <td><?= $row['product_name'] ?></td>
                        <td><img src="../uploads/<?= $row['image'] ?>" width="60"></td>
                        <td><?= $row['quantity'] ?></td>
                        <td>₹<?= $row['total_amount'] ?></td>
                        <td><?= date("d M Y", strtotime($row['purchase_date'])) ?></td>
                    </tr>
                <?php }} else { ?>
                    <tr><td colspan="6" class="text-center">No purchases this month</td></tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<footer>
    © <?= date('Y') ?> Office Pantry Monitoring System
</footer>
</body>
</html>
