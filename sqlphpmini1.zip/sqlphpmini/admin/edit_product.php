<?php
session_start();
require "../db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$id = $_GET['id'];
$res = $conn->query("SELECT * FROM products WHERE product_id=$id");
$data = $res->fetch_assoc();
$message = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $name = $_POST['product_name'];
    $price = $_POST['price'];

    // Update image if uploaded
    if (isset($_FILES['image']) && $_FILES['image']['name'] != "") {
        $filename = time().'_'.$_FILES['image']['name'];
        $target = "../uploads/".$filename;
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
        $img_sql = ", image='$filename'";
    } else {
        $img_sql = "";
    }

    $sql = "UPDATE products SET product_name='$name', price='$price' $img_sql WHERE product_id=$id";
    if ($conn->query($sql)) {
        $message = "<div class='alert alert-success'>Product updated!</div>";
        $res = $conn->query("SELECT * FROM products WHERE product_id=$id");
        $data = $res->fetch_assoc();
    } else {
        $message = "<div class='alert alert-danger'>Error: ".$conn->error."</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5" style="max-width:600px;">
    <div class="card p-4 shadow">
        <h3>Edit Product</h3>
        <?= $message ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Product Name</label>
                <input type="text" name="product_name" value="<?= $data['product_name'] ?>" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Price</label>
                <input type="number" name="price" value="<?= $data['price'] ?>" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Current Image</label><br>
                <img src="../uploads/<?= $data['image'] ?>" width="100">
            </div>

            <div class="mb-3">
                <label>Change Image</label>
                <input type="file" name="image" class="form-control" accept="image/*">
            </div>

            <button class="btn btn-primary w-100">Update Product</button>
        </form>
    </div>
</div>
</body>
</html>
