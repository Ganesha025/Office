<?php
session_start();
require "../db.php";

if($_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}

$id = (int)$_GET['id'];
$stmt = $conn->prepare("DELETE FROM users WHERE user_id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: employee_list.php");
exit;
