<?php
session_start();
require "../db.php";

// Only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// Fetch products
$sql = "SELECT * FROM products ORDER BY product_name ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Product Management | Office Pantry</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body {
    background: #fff8f0;
    font-family: 'Segoe UI', sans-serif;
    margin-bottom: 80px;
}

/* Header */
header {
    background: linear-gradient(135deg,#ff6f3c,#ff8c5a);
    color: white;
    padding: 15px 30px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-radius: 0 0 12px 12px;
}

header h2 {
    margin: 0;
    font-weight: bold;
    letter-spacing: 1px;
}

header a {
    color: white;
    text-decoration: none;
    margin-left: 15px;
}

header a:hover {
    text-decoration: underline;
}

/* Card */
.card {
    border-radius: 15px;
    box-shadow: 0 15px 30px rgba(0,0,0,0.1);
}

/* Table */
.table thead {
    background: #000;
    color: white;
}

.table img {
    border-radius: 8px;
    box-shadow: 0 5px 10px rgba(0,0,0,0.2);
}

/* Buttons */
.btn-add {
    background: linear-gradient(135deg,#28a745,#5fd37b);
    border: none;
    color: white;
    border-radius: 10px;
}

.btn-add:hover {
    opacity: 0.9;
}

.btn-sm {
    border-radius: 8px;
}

/* Footer */
footer {
    background: #000;
    color: white;
    text-align: center;
    padding: 15px;
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
}
</style>
</head>

<body>

<!-- HEADER -->
<header>
    <h2><i class="fa fa-box"></i> Product Management</h2>
    <div>
        <a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
      
    </div>
</header>

<!-- CONTENT -->
<div class="container mt-4">

    <div class="card p-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0">Available Products</h4>
            <a href="add_product.php" class="btn btn-add">
                <i class="fa fa-plus"></i> Add Product
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Product Name</th>
                        <th>Price (₹)</th>
                        <th width="160">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if($result->num_rows > 0){ 
                    while($row = $result->fetch_assoc()){ ?>
                    <tr>
                        <td><?= $row['product_id'] ?></td>
                        <td>
                            <img src="../uploads/<?= $row['image'] ?>" width="55">
                        </td>
                        <td><?= htmlspecialchars($row['product_name']) ?></td>
                        <td><?= number_format($row['price']) ?></td>
                        <td>
                            <a href="edit_product.php?id=<?= $row['product_id'] ?>" 
                               class="btn btn-primary btn-sm">
                               <i class="fa fa-edit"></i> Edit
                            </a>
                            <a href="delete_product.php?id=<?= $row['product_id'] ?>" 
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Delete this product?');">
                               <i class="fa fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                <?php }} else { ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">
                            No products found.
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- FOOTER -->
<footer>
    © <?= date('Y') ?> Office Pantry Monitoring System
</footer>

</body>
</html>
