<?php
session_start();
require "../db.php";

// Only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// Department-wise summary (EMPLOYEES ONLY)
$sql = "SELECT 
            u.department,
            SUM(p.total_amount) AS dept_total,

            (SELECT u2.emp_name
             FROM users u2
             JOIN purchases p2 ON u2.user_id = p2.user_id
             WHERE u2.department = u.department
               AND u2.role = 'employee'
             GROUP BY u2.user_id
             ORDER BY SUM(p2.total_amount) DESC
             LIMIT 1) AS top_spender,

            (SELECT pr.product_name
             FROM purchases p3
             JOIN users u3 ON p3.user_id = u3.user_id
             JOIN products pr ON p3.product_id = pr.product_id
             WHERE u3.department = u.department
               AND u3.role = 'employee'
             GROUP BY pr.product_name
             ORDER BY COUNT(*) DESC
             LIMIT 1) AS frequent_item

        FROM users u
        LEFT JOIN purchases p ON u.user_id = p.user_id
        WHERE u.role = 'employee'
        GROUP BY u.department";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Department Dashboard | Office Pantry</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body{
    background:#fff8f0;
    font-family:'Segoe UI',sans-serif;
    margin-bottom:80px;
}

/* HEADER */
header{
    background:linear-gradient(135deg,#ff6f3c,#ff8c5a);
    color:white;
    padding:15px 30px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    border-radius:0 0 12px 12px;
}
header h3{
    margin:0;
    font-weight:bold;
}
header a{
    color:white;
    text-decoration:none;
    margin-left:15px;
}

/* CARD */
.card{
    border-radius:15px;
    box-shadow:0 15px 30px rgba(0,0,0,0.12);
}

/* TABLE */
.table thead{
    background:#000;
    color:white;
}
.table td, .table th{
    vertical-align:middle;
}

/* FOOTER */
footer{
    background:#000;
    color:white;
    text-align:center;
    padding:15px;
    position:fixed;
    bottom:0;
    left:0;
    width:100%;
}
</style>
</head>

<body>

<!-- HEADER -->
<header>
    <h3><i class="fa-solid fa-building"></i> Department Dashboard</h3>
    <div>
        <a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
        
    </div>
</header>

<!-- CONTENT -->
<div class="container mt-4">
    <div class="card p-4">

        <h4 class="mb-3">Department-wise Purchase Summary</h4>

        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
                <thead>
                    <tr>
                        <th>Department</th>
                        <th>Total Spent (₹)</th>
                        <th>Top Spender</th>
                        <th>Most Frequent Item</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                ?>
                    <tr>
                        <td><?= htmlspecialchars($row['department']) ?></td>
                        <td><?= number_format($row['dept_total'] ?? 0) ?></td>
                        <td><?= $row['top_spender'] ?? '-' ?></td>
                        <td><?= $row['frequent_item'] ?? '-' ?></td>
                    </tr>
                <?php
                    }
                } else {
                ?>
                    <tr>
                        <td colspan="4" class="text-center text-muted">
                            No department data available
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<!-- FOOTER -->
<footer>
    © <?= date('Y') ?> Office Pantry Monitoring System
</footer>

</body>
</html>
