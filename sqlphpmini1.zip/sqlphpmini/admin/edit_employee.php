<?php
session_start();
require "../db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$id = $_GET['id'];

// Fetch employee details
$sql = "SELECT * FROM users WHERE user_id=$id";
$result = $conn->query($sql);
$data = $result->fetch_assoc();

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $emp_name = $_POST['emp_name'];
    $department = $_POST['department'];
    $username = $_POST['username'];

    $update = "UPDATE users SET 
              emp_name='$emp_name',
              department='$department',
              username='$username'
              WHERE user_id=$id";

    if ($conn->query($update)) {
        $message = "<div class='alert alert-success'>Updated successfully!</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Employee</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5" style="max-width: 600px;">
    <div class="card p-4 shadow">
        <h3>Edit Employee</h3>

        <?= $message ?>

        <form method="POST">

            <div class="mb-3">
                <label>Name</label>
                <input type="text" name="emp_name" value="<?= $data['emp_name'] ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label>Department</label>
                <input type="text" name="department" value="<?= $data['department'] ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label>Username</label>
                <input type="text" name="username" value="<?= $data['username'] ?>" class="form-control">
            </div>

            <button class="btn btn-primary w-100">Update</button>

        </form>
    </div>
</div>

</body>
</html>
