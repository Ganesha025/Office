<?php
session_start();
require "../db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (
        empty($_POST['emp_name']) ||
        empty($_POST['department']) ||
        empty($_POST['username']) ||
        empty($_POST['password'])
    ) {
        $message = "<div class='alert alert-danger'>Please fill all fields correctly</div>";
    } else {

        $emp_name   = $_POST['emp_name'];
        $department = $_POST['department'];
        $username   = $_POST['username'];
        $password   = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $role       = "employee";

        $stmt = $conn->prepare(
            "INSERT INTO users (username, password, role, emp_name, department)
             VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("sssss", $username, $password, $role, $emp_name, $department);

        if ($stmt->execute()) {
            $message = "<div class='alert alert-success'>Employee added successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Username already exists</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Employee</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

<style>
body, html {
    margin: 0;
    padding: 0;
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f0f4f8;
    display: flex;
    flex-direction: column;
}

/* HEADER */
.header {
    background: linear-gradient(90deg, #ff7e5f, #feb47b);
    color: white;
    padding: 20px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.header a {
    color: white;
    text-decoration: none;
    border: 1px solid white;
    padding: 6px 12px;
    border-radius: 6px;
}

/* CONTENT */
.main-content {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* CARD */
.card {
    width: 100%;
    max-width: 500px;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

/* PASSWORD TOGGLE */
.password-wrapper {
    position: relative;
}
.password-toggle {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    color: #ff6f3c;
    font-weight: bold;
    user-select: none;
}

/* FOOTER */
.footer {
    background: #333;
    color: white;
    text-align: center;
    padding: 12px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <h3><i class="fa-solid fa-user-plus"></i> Add Employee</h3>
    <a href="dashboard.php"><i class="fa-solid fa-house"></i> Dashboard</a>
</div>

<!-- CONTENT -->
<div class="main-content">
    <div class="card bg-white">

        <?= $message ?>

        <form method="POST" id="employeeForm" novalidate>

            <div class="mb-3">
                <label>Employee Name</label>
                <input type="text" name="emp_name" id="emp_name"
                       class="form-control"
                       maxlength="15" required autofocus>
            </div>

            <div class="mb-3">
                <label>Department</label>
                <input type="text" name="department" id="department"
                       class="form-control"
                       maxlength="15" required>
            </div>

            <div class="mb-3">
                <label>Username</label>
                <input type="text" name="username" id="username"
                       class="form-control"
                       maxlength="15" required>
            </div>

            <div class="mb-3 password-wrapper">
                <label>Password</label>
                <input type="password" name="password" id="password"
                       class="form-control"
                       maxlength="15" required>
                <span class="password-toggle" id="togglePwd">Show</span>
            </div>

            <button type="submit" class="btn btn-primary w-100">
                Add Employee
            </button>
        </form>
    </div>
</div>

<!-- FOOTER -->
<div class="footer">
    &copy; 2025 Office Pantry System
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function(){

    // Focus first field
    $("#emp_name").focus();

    // Hide error while typing
    $("input").on("input", function(){
        $(".alert-danger").fadeOut();
    });

    // Only alphabets & spaces (Employee + Department)
    $("#emp_name, #department").on("input", function(){
        this.value = this.value.replace(/[^a-zA-Z ]/g, '').substring(0,15);
    });

    // Username max 15 (spaces allowed)
    $("#username").on("input", function(){
        if(this.value.length > 15){
            this.value = this.value.substring(0,15);
        }
    });

    // Password max 15
    $("#password").on("input", function(){
        if(this.value.length > 15){
            this.value = this.value.substring(0,15);
        }
    });

    // Show / Hide password
    $("#togglePwd").click(function(){
        let pwd = $("#password");
        if(pwd.attr("type") === "password"){
            pwd.attr("type", "text");
            $(this).text("Hide");
        } else {
            pwd.attr("type", "password");
            $(this).text("Show");
        }
    });

});
</script>

</body>
</html>
