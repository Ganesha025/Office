<?php
session_start();
include "../db.php";
if($_SESSION['role'] != 'admin'){
    header("Location: ../index.php");
    exit;
}

$total = $conn->query("SELECT SUM(total_amount) as total FROM purchases")->fetch_assoc()['total'];
$product_count = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'];
$employee_count = $conn->query("SELECT COUNT(*) as count FROM users WHERE role='employee'")->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
body, html {
    margin: 0;
    padding: 0;
    height: 100%;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f0f4f8;
    display: flex;
    flex-direction: column;
}

/* HEADER */
.header {
    background: linear-gradient(90deg, #ff7e5f, #feb47b);
    color: white;
    padding: 20px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 10px rgba(0,0,0,0.1);
}
.header h2 { margin: 0; }
.header a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    border: 1px solid white;
    padding: 8px 15px;
    border-radius: 8px;
    transition: 0.3s;
}
.header a:hover { background: rgba(255,255,255,0.2); }

/* MAIN CONTENT */
.main-content {
    flex: 1; /* Take remaining height */
    padding: 20px 30px;
}

/* STATS CARDS */
.dashboard-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}
.card {
    border-radius: 12px;
    padding: 25px;
    color: white;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    transition: transform 0.2s;
    text-align: center;
}
.card:hover { transform: translateY(-5px); }
.card h4 { margin-bottom: 15px; font-size: 18px; }
.card p { font-size: 28px; font-weight: bold; margin: 0; }
.card-total { background: linear-gradient(135deg, #ff7e5f, #feb47b); }
.card-products { background: linear-gradient(135deg, #6a11cb, #2575fc); }
.card-employees { background: linear-gradient(135deg, #43cea2, #185a9d); }

/* DASHBOARD BUTTONS */
.dashboard-buttons {
    display: grid;
    grid-template-columns: repeat(3, 1fr); /* 3 per row */
    gap: 20px;
    margin-bottom: 30px;
}
.dashboard-buttons a {
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    color: white;
    font-weight: bold;
    font-size: 16px;
    padding: 15px;
    border-radius: 10px;
    transition: 0.3s;
}
.dashboard-buttons a i { margin-right: 10px; }
.btn-products { background: #ff7e5f; }
.btn-purchases { background: #43cea2; }
.btn-reports { background: #2575fc; }
.btn-add-employee { background: #ffb347; }
.btn-manage-employees { background: #6a11cb; }
.btn-dept { background: #f7971e; }
.dashboard-buttons a:hover { opacity: 0.85; }

/* FOOTER */
.footer {
    background: #333;
    color: #fff;
    text-align: center;
    padding: 15px;
}

/* RESPONSIVE */
@media(max-width:992px){
    .dashboard-buttons { grid-template-columns: repeat(2, 1fr); }
}
@media(max-width:576px){
    .dashboard-buttons { grid-template-columns: 1fr; }
    .header { flex-direction: column; gap: 10px; }
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h2><i class="fa-solid fa-chart-simple"></i> Pantry Dashboard</h2>
    <a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="main-content">

    <!-- STATS CARDS -->
    <div class="dashboard-container">
        <div class="card card-total">
            <h4>Total Spend</h4>
            <p>₹<?= $total ?: '0' ?></p>
            <i class="fa-solid fa-money-bill-trend-up fa-2x mt-2"></i>
        </div>
        <div class="card card-products">
            <h4>Products</h4>
            <p><?= $product_count ?></p>
            <i class="fa-solid fa-boxes-stacked fa-2x mt-2"></i>
        </div>
        <div class="card card-employees">
            <h4>Employees</h4>
            <p><?= $employee_count ?></p>
            <i class="fa-solid fa-users fa-2x mt-2"></i>
        </div>
    </div>

    <!-- DASHBOARD BUTTONS -->
    <div class="dashboard-buttons">
        <a href="products.php" class="btn-products"><i class="fa-solid fa-box"></i> Manage Products</a>
        <a href="purchases.php" class="btn-purchases"><i class="fa-solid fa-cart-shopping"></i> View Purchases</a>
        <a href="reports.php" class="btn-reports"><i class="fa-solid fa-file-chart-column"></i> Reports</a>
        <a href="add_employee.php" class="btn-add-employee"><i class="fa-solid fa-user-plus"></i> Add Employee</a>
        <a href="employee_list.php" class="btn-manage-employees"><i class="fa-solid fa-users-gear"></i> Manage Employees</a>
        <a href="dept_dashboard.php" class="btn-dept"><i class="fa-solid fa-building"></i> Department Dashboard</a>
    </div>

</div>

<!-- FOOTER -->
<div class="footer">
    &copy; 2025 Office Pantry System | Designed by Your Company
</div>

</body>
</html>
