<?php
session_start();
include "../db.php";
if($_SESSION['role'] != 'admin'){
    header("Location: ../index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin - Purchases</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
body, html {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f0f4f8;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* HEADER */
.header {
    background: linear-gradient(90deg, #ff7e5f, #feb47b);
    color: white;
    padding: 20px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 10px rgba(0,0,0,0.1);
}
.header h2 { margin: 0; }
.header a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    border: 1px solid white;
    padding: 8px 15px;
    border-radius: 8px;
    transition: 0.3s;
}
.header a:hover { background: rgba(255,255,255,0.2); }

/* MAIN CONTENT */
.main-content {
    flex: 1;
    padding: 20px 30px;
}

/* TABLE */
.table-responsive { box-shadow: 0 5px 15px rgba(0,0,0,0.05); border-radius: 10px; overflow: hidden; }
table { margin-bottom: 0; }
.table th, .table td { vertical-align: middle; text-align: center; }

/* Color-coded rows */
.table-danger { background-color: #f8d7da !important; }

/* FOOTER */
.footer {
    background: #333;
    color: #fff;
    text-align: center;
    padding: 15px;
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h2><i class="fa-solid fa-cart-shopping"></i> All Purchases</h2>
    <a href="dashboard.php"><i class="fa-solid fa-house"></i> Dashboard</a>
</div>

<!-- MAIN CONTENT -->
<div class="main-content">
    <div class="table-responsive">
        <table class="table table-hover table-striped table-bordered align-middle text-center">
            <thead class="table-dark">
                <tr>
                    <th>Employee</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Total Amount</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT pu.*, u.emp_name, p.product_name FROM purchases pu
                        JOIN users u ON pu.user_id=u.user_id
                        JOIN products p ON pu.product_id=p.product_id
                        ORDER BY pu.purchase_date DESC";
                $res = $conn->query($sql);
                while($row = $res->fetch_assoc()){
                    $class = $row['total_amount'] > 1000 ? 'table-danger' : '';
                    echo "<tr class='$class'>
                            <td>{$row['emp_name']}</td>
                            <td>{$row['product_name']}</td>
                            <td>{$row['quantity']}</td>
                            <td>₹{$row['total_amount']}</td>
                            <td>{$row['purchase_date']}</td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- FOOTER -->
<div class="footer">
    &copy; 2025 Office Pantry System | Designed by Your Company
</div>

</body>
</html>
