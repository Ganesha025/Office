<?php
// setup.php

$host = "localhost";
$user = "root";
$pass = "";

// Connect to MySQL server
$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 1. Create database
$conn->query("CREATE DATABASE IF NOT EXISTS pantry_monitor");
$conn->select_db("pantry_monitor");

// 2. Create users table
$conn->query("CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    password VARCHAR(255),
    role ENUM('admin','employee') NOT NULL,
    emp_name VARCHAR(100),
    department VARCHAR(50)
) ENGINE=InnoDB");

// 3. Create products table
$conn->query("CREATE TABLE IF NOT EXISTS products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(100),
    price INT,
    image VARCHAR(255)
) ENGINE=InnoDB");

// 4. Create purchases table
$conn->query("CREATE TABLE IF NOT EXISTS purchases (
    purchase_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    product_id INT,
    quantity INT,
    total_amount INT,
    purchase_date DATE,
    FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY(product_id) REFERENCES products(product_id) ON DELETE CASCADE
) ENGINE=InnoDB");

/* ===================================================
   IMPORTANT FIX – RESET DATA (FOREIGN KEY SAFE)
   =================================================== */
$conn->query("SET FOREIGN_KEY_CHECKS=0");
$conn->query("TRUNCATE TABLE purchases");
$conn->query("TRUNCATE TABLE products");
$conn->query("TRUNCATE TABLE users");
$conn->query("SET FOREIGN_KEY_CHECKS=1");

// 5. Insert sample users (SECURE PASSWORDS)
$adminPass = password_hash('admin123', PASSWORD_DEFAULT);
$johnPass  = password_hash('john123', PASSWORD_DEFAULT);
$anitaPass = password_hash('anita123', PASSWORD_DEFAULT);

$sql = "INSERT INTO users (username, password, role, emp_name, department) VALUES
('admin', '$adminPass', 'admin', 'Admin User', 'Admin'),
('john', '$johnPass', 'employee', 'John Doe', 'HR'),
('anita', '$anitaPass', 'employee', 'Anita Sharma', 'Accounts')";

if ($conn->query($sql)) {
    echo "Sample users inserted<br>";
}

// 6. Insert sample products
$sql = "INSERT INTO products (product_name, price, image) VALUES
('Tea', 10, 'tea.jpg'),
('Coffee', 20, 'coffee.jpg'),
('Snacks', 50, 'snacks.jpg'),
('Stationery', 30, 'stationery.jpg')";

if ($conn->query($sql)) {
    echo "Sample products inserted<br>";
}

// 7. Insert sample purchases (NOW IDs EXIST)
$sql = "INSERT INTO purchases (user_id, product_id, quantity, total_amount, purchase_date) VALUES
(2, 1, 5, 50, '2025-12-01'),
(2, 2, 2, 40, '2025-12-02'),
(3, 3, 3, 150, '2025-12-03'),
(3, 4, 2, 60, '2025-12-04'),
(2, 3, 4, 200, '2025-12-05')";

if ($conn->query($sql)) {
    echo "Sample purchases inserted<br>";
}

$conn->close();
echo "<br><b>Setup completed successfully!</b>";
?>
