<?php
namespace App\Controllers;

use App\Models\EmployeeModel;
use CodeIgniter\Controller;
class EmployeeController extends Controller
{
    protected $employeeModel;

    public function __construct()
    {
        $this->employeeModel = new EmployeeModel();
    }

    public function index()
    {
        $session = session();
        $role = $session->get('role');
        $department = $session->get('department');

        if ($role == 'HR') {
            $employees = $this->employeeModel->where('department', $department)->findAll();
        } else {
            $employees = $this->employeeModel->findAll();
        }

        return view('employees/index', ['employees' => $employees, 'role' => $role]);
    }

    public function create()
    {
        $session = session();
        $role = $session->get('role');
        $department = $session->get('department');

        return view('employees/create', ['role' => $role, 'department' => $department]);
    }

    public function store()
    {
        $data = $this->request->getPost();
        $session = session();
        $role = $session->get('role');
        $department = $session->get('department');

        if ($role == 'HR') {
            // HR can only add Staff in their department
            $data['role'] = 'Staff';
            $data['department'] = $department;
        }

        if (!$this->employeeModel->insert($data)) {
            return redirect()->back()->with('errors', $this->employeeModel->errors());
        }

        return redirect()->to('/employees')->with('success', 'Employee added successfully');
    }

    public function edit($id)
    {
        $session = session();
        $role = $session->get('role');
        $department = $session->get('department');
        $employee = $this->employeeModel->find($id);

        if (!$employee) return redirect()->to('/employees')->with('error', 'Employee not found');
        if ($role == 'HR' && $employee['department'] != $department)
            return redirect()->to('/employees')->with('error', 'Unauthorized');

        return view('employees/edit', ['employee' => $employee, 'role' => $role, 'department' => $department]);
    }

    public function update($id)
    {
        $data = $this->request->getPost();
        $session = session();
        $role = $session->get('role');
        $department = $session->get('department');
        $employee = $this->employeeModel->find($id);

        if (!$employee) return redirect()->to('/employees')->with('error', 'Employee not found');
        if ($role == 'HR' && $employee['department'] != $department)
            return redirect()->to('/employees')->with('error', 'Unauthorized');

        // HR cannot change role/department
        if ($role == 'HR') {
            $data['role'] = 'Staff';
            $data['department'] = $employee['department'];
        }

        // Set validation rules dynamically for update
        $this->employeeModel->setValidationRules([
            'emp_name'   => 'required|min_length[3]|max_length[100]',
            'email'      => 'required|valid_email|is_unique[employees.email,id,' . $id . ']',
            'department' => 'required|in_list[Sales,Finance]',
            'role'       => 'required|in_list[Staff,Manager,Admin]'
        ]);

        if (!$this->employeeModel->update($id, $data)) {
            return redirect()->back()->with('errors', $this->employeeModel->errors());
        }

        return redirect()->to('/employees')->with('success', 'Employee updated successfully');
    }

    public function delete($id)
    {
        $session = session();
        $role = $session->get('role');
        $department = $session->get('department');
        $employee = $this->employeeModel->find($id);

        if (!$employee) return redirect()->to('/employees')->with('error', 'Employee not found');
        if ($role == 'HR' && $employee['department'] != $department)
            return redirect()->to('/employees')->with('error', 'Unauthorized');

        $this->employeeModel->delete($id);
        return redirect()->to('/employees')->with('success', 'Employee deleted successfully');
    }
}
