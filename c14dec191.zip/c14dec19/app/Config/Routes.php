<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'AuthController::login');   // default page
$routes->get('login', 'AuthController::login');
$routes->post('loginPost', 'AuthController::loginPost');
$routes->get('logout', 'AuthController::logout');



$routes->group('', ['filter' => 'role:Admin,HR,Manager'], function($routes) {

   
    $routes->get('employees', 'EmployeeController::index');

    
    $routes->get('employees/create', 'EmployeeController::create', ['filter' => 'role:Admin,HR']);
    $routes->post('employees/store', 'EmployeeController::store', ['filter' => 'role:Admin,HR']);

    $routes->get('employees/edit/(:num)', 'EmployeeController::edit/$1', ['filter' => 'role:Admin,HR']);
    $routes->post('employees/update/(:num)', 'EmployeeController::update/$1', ['filter' => 'role:Admin,HR']);

    $routes->get('employees/delete/(:num)', 'EmployeeController::delete/$1', ['filter' => 'role:Admin,HR']);
});
