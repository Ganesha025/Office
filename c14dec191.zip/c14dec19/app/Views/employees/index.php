<?php helper('form'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Employee List</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

</head>
<body>
    <h1>Employee List</h1>

    <!-- Flash Messages -->
    <?php if(session()->getFlashdata('success')): ?>
        <div style="color:green"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>
    <?php if(session()->getFlashdata('error')): ?>
        <div style="color:red"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <!-- Add Employee Link (Admin/HR only) -->
    <?php if($role == 'Admin' || $role == 'HR'): ?>
        <a href="/employees/create">Add Employee</a>
    <?php endif; ?>

    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Department</th>
            <th>Role</th>
            <?php if($role == 'Admin' || $role == 'HR'): ?>
                <th>Actions</th>
            <?php endif; ?>
        </tr>
        <?php foreach($employees as $emp): ?>
        <tr>
            <td><?= $emp['id'] ?></td>
            <td><?= $emp['emp_name'] ?></td>
            <td><?= $emp['email'] ?></td>
            <td><?= $emp['department'] ?></td>
            <td><?= $emp['role'] ?></td>
            <?php if($role == 'Admin' || ($role == 'HR' && session()->get('department') == $emp['department'])): ?>
                <td>
                    <a href="/employees/edit/<?= $emp['id'] ?>" title="Edit">
    <i class="fas fa-edit"></i>
</a>
&nbsp;
<a href="/employees/delete/<?= $emp['id'] ?>" onclick="return confirm('Are you sure?')" title="Delete">
    <i class="fas fa-trash-alt" style="color:red"></i>
</a>

                </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; ?>
    </table>

    <br><a href="/logout">Logout</a>
</body>
</html>
