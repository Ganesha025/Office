<?php helper('form'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Employee</title>
</head>
<body>
    <h1>Create Employee</h1>

    <?php if(session()->getFlashdata('success')): ?>
        <div style="color:green"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>
    <?php if(session()->getFlashdata('error')): ?>
        <div style="color:red"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>
    <?php if(isset($errors)): ?>
        <div style="color:red">
            <ul>
            <?php foreach($errors as $error): ?>
                <li><?= $error ?></li>
            <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="/employees/store" method="post">
        <label>Name:</label><br>
        <input type="text" name="emp_name" value="<?= set_value('emp_name') ?>" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?= set_value('email') ?>" required><br><br>

        <label>Department:</label><br>
        <?php if($role == 'Admin'): ?>
            <select name="department" required>
                <option value="">Select</option>
                <option value="Sales" <?= set_select('department','Sales') ?>>Sales</option>
                <option value="Finance" <?= set_select('department','Finance') ?>>Finance</option>
            </select>
        <?php else: ?>
            <input type="text" name="department" value="<?= $department ?>" readonly>
        <?php endif; ?><br><br>

        <label>Role:</label><br>
        <?php if($role == 'Admin'): ?>
            <select name="role" required>
                <option value="Staff" <?= set_select('role','Staff') ?>>Staff</option>
                <option value="Manager" <?= set_select('role','Manager') ?>>Manager</option>
                <option value="Admin" <?= set_select('role','Admin') ?>>Admin</option>
            </select>
        <?php else: ?>
            <input type="text" name="role" value="Staff" readonly>
        <?php endif; ?><br><br>

        <button type="submit">Create</button>
    </form>

    <br><a href="/employees">Back to Employee List</a>
</body>
</html>
