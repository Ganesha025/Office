<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
<h1>Login</h1>
<?php if(session()->getFlashdata('error')): ?>
<div style="color:red"><?= session()->getFlashdata('error') ?></div>
<?php endif; ?>
<form action="<?= base_url('loginPost') ?>" method="post">
Email: <input type="email" name="email" required><br><br>
Password: <input type="password" name="password" required><br><br>
<button type="submit">Login</button>
</form>
</body>
</html>
