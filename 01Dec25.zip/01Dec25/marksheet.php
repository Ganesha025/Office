<?php
session_start();
require_once './config/db.php';

$departments = $conn->query("SELECT * FROM departments ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);

$selected_department = $_POST['department'] ?? '';
$selected_student = $_POST['student'] ?? '';
$students = [];
$marks = [];
$stats = [];
$student_totals = [];

// Get students of selected department
if ($selected_department) {
    $stmt = $conn->prepare("SELECT reg_no, name FROM students WHERE department_id = ? ORDER BY name ASC");
    $stmt->bind_param("i", $selected_department);
    $stmt->execute();
    $students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

// Get marks for selected student
if ($selected_student) {
    $stmt = $conn->prepare("SELECT department_id FROM students WHERE reg_no = ?");
    $stmt->bind_param("s", $selected_student);
    $stmt->execute();
    $dept_id = $stmt->get_result()->fetch_assoc()['department_id'] ?? 0;
    $stmt->close();

    if ($dept_id) {
        $stmt = $conn->prepare("
            SELECT s.subject_name, i.internal1, i.internal2, i.assignment, i.total AS internal_total,
                   e.marks AS external_marks
            FROM subjects s
            LEFT JOIN internal_marks i ON s.id = i.subject_id AND i.reg_no = ?
            LEFT JOIN external_marks e ON s.id = e.subject_id AND e.reg_no = ?
            WHERE s.department_id = ?
            ORDER BY s.subject_name ASC
        ");
        $stmt->bind_param("ssi", $selected_student, $selected_student, $dept_id);
        $stmt->execute();
        $marks = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        $marks = array_filter($marks, fn($m) => ($m['internal_total']??0) + ($m['external_marks']??0) > 0);
    }
}

// Get semester stats for all students in department
if ($selected_department) {
    $stmt = $conn->prepare("
        SELECT st.reg_no, st.name, SUM(IFNULL(im.total,0) + IFNULL(em.marks,0)) as total_marks
        FROM students st
        LEFT JOIN subjects sub ON sub.department_id = st.department_id
        LEFT JOIN internal_marks im ON im.reg_no = st.reg_no AND im.subject_id = sub.id
        LEFT JOIN external_marks em ON em.reg_no = st.reg_no AND em.subject_id = sub.id
        WHERE st.department_id = ?
        GROUP BY st.reg_no
    ");
    $stmt->bind_param("i", $selected_department);
    $stmt->execute();
    $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    foreach ($results as $r) $student_totals[] = $r['total_marks'];

    if ($student_totals && max($student_totals) > 0) {
        $stats['average'] = array_sum($student_totals)/count($student_totals);
        $stats['highest'] = max($student_totals);
        $stats['lowest'] = min($student_totals);
        $pass_count = count(array_filter($student_totals, fn($m)=> $m>=40));
        $stats['pass_percentage'] = ($pass_count/count($student_totals))*100;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Marksheet & Department Analysis</title>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@3.3.3/dist/tailwind.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.tailwindcss.com"></script>

<style>
body { font-family: 'Inter', sans-serif; }
.bar-container { height: 40px; border-radius: 8px; overflow: hidden; }
.bar-fill { height: 100%; display: flex; align-items: center; justify-content: flex-end; padding-right: 10px; color: white; font-weight: 600; transition: width 1.2s; }
</style>
</head>
<body class="bg-gray-50 min-h-screen p-6">
<div class="max-w-7xl mx-auto">

<!-- Header -->
<div class="flex items-center justify-between mb-6">
    <h1 class="text-3xl font-bold text-gray-800"><i class="fas fa-chart-line mr-2 text-blue-500"></i>Marksheet & Department Analysis</h1>
</div>

<!-- Filters -->
<form method="post" class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
<div>
<label class="block mb-2 font-semibold text-gray-700"><i class="fas fa-building mr-1"></i> Department</label>
<select name="department" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-400" onchange="this.form.submit()">
<option value="">-- Select Department --</option>
<?php foreach($departments as $d): ?>
<option value="<?= $d['id'] ?>" <?= ($d['id']==$selected_department)?'selected':'' ?>><?= htmlspecialchars($d['name']) ?></option>
<?php endforeach; ?>
</select>
</div>

<?php if($students): ?>
<div>
<label class="block mb-2 font-semibold text-gray-700"><i class="fas fa-user-graduate mr-1"></i> Student</label>
<select name="student" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-400" onchange="this.form.submit()">
<option value="">-- Select Student --</option>
<?php foreach($students as $s): ?>
<option value="<?= $s['reg_no'] ?>" <?= ($s['reg_no']==$selected_student)?'selected':'' ?>><?= htmlspecialchars($s['name']) ?></option>
<?php endforeach; ?>
</select>
</div>
<?php endif; ?>
</form>

<!-- Student Marksheet -->
<?php if($marks): ?>
<h2 class="text-2xl font-semibold text-gray-800 mb-4"><i class="fas fa-file-alt mr-2 text-green-500"></i>Marksheet: <?= htmlspecialchars($selected_student) ?></h2>
<div class="overflow-x-auto rounded-lg shadow-lg mb-8">
<table class="w-full table-auto text-center border-collapse border border-gray-200">
<thead class="bg-gradient-to-r from-green-200 to-blue-200 text-gray-800 font-semibold">
<tr>
<th class="border px-4 py-2">Subject</th>
<th class="border px-4 py-2">Intern 1</th>
<th class="border px-4 py-2">Intern 2</th>
<th class="border px-4 py-2">Ass</th>
<th class="border px-4 py-2">Ext</th>
<th class="border px-4 py-2">Total</th>
</tr>
</thead>
<tbody class="bg-white">
<?php foreach($marks as $m): 
$external = $m['external_marks'] ?? 0;
if ($external > 50) $external = 50;
$grand_total = $external + ($m['internal1'] ?? 0) + ($m['internal2'] ?? 0) + ($m['assignment'] ?? 0);
?>
<tr class="hover:bg-gray-100 transition">
<td class="border px-4 py-2 font-medium"><?= htmlspecialchars($m['subject_name']) ?></td>
<td class="border px-4 py-2"><?= $m['internal1'] ?? 0 ?></td>
<td class="border px-4 py-2"><?= $m['internal2'] ?? 0 ?></td>
<td class="border px-4 py-2"><?= $m['assignment'] ?? 0 ?></td>
<td class="border px-4 py-2"><?= $external ?></td>
<td class="border px-4 py-2 font-bold text-blue-600"><?= $grand_total ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php elseif($selected_student): ?>
<p class="text-red-600 font-semibold mb-6">No marks found for this student.</p>
<?php endif; ?>

<!-- Department Analysis -->
<?php if($stats && max($student_totals) > 0): ?>
<h2 class="text-2xl font-semibold text-gray-800 mb-4"><i class="fas fa-chart-pie mr-2 text-purple-500"></i>Department Analysis</h2>
<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 mb-6">
<div class="p-4 bg-blue-50 rounded-xl shadow hover:shadow-lg transition text-center">
<p class="text-gray-600 font-medium mb-2"><i class="fas fa-calculator mr-1"></i> Average Marks</p>
<p class="text-2xl font-bold text-blue-600"><?= number_format($stats['average']/4,2) ?></p>
</div>
<div class="p-4 bg-green-50 rounded-xl shadow hover:shadow-lg transition text-center">
<p class="text-gray-600 font-medium mb-2"><i class="fas fa-trophy mr-1"></i> Highest Marks</p>
<p class="text-2xl font-bold text-green-600"><?= $stats['highest'] ?></p>
</div>
<div class="p-4 bg-red-50 rounded-xl shadow hover:shadow-lg transition text-center">
<p class="text-gray-600 font-medium mb-2"><i class="fas fa-arrow-down mr-1"></i> Lowest Marks</p>
<p class="text-2xl font-bold text-red-600"><?= $stats['lowest'] ?></p>
</div>
<div class="p-4 bg-yellow-50 rounded-xl shadow hover:shadow-lg transition text-center">
<p class="text-gray-600 font-medium mb-2"><i class="fas fa-percentage mr-1"></i> Pass %</p>
<p class="text-2xl font-bold text-yellow-600"><?= number_format($stats['pass_percentage'],2) ?>%</p>
</div>
</div>

<h3 class="text-xl font-semibold mb-3"><i class="fas fa-bars mr-1 text-indigo-500"></i>Marks Distribution</h3>
<div id="barChart" class="space-y-3">
<?php 
$max_marks = max($student_totals);
foreach($results as $r): 
    $width = $max_marks > 0 ? ($r['total_marks'] / $max_marks) * 100 : 0;
?>
<div class="bar-container bg-gray-200">
<div class="bar-fill bg-gradient-to-r from-purple-500 to-indigo-500" data-width="<?= $width ?>">
<?= htmlspecialchars($r['name']) ?> - <?= $r['total_marks'] ?>
</div>
</div>
<?php endforeach; ?>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(function(){
    $('.bar-fill').each(function(){
        var w = $(this).data('width');
        $(this).css('width','0%');
        $(this).animate({width: w+'%'}, 1200);
    });
});
</script>
<?php elseif($stats): ?>
<p class="text-gray-500">No marks available to display analysis.</p>
<?php endif; ?>

</div>
</body>
</html>
