<?php
session_start();
require_once '../../config/db.php';

if(!isset($_SESSION['role']) || $_SESSION['role']!=='admin'){
    header("Location: ../../public/index.php");
    exit;
}

$action = $_GET['action'] ?? 'form';
$departments_result = $conn->query("SELECT * FROM departments ORDER BY name ASC");
if(!$departments_result){
    die("Error fetching departments: " . $conn->error);
}
$departments = $departments_result->fetch_all(MYSQLI_ASSOC);

$semesters = $conn->query("SELECT * FROM semesters ORDER BY sem_number ASC")->fetch_all(MYSQLI_ASSOC);

if(isset($_POST['get_students'])){
    $semester_id = intval($_POST['semester_id']);
    $department_id = intval($_POST['department_id']);
    $res = $conn->query("SELECT s.reg_no, s.name FROM students s WHERE s.department_id=$department_id ORDER BY s.name ASC");
    echo '<option value="">Select Student</option>';
    while($row = $res->fetch_assoc()){
        echo '<option value="'.$row['reg_no'].'">'.$row['name'].' ('.$row['reg_no'].')</option>';
    }
    exit;
}

if(isset($_POST['get_semesters'])){
    $department_id = intval($_POST['department_id']);
    $sql = "SELECT DISTINCT sem.id, sem.sem_number FROM semesters sem JOIN programs p ON sem.program_id = p.id JOIN students s ON s.program_id = p.id WHERE s.department_id = $department_id ORDER BY sem.sem_number ASC";
    $res = $conn->query($sql);
    if(!$res){
        die("Error fetching semesters: " . $conn->error);
    }
    echo '<option value="">Select Semester</option>';
    while($row = $res->fetch_assoc()){
        echo '<option value="'.$row['id'].'">Semester '.$row['sem_number'].'</option>';
    }
    exit;
}

if(isset($_POST['get_subjects'])){
    $reg_no = $_POST['reg_no'];
    $semester_id = intval($_POST['semester_id']);
    $department_id = intval($_POST['department_id']);
    $subjects = $conn->query("SELECT * FROM subjects WHERE department_id=$department_id AND semester_id=$semester_id LIMIT 6")->fetch_all(MYSQLI_ASSOC);
    if(count($subjects)==6){
        echo '<h3 class="font-bold mb-2">Subjects:</h3><ul class="list-disc pl-6">';
        foreach($subjects as $sub){
            echo '<li>'.$sub['subject_name'].'</li>';
        }
        echo '</ul>';
    } else {
        echo '<p class="text-red-500">This student is not eligible for hall ticket (less than 6 subjects).</p>';
    }
    exit;
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['generate'])){
    $reg_no = $_POST['reg_no'];
    $semester_id = intval($_POST['semester_id']);
    $department_id = intval($_POST['department_id']);
    $subjects = $conn->query("SELECT * FROM subjects WHERE department_id=$department_id AND semester_id=$semester_id LIMIT 6")->fetch_all(MYSQLI_ASSOC);
    if(count($subjects)!=6){
        die("Cannot generate hall ticket. Student is not eligible (less than 6 subjects).");
    }
    $stmt = $conn->prepare("INSERT INTO hall_tickets (reg_no, semester_id, exam_session) VALUES (?,?,?)");
    $exam_session = date("M Y");
    $stmt->bind_param("sis",$reg_no,$semester_id,$exam_session);
    $stmt->execute();
    $hall_ticket_id = $stmt->insert_id;
    $stmt2 = $conn->prepare("INSERT INTO hall_ticket_subjects (hall_ticket_id, subject_id) VALUES (?,?)");
    foreach($subjects as $sub){
        $stmt2->bind_param("ii",$hall_ticket_id,$sub['id']);
        $stmt2->execute();
    }
    header("Location: ?action=print&id=$hall_ticket_id");
    exit;
}

$ticket = null;
$ticket_subjects = [];
if($action==='print' && isset($_GET['id'])){
    $id = intval($_GET['id']);
    $ticket = $conn->query("SELECT ht.*, s.name as student_name, s.reg_no FROM hall_tickets ht JOIN students s ON ht.reg_no=s.reg_no WHERE ht.id=$id")->fetch_assoc();
    $ticket_subjects = $conn->query("SELECT sub.subject_name FROM hall_ticket_subjects hts JOIN subjects sub ON hts.subject_id=sub.id WHERE hts.hall_ticket_id=$id")->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Generate Hall Ticket</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class="bg-gray-100">
<div class="flex min-h-screen p-6">

<div class="flex-1">

<?php if($action==='form'): ?>

<h1 class="text-4xl font-bold mb-6 flex items-center gap-2">
<span class="material-icons text-blue-700 text-4xl">assignment</span>
Generate Hall Ticket
</h1>

<form method="POST" class="bg-white p-8 rounded-[25px] shadow-lg max-w-xl">

<label class="block mb-2 font-semibold">Department</label>
<select name="department_id" id="department_select" required class="w-full p-3 border rounded-[25px] mb-4">
<option value="">Select Department</option>
<?php foreach($departments as $dept): ?>
<option value="<?= $dept['id'] ?>"><?= $dept['name'] ?></option>
<?php endforeach; ?>
</select>

<label class="block mb-2 font-semibold">Semester</label>
<select name="semester_id" id="semester_select" required class="w-full p-3 border rounded-[25px] mb-4" disabled>
<option value="">Select Department First</option>
</select>

<label class="block mb-2 font-semibold">Student</label>
<select name="reg_no" id="student_select" required class="w-full p-3 border rounded-[25px] mb-4" disabled>
<option value="">Select Semester First</option>
</select>

<div id="subjects_list" class="mb-4"></div>

<button type="submit" name="generate" class="w-full py-3 bg-blue-700 text-white rounded-[25px] hover:bg-blue-800 text-lg">
Generate Hall Ticket
</button>

</form>

<script>
$(document).ready(function(){
$("#department_select").change(function(){
    let dept_id = $(this).val();
    if(dept_id){
        $.ajax({
            method: 'POST',
            data: {get_semesters: 1, department_id: dept_id},
            success: function(data){
                $("#semester_select").html(data).prop('disabled', false);
                $("#student_select").html('<option>Select Semester First</option>').prop('disabled', true);
                $("#subjects_list").html('');
            }
        });
    }
});

$("#semester_select").change(function(){
    let semester_id = $(this).val();
    let department_id = $("#department_select").val();
    if(semester_id && department_id){
        $.ajax({
            method: 'POST',
            data: {get_students:1, semester_id:semester_id, department_id:department_id},
            success: function(data){
                $("#student_select").html(data).prop('disabled', false);
                $("#subjects_list").html('');
            }
        });
    }
});

$("#student_select").change(function(){
    let reg_no = $(this).val();
    let semester_id = $("#semester_select").val();
    let department_id = $("#department_select").val();
    if(reg_no && semester_id && department_id){
        $.ajax({
            method: 'POST',
            data: {get_subjects:1, reg_no:reg_no, semester_id:semester_id, department_id:department_id},
            success: function(data){
                $("#subjects_list").html(data);
            }
        });
    }
});
});
</script>

<?php elseif($action==='print' && $ticket): ?>

<div class="bg-white p-8 rounded-[25px] shadow-lg max-w-xl mx-auto mt-10">
<h2 class="text-3xl font-bold text-center mb-4 flex items-center justify-center gap-2">
<span class="material-icons text-green-700 text-3xl">badge</span>
Hall Ticket
</h2>

<p class="text-lg"><strong>Name:</strong> <?= $ticket['student_name'] ?></p>
<p class="text-lg"><strong>Reg No:</strong> <?= $ticket['reg_no'] ?></p>
<p class="text-lg"><strong>Exam Session:</strong> <?= $ticket['exam_session'] ?></p>

<hr class="my-4">

<h3 class="text-xl font-bold mb-2">Subjects</h3>
<ul class="list-disc pl-6 text-lg">
<?php foreach($ticket_subjects as $sub): ?>
<li><?= $sub['subject_name'] ?></li>
<?php endforeach; ?>
</ul>

<button onclick="window.print()" class="w-full mt-6 py-3 bg-green-700 text-white rounded-[25px] hover:bg-green-800 text-lg">
Print Hall Ticket
</button>

</div>

<?php endif; ?>

</div>
</div>
</body>
</html>
