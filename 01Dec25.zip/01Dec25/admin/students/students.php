<?php
session_start();
require_once '../../config/db.php';

// Admin access only
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../../public/index.php");
    exit;
}

// Action: list | view | add | edit | delete
$action = $_GET['action'] ?? 'list';

// Handle POST for add/edit
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $reg_no = $_POST['reg_no'];
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $department_id = $_POST['department_id'];
    $program_id = $_POST['program_id'];
    $semester_id = $_POST['semester_id'];
    $admission_year = $_POST['admission_year'];

    if($action === 'add'){
        $stmt = $conn->prepare("INSERT INTO students 
            (reg_no, name, dob, gender, department_id, program_id, semester_id, admission_year) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssiiii", $reg_no, $name, $dob, $gender, $department_id, $program_id, $semester_id, $admission_year);
        $stmt->execute();
        header("Location: students.php");
        exit;
    }

    if($action === 'edit'){
        $stmt = $conn->prepare("UPDATE students SET 
            name=?, dob=?, gender=?, department_id=?, program_id=?, semester_id=?, admission_year=? 
            WHERE reg_no=?");
        $stmt->bind_param("sssiiiis", $name, $dob, $gender, $department_id, $program_id, $semester_id, $admission_year, $reg_no);
        $stmt->execute();
        header("Location: students.php");
        exit;
    }
}

// Handle Delete
if($action === 'delete'){
    $reg_no = $_GET['reg_no'];
    $conn->query("DELETE FROM students WHERE reg_no='$reg_no'");
    header("Location: students.php");
    exit;
}

// Fetch data for view/edit forms
$student = null;
if(in_array($action, ['view','edit'])){
    $reg_no = $_GET['reg_no'];
    $stmt = $conn->prepare("SELECT * FROM students WHERE reg_no=?");
    $stmt->bind_param("s", $reg_no);
    $stmt->execute();
    $student = $stmt->get_result()->fetch_assoc();
}

// Fetch list of students
$students = [];
if($action === 'list'){
    $res = $conn->query("SELECT s.*, d.name as dept_name, p.program_name, sem.sem_number
        FROM students s
        LEFT JOIN departments d ON s.department_id=d.id
        LEFT JOIN programs p ON s.program_id=p.id
        LEFT JOIN semesters sem ON s.semester_id=sem.id
        ORDER BY s.admission_year DESC");
    $students = $res->fetch_all(MYSQLI_ASSOC);
}

// Fetch departments, programs, semesters for forms
$departments = $conn->query("SELECT * FROM departments")->fetch_all(MYSQLI_ASSOC);
$programs = $conn->query("SELECT * FROM programs")->fetch_all(MYSQLI_ASSOC);
$semesters = $conn->query("SELECT * FROM semesters")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Students</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<div class="flex min-h-screen">
    <!-- <?php include '../includes/sidebar_admin.php'; ?> -->
    <div class="flex-1 p-6">

        <?php if($action === 'list'): ?>
            <h1 class="text-3xl font-bold mb-6">Students List</h1>
            <a href="?action=add" class="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 mb-4 inline-block">Add New Student</a>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white shadow rounded-lg overflow-hidden">
                    <thead class="bg-blue-100 text-left">
                        <tr>
                            <th class="px-4 py-2">Reg No</th>
                            <th class="px-4 py-2">Name</th>
                            <th class="px-4 py-2">Department</th>
                            <th class="px-4 py-2">Program</th>
                            <th class="px-4 py-2">Semester</th>
                            <th class="px-4 py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($students as $s): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="px-4 py-2"><?= $s['reg_no'] ?></td>
                            <td class="px-4 py-2"><?= $s['name'] ?></td>
                            <td class="px-4 py-2"><?= $s['dept_name'] ?></td>
                            <td class="px-4 py-2"><?= $s['program_name'] ?></td>
                            <td class="px-4 py-2"><?= $s['sem_number'] ?></td>
                            <td class="px-4 py-2">
                                <a href="?action=view&reg_no=<?= $s['reg_no'] ?>" class="px-2 py-1 bg-green-500 text-white rounded">View</a>
                                <a href="?action=edit&reg_no=<?= $s['reg_no'] ?>" class="px-2 py-1 bg-yellow-500 text-white rounded">Edit</a>
                                <a href="?action=delete&reg_no=<?= $s['reg_no'] ?>" onclick="return confirm('Are you sure?');" class="px-2 py-1 bg-red-500 text-white rounded">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(count($students)==0): ?>
                        <tr><td colspan="6" class="text-center py-2">No students found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif($action === 'add' || $action === 'edit'): ?>
            <h1 class="text-3xl font-bold mb-6"><?= ucfirst($action) ?> Student</h1>
            <form method="POST" class="bg-white p-6 rounded shadow max-w-xl">
                <label class="block mb-2">Reg No:</label>
                <input type="text" name="reg_no" required value="<?= $student['reg_no'] ?? '' ?>" class="w-full p-2 border rounded mb-4" <?= ($action==='edit')?'readonly':'' ?>>

                <label class="block mb-2">Name:</label>
                <input type="text" name="name" required value="<?= $student['name'] ?? '' ?>" class="w-full p-2 border rounded mb-4">

                <label class="block mb-2">DOB:</label>
                <input type="date" name="dob" value="<?= $student['dob'] ?? '' ?>" class="w-full p-2 border rounded mb-4">

                <label class="block mb-2">Gender:</label>
                <select name="gender" class="w-full p-2 border rounded mb-4">
                    <option value="Male" <?= (isset($student['gender']) && $student['gender']=='Male')?'selected':'' ?>>Male</option>
                    <option value="Female" <?= (isset($student['gender']) && $student['gender']=='Female')?'selected':'' ?>>Female</option>
                    <option value="Other" <?= (isset($student['gender']) && $student['gender']=='Other')?'selected':'' ?>>Other</option>
                </select>

                <label class="block mb-2">Department:</label>
                <select name="department_id" class="w-full p-2 border rounded mb-4" required>
                    <?php foreach($departments as $d): ?>
                        <option value="<?= $d['id'] ?>" <?= (isset($student['department_id']) && $student['department_id']==$d['id'])?'selected':'' ?>><?= $d['name'] ?></option>
                    <?php endforeach; ?>
                </select>

                <label class="block mb-2">Program:</label>
                <select name="program_id" class="w-full p-2 border rounded mb-4" required>
                    <?php foreach($programs as $p): ?>
                        <option value="<?= $p['id'] ?>" <?= (isset($student['program_id']) && $student['program_id']==$p['id'])?'selected':'' ?>><?= $p['program_name'] ?></option>
                    <?php endforeach; ?>
                </select>

                <label class="block mb-2">Semester:</label>
                <select name="semester_id" class="w-full p-2 border rounded mb-4" required>
                    <?php foreach($semesters as $s): ?>
                        <option value="<?= $s['id'] ?>" <?= (isset($student['semester_id']) && $student['semester_id']==$s['id'])?'selected':'' ?>><?= $s['sem_number'] ?></option>
                    <?php endforeach; ?>
                </select>

                <label class="block mb-2">Admission Year:</label>
                <input type="number" name="admission_year" value="<?= $student['admission_year'] ?? '' ?>" class="w-full p-2 border rounded mb-4">

                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"><?= ucfirst($action) ?> Student</button>
                <a href="students.php" class="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 ml-2">Cancel</a>
            </form>

        <?php elseif($action === 'view'): ?>
            <h1 class="text-3xl font-bold mb-6">View Student</h1>
            <div class="bg-white p-6 rounded shadow max-w-xl">
                <p><strong>Reg No:</strong> <?= $student['reg_no'] ?></p>
                <p><strong>Name:</strong> <?= $student['name'] ?></p>
                <p><strong>DOB:</strong> <?= $student['dob'] ?></p>
                <p><strong>Gender:</strong> <?= $student['gender'] ?></p>
                <p><strong>Department:</strong> <?= $student['department_id'] ?></p>
                <p><strong>Program:</strong> <?= $student['program_id'] ?></p>
                <p><strong>Semester:</strong> <?= $student['semester_id'] ?></p>
                <p><strong>Admission Year:</strong> <?= $student['admission_year'] ?></p>
            </div>
            <a href="students.php" class="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 mt-4 inline-block">Back</a>

        <?php endif; ?>

    </div>
</div>

</body>
</html>
