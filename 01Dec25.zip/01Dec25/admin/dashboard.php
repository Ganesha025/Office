<?php
session_start();
require_once '../config/db.php';

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../public/index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard</title>

<script src="https://cdn.tailwindcss.com"></script>

<!-- Google Material Icons -->
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" rel="stylesheet" />

<style>
    .rounded-25 { border-radius: 25px; }
    /* Hide scrollbar for Chrome, Safari and Edge */
::-webkit-scrollbar {
    width: 0;
    height: 0;
}

/* Hide scrollbar for Firefox */
* {
    scrollbar-width: none;
}

/* Hide scrollbar for IE and older Edge */
html {
    -ms-overflow-style: none;
}

</style>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('-translate-x-full');
}
</script>

</head>

<body class="bg-gray-100 flex flex-col md:flex-row h-screen">

<!-- MOBILE TOP BAR -->
<div class="md:hidden flex items-center justify-between bg-white shadow px-4 py-3">
    <span class="text-xl font-bold">Admin Panel</span>
    <button onclick="toggleSidebar()">
        <span class="material-symbols-rounded text-3xl">menu</span>
    </button>
</div>

<!-- Sidebar -->
<aside id="sidebar"
    class="w-72 bg-white shadow-xl rounded-25 m-4 md:m-4 fixed md:static top-0 left-0 h-full md:h-auto z-50 transform -translate-x-full md:translate-x-0 transition duration-300 flex flex-col">

    <div class="p-6 text-2xl font-bold text-gray-800 flex items-center gap-2">
        <span class="material-symbols-rounded text-blue-600 text-3xl">dashboard</span>
        Admin Panel
    </div>

    <nav class="flex-1 px-4 space-y-1 overflow-y-auto pb-4">
        <?php
        $links = [
            ["Dashboard","dashboard.php","home"],
            ["Students","students/students.php","group"],
            ["Departments","departments/departments.php","domain"],
            ["Programs","programs/programs.php","school"],
            ["Semesters","semesters/semesters.php","calendar_month"],
            ["Subjects","subjects/subjects.php","menu_book"],
            ["Electives","electives/electives.php","import_contacts"],
            ["Attendance","attendance/attendance.php","task_alt"],
            ["Marks","marks/marks.php","grading"],
            ["Hall Tickets","hall_tickets/generate_hall_ticket.php","confirmation_number"],
            ["Seating","seating/seating_allotment.php","event_seat"],
            ["Fee Slips","fees/generate_fee_slip.php","receipt_long"],
            ["Grade Appeals","grade_appeals/view_appeals.php","support"],
            ["Graduation","sample.php","school"]

        ];

        foreach($links as $l){
            echo '
            <a href="'.$l[1].'" 
               class="flex items-center gap-3 px-4 py-3 rounded-25 text-gray-700 hover:bg-gray-100 transition">
                <span class="material-symbols-rounded text-gray-600">'.$l[2].'</span>
                '.$l[0].'
            </a>';
        }
        ?>
        <a href="../public/logout.php" class="flex items-center gap-3 px-4 py-3 mt-3 bg-red-500 text-white rounded-25 hover:bg-red-600 transition">
            <span class="material-symbols-rounded">logout</span> Logout
        </a>
    </nav>
</aside>


<!-- Main Content -->
<div class="flex-1 p-4 md:p-6 overflow-auto md:ml-0 mt-[90px] md:mt-0">

    <!-- Header -->
    <header class="flex flex-col md:flex-row md:justify-between md:items-center mb-6 gap-2">
        <h1 class="text-3xl md:text-4xl font-bold text-gray-800">
            Welcome, <?= $_SESSION['username'] ?>
        </h1>
        <span class="text-gray-600 text-lg"><?= date("l, d M Y") ?></span>
    </header>

    <!-- Dashboard Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">

        <?php
        $students = ($conn->query("SELECT COUNT(*) as total FROM students")->fetch_assoc()['total']) ?? 0;
        $departments = ($conn->query("SELECT COUNT(*) as total FROM departments")->fetch_assoc()['total']) ?? 0;
        $programs = ($conn->query("SELECT COUNT(*) as total FROM programs")->fetch_assoc()['total']) ?? 0;
        ?>

        <!-- Card -->
        <div class="bg-white p-6 rounded-25 shadow hover:shadow-lg transition">
            <div class="flex justify-between items-center">
                <h2 class="text-xl font-semibold">Total Students</h2>
                <span class="material-symbols-rounded text-blue-600 text-4xl">group</span>
            </div>
            <p class="text-4xl font-bold text-blue-700 mt-3"><?= $students ?></p>
        </div>

        <div class="bg-white p-6 rounded-25 shadow hover:shadow-lg transition">
            <div class="flex justify-between items-center">
                <h2 class="text-xl font-semibold">Departments</h2>
                <span class="material-symbols-rounded text-green-600 text-4xl">domain</span>
            </div>
            <p class="text-4xl font-bold text-green-700 mt-3"><?= $departments ?></p>
        </div>

        <div class="bg-white p-6 rounded-25 shadow hover:shadow-lg transition">
            <div class="flex justify-between items-center">
                <h2 class="text-xl font-semibold">Programs</h2>
                <span class="material-symbols-rounded text-yellow-600 text-4xl">school</span>
            </div>
            <p class="text-4xl font-bold text-yellow-700 mt-3"><?= $programs ?></p>
        </div>
    </div>

    <!-- More Stats -->
    <div class="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">

        <?php
        $subjects = ($conn->query("SELECT COUNT(*) as total FROM subjects")->fetch_assoc()['total']) ?? 0;
        $hall_tickets = ($conn->query("SELECT COUNT(*) as total FROM hall_tickets")->fetch_assoc()['total']) ?? 0;
        ?>

        <div class="bg-white p-6 rounded-25 shadow hover:shadow-lg transition">
            <div class="flex justify-between items-center">
                <h2 class="text-xl font-semibold">Subjects</h2>
                <span class="material-symbols-rounded text-purple-600 text-4xl">menu_book</span>
            </div>
            <p class="text-4xl font-bold text-purple-700 mt-3"><?= $subjects ?></p>
        </div>

        <div class="bg-white p-6 rounded-25 shadow hover:shadow-lg transition">
            <div class="flex justify-between items-center">
                <h2 class="text-xl font-semibold">Hall Tickets Generated</h2>
                <span class="material-symbols-rounded text-pink-600 text-4xl">confirmation_number</span>
            </div>
            <p class="text-4xl font-bold text-pink-700 mt-3"><?= $hall_tickets ?></p>
        </div>
    </div>

    <!-- Recent Students -->
    <div class="mt-10">
        <h2 class="text-2xl font-semibold mb-4 text-gray-800">Recent Students</h2>

        <div class="overflow-x-auto bg-white rounded-25 shadow">
            <table class="min-w-full text-left whitespace-nowrap">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3">Reg No</th>
                        <th class="px-6 py-3">Name</th>
                        <th class="px-6 py-3">Department</th>
                        <th class="px-6 py-3">Semester</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    $res = $conn->query("
                        SELECT s.reg_no, s.name, d.name AS dept_name, sem.sem_number
                        FROM students s
                        LEFT JOIN departments d ON s.department_id = d.id
                        LEFT JOIN semesters sem ON s.semester_id = sem.id
                        ORDER BY s.admission_year DESC
                        LIMIT 5
                    ");

                    while($row = $res->fetch_assoc()):
                    ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-6 py-3"><?= $row['reg_no'] ?></td>
                        <td class="px-6 py-3"><?= $row['name'] ?></td>
                        <td class="px-6 py-3"><?= $row['dept_name'] ?></td>
                        <td class="px-6 py-3"><?= $row['sem_number'] ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

</body>
</html>
