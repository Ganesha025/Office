<?php
session_start();
require_once '../../config/db.php';

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../../public/index.php");
    exit;
}

$action = $_GET['action'] ?? 'list';

if($action === 'ajax_update'){
    $id = $_POST['id'];
    $program_id = $_POST['program_id'];
    $sem_number = $_POST['sem_number'];
    $stmt = $conn->prepare("UPDATE semesters SET program_id=?, sem_number=?, updated_at=NOW() WHERE id=?");
    $stmt->bind_param("iii", $program_id, $sem_number, $id);
    $stmt->execute();
    echo "success";
    exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add'){
    $program_id = $_POST['program_id'];
    $sem_number = $_POST['sem_number'];
    $stmt = $conn->prepare("INSERT INTO semesters (program_id, sem_number, updated_at) VALUES (?, ?, NOW())");
    $stmt->bind_param("ii", $program_id, $sem_number);
    $stmt->execute();
    header("Location: semesters.php");
    exit;
}

if($action === 'delete'){
    $id = $_GET['id'];
    $conn->query("DELETE FROM semesters WHERE id='$id'");
    header("Location: semesters.php");
    exit;
}

$semesters = [];
if($action === 'list'){
    $sql = "SELECT s.id, s.sem_number, s.program_id, p.program_name 
            FROM semesters s 
            JOIN programs p ON s.program_id = p.id 
            ORDER BY s.updated_at DESC, s.id DESC";
    $res = $conn->query($sql);
    if($res){
        $semesters = $res->fetch_all(MYSQLI_ASSOC);
    } else {
        die("Database Error: ".$conn->error);
    }
}

$programs = [];
$res_programs = $conn->query("SELECT * FROM programs ORDER BY program_name ASC");
$programs = $res_programs->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Semesters</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>*{border-radius:25px; font-family: 'Inter', sans-serif;}</style>
</head>
<body class="bg-gray-50">

<div class="flex min-h-screen">
    <div class="flex-1 p-10">

        <div class="flex justify-between items-center mb-8">
            <h1 class="text-5xl font-bold text-gray-900">Semesters</h1>
            <button id="openModal" class="bg-blue-600 text-white px-6 py-3 flex items-center gap-3 rounded-full hover:bg-blue-700 shadow-md">
                <span class="material-icons">add</span> Add Semester
            </button>
        </div>

        <div class="bg-white p-8 shadow-xl rounded-3xl overflow-x-auto">
            <table class="min-w-full text-left border-collapse">
                <thead class="bg-gray-100">
                    <tr class="text-gray-700 text-lg">
                        <th class="px-6 py-4">ID</th>
                        <th class="px-6 py-4">Program</th>
                        <th class="px-6 py-4">Semester Number</th>
                        <th class="px-6 py-4">Actions</th>
                    </tr>
                </thead>
                <tbody id="semesterTable">
                    <?php foreach($semesters as $s): ?>
                    <tr class="border-b border-gray-200 hover:bg-gray-50 transition" data-id="<?= $s['id'] ?>">
                        <td class="px-6 py-4 font-medium text-gray-800"><?= $s['id'] ?></td>

                        <td class="px-6 py-4">
                            <span class="text-display"><?= $s['program_name'] ?></span>
                            <select class="hidden p-2 border w-full edit-field">
                                <?php foreach($programs as $p): ?>
                                    <option value="<?= $p['id'] ?>" <?= $s['program_id']==$p['id']?'selected':'' ?>><?= $p['program_name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>

                        <td class="px-6 py-4">
                            <span class="text-display"><?= $s['sem_number'] ?></span>
                            <input type="number" class="hidden p-2 border w-full edit-field" value="<?= $s['sem_number'] ?>">
                        </td>

                        <td class="px-6 py-4 flex gap-2">
                            <button class="bg-yellow-500 text-white px-5 py-2 flex gap-2 items-center edit-btn hover:bg-yellow-600 transition">
                                <span class="material-icons text-sm">edit</span> Edit
                            </button>
                            <button class="bg-green-600 text-white px-5 py-2 flex gap-2 items-center hidden save-btn hover:bg-green-700 transition">
                                <span class="material-icons text-sm">save</span> Save
                            </button>
                            <a href="?action=delete&id=<?= $s['id'] ?>" onclick="return confirm('Are you sure?');" class="bg-red-600 text-white px-5 py-2 flex gap-2 items-center hover:bg-red-700 transition">
                                <span class="material-icons text-sm">delete</span> Delete
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(count($semesters)==0): ?>
                    <tr><td colspan="4" class="text-center py-6 text-gray-400 text-lg">No semesters found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<div id="semesterModal" class="fixed inset-0 bg-black bg-opacity-40 hidden items-center justify-center">
    <div class="bg-white p-8 shadow-2xl rounded-3xl w-96 relative">
        <h2 class="text-3xl font-bold mb-5 text-gray-900">Add Semester</h2>
        <form method="POST" action="semesters.php?action=add" class="flex flex-col gap-4">
            <select name="program_id" required class="p-3 border border-gray-300 rounded-3xl focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Select Program</option>
                <?php foreach($programs as $p): ?>
                    <option value="<?= $p['id'] ?>"><?= $p['program_name'] ?></option>
                <?php endforeach; ?>
            </select>
            <input type="number" name="sem_number" placeholder="Semester Number" required class="p-3 border border-gray-300 rounded-3xl focus:outline-none focus:ring-2 focus:ring-blue-500">
            <div class="flex justify-end gap-3 mt-4">
                <button type="submit" class="bg-blue-600 text-white px-6 py-3 rounded-full hover:bg-blue-700 shadow-md">Save</button>
                <button type="button" id="closeModal" class="bg-gray-500 text-white px-6 py-3 rounded-full hover:bg-gray-600 shadow-md">Cancel</button>
            </div>
        </form>
        <button id="closeModalX" class="absolute top-4 right-4 text-gray-500 hover:text-gray-900 material-icons text-3xl">close</button>
    </div>
</div>

<script>
const table = document.getElementById("semesterTable");

function createRow(id, program_name, program_id, sem_number) {
    const tr = document.createElement("tr");
    tr.className = "border-b border-gray-200 hover:bg-gray-50 transition";
    tr.dataset.id = id;
    tr.innerHTML = `
        <td class="px-6 py-4 font-medium text-gray-800">${id}</td>
        <td class="px-6 py-4">
            <span class="text-display">${program_name}</span>
            <select class="hidden p-2 border w-full edit-field">
                <?php foreach($programs as $p): ?>
                <option value="<?= $p['id'] ?>" ${program_id==<?= $p['id'] ?>?'selected':''}><?= $p['program_name'] ?></option>
                <?php endforeach; ?>
            </select>
        </td>
        <td class="px-6 py-4">
            <span class="text-display">${sem_number}</span>
            <input type="number" class="hidden p-2 border w-full edit-field" value="${sem_number}">
        </td>
        <td class="px-6 py-4 flex gap-2">
            <button class="bg-yellow-500 text-white px-5 py-2 flex gap-2 items-center edit-btn hover:bg-yellow-600 transition">
                <span class="material-icons text-sm">edit</span> Edit
            </button>
            <button class="bg-green-600 text-white px-5 py-2 flex gap-2 items-center hidden save-btn hover:bg-green-700 transition">
                <span class="material-icons text-sm">save</span> Save
            </button>
            <a href="?action=delete&id=${id}" onclick="return confirm('Are you sure?');" class="bg-red-600 text-white px-5 py-2 flex gap-2 items-center hover:bg-red-700 transition">
                <span class="material-icons text-sm">delete</span> Delete
            </a>
        </td>
    `;
    table.prepend(tr);
    attachRowEvents(tr);
}

function attachRowEvents(row){
    const editBtn = row.querySelector(".edit-btn");
    const saveBtn = row.querySelector(".save-btn");

    editBtn.addEventListener("click", ()=>{
        row.querySelectorAll(".text-display").forEach(e=>e.classList.add("hidden"));
        row.querySelectorAll(".edit-field").forEach(e=>e.classList.remove("hidden"));
        saveBtn.classList.remove("hidden");
        editBtn.classList.add("hidden");
    });

    saveBtn.addEventListener("click", ()=>{
        const id = row.dataset.id;
        const fields = row.querySelectorAll(".edit-field");
        const program_id = fields[0].value;
        const sem_number = fields[1].value;

        const formData = new FormData();
        formData.append("id", id);
        formData.append("program_id", program_id);
        formData.append("sem_number", sem_number);

        fetch("semesters.php?action=ajax_update",{
            method:"POST",
            body:formData
        }).then(r=>r.text()).then(res=>{
            if(res==="success"){
                const program_name = row.querySelector(".edit-field:first-child option:checked").text;
                row.querySelectorAll(".text-display")[0].innerText = program_name;
                row.querySelectorAll(".text-display")[1].innerText = sem_number;
                row.querySelectorAll(".text-display").forEach(e=>e.classList.remove("hidden"));
                row.querySelectorAll(".edit-field").forEach(e=>e.classList.add("hidden"));
                editBtn.classList.remove("hidden");
                saveBtn.classList.add("hidden");
                table.prepend(row);
            }
        });
    });
}

document.querySelectorAll("#semesterTable tr").forEach(tr=>attachRowEvents(tr));

const modal = document.getElementById("semesterModal");
document.getElementById("openModal").onclick = ()=>{modal.classList.remove("hidden"); modal.classList.add("flex")};
document.getElementById("closeModal").onclick = ()=>{modal.classList.add("hidden"); modal.classList.remove("flex")};
document.getElementById("closeModalX").onclick = ()=>{modal.classList.add("hidden"); modal.classList.remove("flex")};
</script>

</body>
</html>
