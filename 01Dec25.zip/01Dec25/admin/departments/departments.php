<?php
session_start();
require_once '../../config/db.php';
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
header("Location: ../../public/index.php");
exit;
}
$action = $_GET['action'] ?? 'list';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
$code = $_POST['code'];
$name = $_POST['name'];
$hod = $_POST['hod'] ?? '';
if($action === 'add'){
$stmt = $conn->prepare("INSERT INTO departments (code, name, hod, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
$stmt->bind_param("sss", $code, $name, $hod);
$stmt->execute();
header("Location: departments.php");
exit;
}
if($action === 'edit'){
$id = $_POST['id'];
$stmt = $conn->prepare("UPDATE departments SET code=?, name=?, hod=?, updated_at=NOW() WHERE id=?");
$stmt->bind_param("sssi", $code, $name, $hod, $id);
$stmt->execute();
header("Location: departments.php");
exit;
}
}
if($action === 'delete'){
$id = $_GET['id'];
$conn->query("DELETE FROM departments WHERE id='$id'");
header("Location: departments.php");
exit;
}
$department = null;
if(in_array($action, ['view','edit'])){
$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM departments WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$department = $stmt->get_result()->fetch_assoc();
}
$departments = [];
if($action === 'list'){
$res = $conn->query("SELECT *, 
    CASE 
        WHEN updated_at > created_at THEN 1 
        ELSE 0 
    END as is_edited,
    CASE 
        WHEN updated_at > created_at THEN updated_at 
        ELSE created_at 
    END as sort_date
    FROM departments 
    ORDER BY is_edited DESC, sort_date DESC");
$departments = $res->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Department Management</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
* {
  font-family: 'Inter', sans-serif;
}
.material-symbols-outlined {
  font-variation-settings:
  'FILL' 0,
  'wght' 400,
  'GRAD' 0,
  'opsz' 24
}
.custom-rounded {
  border-radius: 25px;
}
.custom-shadow {
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
}
.hover-scale {
  transition: all 0.3s ease;
}
.hover-scale:hover {
  transform: translateY(-2px);
  box-shadow: 0 15px 40px rgba(0, 0, 0, 0.12);
}
.edited-row {
  background: linear-gradient(90deg, rgba(59, 130, 246, 0.05) 0%, rgba(255, 255, 255, 1) 100%);
  border-left: 4px solid #3b82f6;
}
.pulse-animation {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
@keyframes pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.7;
  }
}
</style>
</head>
<body class="bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
<div class="flex min-h-screen">
<div class="flex-1 p-8">

<?php if($action === 'list'): ?>
<div class="bg-white custom-rounded custom-shadow p-8 mb-6">
<div class="flex items-center justify-between mb-8">
<div class="flex items-center">
<span class="material-symbols-outlined text-4xl text-blue-600 mr-4">corporate_fare</span>
<h1 class="text-4xl font-bold text-gray-800">Department Management</h1>
</div>
<a href="?action=add" class="flex items-center px-6 py-3 bg-blue-600 text-white custom-rounded hover:bg-blue-700 hover-scale transition-all duration-300 font-medium">
<span class="material-symbols-outlined mr-2">add_circle</span>
Add New Department
</a>
</div>

<div class="overflow-hidden custom-rounded custom-shadow bg-white">
<table class="min-w-full">
<thead class="bg-slate-50">
<tr>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">tag</span>
ID
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">code</span>
Code
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">business</span>
Department Name
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">person_pin</span>
Head of Department
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">schedule</span>
Status
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">settings</span>
Actions
</div>
</th>
</tr>
</thead>
<tbody class="divide-y divide-gray-100">
<?php foreach($departments as $d): ?>
<tr class="hover:bg-slate-50 transition-colors duration-200 <?= $d['is_edited'] ? 'edited-row' : '' ?>">
<td class="px-6 py-4 whitespace-nowrap">
<div class="flex items-center">
<span class="inline-flex items-center justify-center w-8 h-8 bg-blue-100 text-blue-800 custom-rounded text-sm font-medium">
<?= $d['id'] ?>
</span>
<?php if($d['is_edited']): ?>
<span class="ml-2 inline-flex items-center px-2 py-1 custom-rounded text-xs font-medium bg-blue-100 text-blue-800 pulse-animation">
<span class="material-symbols-outlined mr-1" style="font-size: 12px;">edit</span>
Updated
</span>
<?php endif; ?>
</div>
</td>
<td class="px-6 py-4">
<div class="flex items-center">
<span class="inline-flex items-center px-3 py-1 custom-rounded text-sm font-semibold bg-purple-100 text-purple-800">
<span class="material-symbols-outlined mr-1 text-sm">label</span>
<?= $d['code'] ?>
</span>
</div>
</td>
<td class="px-6 py-4">
<div class="flex items-center">
<span class="material-symbols-outlined mr-3 text-blue-500">domain</span>
<div>
<div class="font-semibold text-gray-900"><?= $d['name'] ?></div>
<?php if($d['is_edited']): ?>
<div class="text-xs text-blue-600 flex items-center mt-1">
<span class="material-symbols-outlined mr-1" style="font-size: 12px;">update</span>
Last updated: <?= date('M d, Y H:i', strtotime($d['updated_at'])) ?>
</div>
<?php endif; ?>
</div>
</div>
</td>
<td class="px-6 py-4">
<div class="flex items-center">
<span class="material-symbols-outlined mr-3 text-green-500">account_circle</span>
<span class="font-medium text-gray-900"><?= $d['hod'] ?: 'Not Assigned' ?></span>
</div>
</td>
<td class="px-6 py-4">
<?php if($d['is_edited']): ?>
<span class="inline-flex items-center px-3 py-1 custom-rounded text-sm font-semibold bg-blue-100 text-blue-800">
<span class="material-symbols-outlined mr-1 text-sm">edit_note</span>
Recently Edited
</span>
<?php else: ?>
<span class="inline-flex items-center px-3 py-1 custom-rounded text-sm font-semibold bg-green-100 text-green-800">
<span class="material-symbols-outlined mr-1 text-sm">fiber_new</span>
Original
</span>
<?php endif; ?>
</td>
<td class="px-6 py-4">
<div class="flex items-center space-x-2">
<a href="?action=view&id=<?= $d['id'] ?>" class="flex items-center px-3 py-2 bg-green-500 text-white custom-rounded hover:bg-green-600 hover-scale transition-all duration-200">
<span class="material-symbols-outlined mr-1 text-sm">visibility</span>
View
</a>
<a href="?action=edit&id=<?= $d['id'] ?>" class="flex items-center px-3 py-2 bg-amber-500 text-white custom-rounded hover:bg-amber-600 hover-scale transition-all duration-200">
<span class="material-symbols-outlined mr-1 text-sm">edit</span>
Edit
</a>
<a href="?action=delete&id=<?= $d['id'] ?>" onclick="return confirm('Are you sure you want to delete this department?');" class="flex items-center px-3 py-2 bg-red-500 text-white custom-rounded hover:bg-red-600 hover-scale transition-all duration-200">
<span class="material-symbols-outlined mr-1 text-sm">delete</span>
Delete
</a>
</div>
</td>
</tr>
<?php endforeach; ?>
<?php if(count($departments)==0): ?>
<tr>
<td colspan="6" class="px-6 py-12 text-center">
<div class="flex flex-col items-center">
<span class="material-symbols-outlined text-6xl text-gray-300 mb-4">inbox</span>
<p class="text-gray-500 text-lg">No departments found.</p>
<p class="text-gray-400 text-sm mt-2">Start by adding your first department.</p>
</div>
</td>
</tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

<?php elseif($action === 'add' || $action === 'edit'): ?>
<div class="max-w-2xl mx-auto">
<div class="bg-white custom-rounded custom-shadow p-8">
<div class="flex items-center mb-8">
<span class="material-symbols-outlined text-4xl text-blue-600 mr-4"><?= $action === 'add' ? 'add_business' : 'edit_square' ?></span>
<h1 class="text-4xl font-bold text-gray-800"><?= ucfirst($action) ?> Department</h1>
</div>

<form method="POST" class="space-y-6">
<?php if($action==='edit'): ?>
<input type="hidden" name="id" value="<?= $department['id'] ?>">
<?php endif; ?>

<div>
<label class="flex items-center text-lg font-semibold text-gray-700 mb-3">
<span class="material-symbols-outlined mr-2 text-purple-500">code</span>
Department Code
</label>
<input type="text" name="code" required value="<?= $department['code'] ?? '' ?>" class="w-full p-4 border-2 border-gray-200 custom-rounded focus:border-blue-500 focus:outline-none transition-colors duration-200" placeholder="Enter department code (e.g., CS, EE, ME)">
</div>

<div>
<label class="flex items-center text-lg font-semibold text-gray-700 mb-3">
<span class="material-symbols-outlined mr-2 text-blue-500">business</span>
Department Name
</label>
<input type="text" name="name" required value="<?= $department['name'] ?? '' ?>" class="w-full p-4 border-2 border-gray-200 custom-rounded focus:border-blue-500 focus:outline-none transition-colors duration-200" placeholder="Enter full department name">
</div>

<div>
<label class="flex items-center text-lg font-semibold text-gray-700 mb-3">
<span class="material-symbols-outlined mr-2 text-green-500">person_pin</span>
Head of Department
</label>
<input type="text" name="hod" value="<?= $department['hod'] ?? '' ?>" class="w-full p-4 border-2 border-gray-200 custom-rounded focus:border-blue-500 focus:outline-none transition-colors duration-200" placeholder="Enter HOD name (optional)">
</div>

<div class="flex items-center space-x-4 pt-6">
<button type="submit" class="flex items-center px-8 py-4 bg-blue-600 text-white custom-rounded hover:bg-blue-700 hover-scale transition-all duration-300 font-semibold text-lg">
<span class="material-symbols-outlined mr-2"><?= $action === 'add' ? 'add_circle' : 'save' ?></span>
<?= $action === 'add' ? 'Add Department' : 'Update Department' ?>
</button>
<a href="departments.php" class="flex items-center px-8 py-4 bg-gray-500 text-white custom-rounded hover:bg-gray-600 hover-scale transition-all duration-300 font-semibold text-lg">
<span class="material-symbols-outlined mr-2">arrow_back</span>
Cancel
</a>
</div>
</form>
</div>
</div>

<?php elseif($action === 'view'): ?>
<div class="max-w-2xl mx-auto">
<div class="bg-white custom-rounded custom-shadow p-8">
<div class="flex items-center mb-8">
<span class="material-symbols-outlined text-4xl text-blue-600 mr-4">visibility</span>
<h1 class="text-4xl font-bold text-gray-800">Department Details</h1>
</div>

<div class="space-y-6">
<div class="flex items-center p-6 bg-slate-50 custom-rounded">
<span class="material-symbols-outlined mr-4 text-blue-500 text-2xl">tag</span>
<div>
<span class="text-sm text-gray-500 uppercase tracking-wide font-medium">Department ID</span>
<div class="text-2xl font-bold text-gray-800"><?= $department['id'] ?></div>
</div>
</div>

<div class="flex items-center p-6 bg-slate-50 custom-rounded">
<span class="material-symbols-outlined mr-4 text-purple-500 text-2xl">label</span>
<div>
<span class="text-sm text-gray-500 uppercase tracking-wide font-medium">Department Code</span>
<div class="text-2xl font-bold text-purple-700"><?= $department['code'] ?></div>
</div>
</div>

<div class="flex items-center p-6 bg-slate-50 custom-rounded">
<span class="material-symbols-outlined mr-4 text-blue-500 text-2xl">domain</span>
<div>
<span class="text-sm text-gray-500 uppercase tracking-wide font-medium">Department Name</span>
<div class="text-2xl font-bold text-gray-800"><?= $department['name'] ?></div>
</div>
</div>

<div class="flex items-center p-6 bg-slate-50 custom-rounded">
<span class="material-symbols-outlined mr-4 text-green-500 text-2xl">person_pin</span>
<div>
<span class="text-sm text-gray-500 uppercase tracking-wide font-medium">Head of Department</span>
<div class="text-2xl font-bold text-gray-800"><?= $department['hod'] ?: 'Not Assigned' ?></div>
</div>
</div>

<?php if(isset($department['created_at'])): ?>
<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
<div class="flex items-center p-4 bg-green-50 custom-rounded">
<span class="material-symbols-outlined mr-3 text-green-600">schedule</span>
<div>
<span class="text-xs text-green-600 uppercase tracking-wide font-medium">Created</span>
<div class="text-sm font-semibold text-green-700"><?= date('M d, Y H:i', strtotime($department['created_at'])) ?></div>
</div>
</div>
<?php if($department['updated_at'] != $department['created_at']): ?>
<div class="flex items-center p-4 bg-blue-50 custom-rounded">
<span class="material-symbols-outlined mr-3 text-blue-600">update</span>
<div>
<span class="text-xs text-blue-600 uppercase tracking-wide font-medium">Last Updated</span>
<div class="text-sm font-semibold text-blue-700"><?= date('M d, Y H:i', strtotime($department['updated_at'])) ?></div>
</div>
</div>
<?php endif; ?>
</div>
<?php endif; ?>
</div>

<div class="mt-8">
<a href="departments.php" class="flex items-center px-8 py-4 bg-gray-500 text-white custom-rounded hover:bg-gray-600 hover-scale transition-all duration-300 font-semibold text-lg w-fit">
<span class="material-symbols-outlined mr-2">arrow_back</span>
Back to Departments
</a>
</div>
</div>
</div>
<?php endif; ?>

</div>
</div>
</body>
</html>