<?php
session_start();
require_once '../../config/db.php';

if(!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'student'])){
    header("Location: ../../public/index.php");
    exit;
}

$action = $_GET['action'] ?? 'list';
$message = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $selected_subjects = $_POST['electives'] ?? [];
    
    // Validate max 3 electives
    if(count($selected_subjects) > 3){
        $error = "Maximum 3 electives can be selected.";
    } else {
        // Validate all selected subjects exist and are electives
        $valid_subjects = [];
        $invalid_subjects = [];
        
        foreach($selected_subjects as $subject_id){
            $stmt = $conn->prepare("SELECT id, subject_code, subject_name FROM subjects WHERE id=? AND type='Elective'");
            $stmt->bind_param("i", $subject_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if($result->num_rows > 0){
                $valid_subjects[] = $result->fetch_assoc();
            } else {
                $invalid_subjects[] = $subject_id;
            }
        }
        
        if(empty($invalid_subjects)){
            $_SESSION['selected_electives'] = $valid_subjects;
            $message = "Successfully selected " . count($valid_subjects) . " elective(s).";
            $action = 'confirmation';
        } else {
            $error = "Invalid elective(s): " . implode(', ', $invalid_subjects);
        }
    }
}

// Fetch all elective subjects (limit 10)
$electives_query = "SELECT s.id, s.subject_code, s.subject_name, d.name as department, p.program_name, sem.sem_number 
                    FROM subjects s 
                    LEFT JOIN departments d ON s.department_id = d.id
                    LEFT JOIN programs p ON s.program_id = p.id
                    LEFT JOIN semesters sem ON s.semester_id = sem.id
                    WHERE s.type = 'Elective' 
                    ORDER BY s.subject_name ASC 
                    LIMIT 10";

$electives = $conn->query($electives_query)->fetch_all(MYSQLI_ASSOC);

// Get previously selected electives for confirmation view
$selected_electives = [];
if($action === 'confirmation' && isset($_SESSION['selected_electives'])){
    $selected_electives = $_SESSION['selected_electives'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elective Selection</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .elective-card { transition: all 0.3s ease; }
        .elective-card:hover { transform: translateY(-2px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .selected-count { background: linear-gradient(45deg, #10b981, #059669); }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen py-8">

<div class="container mx-auto px-4 max-w-4xl">
    
    <?php if($error): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-6 py-4 rounded-lg mb-6 shadow">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <?php if($message): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-6 py-4 rounded-lg mb-6 shadow">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <?php if($action === 'list'): ?>
        <!-- Elective Selection Form -->
        <div class="bg-white rounded-2xl shadow-xl p-8 mb-8">
            <h1 class="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-4">
                Select Your Electives
            </h1>
            <p class="text-gray-600 mb-8 text-lg">Choose up to <span class="font-bold text-green-600">3 electives</span> from the available options below.</p>
            
            <form method="POST" id="electiveForm">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                    <?php foreach($electives as $elective): ?>
                        <div class="elective-card bg-gray-50 border-2 border-gray-200 rounded-xl p-6 cursor-pointer group">
                            <label class="cursor-pointer w-full">
                                <input type="checkbox" 
                                       name="electives[]" 
                                       value="<?= $elective['id'] ?>"
                                       class="sr-only peer">
                                <div class="elective-checkbox peer-checked:bg-green-500 peer-checked:border-green-500 peer-focus:ring-4 peer-focus:ring-green-200">
                                    <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                    </svg>
                                </div>
                                <div class="mt-4 text-center">
                                    <div class="font-bold text-lg text-gray-900 mb-1 group-hover:text-blue-600 transition-colors">
                                        <?= htmlspecialchars($elective['subject_code']) ?> - <?= htmlspecialchars($elective['subject_name']) ?>
                                    </div>
                                    <div class="text-sm text-gray-500 space-y-1">
                                        <div>Dept: <?= htmlspecialchars($elective['department']) ?></div>
                                        <div>Program: <?= htmlspecialchars($elective['program_name']) ?></div>
                                        <div>Semester: <?= htmlspecialchars($elective['sem_number']) ?></div>
                                    </div>
                                </div>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="flex flex-col sm:flex-row gap-4 justify-center items-center p-6 bg-blue-50 rounded-xl border-2 border-dashed border-blue-200">
                    <div class="selected-display bg-white px-6 py-3 rounded-lg shadow-sm border-2 border-green-200">
                        <span class="text-sm text-gray-600 font-medium">Selected: </span>
                        <span id="selectedCount" class="font-bold text-xl text-green-600">0</span>
                        <span class="text-sm text-gray-600">/ 3</span>
                    </div>
                    <button type="submit" 
                            class="px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                            id="submitBtn"
                            disabled>
                        Confirm Selection
                    </button>
                </div>
            </form>
        </div>

    <?php elseif($action === 'confirmation'): ?>
        <!-- Confirmation View -->
        <div class="bg-white rounded-2xl shadow-2xl p-10 text-center">
            <div class="w-24 h-24 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <svg class="w-12 h-12 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                </svg>
            </div>
            <h1 class="text-3xl font-bold text-gray-900 mb-4">Selection Confirmed!</h1>
            <p class="text-xl text-green-700 mb-8 font-semibold">Your elective choices have been successfully saved.</p>
            
            <div class="max-w-2xl mx-auto">
                <h3 class="text-2xl font-bold text-gray-900 mb-6">Your Selected Electives:</h3>
                <div class="space-y-4">
                    <?php foreach($selected_electives as $elective): ?>
                        <div class="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200">
                            <div>
                                <div class="font-bold text-lg"><?= htmlspecialchars($elective['subject_code']) ?></div>
                                <div class="text-gray-600"><?= htmlspecialchars($elective['subject_name']) ?></div>
                            </div>
                            <div class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
                                ✓ Confirmed
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="flex flex-col sm:flex-row gap-4 mt-12 justify-center">
                <a href="?action=list" class="px-8 py-3 bg-gradient-to-r from-gray-500 to-gray-600 text-white font-semibold rounded-xl hover:shadow-lg transform hover:-translate-y-1 transition-all">
                    Change Selection
                </a>
                <form method="POST" style="display: inline;">
                    <button type="submit" name="clear_selection" class="px-8 py-3 bg-red-500 text-white font-semibold rounded-xl hover:shadow-lg transform hover:-translate-y-1 transition-all">
                        Clear All
                    </button>
                </form>
            </div>
        </div>
    <?php endif; ?>

</div>

<script>
$(document).ready(function(){
    let selectedCount = 0;
    
    // Handle checkbox selection with constraint
    $('input[name="electives[]"]').change(function(){
        const $checkbox = $(this);
        const isChecked = $checkbox.is(':checked');
        
        if(isChecked && selectedCount >= 3){
            $checkbox.prop('checked', false);
            alert('Maximum 3 electives can be selected!');
            return;
        }
        
        if(isChecked){
            selectedCount++;
        } else {
            selectedCount--;
        }
        
        updateSelectionDisplay();
        toggleSubmitButton();
    });
    
    function updateSelectionDisplay(){
        $('#selectedCount').text(selectedCount);
        $('.selected-display').toggleClass('selected-count', selectedCount > 0);
    }
    
    function toggleSubmitButton(){
        const $submitBtn = $('#submitBtn');
        $submitBtn.prop('disabled', selectedCount === 0);
        
        if(selectedCount === 0){
            $submitBtn.text('Select Electives First');
        } else {
            $submitBtn.text(`Confirm Selection (${selectedCount}/3)`);
        }
    }
    
    // Smooth hover effects
    $('.elective-card').hover(
        function(){ $(this).addClass('shadow-lg'); },
        function(){ $(this).removeClass('shadow-lg'); }
    );
    
    // Initialize
    updateSelectionDisplay();
    toggleSubmitButton();
});
</script>

</body>
</html>
