<?php
include '../config/db.php'; // your database connection

// Function to check graduation eligibility for a student
function checkGraduationEligibility($reg_no, $conn) {
    $sql = "SELECT SUM(s.credit) AS total_credits
            FROM subjects s
            JOIN internal_marks im ON s.id = im.subject_id
            WHERE im.reg_no = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $reg_no);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    $earnedCredits = $row['total_credits'] ?? 0;
    $requiredCredits = 120;

    if ($earnedCredits >= $requiredCredits) {
        return [
            'status' => 'Eligible',
            'earned' => $earnedCredits,
            'missing' => 0
        ];
    } else {
        return [
            'status' => 'Pending',
            'earned' => $earnedCredits,
            'missing' => $requiredCredits - $earnedCredits
        ];
    }
}

// Fetch all students
$studentsResult = $conn->query("SELECT reg_no, name FROM students ORDER BY name ASC");

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Graduation Credit Eligibility</title>
<style>
    body { font-family: Arial, sans-serif; margin: 50px; }
    table { border-collapse: collapse; width: 100%; max-width: 800px; }
    th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
    th { background-color: #f4f4f4; }
    .eligible { background-color: #d4edda; color: #155724; }
    .pending { background-color: #f8d7da; color: #721c24; }
</style>
</head>
<body>

<h2>Graduation Credit Eligibility for All Students</h2>

<table>
    <thead>
        <tr>
            <th>Reg No</th>
            <th>Name</th>
            <th>Credits Earned</th>
            <th>Status</th>
            <th>Missing Credits</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($studentsResult->num_rows > 0) {
            while ($student = $studentsResult->fetch_assoc()) {
                $eligibility = checkGraduationEligibility($student['reg_no'], $conn);
                echo "<tr class='".strtolower($eligibility['status'])."'>";
                echo "<td>{$student['reg_no']}</td>";
                echo "<td>{$student['name']}</td>";
                echo "<td>{$eligibility['earned']}</td>";
                echo "<td>{$eligibility['status']}</td>";
                echo "<td>{$eligibility['missing']}</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No students found</td></tr>";
        }
        ?>
    </tbody>
</table>

</body>
</html>
