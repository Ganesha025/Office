<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Grade Calculator</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<style>
.card-module { margin: 40px auto; padding: 30px; border-radius: 20px; background:#f8f9fa; box-shadow:0 12px 40px rgba(0,0,0,0.12); max-width: 900px; }
.card-module h3 { font-weight:700; color:#0d6efd; display:flex; align-items:center; gap:12px; }
.input-field { border-radius:8px; font-weight:500; text-align:center; }
.input-error { border: 2px solid #dc3545 !important; }
.btn-modern { border-radius:10px; font-weight:600; transition:0.3s; }
.btn-modern:hover { transform:scale(1.05); box-shadow:0 5px 15px rgba(0,0,0,0.15); }
.removeRowBtn { background:#dc3545; color:white; border:none; border-radius:8px; padding:6px 12px; cursor:pointer; }
.removeRowBtn:hover { background:#c82333; }
.fadeRow { animation: fadeIn 0.3s ease-in-out; }
@keyframes fadeIn { from {opacity:0; transform:translateY(12px);} to {opacity:1; transform:translateY(0);} }
.required-star { color:red; margin-left:2px; }
.result-box { margin-top:20px; padding:20px; background:#e8f1ff; border-left:6px solid #0d6efd; border-radius:10px; font-weight:bold; }

/* Remove spinner arrows in number inputs */
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
input[type=number] { -moz-appearance: textfield; }
</style>
</head>
<body>

<div class="container">
  <div class="card card-module">
    <h3><i class="bi bi-award"></i> Student Grade Calculator</h3>
    <p class="text-secondary">Enter student name and marks in 5 subjects. Marks should be 0-100.</p>

    <button class="btn btn-info btn-modern mb-3" id="addRow"><i class="bi bi-plus-circle"></i> Add Student</button>

    <div class="table-responsive">
      <table class="table table-striped table-hover align-middle text-center" id="gradeTable">
        <thead class="table-primary">
          <tr>
            <th>Student Name <span class="required-star">*</span></th>
            <th>Subject 1 <span class="required-star">*</span></th>
            <th>Subject 2 <span class="required-star">*</span></th>
            <th>Subject 3 <span class="required-star">*</span></th>
            <th>Subject 4 <span class="required-star">*</span></th>
            <th>Subject 5 <span class="required-star">*</span></th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr class="fadeRow">
            <td><input type="text" class="form-control input-field student-name" placeholder="e.g. John Doe" maxlength="20"></td>
            <td><input type="number" class="form-control input-field mark" min="0" max="100" placeholder="0-100"></td>
            <td><input type="number" class="form-control input-field mark" min="0" max="100" placeholder="0-100"></td>
            <td><input type="number" class="form-control input-field mark" min="0" max="100" placeholder="0-100"></td>
            <td><input type="number" class="form-control input-field mark" min="0" max="100" placeholder="0-100"></td>
            <td><input type="number" class="form-control input-field mark" min="0" max="100" placeholder="0-100"></td>
            <td><button class="removeRowBtn">Remove</button></td>
          </tr>
        </tbody>
      </table>
    </div>

    <button class="btn btn-success btn-modern mt-3" id="calculateGrade"><i class="bi bi-check-circle"></i> Calculate Grades</button>
    <div id="gradeResult" class="mt-3"></div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
$(document).ready(function(){
    $('.student-name').first().focus();

    // Name validation: letters + spaces only
    $(document).on('input', '.student-name', function() {
        this.value = this.value.replace(/[^a-zA-Z ]/g,'').slice(0,20);
        if(this.value !== "") $(this).removeClass('input-error');
    });

    // Marks validation: 0-100
    $(document).on('input', '.mark', function() {
        if(this.value > 100) this.value = 100;
        if(this.value < 0) this.value = 0;
        if(this.value !== "" && this.value >=0 && this.value <=100) $(this).removeClass('input-error');
    });

    // Add row
    $('#addRow').click(function(){
        $('#gradeTable tbody').append(`
          <tr class="fadeRow">
            <td><input type="text" class="form-control input-field student-name" placeholder="e.g. John Doe" maxlength="20"></td>
            <td><input type="number" class="form-control input-field mark" min="0" max="100" placeholder="0-100"></td>
            <td><input type="number" class="form-control input-field mark" min="0" max="100" placeholder="0-100"></td>
            <td><input type="number" class="form-control input-field mark" min="0" max="100" placeholder="0-100"></td>
            <td><input type="number" class="form-control input-field mark" min="0" max="100" placeholder="0-100"></td>
            <td><input type="number" class="form-control input-field mark" min="0" max="100" placeholder="0-100"></td>
            <td><button class="removeRowBtn">Remove</button></td>
          </tr>
        `);
        $('.student-name').last().focus();
    });

    // Remove row
    $(document).on('click', '.removeRowBtn', function(){
        $(this).closest('tr').remove();
    });

    // Grade calculation
    function getGrade(avg){
        if(avg > 90) return "A";
        if(avg >= 80) return "B";
        if(avg >= 70) return "C";
        if(avg >= 60) return "D";
        return "F";
    }

    $('#calculateGrade').click(function(){
        let valid = true;
        let html = "";

        $('#gradeTable tbody tr').each(function(index){
            let nameInput = $(this).find('.student-name');
            let name = nameInput.val().trim();
            let marks = [];
            $(this).find('.mark').each(function(){ marks.push($(this).val()); });

            // Reset previous errors
            nameInput.removeClass('input-error');
            $(this).find('.mark').removeClass('input-error');

            // Validate
            if(name === ""){
                valid = false;
                nameInput.addClass('input-error');
            }
            marks.forEach((m,i)=>{
                if(m === "" || m < 0 || m > 100){
                    valid = false;
                    $(this).find('.mark').eq(i).addClass('input-error');
                }
            });

            let sum = marks.reduce((a,b) => a + Number(b), 0);
            let avg = (sum / marks.length).toFixed(2);
            let grade = getGrade(avg);

            html += `<div class="result-box">Student ${index+1}: ${name} | Average: ${avg} | Grade: ${grade}</div>`;
        });

        if(!valid){
            $('#gradeResult').html(`<div class="alert alert-danger">⚠ Please fill valid student names and marks (0-100) for all students.</div>`);
            return;
        }

        $('#gradeResult').html(html);

        // Optional: fade result after 4 seconds
        setTimeout(function(){
            $('#gradeResult').fadeOut('slow', function(){ $(this).html('').show(); });
        }, 4000);
    });
});
</script>

</body>
</html>
