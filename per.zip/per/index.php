<?php
function getSystemUsage() {
    $usage = [];

    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        $output = [];
        exec("wmic cpu get loadpercentage", $output);
        $usage['CPU'] = isset($output[1]) ? intval($output[1]) . "%" : "N/A";

        $output = [];
        exec("wmic OS get FreePhysicalMemory,TotalVisibleMemorySize /Value", $output);
        $mem = [];
        foreach ($output as $line) {
            if (strpos($line, "=") !== false) {
                list($k, $v) = explode("=", $line);
                $mem[$k] = intval($v);
            }
        }
        if (isset($mem['FreePhysicalMemory'], $mem['TotalVisibleMemorySize'])) {
            $used = $mem['TotalVisibleMemorySize'] - $mem['FreePhysicalMemory'];
            $usage['Memory'] = round(($used / $mem['TotalVisibleMemorySize']) * 100, 2) . "%";
        } else {
            $usage['Memory'] = "N/A";
        }

    } else {
        if (function_exists('sys_getloadavg')) {
            $load = sys_getloadavg();
            $usage['CPU'] = round($load[0] * 100, 2) . "%";
        } else {
            $usage['CPU'] = "N/A";
        }

        $mem = [];
        if (is_readable("/proc/meminfo")) {
            $data = file_get_contents("/proc/meminfo");
            preg_match("/MemTotal:\s+(\d+)/", $data, $matches);
            $memTotal = intval($matches[1]);
            preg_match("/MemAvailable:\s+(\d+)/", $data, $matches);
            $memAvailable = intval($matches[1]);
            $used = $memTotal - $memAvailable;
            $usage['Memory'] = round(($used / $memTotal) * 100, 2) . "%";
        } else {
            $usage['Memory'] = "N/A";
        }
    }

    return $usage;
}

header('Content-Type: application/json');
echo json_encode(getSystemUsage());
?>
