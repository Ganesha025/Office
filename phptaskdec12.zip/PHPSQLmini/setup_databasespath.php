<?php
$host = '127.0.0.1';
$user = 'root';
$pass = '';
$dbName = 'pantry_monitor';

try {
    $pdo = new PDO("mysql:host=$host", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create database if not exists
    $pdo->exec("CREATE DATABASE IF NOT EXISTS $dbName");
    echo "Database '$dbName' created or already exists.<br>";

    // Use the database
    $pdo->exec("USE $dbName");

    // Create employees table
    $pdo->exec("CREATE TABLE IF NOT EXISTS employees (
        emp_id INT AUTO_INCREMENT PRIMARY KEY,
        emp_name VARCHAR(100),
        department VARCHAR(50)
    )");
    echo "Table 'employees' created.<br>";

    // Insert sample employees only if table is empty
    $stmt = $pdo->query("SELECT COUNT(*) FROM employees");
    if($stmt->fetchColumn() == 0){
        $employees = [
            ['Abirami','CSE'],
            ['John','ECE'],
            ['Mary','EEE']
        ];
        $stmtInsert = $pdo->prepare("INSERT INTO employees(emp_name, department) VALUES (?, ?)");
        foreach ($employees as $e) {
            $stmtInsert->execute($e);
        }
        echo "Sample employees inserted.<br>";
    } else {
        echo "Employees already exist, skipping insertion.<br>";
    }

    // Create users table
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE,
        password VARCHAR(255),
        role ENUM('admin','employee'),
        emp_id INT,
        FOREIGN KEY(emp_id) REFERENCES employees(emp_id)
    )");
    echo "Table 'users' created.<br>";

    // Insert sample users only if they do not exist
    $users = [
        ['admin', password_hash('Admin@123', PASSWORD_DEFAULT), 'admin', NULL],
        ['abirami', password_hash('user12345', PASSWORD_DEFAULT), 'employee', 1],
        ['john', password_hash('user12345', PASSWORD_DEFAULT), 'employee', 2]
    ];

    $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username=?");
    $stmtInsert = $pdo->prepare("INSERT INTO users(username,password,role,emp_id) VALUES (?, ?, ?, ?)");
    foreach ($users as $u) {
        $stmtCheck->execute([$u[0]]);
        if($stmtCheck->fetchColumn() == 0){
            $stmtInsert->execute($u);
            echo "User '{$u[0]}' inserted.<br>";
        } else {
            echo "User '{$u[0]}' already exists, skipping insertion.<br>";
        }
    }

    // Create purchases table
    $pdo->exec("CREATE TABLE IF NOT EXISTS purchases (
        purchase_id INT AUTO_INCREMENT PRIMARY KEY,
        emp_id INT,
        item_name VARCHAR(100),
        quantity INT,
        amount INT,
        purchase_date DATE,
        receipt_image VARCHAR(255),
        FOREIGN KEY(emp_id) REFERENCES employees(emp_id)
    )");
    echo "Table 'purchases' created.<br>";

    // Insert sample purchases only if table is empty
    $stmt = $pdo->query("SELECT COUNT(*) FROM purchases");
    if($stmt->fetchColumn() == 0){
        $purchases = [
            [1,'Tea',2,50,'2025-12-01',NULL],
            [1,'Coffee',1,100,'2025-12-02',NULL],
            [2,'Snacks',5,20,'2025-12-03',NULL],
            [3,'Stationery',3,150,'2025-12-04',NULL],
            [2,'Tea',3,50,'2025-12-05',NULL]
        ];
        $stmtInsert = $pdo->prepare("INSERT INTO purchases(emp_id,item_name,quantity,amount,purchase_date,receipt_image) VALUES (?,?,?,?,?,?)");
        foreach ($purchases as $p) {
            $stmtInsert->execute($p);
        }
        echo "Sample purchases inserted.<br>";
    } else {
        echo "Purchases already exist, skipping insertion.<br>";
    }

    echo "<strong>Database setup completed successfully!</strong>";

} catch(PDOException $e) {
    die("ERROR: " . $e->getMessage());
}
