<?php
require_once __DIR__ . '/../config/db.php';
requireLogin();
if (!isAdmin()) {
    header('Location: my_purchases.php');
    exit;
}

// Fetch department report
$sql = "
SELECT 
    e.department,
    COALESCE(SUM(p.quantity*p.amount),0) AS total_spent,
    (
        SELECT emp_name 
        FROM employees emp
        JOIN purchases pp ON emp.emp_id=pp.emp_id
        WHERE emp.department = e.department
        GROUP BY emp.emp_id
        ORDER BY SUM(pp.quantity*pp.amount) DESC
        LIMIT 1
    ) AS highest_spender,
    (
        SELECT item_name
        FROM purchases pp
        JOIN employees emp ON emp.emp_id=pp.emp_id
        WHERE emp.department = e.department
        GROUP BY item_name
        ORDER BY COUNT(*) DESC
        LIMIT 1
    ) AS most_frequent_item
FROM employees e
LEFT JOIN purchases p ON e.emp_id=p.emp_id
GROUP BY e.department
ORDER BY total_spent DESC
";
$stmt = $pdo->query($sql);
$departments = $stmt->fetchAll();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Department Report - Pantry Monitor</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../assets/js/script.js"></script>
</head>
<body class="bg-light">
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4>Department-Level Insights</h4>
    <a href="index.php" class="btn btn-outline-secondary btn-sm">Back to Dashboard</a>
  </div>

  <div class="card shadow-sm">
    <div class="card-body">
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>Department</th>
            <th>Total Spent</th>
            <th>Highest Spender</th>
            <th>Most Frequent Item</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($departments as $d): ?>
            <tr class="<?=($d['total_spent']>2000)?'table-danger':''?>">
              <td><?=htmlspecialchars($d['department'])?></td>
              <td>₹ <?=$d['total_spent']?></td>
              <td><?=htmlspecialchars($d['highest_spender'] ?? '-')?></td>
              <td><?=htmlspecialchars($d['most_frequent_item'] ?? '-')?></td>
            </tr>
          <?php endforeach; ?>
          <?php if(count($departments)===0): ?>
            <tr><td colspan="4" class="text-center">No departments found</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>
