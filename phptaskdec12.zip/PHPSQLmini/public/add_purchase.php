<?php
require_once __DIR__ . '/../config/db.php';
requireLogin();

$success = '';
$err = '';

if (isAdmin()) {
    $stmt = $pdo->query('SELECT emp_id, emp_name FROM employees ORDER BY emp_name');
    $employees = $stmt->fetchAll();
} else if (isEmployee()) {
    $stmt = $pdo->prepare('SELECT emp_id, emp_name FROM employees WHERE emp_id=?');
    $stmt->execute([$_SESSION['user']['emp_id']]);
    $employees = $stmt->fetchAll();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_name = trim($_POST['item_name'] ?? '');
    $quantity = (int)($_POST['quantity'] ?? 0);
    $amount = (int)($_POST['amount'] ?? 0);
    $purchase_date = $_POST['purchase_date'] ?? date('Y-m-d');
    $emp_id = isEmployee() ? $_SESSION['user']['emp_id'] : (int)($_POST['emp_id'] ?? 0);

    if ($item_name === '' || $quantity <= 0 || $amount <= 0) {
        $err = 'Please fill all fields correctly.';
    } else {
        if ($quantity*$amount > 1000) {
            echo "<script>alert('High-value purchase – admin approval required.');</script>";
        }
        $stmt = $pdo->prepare("INSERT INTO purchases(emp_id,item_name,quantity,amount,purchase_date) VALUES(?,?,?,?,?)");
        $stmt->execute([$emp_id,$item_name,$quantity,$amount,$purchase_date]);
        $success = 'Purchase saved successfully.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Add Purchase</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../assets/js/script.js"></script>
</head>
<body class="bg-light">
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4>Add Purchase</h4>
    <a href="<?=isAdmin()?'index.php':'my_purchases.php'?>" class="btn btn-outline-secondary btn-sm">Back</a>
  </div>
  <?php if($success): ?><div class="alert alert-success"><?=$success?></div><?php endif; ?>
  <?php if($err): ?><div class="alert alert-danger"><?=$err?></div><?php endif; ?>
  <div class="card shadow-sm">
    <div class="card-body">
      <form method="POST" id="purchaseForm">
        <?php if(isAdmin()): ?>
        <div class="mb-3">
          <label>Employee</label>
          <select name="emp_id" class="form-control" required>
            <option value="">Select Employee</option>
            <?php foreach($employees as $e): ?>
              <option value="<?=$e['emp_id']?>"><?=$e['emp_name']?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php endif; ?>
        <div class="mb-3">
          <label>Item Name</label>
          <input type="text" name="item_name" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Quantity</label>
          <input type="number" name="quantity" class="form-control" min="1" required>
        </div>
        <div class="mb-3">
          <label>Amount per unit</label>
          <input type="number" name="amount" class="form-control" min="1" required>
        </div>
        <div class="mb-3">
          <label>Date</label>
          <input type="date" name="purchase_date" class="form-control" value="<?=date('Y-m-d')?>" required>
        </div>
        <button class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>
</div>
<script>
$(document).ready(function(){
    $('#purchaseForm').submit(function(){
        let qty = parseInt($('input[name="quantity"]').val());
        let amt = parseInt($('input[name="amount"]').val());
        if(qty*amt > 1000){
            alert('High-value purchase – admin approval required.');
        }
    });
});
</script>
</body>
</html>
