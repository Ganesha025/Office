<?php
require_once __DIR__ . '/../config/db.php';
requireLogin();
if (!isEmployee()) {
    header('Location: index.php');
    exit;
}

$emp_id = $_SESSION['user']['emp_id'];

// Fetch employee purchases
$stmt = $pdo->prepare("SELECT * FROM purchases WHERE emp_id = ? ORDER BY purchase_date DESC");
$stmt->execute([$emp_id]);
$purchases = $stmt->fetchAll();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>My Purchases - Pantry Monitor</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../assets/js/script.js"></script>
</head>
<body class="bg-light">
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4>My Purchases</h4>
    <div>
      <a href="add_purchase.php" class="btn btn-success btn-sm">Add Purchase</a>
      <a href="logout.php" class="btn btn-outline-secondary btn-sm">Logout</a>
    </div>
  </div>

  <div class="card shadow-sm">
    <div class="card-body">
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>Item Name</th>
            <th>Quantity</th>
            <th>Amount/unit</th>
            <th>Total</th>
            <th>Date</th>
            <th>Receipt</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($purchases as $p): ?>
            <tr>
              <td><?=htmlspecialchars($p['item_name'])?></td>
              <td><?=$p['quantity']?></td>
              <td>₹ <?=$p['amount']?></td>
              <td>₹ <?=($p['quantity']*$p['amount'])?></td>
              <td><?=$p['purchase_date']?></td>
              <td>
                <?php if($p['receipt_image']): ?>
                  <a href="<?=$p['receipt_image']?>" target="_blank">View</a>
                <?php else: ?>
                  -
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if(count($purchases)===0): ?>
            <tr><td colspan="6" class="text-center">No purchases yet</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</body>
</html>
