<?php
require_once __DIR__ . '/../config/db.php';
requireLogin();
if (!isAdmin()) {
    header('Location: my_purchases.php');
    exit;
}

// Fetch employee report
$sql = "
SELECT 
    e.emp_id,
    e.emp_name,
    e.department,
    COALESCE(SUM(p.quantity*p.amount),0) AS total_spent,
    COUNT(p.purchase_id) AS num_purchases,
    (
        SELECT item_name 
        FROM purchases 
        WHERE emp_id = e.emp_id 
        GROUP BY item_name 
        ORDER BY COUNT(*) DESC 
        LIMIT 1
    ) AS most_frequent_item
FROM employees e
LEFT JOIN purchases p ON e.emp_id = p.emp_id
GROUP BY e.emp_id
ORDER BY total_spent DESC
";
$stmt = $pdo->query($sql);
$employees = $stmt->fetchAll();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Employee Report - Pantry Monitor</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../assets/js/script.js"></script>
</head>
<body class="bg-light">
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4>Employee Purchase Report</h4>
    <a href="index.php" class="btn btn-outline-secondary btn-sm">Back to Dashboard</a>
  </div>

  <div class="card shadow-sm">
    <div class="card-body">
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>Employee Name</th>
            <th>Department</th>
            <th>Total Spent</th>
            <th>No. of Purchases</th>
            <th>Most Frequent Item</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($employees as $emp): ?>
            <tr class="<?=($emp['total_spent']>2000)?'table-danger':''?>">
              <td><?=htmlspecialchars($emp['emp_name'])?></td>
              <td><?=htmlspecialchars($emp['department'])?></td>
              <td>₹ <?=$emp['total_spent']?></td>
              <td><?=$emp['num_purchases']?></td>
              <td><?=htmlspecialchars($emp['most_frequent_item'] ?? '-')?></td>
            </tr>
          <?php endforeach; ?>
          <?php if(count($employees)===0): ?>
            <tr><td colspan="5" class="text-center">No employees found</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>
