// jQuery ready
$(document).ready(function(){

    // High-value purchase alert
    $('#purchaseForm').submit(function(){
        let qty = parseInt($('input[name="quantity"]').val());
        let amt = parseInt($('input[name="amount"]').val());
        if(qty*amt > 1000){
            alert('High-value purchase – admin approval required.');
        }
    });

    // Optional: Confirm before logout
    $('a[href="logout.php"]').click(function(e){
        if(!confirm('Are you sure you want to logout?')){
            e.preventDefault();
        }
    });

    // Highlight total spent cells dynamically
    $('table tbody tr').each(function(){
        let totalSpentCell = $(this).find('td:nth-child(3)');
        let val = parseInt(totalSpentCell.text().replace('₹','').trim());
        if(val > 2000){
            $(this).addClass('table-danger');
        }
    });

});
