<?php
require_once __DIR__ . '/../config/db.php';
requireLogin();
if (!isAdmin()) {
    header('Location: my_purchases.php');
    exit;
}

// Total spent this month
$stmt = $pdo->query("SELECT COALESCE(SUM(quantity*amount),0) AS total FROM purchases WHERE MONTH(purchase_date)=MONTH(CURDATE()) AND YEAR(purchase_date)=YEAR(CURDATE())");
$totRow = $stmt->fetch();
$tot = $totRow['total'] ?? 0;

// Top 3 spenders
$stmt = $pdo->query("SELECT e.emp_name, COALESCE(SUM(p.quantity*p.amount),0) as spent FROM employees e LEFT JOIN purchases p ON e.emp_id=p.emp_id GROUP BY e.emp_id ORDER BY spent DESC LIMIT 3");
$top = $stmt->fetchAll();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Dashboard - Pantry Monitor</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../assets/js/script.js"></script>
</head>
<body>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4>Admin Dashboard</h4>
    <a href="logout.php" class="btn btn-outline-secondary btn-sm">Logout</a>
  </div>
  <div class="row mb-4">
    <div class="col-md-4">
      <div class="card text-white bg-primary mb-3">
        <div class="card-body">
          <h5>Total Spent This Month</h5>
          <h3>₹ <?=$tot?></h3>
        </div>
      </div>
    </div>
    <div class="col-md-8">
      <div class="card mb-3">
        <div class="card-body">
          <h5>Top 3 Spenders</h5>
          <ul>
            <?php foreach($top as $t): ?>
              <li><?=$t['emp_name']?>: ₹ <?=$t['spent']?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <a href="employee_report.php" class="btn btn-success mb-3">Employee Report</a>
  <a href="department_report.php" class="btn btn-info mb-3">Department Report</a>
  <a href="add_purchase.php" class="btn btn-primary mb-3">Add Purchase</a>
</div>

</body>
</html>
