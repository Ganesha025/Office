<?php
session_start();
$conn = require_once '../config/db.php';

// Manager role check
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'manager') {
    header("Location: ../login.php");
    exit;
}

// Handle Add or Edit requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? 0;
    $name = $_POST['name'];
    $stock_quantity = $_POST['stock_quantity'];
    $price = $_POST['price'];
    $expiration_date = $_POST['expiration_date'] ?? null;

    // Handle file upload for image
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_path = 'uploads/' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], $image_path);
    } else {
        $image_path = null;
    }

    if ($id == 0) {
        // Add new item to inventory
        $stmt = $conn->prepare("INSERT INTO inventory_items (name, stock_quantity, price, image, expiration_date) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sidsi", $name, $stock_quantity, $price, $image_path, $expiration_date);
        $stmt->execute();
        $stmt->close();
    } else {
        // Update existing item
        $stmt = $conn->prepare("UPDATE inventory_items SET name=?, stock_quantity=?, price=?, image=?, expiration_date=? WHERE id=?");
        $stmt->bind_param("sidsii", $name, $stock_quantity, $price, $image_path, $expiration_date, $id);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: manage_inventory.php");
    exit;
}

// Handle Delete request
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM inventory_items WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    header("Location: manage_inventory.php");
    exit;
}

// Fetch all pantry items
$result = $conn->query("SELECT * FROM inventory_items ORDER BY name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Inventory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <h1 class="my-4">Manage Pantry Inventory</h1>
    
    <!-- Form for Add/Edit Inventory Item -->
    <h2>Add or Edit Inventory Item</h2>
    <form method="post" enctype="multipart/form-data">
        <?php if (isset($_GET['edit_id'])): ?>
            <?php
            // Fetch item details for editing
            $edit_id = $_GET['edit_id'];
            $stmt = $conn->prepare("SELECT * FROM inventory_items WHERE id = ?");
            $stmt->bind_param("i", $edit_id);
            $stmt->execute();
            $result_edit = $stmt->get_result();
            $item = $result_edit->fetch_assoc();
            $stmt->close();
            ?>
            <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
        <?php endif; ?>

        <div class="mb-3">
            <label for="name" class="form-label">Product Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo $item['name'] ?? ''; ?>" required>
        </div>

        <div class="mb-3">
            <label for="stock_quantity" class="form-label">Stock Quantity</label>
            <input type="number" class="form-control" id="stock_quantity" name="stock_quantity" value="<?php echo $item['stock_quantity'] ?? ''; ?>" required>
        </div>

        <div class="mb-3">
            <label for="price" class="form-label">Price</label>
            <input type="number" class="form-control" id="price" name="price" value="<?php echo $item['price'] ?? ''; ?>" step="0.01" required>
        </div>

        <div class="mb-3">
            <label for="expiration_date" class="form-label">Expiration Date</label>
            <input type="date" class="form-control" id="expiration_date" name="expiration_date" value="<?php echo $item['expiration_date'] ?? ''; ?>">
        </div>

        <div class="mb-3">
            <label for="image" class="form-label">Product Image</label>
            <input type="file" class="form-control" id="image" name="image" accept="image/*">
            <?php if (isset($item['image']) && $item['image']): ?>
                <img src="<?php echo $item['image']; ?>" alt="Product Image" width="100" class="mt-2">
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-primary"><?php echo isset($item['id']) ? 'Update' : 'Add'; ?> Product</button>
    </form>

    <!-- Product List -->
    <h2 class="my-4">Product List</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Name</th>
                <th>Stock</th>
                <th>Price</th>
                <th>Image</th>
                <th>Expiration Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo $row['stock_quantity']; ?></td>
                    <td><?php echo $row['price']; ?></td>
                    <td>
                        <?php if ($row['image']): ?>
                            <img src="<?php echo $row['image']; ?>" alt="Product Image" width="50">
                        <?php endif; ?>
                    </td>
                    <td><?php echo $row['expiration_date'] ?? 'N/A'; ?></td>
                    <td>
                        <a href="manage_inventory.php?edit_id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="manage_inventory.php?delete_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
