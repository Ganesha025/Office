<?php
session_start();
$conn = require_once '../config/db.php';

// // Manager role check
// if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'manager') {
//     header("Location: ../login.php");
//     exit;
// }

// Fetch pantry inventory data
$result = $conn->query("SELECT id, name, stock_quantity, reserved_quantity FROM inventory_items ORDER BY name");

$items = [];
$stock = [];
$reserved = [];

while ($row = $result->fetch_assoc()) {
    $items[] = $row['name'];
    $stock[] = (int)$row['stock_quantity'];
    $reserved[] = (int)$row['reserved_quantity'];
}

// Handle reservations
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reserve_item_id'])) {
    $item_id = $_POST['reserve_item_id'];
    $quantity = (int)$_POST['quantity'];

    // Check if there is enough stock
    $stock_check = $conn->query("SELECT stock_quantity, reserved_quantity FROM inventory_items WHERE id = $item_id");
    $stock_data = $stock_check->fetch_assoc();
    $available_stock = $stock_data['stock_quantity'] - $stock_data['reserved_quantity'];

    if ($available_stock >= $quantity) {
        // Update reserved quantity
        $conn->query("UPDATE inventory_items SET reserved_quantity = reserved_quantity + $quantity WHERE id = $item_id");
        // Record the reservation (optional: can link to users or departments)
        $conn->query("INSERT INTO reservations (item_id, quantity, reserved_by, reserved_at) VALUES ($item_id, $quantity, {$_SESSION['user_id']}, NOW())");
        $message = "Reservation successful!";
    } else {
        $message = "Not enough stock available!";
    }
}

// Fetch all reservations
$reservations_result = $conn->query("SELECT r.id, i.name, r.quantity, r.reserved_at, u.username FROM reservations r JOIN inventory_items i ON r.item_id = i.id JOIN users u ON r.reserved_by = u.id ORDER BY r.reserved_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manager Dashboard - Pantry App</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .card { margin-bottom: 20px; }
        .chart-container { height: 300px; width: 100%; }
        .btn { margin-top: 10px; }
        .table th, .table td { text-align: center; }
    </style>
</head>
<body>

<div class="container">
    <h1 class="my-4">Manager Dashboard</h1>

    <div class="card">
        <h2 class="card-header">Pantry Overview</h2>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Stock</th>
                        <th>Reserved</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $idx => $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item); ?></td>
                            <td><?php echo $stock[$idx]; ?></td>
                            <td><?php echo $reserved[$idx]; ?></td>
                            <td>
                                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#reserveModal" data-itemid="<?php echo $idx; ?>" data-itemname="<?php echo htmlspecialchars($item); ?>">Reserve</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <h2 class="card-header">Reservations</h2>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Quantity</th>
                        <th>Reserved By</th>
                        <th>Reserved At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $reservations_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo $row['quantity']; ?></td>
                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                            <td><?php echo $row['reserved_at']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal for Reserving Items -->
    <div class="modal fade" id="reserveModal" tabindex="-1" aria-labelledby="reserveModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="reserveModalLabel">Reserve Item</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="post">
                        <input type="hidden" name="reserve_item_id" id="reserve_item_id">
                        <label for="quantity">Quantity:</label>
                        <input type="number" name="quantity" id="quantity" class="form-control" min="1" required>
                        <div class="mt-3">
                            <button type="submit" class="btn btn-success">Reserve</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
    var reserveModal = document.getElementById('reserveModal');
    reserveModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget;
        var itemId = button.getAttribute('data-itemid');
        var itemName = button.getAttribute('data-itemname');
        
        var modalTitle = reserveModal.querySelector('.modal-title');
        var reserveItemId = reserveModal.querySelector('#reserve_item_id');

        modalTitle.textContent = 'Reserve ' + itemName;
        reserveItemId.value = itemId;
    });
</script>

</body>
</html>
