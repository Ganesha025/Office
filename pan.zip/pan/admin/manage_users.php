<?php
session_start();
$conn = require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$MAX_MANAGERS = 5;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'];
    $department = $_POST['department'] ?? null;
    $user_uid = $_POST['user_uid'] ?? uniqid('U');
    $edit_id = $_POST['edit_id'] ?? 0;

    if ($edit_id > 0) {
        $update_sql = "UPDATE users SET username=?, email=?, role=?, department=?";
        $params = [$username, $email, $role, $department];

        if (!empty($password)) {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $update_sql .= ", password_hash=?";
            $params[] = $password_hash;
        }

        $update_sql .= " WHERE id=?";
        $params[] = $edit_id;

        $types = str_repeat("s", count($params)-1) . "i";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $stmt->close();
        header("Location: manage_users.php");
        exit;
    } else {
        if ($role === 'manager') {
            $res = $conn->query("SELECT COUNT(*) as total FROM users WHERE role='manager' AND status='active'");
            $row = $res->fetch_assoc();
            if ($row['total'] >= $MAX_MANAGERS) {
                $error = "Maximum manager limit reached!";
            }
        }

        if (!isset($error)) {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (user_uid, username, password_hash, email, role, department, status) VALUES (?,?,?,?,?,?, 'active')");
            $stmt->bind_param("ssssss", $user_uid, $username, $password_hash, $email, $role, $department);
            $stmt->execute();
            $stmt->close();
            header("Location: manage_users.php");
            exit;
        }
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'update_status' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $status = $_GET['status'] === 'active' ? 'inactive' : 'active';
    $stmt = $conn->prepare("UPDATE users SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_users.php");
    exit;
}

$result = $conn->query("SELECT * FROM users WHERE status='active' ORDER BY role, username");

$role = 'employee';
if (isset($_GET['id'])) {
    $edit_id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $user_result = $stmt->get_result();
    if ($user_result->num_rows > 0) {
        $user = $user_result->fetch_assoc();
        $username = $user['username'];
        $email = $user['email'];
        $role = $user['role'];
        $department = $user['department'];
        $user_uid = $user['user_uid'];
    }
    $stmt->close();
} else {
    $username = '';
    $email = '';
    $department = '';
    $user_uid = uniqid('U');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Users - Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root {
    --bg-primary: #f8f9fa;
    --bg-secondary: #ffffff;
    --text-primary: #2c3e50;
    --text-secondary: #6c757d;
    --border-color: #e9ecef;
    --accent: #3b82f6;
    --success: #10b981;
    --danger: #ef4444;
}

[data-theme="dark"] {
    --bg-primary: #1a1a1a;
    --bg-secondary: #2d2d2d;
    --text-primary: #ffffff;
    --text-secondary: #a0a0a0;
    --border-color: #404040;
    --accent: #60a5fa;
    --success: #34d399;
    --danger: #f87171;
}

* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: var(--bg-primary);
    color: var(--text-primary);
    transition: all 0.3s;
    overflow: hidden;
    height: 100vh;
}

.container-fluid {
    height: 100vh;
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.header {
    background: var(--bg-secondary);
    padding: 1rem 2rem;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-shrink: 0;
}

.header h1 {
    font-size: 1.5rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.header-actions {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.icon-btn {
    background: none;
    border: none;
    color: var(--text-primary);
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 50%;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
}

.icon-btn:hover { background: var(--bg-primary); }

.main-content {
    flex: 1;
    overflow: hidden;
    display: grid;
    grid-template-columns: 400px 1fr;
    gap: 1.5rem;
    padding: 1.5rem 2rem;
}

.card {
    background: var(--bg-secondary);
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    border: 1px solid var(--border-color);
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.card-header {
    padding: 1.25rem;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    gap: 0.75rem;
    flex-shrink: 0;
}

.card-header h2 {
    font-size: 1.1rem;
    font-weight: 600;
    margin: 0;
}

.card-header .material-icons {
    font-size: 22px;
    color: var(--accent);
}

.card-body {
    padding: 1.25rem;
    flex: 1;
    overflow-y: auto;
}

.card-body::-webkit-scrollbar { width: 6px; }
.card-body::-webkit-scrollbar-track { background: transparent; }
.card-body::-webkit-scrollbar-thumb { background: var(--border-color); border-radius: 3px; }

.form-group {
    margin-bottom: 1rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    font-size: 0.875rem;
    color: var(--text-secondary);
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 0.625rem 0.875rem;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    background: var(--bg-primary);
    color: var(--text-primary);
    font-size: 0.875rem;
    transition: all 0.3s;
}

.form-group input:focus,
.form-group select:focus {
    outline: none;
    border-color: var(--accent);
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.form-group input:read-only {
    background: var(--border-color);
    cursor: not-allowed;
}

.btn {
    padding: 0.625rem 1.25rem;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.3s;
    font-size: 0.875rem;
    font-weight: 500;
    text-decoration: none;
}

.btn .material-icons { font-size: 18px; }

.btn-primary {
    background: var(--accent);
    color: white;
}

.btn-primary:hover {
    opacity: 0.9;
    transform: translateY(-1px);
}

.btn-success {
    background: var(--success);
    color: white;
}

.btn-danger {
    background: var(--danger);
    color: white;
}

.btn-secondary {
    background: var(--border-color);
    color: var(--text-primary);
}

.table-container {
    overflow: auto;
    height: 100%;
}

table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.875rem;
}

th, td {
    padding: 0.875rem;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}

th {
    font-weight: 600;
    color: var(--text-secondary);
    font-size: 0.8rem;
    text-transform: uppercase;
    background: var(--bg-primary);
    position: sticky;
    top: 0;
    z-index: 10;
}

tbody tr:hover {
    background: var(--bg-primary);
}

.badge {
    padding: 0.25rem 0.75rem;
    border-radius: 15px;
    font-size: 0.75rem;
    font-weight: 600;
    display: inline-block;
}

.badge-employee { background: #dbeafe; color: #1e40af; }
.badge-manager { background: #fef3c7; color: #92400e; }

[data-theme="dark"] .badge-employee { background: #1e40af; color: #dbeafe; }
[data-theme="dark"] .badge-manager { background: #92400e; color: #fef3c7; }

.action-links {
    display: flex;
    gap: 0.75rem;
}

.action-links a {
    color: var(--accent);
    text-decoration: none;
    font-size: 0.875rem;
    transition: all 0.3s;
}

.action-links a:hover {
    text-decoration: underline;
}

.alert {
    padding: 0.75rem 1rem;
    border-radius: 8px;
    margin-bottom: 1rem;
    font-size: 0.875rem;
}

.alert-danger {
    background: rgba(239, 68, 68, 0.1);
    color: var(--danger);
    border: 1px solid var(--danger);
}

@media (max-width: 1024px) {
    .main-content {
        grid-template-columns: 1fr;
        overflow-y: auto;
    }
    
    .card {
        overflow: visible;
    }
    
    .card-body {
        overflow: visible;
    }
}
</style>
</head>
<body>

<div class="container-fluid">
    <div class="header">
        <h1>
            <span class="material-icons">people</span>
            Manage Users
        </h1>
        <div class="header-actions">
            <button class="icon-btn" onclick="toggleTheme()">
                <span class="material-icons">dark_mode</span>
            </button>
            <a href="dashboard.php" class="btn btn-secondary">
                <span class="material-icons">arrow_back</span>
                Dashboard
            </a>
        </div>
    </div>

    <div class="main-content">
        <div class="card">
            <div class="card-header">
                <span class="material-icons">person_add</span>
                <h2><?php echo isset($_GET['id']) ? 'Edit User' : 'Add User'; ?></h2>
            </div>
            <div class="card-body">
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger">
                        <strong>Error:</strong> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <form method="post" action="manage_users.php">
                    <input type="hidden" name="edit_id" value="<?php echo $_GET['id'] ?? ''; ?>">
                    
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" required value="<?php echo htmlspecialchars($username ?? ''); ?>" placeholder="Enter username">
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" required value="<?php echo htmlspecialchars($email ?? ''); ?>" placeholder="Enter email">
                    </div>

                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" placeholder="<?php echo isset($_GET['id']) ? 'Leave blank to keep current' : 'Enter password'; ?>">
                    </div>

                    <div class="form-group">
                        <label>Role</label>
                        <select name="role">
                            <option value="employee" <?php if($role === 'employee') echo 'selected'; ?>>Employee</option>
                            <option value="manager" <?php if($role === 'manager') echo 'selected'; ?>>Manager</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Department</label>
                        <input type="text" name="department" value="<?php echo htmlspecialchars($department ?? ''); ?>" placeholder="Enter department">
                    </div>

                    <div class="form-group">
                        <label>Unique ID</label>
                        <input type="text" name="user_uid" value="<?php echo htmlspecialchars($user_uid ?? uniqid('U')); ?>" readonly>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">
                        <span class="material-icons"><?php echo isset($_GET['id']) ? 'save' : 'add'; ?></span>
                        <?php echo isset($_GET['id']) ? 'Update User' : 'Add User'; ?>
                    </button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <span class="material-icons">group</span>
                <h2>Active Users</h2>
            </div>
            <div class="card-body">
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Unique ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Department</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo htmlspecialchars($row['user_uid']); ?></td>
                                <td><?php echo htmlspecialchars($row['username']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $row['role']; ?>">
                                        <?php echo ucfirst($row['role']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($row['department']); ?></td>
                                <td>
                                    <div class="action-links">
                                        <a href="manage_users.php?id=<?php echo $row['id']; ?>">Edit</a>
                                        <a href="manage_users.php?action=update_status&id=<?php echo $row['id']; ?>&status=<?php echo $row['status']; ?>">
                                            <?php echo $row['status'] === 'active' ? 'Deactivate' : 'Activate'; ?>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleTheme() {
    const html = document.documentElement;
    const currentTheme = html.getAttribute('data-theme');
    html.setAttribute('data-theme', currentTheme === 'dark' ? 'light' : 'dark');
    localStorage.setItem('theme', currentTheme === 'dark' ? 'light' : 'dark');
}

const savedTheme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', savedTheme);
</script>

</body>
</html>