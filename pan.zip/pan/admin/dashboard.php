<?php
session_start();
$conn = require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$result = $conn->query("SELECT name, stock_quantity, reserved_quantity FROM inventory_items ORDER BY name LIMIT 5");

$items = [];
$stock = [];
$reserved = [];

while ($row = $result->fetch_assoc()) {
    $items[] = $row['name'];
    $stock[] = (int)$row['stock_quantity'];
    $reserved[] = (int)$row['reserved_quantity'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Admin Dashboard - Pantry App</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
  :root {
    --bg-primary: #f8f9fa;
    --bg-secondary: #ffffff;
    --bg-sidebar: #2c3e50;
    --text-primary: #2c3e50;
    --text-secondary: #6c757d;
    --text-sidebar: #ffffff;
    --border-color: #e9ecef;
    --accent: #3b82f6;
  }
  
  [data-theme="dark"] {
    --bg-primary: #1a1a1a;
    --bg-secondary: #2d2d2d;
    --bg-sidebar: #1e293b;
    --text-primary: #ffffff;
    --text-secondary: #a0a0a0;
    --text-sidebar: #ffffff;
    --border-color: #404040;
    --accent: #60a5fa;
  }
  
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { 
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: var(--bg-primary);
    color: var(--text-primary);
    overflow: hidden;
    transition: all 0.3s;
    height: 100vh;
  }
  
  .sidebar {
    position: fixed;
    left: 0;
    top: 0;
    height: 100vh;
    width: 260px;
    background: var(--bg-sidebar);
    color: var(--text-sidebar);
    transition: all 0.3s;
    z-index: 1000;
    display: flex;
    flex-direction: column;
  }
  
  .sidebar-header {
    text-align: center;
    padding: 1.5rem 1rem;
    border-bottom: 1px solid rgba(255,255,255,0.1);
  }
  
  .sidebar-header img {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    margin-bottom: 0.75rem;
    border: 2px solid var(--accent);
  }
  
  .sidebar-header h3 { font-size: 1rem; margin-bottom: 0.25rem; }
  .sidebar-header p { font-size: 0.75rem; opacity: 0.7; }
  
  .sidebar-menu {
    list-style: none;
    padding: 1rem 0;
    flex: 1;
    overflow-y: auto;
  }
  
  .sidebar-menu li { margin: 0.25rem 0.5rem; }
  
  .sidebar-menu a {
    display: flex;
    align-items: center;
    padding: 0.75rem 1rem;
    color: var(--text-sidebar);
    text-decoration: none;
    border-radius: 8px;
    transition: all 0.3s;
    gap: 0.75rem;
    font-size: 0.9rem;
  }
  
  .sidebar-menu a .material-icons { font-size: 20px; }
  
  .sidebar-menu a:hover,
  .sidebar-menu a.active {
    background: rgba(59, 130, 246, 0.2);
    color: var(--accent);
  }
  
  .logout-btn {
    padding: 1rem;
    border-top: 1px solid rgba(255,255,255,0.1);
  }
  
  .main-content {
    margin-left: 260px;
    height: 100vh;
    display: flex;
    flex-direction: column;
  }
  
  .topbar {
    background: var(--bg-secondary);
    padding: 0.75rem 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--border-color);
    height: 60px;
    flex-shrink: 0;
  }
  
  .search-box {
    flex: 1;
    max-width: 400px;
    position: relative;
  }
  
  .search-box input {
    width: 100%;
    padding: 0.5rem 1rem 0.5rem 2.5rem;
    border: 1px solid var(--border-color);
    border-radius: 20px;
    background: var(--bg-primary);
    color: var(--text-primary);
    font-size: 0.875rem;
  }
  
  .search-box .material-icons {
    position: absolute;
    left: 0.75rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-secondary);
    font-size: 20px;
  }
  
  .topbar-actions {
    display: flex;
    gap: 0.5rem;
    align-items: center;
  }
  
  .icon-btn {
    background: none;
    border: none;
    color: var(--text-primary);
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 50%;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .icon-btn .material-icons { font-size: 22px; }
  .icon-btn:hover { background: var(--bg-primary); }
  
  .content-area {
    flex: 1;
    padding: 1rem 1.5rem;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }
  
  .content-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: auto auto;
    gap: 1rem;
    height: calc(100vh - 60px - 2rem);
  }
  
  .card {
    background: var(--bg-secondary);
    border-radius: 10px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.06);
    padding: 1.25rem;
    border: 1px solid var(--border-color);
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
  
  .card-header {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 1rem;
    flex-shrink: 0;
  }
  
  .card-header h2 {
    font-size: 1.1rem;
    font-weight: 600;
    margin: 0;
  }
  
  .card-header .material-icons { font-size: 22px; color: var(--accent); }
  
  .card-body {
    flex: 1;
    overflow: auto;
    min-height: 0;
  }
  
  .card-body::-webkit-scrollbar { width: 6px; }
  .card-body::-webkit-scrollbar-track { background: transparent; }
  .card-body::-webkit-scrollbar-thumb { background: var(--border-color); border-radius: 3px; }
  
  .card-full { grid-column: 1 / -1; }
  
  .table-container { overflow: auto; height: 100%; }
  
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.875rem;
  }
  
  th, td {
    padding: 0.75rem;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
  }
  
  th {
    font-weight: 600;
    color: var(--text-secondary);
    font-size: 0.8rem;
    text-transform: uppercase;
    background: var(--bg-primary);
    position: sticky;
    top: 0;
    z-index: 10;
  }
  
  td { font-weight: 500; }
  
  .status-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 15px;
    font-size: 0.75rem;
    font-weight: 600;
    display: inline-block;
  }
  
  .status-delivered { background: #d1fae5; color: #065f46; }
  .status-cancelled { background: #fee2e2; color: #991b1b; }
  
  [data-theme="dark"] .status-delivered { background: #065f46; color: #d1fae5; }
  [data-theme="dark"] .status-cancelled { background: #991b1b; color: #fee2e2; }
  
  .chart-wrapper {
    height: 100%;
    position: relative;
    min-height: 0;
  }
  
  .btn-group-custom {
    display: flex;
    gap: 0.75rem;
    flex-wrap: wrap;
  }
  
  .btn-primary {
    background: var(--accent);
    color: white;
    padding: 0.5rem 1.25rem;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.3s;
    font-size: 0.875rem;
    font-weight: 500;
  }
  
  .btn-primary .material-icons { font-size: 18px; }
  .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
  
  .form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
  }
  
  .form-group {
    margin-bottom: 0;
  }
  
  .form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    font-size: 0.875rem;
  }
  
  .form-group input {
    width: 100%;
    padding: 0.5rem 0.75rem;
    border: 1px solid var(--border-color);
    border-radius: 6px;
    background: var(--bg-primary);
    color: var(--text-primary);
    font-size: 0.875rem;
  }
  
  @media (max-width: 1200px) {
    .content-grid { grid-template-columns: 1fr; }
    .card-full { grid-column: 1; }
  }
  
  @media (max-width: 768px) {
    .sidebar { transform: translateX(-100%); }
    .sidebar.mobile-open { transform: translateX(0); }
    .main-content { margin-left: 0; }
    .topbar { padding: 0.75rem 1rem; }
    .content-area { padding: 1rem; }
    .search-box { max-width: 200px; }
    .form-grid { grid-template-columns: 1fr; }
  }
</style>
</head>
<body>

<div class="sidebar" id="sidebar">
  <div class="sidebar-header">
    <img src="https://via.placeholder.com/60" alt="Admin">
    <h3>Admin User</h3>
    <p>admin@pantry.com</p>
  </div>
  
  <ul class="sidebar-menu">
    <li><a href="#" class="active"><span class="material-icons">dashboard</span> Dashboard</a></li>
    <li><a href="#"><span class="material-icons">inventory_2</span> Inventory</a></li>
    <li><a href="#"><span class="material-icons">shopping_cart</span> Orders</a></li>
    <li><a href="#"><span class="material-icons">shopping_bag</span> Purchase</a></li>
    <li><a href="#"><span class="material-icons">bar_chart</span> Reporting</a></li>
    <li><a href="#"><span class="material-icons">support_agent</span> Support</a></li>
    <li><a href="#"><span class="material-icons">settings</span> Settings</a></li>
  </ul>
  
  <div class="logout-btn">
    <a href="#" style="display: flex; align-items: center; gap: 0.75rem; color: var(--text-sidebar); text-decoration: none; padding: 0.75rem 1rem; border-radius: 8px; transition: all 0.3s;">
      <span class="material-icons" style="font-size: 20px;">logout</span>
      <span style="font-size: 0.9rem;">Logout</span>
    </a>
  </div>
</div>

<div class="main-content">
  <div class="topbar">
    <button class="icon-btn d-md-none" onclick="toggleSidebar()">
      <span class="material-icons">menu</span>
    </button>
    
    <div class="search-box">
      <span class="material-icons">search</span>
      <input type="text" placeholder="Search...">
    </div>
    
    <div class="topbar-actions">
      <button class="icon-btn" onclick="toggleTheme()">
        <span class="material-icons">dark_mode</span>
      </button>
      <button class="icon-btn">
        <span class="material-icons">notifications</span>
      </button>
    </div>
  </div>
  
  <div class="content-area">
    <div class="content-grid">
      
      <div class="card">
        <div class="card-header">
          <span class="material-icons">people</span>
          <h2>User Management</h2>
        </div>
        <div class="card-body">
          <div class="btn-group-custom">
            <button class="btn-primary" data-bs-toggle="modal" data-bs-target="#manageUsersModal">
              <span class="material-icons">person</span> Employees
            </button>
            <button class="btn-primary" data-bs-toggle="modal" data-bs-target="#manageUsersModal">
              <span class="material-icons">supervisor_account</span> Managers
            </button>
          </div>
        </div>
      </div>
      
      <div class="card">
        <div class="card-header">
          <span class="material-icons">tune</span>
          <h2>System Settings</h2>
        </div>
        <div class="card-body">
          <form method="post" action="settings_save.php">
            <div class="form-grid">
              <div class="form-group">
                <label for="setting1">Setting 1</label>
                <input type="text" id="setting1" name="setting1" placeholder="Enter value">
              </div>
              
              <div class="form-group">
                <label for="setting2">Setting 2</label>
                <input type="number" id="setting2" name="setting2" placeholder="Enter number">
              </div>
            </div>
            
            <button type="submit" class="btn-primary mt-3">
              <span class="material-icons">save</span> Save Settings
            </button>
          </form>
        </div>
      </div>
      
      <div class="card">
        <div class="card-header">
          <span class="material-icons">inventory</span>
          <h2>Pantry Overview</h2>
        </div>
        <div class="card-body">
          <div class="table-container">
            <table>
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Stock</th>
                  <th>Reserved</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($items as $idx => $item): ?>
                  <tr>
                    <td><?php echo htmlspecialchars($item); ?></td>
                    <td><?php echo number_format($stock[$idx]); ?></td>
                    <td><?php echo number_format($reserved[$idx]); ?></td>
                    <td>
                      <span class="status-badge <?php echo $stock[$idx] > $reserved[$idx] ? 'status-delivered' : 'status-cancelled'; ?>">
                        <?php echo $stock[$idx] > $reserved[$idx] ? 'Available' : 'Low Stock'; ?>
                      </span>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div class="card">
        <div class="card-header">
          <span class="material-icons">analytics</span>
          <h2>Analytics</h2>
        </div>
        <div class="card-body">
          <div class="chart-wrapper">
            <canvas id="pantryChart"></canvas>
          </div>
        </div>
      </div>
      
    </div>
  </div>
</div>

<div class="modal fade" id="manageUsersModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="background: var(--bg-secondary); color: var(--text-primary);">
      <div class="modal-header">
        <h5 class="modal-title">Manage Users</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <iframe src="manage_users.php" style="width:100%; height:500px; border:none;"></iframe>
      </div>
    </div>
  </div>
</div>

<script>
const ctx = document.getElementById('pantryChart').getContext('2d');

const pantryChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: <?php echo json_encode($items); ?>,
    datasets: [
      {
        label: 'Stock',
        data: <?php echo json_encode($stock); ?>,
        borderColor: '#3b82f6',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        fill: true,
        tension: 0.4,
        pointRadius: 3,
        pointHoverRadius: 5,
      },
      {
        label: 'Reserved',
        data: <?php echo json_encode($reserved); ?>,
        borderColor: '#ef4444',
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
        fill: true,
        tension: 0.4,
        pointRadius: 3,
        pointHoverRadius: 5,
      }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'top', labels: { boxWidth: 12, padding: 10, font: { size: 11 } } },
      title: { display: false }
    },
    scales: {
      y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { font: { size: 10 } } },
      x: { grid: { display: false }, ticks: { font: { size: 10 } } }
    }
  }
});

function toggleTheme() {
  const html = document.documentElement;
  const currentTheme = html.getAttribute('data-theme');
  html.setAttribute('data-theme', currentTheme === 'dark' ? 'light' : 'dark');
  localStorage.setItem('theme', currentTheme === 'dark' ? 'light' : 'dark');
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('mobile-open');
}

const savedTheme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', savedTheme);
</script>

</body>
</html>