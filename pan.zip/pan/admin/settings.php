<?php
session_start();
$conn = require_once '../config/db.php';

// Admin check
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$message = '';

// Handle form submission to update settings
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST as $key => $value) {
        $key = $conn->real_escape_string($key);
        $value = $conn->real_escape_string($value);

        $sql = "INSERT INTO system_settings (setting_key, setting_value)
                VALUES ('$key', '$value')
                ON DUPLICATE KEY UPDATE setting_value = '$value', updated_at = NOW()";
        $conn->query($sql);
    }
    $message = "Settings updated successfully.";
}

// Fetch current settings
$settings_result = $conn->query("SELECT setting_key, setting_value FROM system_settings");
$settings = [];
while ($row = $settings_result->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>System Settings - Admin - Pantry App</title>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 20px;
    background: #f8f9fa;
}
h1 {
    margin-bottom: 20px;
}
form {
    background: white;
    padding: 20px;
    border-radius: 6px;
    box-shadow: 0 2px 5px rgb(0 0 0 / 0.1);
    max-width: 500px;
}
label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
}
input[type="text"], input[type="number"], input[type="email"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 4px;
    border: 1px solid #ccc;
}
button {
    background: #007bff;
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
}
button:hover {
    background: #0056b3;
}
.message {
    margin-bottom: 20px;
    padding: 10px;
    background-color: #d4edda;
    color: #155724;
    border-radius: 4px;
    border: 1px solid #c3e6cb;
}
a {
    display: inline-block;
    margin-bottom: 20px;
    text-decoration: none;
    color: #007bff;
}
a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>

<a href="dashboard.php">&larr; Back to Dashboard</a>

<h1>System Settings</h1>

<?php if ($message): ?>
    <div class="message"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<form method="post" action="">
    <label for="notification_email">Notification Email</label>
    <input type="email" id="notification_email" name="notification_email" value="<?php echo htmlspecialchars($settings['notification_email'] ?? ''); ?>" required>

    <label for="max_managers">Maximum Number of Managers</label>
    <input type="number" id="max_managers" name="max_managers" min="1" value="<?php echo htmlspecialchars($settings['max_managers'] ?? 5); ?>" required>

    <button type="submit">Save Settings</button>
</form>

</body>
</html>
