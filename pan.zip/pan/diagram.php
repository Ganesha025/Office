pantry-app/
│
├── assets/
│   ├── css/                 # Stylesheets (e.g., main.css)
│   ├── js/                  # JavaScript files (AJAX, UI scripts)
│   └── images/              # Icons and images (coffee, tea, etc.)
│
├── config/
│   └── db.php               # Database connection setup
│
├── includes/
│   ├── header.php           # Common header (navbar, meta, etc.)
│   ├── footer.php           # Common footer
│   ├── functions.php        # Utility functions (role checks, sanitization)
│   └── auth.php             # Authentication and session management
│
├── admin/                   # Admin-specific pages
│   ├── dashboard.php
│   ├── manage_users.php
│   └── settings.php
│
├── manager/                 # Pantry Manager-specific pages
│   ├── dashboard.php
│   ├── inventory.php
│   ├── add_item.php
│   └── analytics.php
│
├── employee/                # Employee-specific pages
│   ├── dashboard.php
│   ├── book_item.php
│   └── favorites.php
│
├── api/                     # AJAX API endpoints for real-time actions
│   ├── get_inventory.php
│   ├── book_item.php
│   ├── restock_item.php
│   └── mark_expired.php
│
├── index.php                # Entry point (login or role-based redirect)
├── login.php                # Login form and processing
├── logout.php               # Logout script
├── register.php             # Optional, user registration (if needed)
└── README.md                # Project info and setup instructions
