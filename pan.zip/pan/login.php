<?php
session_start();
require_once 'config/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Prepare statement to avoid SQL injection
    $stmt = $conn->prepare("SELECT id, password_hash, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $password_hash, $role);
        $stmt->fetch();

        if (password_verify($password, $password_hash)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['user_role'] = $role;
            $_SESSION['username'] = $username;

            // Redirect based on role
            switch ($role) {
                case 'admin':
                    header("Location: admin/dashboard.php");
                    break;
                case 'manager':
                    header("Location: manager/dashboard.php");
                    break;
                case 'employee':
                    header("Location: employee/dashboard.php");
                    break;
                default:
                    // Unknown role, logout
                    session_destroy();
                    $error = "Invalid user role.";
            }
            exit;
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Invalid username or password.";
    }

    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Pantry App Login</title>
<style>
body { font-family: Arial, sans-serif; }
form { max-width: 300px; margin: 50px auto; padding: 20px; border: 1px solid #ccc; }
input { width: 100%; padding: 8px; margin: 8px 0; }
button { width: 100%; padding: 10px; }
.error { color: red; }
</style>
</head>
<body>
<h2 style="text-align:center;">Pantry App Login</h2>
<?php if ($error): ?>
    <p class="error"><?php echo htmlspecialchars($error); ?></p>
<?php endif; ?>
<form method="post" action="">
    <label>Username:</label>
    <input type="text" name="username" required>

    <label>Password:</label>
    <input type="password" name="password" required>

    <button type="submit">Login</button>
</form>
</body>
</html>
