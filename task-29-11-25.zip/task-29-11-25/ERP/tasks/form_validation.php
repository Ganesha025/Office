<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admission Form Validation</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
body {
    background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
    font-family: "Inter", sans-serif;
    font-size: 18px;
    color: #2b2b2b;
}
.card {
    background: rgba(255,255,255,0.55);
    border-radius: 20px;
    padding: 40px;
    max-width: 650px;
    margin: 0 auto;
    border: 2px solid rgba(0,0,0,0.08);
    backdrop-filter: blur(14px);
}
.card:hover {
    background: rgba(255,255,255,0.7);
    transform: translateY(-5px);
}
input, select {
    width: 100%;
    padding: 1rem 1.2rem;
    border-radius: 10px;
    border: 1px solid #ccc;
    height: 3.3rem;
    font-size: 18px;
}
label {
    margin-bottom: 6px;
    display: inline-block;
}
.error {
    color: red;
    font-size: 15px;
    margin-top: 6px;
}
.result-box {
    background: #D8F3DC;
    padding: 30px;
    border-radius: 14px;
    margin-top: 28px;
    border: 2px solid #95D5B2;
    font-family: monospace;
    white-space: pre-line;
    text-align: center;
}
.error-star { color: red; }
</style>
</head>

<body>

<header class="py-10 text-center">
    <h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 
        text-transparent bg-clip-text">
        Admission Form
    </h1>
    <p class="text-gray-700 mt-4 text-xl">Validate your data before submission</p>
    <a href="../index.php" class="text-blue-800 underline mt-4 inline-block text-lg font-semibold">
        ← Back to Dashboard
    </a>
</header>

<div class="card mt-8">
<form id="admissionForm" autocomplete="off">

    <!-- Name -->
    <div class="mt-2">
        <label class="font-semibold">Name <span class="error-star">*</span></label>
        <input type="text" id="name" placeholder="Enter your name">
        <p class="error" id="nameError"></p>
    </div>

    <!-- Mobile -->
    <div class="mt-6">
        <label class="font-semibold">Mobile <span class="error-star">*</span></label>
        <input type="text" id="mobile" placeholder="Enter 10-digit mobile number">
        <p class="error" id="mobileError"></p>
    </div>

    <!-- Email -->
    <div class="mt-6">
        <label class="font-semibold">Email <span class="error-star">*</span></label>
        <input type="text" id="email" placeholder="Enter your email">
        <p class="error" id="emailError"></p>
    </div>

    <!-- Age -->
    <div class="mt-6">
        <label class="font-semibold">Age <span class="error-star">*</span></label>
        <input type="text" id="age" placeholder="Enter your age (18-100)">
        <p class="error" id="ageError"></p>
    </div>

    <div class="text-center mt-10">
        <button type="submit" class="px-10 py-4 rounded-xl bg-purple-600 text-white
            text-xl font-semibold hover:bg-purple-700 transition">
            Submit Form
        </button>
    </div>

</form>

<div id="result" class="result-box" style="display:none;"></div>
</div>

<script>
$(document).ready(function () {

    // Reset form & result on page load
    $("#admissionForm")[0].reset();
    $("#result").hide();
    $(".error").text("");

    // ---------------------------
    // Validation Functions
    // ---------------------------
    function validateName() {
        let name = $("#name").val().trim();
        if (name === "") {
            $("#nameError").text("This field is required");
            return false;
        } else if (!/^[A-Za-z ]+$/.test(name)) {
            $("#nameError").text("Enter letters only");
            return false;
        } else if (name.length > 15) {
            $("#nameError").text("Maximum 15 characters allowed");
            return false;
        } else {
            $("#nameError").text("");
            return true;
        }
    }

    function validateMobile() {
        let mobile = $("#mobile").val().trim();
        if (mobile === "") {
            $("#mobileError").text("This field is required");
            return false;
        } else if (!/^[6-9]\d{9}$/.test(mobile)) {
            $("#mobileError").text("Mobile must start with 6,7,8,9 and be 10 digits");
            return false;
        } else {
            $("#mobileError").text("");
            return true;
        }
    }

    function validateEmail() {
        let email = $("#email").val().trim();
        // Regex: letters/numbers/symbols before @, letters only after @
        let regex = /^[^\s@]+@[A-Za-z.-]+\.[A-Za-z]{2,}$/;
        if (email === "") {
            $("#emailError").text("This field is required");
            return false;
        } else if (!regex.test(email)) {
            $("#emailError").text("Enter a valid email (no numbers after @)");
            return false;
        } else {
            $("#emailError").text("");
            return true;
        }
    }

    function validateAge() {
        let age = $("#age").val().trim();
        if (age === "") {
            $("#ageError").text("This field is required");
            return false;
        } else if (isNaN(age) || Number(age) < 18) {
            $("#ageError").text("Age must be 18 or older");
            return false;
        } else if (Number(age) > 100) {
            $("#age").val("100");
            $("#ageError").text("");
            return true;
        } else {
            $("#ageError").text("");
            return true;
        }
    }

    // ---------------------------
    // Input Restrictions
    // ---------------------------
    $("#name").on("input", function() {
        let val = $(this).val().replace(/[^A-Za-z ]/g, "");
        if (val.length > 15) val = val.substring(0,15);
        $(this).val(val);
        validateName();
    });

    $("#mobile").on("input", function() {
        let val = $(this).val().replace(/\D/g,'');
        if (val.length > 0 && !/^[6-9]/.test(val[0])) val = "";
        $(this).val(val.substring(0,10));
        validateMobile();
    });

    $("#age").on("input", function() {
        let val = $(this).val().replace(/\D/g,'');
        if (val !== "" && Number(val) > 100) val = "100";
        $(this).val(val);
        validateAge();
    });

    $("#email").on("input", function(){
        let val = $(this).val();
        let parts = val.split("@");
        if(parts.length > 1){
            // Remove numbers after @
            parts[1] = parts[1].replace(/\d/g,'');
            val = parts.join("@");
        }
        $(this).val(val);
        validateEmail();
    });

    // ---------------------------
    // Form Submit
    // ---------------------------
    $("#admissionForm").submit(function(e){
        e.preventDefault();

        let validName = validateName();
        let validMobile = validateMobile();
        let validEmail = validateEmail();
        let validAge = validateAge();

        if (!validName || !validMobile || !validEmail || !validAge) {
            $("#result").hide();
            return;
        }

        let name = $("#name").val().trim();
        let mobile = $("#mobile").val().trim();
        let email = $("#email").val().trim();
        let age = $("#age").val().trim();

        let output = 
`✅ Admission Form Submitted Successfully!
──────────────────────────
Name: ${name}
Mobile: ${mobile}
Email: ${email}
Age: ${age}
──────────────────────────`;

        $("#result").text(output).fadeIn();
    });

});
</script>

</body>
</html>
