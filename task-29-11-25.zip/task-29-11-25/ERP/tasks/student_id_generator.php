<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Unique Student ID Generator</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
body {
    background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
    font-family: "Inter", sans-serif;
    color: #2b2b2b;
    font-size: 18px;
}
.card {
    background: rgba(255,255,255,0.55);
    backdrop-filter: blur(14px);
    border: 2px solid rgba(0,0,0,0.08);
    border-radius: 20px;
    padding: 32px;
    max-width: 600px;
    margin: 0 auto;
    transition: .2s ease-in-out;
}
.card:hover {
    transform: translateY(-5px);
    background: rgba(255,255,255,0.7);
}
input {
    width: 100%;
    padding: 0.8rem 1rem;
    height: 3rem;
    border: 1px solid #ccc;
    border-radius: 8px;
}
input:focus {
    border-color: #7e22ce;
}
#error, .error {
    color: red;
    font-size: 15px;
}
.result-box {
    background: #D8F3DC;
    padding: 25px;
    border-radius: 12px;
    white-space: pre-line;
    font-family: monospace;
    border: 2px solid #95D5B2;
}
.error-star { color: red; }
</style>
</head>

<body>

<header class="py-10 text-center">
<h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
Task 10 - Unique Student ID Generator
</h1>
<p class="text-gray-700 text-xl mt-3">Generate sequential IDs for students</p>
<a href="../index.php" class="text-blue-800 underline mt-3 inline-block text-lg font-semibold">← Back to Dashboard</a>
</header>

<div class="card">
<form id="idForm" autocomplete="off">

<label class="font-semibold">Enter Number of Students <span class="error-star">*</span></label>
<input type="text" id="studentCount" placeholder="ex: 5">
<p class="error" id="countError"></p>

<div id="nameFields"></div>

<div class="text-center mt-6">
<button type="submit" id="submitBtn" class="px-8 py-4 rounded-xl bg-purple-600 text-white text-xl font-semibold hover:bg-purple-700 transition" disabled>
Generate IDs
</button>
</div>

</form>

<div id="result" class="result-box mt-5" style="display:none;"></div>
</div>

<script>
$(document).ready(function () {

    $("#idForm")[0].reset();
    $("#result").hide();
    $("#submitBtn").prop("disabled", true);

    function checkSubmitEnabled(){
        let valid = true;

        let count = $("#studentCount").val().trim();
        if(count === "" || isNaN(count) || Number(count) < 1 || Number(count) > 50){
            valid = false;
        }

        $(".studentName").each(function(){
            let val = $(this).val().trim();
            if(val === "" || !/^[A-Za-z ]+$/.test(val)){
                valid = false;
            }
        });

        $("#submitBtn").prop("disabled", !valid);
    }

    // Create name fields based on count (1-50 only)
    $("#studentCount").on("input", function () {
        let val = $(this).val().replace(/\D/g, "");

        if(Number(val) > 50) val = "50"; // restrict to 50 max

        $(this).val(val);
        $("#countError").text("");
        $("#nameFields").empty();

        if(val === "" || Number(val) < 1){
            $("#submitBtn").prop("disabled", true);
            return;
        }

        let count = Number(val);

        for(let i = 1; i <= count; i++){
            $("#nameFields").append(`
                <div class="mt-4">
                    <label>Student ${i} Name <span class="error-star">*</span></label>
                    <input type="text" class="studentName" placeholder="Enter student name">
                    <p class="error nameError"></p>
                </div>
            `);
        }

        checkSubmitEnabled();
    });

    $(document).on("input", ".studentName", function(){
        let text = $(this).val().replace(/[^A-Za-z ]/g, "");
        $(this).val(text);
        $(this).siblings(".nameError").text("");
        checkSubmitEnabled();
    });

    $("#idForm").submit(function(e){
        e.preventDefault();
        $("#result").hide();

        let allNames = [];

        $(".studentName").each(function(){
            allNames.push($(this).val().trim());
        });

        // Sort names alphabetically
        allNames.sort((a, b) => a.localeCompare(b));

        let prefix = "STD2025";
        let output = "🎓 Generated Student IDs 🎓\n────────────────────────────\n";

        for(let i = 0; i < allNames.length; i++){
            let idNumber = String(i + 1).padStart(3, "0");
            output += `${prefix}${idNumber} — ${allNames[i]}\n`;
        }

        output += "────────────────────────────";

        $("#result").text(output).fadeIn();
    });

});
</script>

</body>
</html>
