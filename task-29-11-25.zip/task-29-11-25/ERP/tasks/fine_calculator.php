<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Library Fine Calculator</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
body {
    background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
    font-family: "Inter", sans-serif;
    font-size: 18px;
    color: #2b2b2b;
}
.card {
    background: rgba(255,255,255,0.55);
    border-radius: 20px;
    padding: 40px;
    max-width: 650px;
    margin: 0 auto;
    border: 2px solid rgba(0,0,0,0.08);
    backdrop-filter: blur(14px);
}
.card:hover {
    background: rgba(255,255,255,0.7);
    transform: translateY(-5px);
}
input {
    width: 100%;
    padding-left:30px;
    border-radius: 10px;
    border: 1px solid #ccc;
    height: 3.3rem;
    font-size: 18px;
}#bookName,#returnDate,#dueDate{
    padding-left:30px;
}
label {
    margin-bottom: 6px;
    display: inline-block;
}
.error {
    color: red;
    font-size: 15px;
    margin-top: 6px;
}
.result-box {
    background: #D8F3DC;
    padding: 30px;
    border-radius: 14px;
    margin-top: 28px;
    border: 2px solid #95D5B2;
    font-family: monospace;
    white-space: pre-line;
    text-align: center;
}
.error-star { color: red; }
</style>
</head>

<body>

<header class="py-10 text-center">
    <h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 
        text-transparent bg-clip-text">
        Library Fine Calculator
    </h1>
    <p class="text-gray-700 mt-4 text-xl">Calculate the fine for late book return</p>
    <a href="../index.php" class="text-blue-800 underline mt-4 inline-block text-lg font-semibold">
        ← Back to Dashboard
    </a>
</header>

<div class="card mt-8">
<form id="fineForm" autocomplete="off">

    <!-- Book Name -->
    <div class="mt-2">
        <label class="font-semibold">Book Name <span class="error-star">*</span></label>
        <input type="text" id="bookName" placeholder="Enter book name">
        <p class="error" id="bookError"></p>
    </div>

    <!-- Due Date -->
    <div class="mt-6">
        <label class="font-semibold">Due Date (DD) <span class="error-star">*</span></label>
        <input type="text" id="dueDate" placeholder="Enter due date (1-31)">
        <p class="error" id="dueError"></p>
    </div>

    <!-- Return Date -->
    <div class="mt-6">
        <label class="font-semibold">Return Date (DD) <span class="error-star">*</span></label>
        <input type="text" id="returnDate" placeholder="Enter return date (1-31)">
        <p class="error" id="returnError"></p>
    </div>

    <div class="text-center mt-10">
        <button type="submit" class="px-10 py-4 rounded-xl bg-purple-600 text-white
            text-xl font-semibold hover:bg-purple-700 transition">
            Calculate Fine
        </button>
    </div>

</form>

<div id="result" class="result-box" style="display:none;"></div>
</div>

<script>
$(document).ready(function () {

    // Reset form & result on page load
    $("#fineForm")[0].reset();
    $("#result").hide();
    $(".error").text("");

    // ---------------------------
    // Validation Functions
    // ---------------------------
    function validateBook() {
        let name = $("#bookName").val().trim();
        if(name === "") {
            $("#bookError").text("This field is required");
            return false;
        } else if(!/^[A-Za-z0-9 ]+$/.test(name)) {
            $("#bookError").text("Only letters and numbers allowed");
            return false;
        } else if(name.length > 30) {
            $("#bookError").text("Max 30 characters allowed");
            return false;
        } else {
            $("#bookError").text("");
            return true;
        }
    }

    function validateDue() {
        let due = $("#dueDate").val().trim();
        if(due === "") {
            $("#dueError").text("This field is required");
            return false;
        } else if(isNaN(due) || due < 1 || due > 31) {
            $("#dueError").text("Enter a valid date between 1-31");
            return false;
        } else {
            $("#dueError").text("");
            return true;
        }
    }

    function validateReturn() {
        let ret = $("#returnDate").val().trim();
        if(ret === "") {
            $("#returnError").text("This field is required");
            return false;
        } else if(isNaN(ret) || ret < 1 || ret > 31) {
            $("#returnError").text("Enter a valid date between 1-31");
            return false;
        } else {
            $("#returnError").text("");
            return true;
        }
    }

    // ---------------------------
    // Input Restrictions
    // ---------------------------
    $("#bookName").on("input", function() {
        let val = $(this).val().replace(/[^A-Za-z0-9 ]/g, "");
        if(val.length > 30) val = val.substring(0,30);
        $(this).val(val);
        validateBook();
    });

    $("#dueDate, #returnDate").on("input", function(){
        $(this).val($(this).val().replace(/\D/g,''));
        if($(this).val() > 31) $(this).val("31");
        if($(this).attr("id") === "dueDate") validateDue();
        else validateReturn();
    });

    // ---------------------------
    // Fine Calculation Function
    // ---------------------------
    function calculateFine(due, ret) {
        let finePerDay = 2; // ₹2/day
        if(ret <= due) return 0;
        return (ret - due) * finePerDay;
    }

    // ---------------------------
    // Form Submit
    // ---------------------------
    $("#fineForm").submit(function(e){
        e.preventDefault();

        let validBook = validateBook();
        let validDue = validateDue();
        let validReturn = validateReturn();

        if(!validBook || !validDue || !validReturn) {
            $("#result").hide();
            return;
        }

        let book = $("#bookName").val().trim();
        let due = Number($("#dueDate").val());
        let ret = Number($("#returnDate").val());

        let fine = calculateFine(due, ret);

        let output =
`📚 Library Fine Calculation
──────────────────────────
Book: ${book}
Due Date: ${due}
Return Date: ${ret}
Fine: ₹${fine}
──────────────────────────`;

        $("#result").text(output).fadeIn();
    });

});
</script>

</body>
</html>
