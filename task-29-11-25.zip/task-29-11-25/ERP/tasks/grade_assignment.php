<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Task 2 - Grade Assignment</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        body {
            background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
            font-family: "Inter", sans-serif;
            color: #2b2b2b;
            font-size: 18px;
        }
        .card {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(14px);
            border: 2px solid rgba(0,0,0,0.08);
            border-radius: 20px;
            padding: 32px;
            transition: .25s ease-in-out;
        }
        .card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.70);
            border-color: rgba(0,0,0,0.20);
            box-shadow: 0 8px 22px rgba(0, 0, 0, 0.15);
        }
        .result-box {
            background: #D8F3DC;
            border: 2px solid #95D5B2;
            border-radius: 14px;
        }
        .error {
            color: #d90429;
            font-size: 16px;
            margin-top: 4px;
        }
        .required-star {
            color: red;
            font-weight: bold;
        }
        /* Hide number input arrows */
        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { 
            -webkit-appearance: none; 
            margin: 0; 
        }
        input[type=number] {
            -moz-appearance: textfield;
        }
    </style>
</head>
<body>

    <!-- HEADER -->
    <header class="py-10 text-center">
        <h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
            Task 2 — Grade Assignment
        </h1>
        <p class="text-gray-700 mt-3 text-xl">Enter marks for 5 subjects to calculate grade</p>

        <a href="../index.php" class="text-blue-800 underline mt-3 inline-block text-lg font-semibold">
            ← Back to Dashboard
        </a>
    </header>

    <!-- MAIN CONTAINER -->
    <div class="max-w-2xl mx-auto px-6 pb-20">
        <div class="card shadow-lg">

            <!-- FORM -->
            <form id="gradeForm" method="POST" autocomplete="off" novalidate>

                <!-- Student Name -->
                <label class="block mb-2 font-semibold text-gray-900 text-lg">
                    Student Name <span class="required-star">*</span>
                </label>
                <input type="text" id="student_name" name="student_name" 
                       placeholder="Enter student name" 
                       class="w-full px-5 py-3 rounded-lg border border-gray-500 shadow-sm outline-none focus:border-purple-600 mb-1" autofocus>
                <p id="nameError" class="error"></p>

                <!-- Marks for 5 subjects -->
                <h3 class="font-bold mb-4 text-gray-900 text-xl mt-6">Enter Marks for 5 Subjects <span class="required-star">*</span></h3>
                
                <?php
                for ($i = 1; $i <= 5; $i++) {
                    echo "
                    <div class='mb-4'>
                        <label class='font-semibold text-gray-900'>Subject $i <span class='required-star'>*</span>:</label>
                        <input type='number' name='subject$i' id='subject$i' min='1' max='100' 
                               class='w-full px-5 py-3 rounded-lg border border-gray-500 shadow-sm outline-none focus:border-purple-600 subject-input'>
                        <p id='subject{$i}Error' class='error'></p>
                    </div>";
                }
                ?>

                <button type="submit" 
                        class="mt-6 px-8 py-4 rounded-xl bg-purple-600 text-white text-xl font-semibold hover:bg-purple-700 transition">
                    Calculate Grade
                </button>
            </form>

            <!-- RESULT (Only after valid submit) -->
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $name = trim($_POST["student_name"]);
                $marks = [];
                for ($i = 1; $i <= 5; $i++) {
                    $marks[] = floatval($_POST["subject$i"]);
                }

                function calculateGrade($marksArray) {
                    $average = array_sum($marksArray) / count($marksArray);
                    if ($average > 90) return ['A', $average];
                    elseif ($average >= 80) return ['B', $average];
                    elseif ($average >= 70) return ['C', $average];
                    elseif ($average >= 60) return ['D', $average];
                    else return ['F', $average];
                }

                list($grade, $avg) = calculateGrade($marks);

                echo "
                <div class='result-box mt-8 p-6'>
                    <h3 class='text-xl font-bold text-green-900'>Result for <span class='text-purple-700'>$name</span>:</h3>
                    <p class='mt-3 text-green-800 text-lg'>
                        Average Marks: <span class='font-extrabold text-green-900 text-2xl'>{$avg}</span>
                    </p>
                    <p class='mt-2 text-green-800 text-lg'>
                        Grade: <span class='font-extrabold text-purple-700 text-2xl'>{$grade}</span>
                    </p>
                </div>";
            }
            ?>

        </div>
    </div>

<script>
$(document).ready(function() {

    // Force full page reset on refresh
    $("#gradeForm")[0].reset();

    // ------------------ Name Validation ------------------
    $("#student_name").on("input", function () {
        let value = $(this).val();
        value = value.replace(/[^A-Za-z ]/g,''); // letters & spaces only
        if (value.length > 15) value = value.substring(0,15);
        $(this).val(value);

        if (value.length > 0) $("#nameError").text('');
    });

    // ------------------ Marks Validation ------------------
    $(".subject-input").on("input", function () {
        let val = parseInt($(this).val());
        if (isNaN(val) || val < 1) val = 1;
        if (val > 100) val = 100;
        $(this).val(val);

        if (val >= 1 && val <= 100) $(this).next(".error").text('');
    });

    // ------------------ Form Submit ------------------
    $("#gradeForm").submit(function(e) {
        let isValid = true;
        $(".error").text("");

        // Name validation
        let name = $("#student_name").val().trim();
        if (name === "") {
            $("#nameError").text("Student name is required.");
            isValid = false;
        }

        // Marks validation
        for (let i=1; i<=5; i++) {
            let mark = $("#subject"+i).val();
            if (mark === "" || isNaN(mark) || mark < 1 || mark > 100) {
                $("#subject"+i+"Error").text("Enter valid marks (1-100)");
                isValid = false;
            }
        }

        if (!isValid) e.preventDefault();
    });

});
</script>
<script>
if (window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href);
}
</script>


</body>
</html>
