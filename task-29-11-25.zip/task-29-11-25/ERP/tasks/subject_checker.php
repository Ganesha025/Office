<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Task 4 - Subject Allotment Checker</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        body {
            background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
            font-family: "Inter", sans-serif;
            color: #2b2b2b;
            font-size: 18px;
        }
        .card {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(14px);
            border: 2px solid rgba(0,0,0,0.08);
            border-radius: 20px;
            padding: 32px;
            transition: .25s ease-in-out;
        }
        .card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.70);
            border-color: rgba(0,0,0,0.20);
            box-shadow: 0 8px 22px rgba(0, 0, 0, 0.15);
        }
        .result-box {
            background: #D8F3DC;
            border: 2px solid #95D5B2;
            border-radius: 14px;
        }
        .error {
            color: #d90429;
            font-size: 16px;
            margin-top: 4px;
        }
        .required-star {
            color: red;
            font-weight: bold;
        }
        select {
            width: 100%;
            padding: 0.75rem 1.25rem;
            border-radius: 0.5rem;
            border: 1px solid #ccc;
            outline: none;
        }
        select:focus {
            border-color: #7e22ce;
        }
    </style>
</head>
<body>

<header class="py-10 text-center">
    <h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
        Task 4 — Subject Allotment Checker
    </h1>
    <p class="text-gray-700 mt-3 text-xl">Select 3 elective subjects</p>
    <a href="../index.php" class="text-blue-800 underline mt-3 inline-block text-lg font-semibold">
        ← Back to Dashboard
    </a>
</header>

<div class="max-w-2xl mx-auto px-6 pb-20">
    <div class="card shadow-lg">
        <form id="subjectForm" autocomplete="off" novalidate>

            <label class="block mb-2 font-semibold text-gray-900 text-lg">
                Student Name <span class="required-star">*</span>
            </label>
            <input type="text" id="student_name" name="student_name" 
                   placeholder="Enter student name" 
                   class="w-full px-5 py-3 rounded-lg border border-gray-500 shadow-sm outline-none focus:border-purple-600 mb-1" autofocus>
            <p id="nameError" class="error"></p>

            <h3 class="font-bold mb-4 text-gray-900 text-xl mt-6">Select 3 Elective Subjects <span class="required-star">*</span></h3>

            <div class="mb-4">
                <label class="font-semibold text-gray-900">Subject 1:</label>
                <select id="subject1" class="w-full px-5 py-3 rounded-lg border border-gray-500 shadow-sm outline-none focus:border-purple-600 mb-1">
                    <option value="">-- Select Subject --</option>
                </select>
                <p id="subject1Error" class="error"></p>
            </div>

            <div class="mb-4">
                <label class="font-semibold text-gray-900">Subject 2:</label>
                <select id="subject2" class="w-full px-5 py-3 rounded-lg border border-gray-500 shadow-sm outline-none focus:border-purple-600 mb-1">
                    <option value="">-- Select Subject --</option>
                </select>
                <p id="subject2Error" class="error"></p>
            </div>

            <div class="mb-4">
                <label class="font-semibold text-gray-900">Subject 3:</label>
                <select id="subject3" class="w-full px-5 py-3 rounded-lg border border-gray-500 shadow-sm outline-none focus:border-purple-600 mb-1">
                    <option value="">-- Select Subject --</option>
                </select>
                <p id="subject3Error" class="error"></p>
            </div>

            <div class="text-center mt-6">
            <button type="submit" 
                    class="px-8 py-4 rounded-xl bg-purple-600 text-white text-xl font-semibold hover:bg-purple-700 transition">
                Check Allotment
            </button>
            </div>
        </form>

        <div id="result" class="result-box mt-8 p-6" style="display:none;">
            <h3 class="text-xl font-bold text-green-900">Selected Subjects:</h3>
            <ul class="mt-3 text-green-800 text-lg" id="subjectList"></ul>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Reset page and hide result
    $("#subjectForm")[0].reset();
    $("#result").hide();

    const subjects = ["Mathematics", "Physics", "Chemistry", "Biology", "Computer Science", "Economics", "History"];
    for (let subj of subjects) {
        $("#subject1, #subject2, #subject3").append(`<option value="${subj}">${subj}</option>`);
    }

    // Name validation
    $("#student_name").on("input", function() {
        let value = $(this).val().replace(/[^A-Za-z ]/g,'');
        if (value.length > 15) value = value.substring(0,15);
        $(this).val(value);
        $("#nameError").text('');
    });

    // Real-time dropdown validation
    $("#subject1, #subject2, #subject3").on("change", function() {
        let selected = [
            $("#subject1").val(),
            $("#subject2").val(),
            $("#subject3").val()
        ];

        // Check duplicates
        selected.forEach((val, idx) => {
            if (!val) {
                $(`#subject${idx+1}Error`).text("This field is required");
            } else if (selected.filter(v => v === val).length > 1) {
                $(`#subject${idx+1}Error`).text("Duplicate subject is selected");
            } else {
                $(`#subject${idx+1}Error`).text('');
            }
        });
    });

    // Form submission
    $("#subjectForm").submit(function(e) {
        e.preventDefault();
        let isValid = true;
        $(".error").text("");
        $("#result").hide();

        let name = $("#student_name").val().trim();
        if (name === "") {
            $("#nameError").text("Student name is required.");
            isValid = false;
        }

        let selected = [
            $("#subject1").val(),
            $("#subject2").val(),
            $("#subject3").val()
        ];

        selected.forEach((val, idx) => {
            if (!val) {
                $(`#subject${idx+1}Error`).text("This field is required");
                isValid = false;
            }
        });

        // Check duplicates
        let unique = [...new Set(selected)];
        if (unique.length < selected.length) {
            selected.forEach((val, idx) => {
                if (selected.indexOf(val) !== selected.lastIndexOf(val)) {
                    $(`#subject${idx+1}Error`).text("Duplicate subject is selected");
                }
            });
            isValid = false;
        }

        if (isValid) {
            $("#subjectList").html(selected.map(s => `<li>${s}</li>`).join(''));
            $("#result").show();
        }
    });
});
</script>

</body>
</html>
