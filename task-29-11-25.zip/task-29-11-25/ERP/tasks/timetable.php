<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Task 5 - Weekly Class Timetable</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #F7EDE2, #F5CAC3, #B8E0D2);
            font-family: "Inter", sans-serif;
            color: #2b2b2b;
            font-size: 18px;
        }
        .card {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(14px);
            border: 2px solid rgba(0,0,0,0.08);
            border-radius: 20px;
            padding: 32px;
            transition: .25s ease-in-out;
        }
        .card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.70);
            border-color: rgba(0,0,0,0.20);
            box-shadow: 0 8px 22px rgba(0, 0, 0, 0.15);
        }
        .result-box {
            background: #D8F3DC;
            border: 2px solid #95D5B2;
            border-radius: 14px;
            overflow-x:auto;
        }
        .error {
            color: #d90429;
            font-size: 16px;
            margin-top: 4px;
        }
        .required-star {
            color: red;
            font-weight: bold;
            margin-left: 3px;
        }
        input, select {
            width: 100%;
            padding: 1rem 1.5rem;
            font-size: 1.1rem;
            border-radius: 0.5rem;
            border: 1px solid #ccc;
            outline: none;
            height: 3.5rem; /* match class name input height */
            box-sizing: border-box;
        }
        input:focus, select:focus {
            border-color: #7e22ce;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 2px solid #95D5B2;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #95D5B2;
            color: #1b4332;
        }
    </style>
</head>
<body>

<header class="py-10 text-center">
    <h1 class="text-4xl font-extrabold bg-gradient-to-r from-rose-600 via-purple-600 to-teal-600 text-transparent bg-clip-text">
        Task 5 — Weekly Class Timetable
    </h1>
    <p class="text-gray-700 mt-3 text-xl">Select 5 subjects for each day</p>
    <a href="../index.php" class="text-blue-800 underline mt-3 inline-block text-lg font-semibold">
        ← Back to Dashboard
    </a>
</header>

<div class="max-w-6xl mx-auto px-6 pb-20">
    <div class="card shadow-lg">
        <form id="timetableForm" autocomplete="off" novalidate>

            <!-- Class Name -->
            <label class="block mb-2 font-semibold text-gray-900 text-lg">
                Class Name <span class="required-star">*</span>
            </label>
            <input type="text" id="class_name" placeholder="Enter class name (letters & numbers only)" autofocus>
            <p id="classError" class="error"></p>

            <!-- Timetable Inputs -->
            <h3 class="font-bold mb-4 text-gray-900 text-xl mt-6">Select 5 Subjects for Each Day</h3>
            <div id="daysContainer" class="space-y-6">
                <!-- Days and dropdowns will be generated here -->
            </div>

            <div class="text-center mt-6">
                <button type="submit" 
                        class="px-8 py-4 rounded-xl bg-purple-600 text-white text-xl font-semibold hover:bg-purple-700 transition">
                    Generate Timetable
                </button>
            </div>
        </form>

        <div id="result" class="result-box mt-8 p-6" style="display:none;">
            <h3 class="text-xl font-bold text-green-900 mb-4">Weekly Timetable for Class <span id="classDisplay"></span></h3>
            <table>
                <thead>
                    <tr>
                        <th>Day</th>
                        <th>Subject 1</th>
                        <th>Subject 2</th>
                        <th>Subject 3</th>
                        <th>Subject 4</th>
                        <th>Subject 5</th>
                    </tr>
                </thead>
                <tbody id="timetableBody">
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
    const subjectsPerDay = 5;
    const subjectsList = ["Mathematics", "Physics", "Chemistry", "Biology", "Computer Science", "Economics", "History", "English", "Geography"];

    // Generate dropdowns with red star next to days
    days.forEach(day=>{
        let row = `<div>
                    <label class="font-semibold">${day}<span class="required-star">*</span></label>
                    <div class="grid grid-cols-1 md:grid-cols-5 gap-3 mt-1">`;
        for(let i=1;i<=subjectsPerDay;i++){
            row += `<div>
                        <select id="${day.toLowerCase()}_sub${i}">
                            <option value="">-- Select Subject --</option>`;
            subjectsList.forEach(sub=>{
                row += `<option value="${sub}">${sub}</option>`;
            });
            row += `</select>
                    <p id="${day.toLowerCase()}_sub${i}Error" class="error"></p>
                    </div>`;
        }
        row += `</div></div>`;
        $("#daysContainer").append(row);
    });

    // Reset form and hide result
    $("#timetableForm")[0].reset();
    $("#result").hide();
    $(".error").text("");

    // Class name validation: letters, numbers, spaces only
    $("#class_name").on("input", function(){
        let val = $(this).val().replace(/[^A-Za-z0-9 ]/g,'');
        if(val.length > 15) val = val.substring(0,15);
        $(this).val(val);
        $("#classError").text('');
    });

    // Real-time dropdown validation
    $("select").on("change", function(){
        if($(this).val() !== "") $(this).next(".error").text('');
    });

    // Form submission
    $("#timetableForm").submit(function(e){
        e.preventDefault();
        let isValid = true;
        $(".error").text('');
        $("#result").hide();

        let className = $("#class_name").val().trim();
        if(className === ""){
            $("#classError").text("Class name is required.");
            isValid = false;
        }

        const timetable = {};
        days.forEach(day=>{
            timetable[day] = [];
            for(let i=1;i<=subjectsPerDay;i++){
                let val = $(`#${day.toLowerCase()}_sub${i}`).val();
                if(val === ""){
                    $(`#${day.toLowerCase()}_sub${i}Error`).text("This field is required");
                    isValid = false;
                }
                timetable[day].push(val);
            }
        });

        if(isValid){
            $("#classDisplay").text(className);
            let html = "";
            days.forEach(day=>{
                html += `<tr><td>${day}</td>`;
                timetable[day].forEach(sub=> html += `<td>${sub}</td>`);
                html += `</tr>`;
            });
            $("#timetableBody").html(html);
            $("#result").show();
        }
    });
});
</script>

</body>
</html>
