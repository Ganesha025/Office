<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>College ERP - Task Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        body {
            background: linear-gradient(135deg, #A6E3E9, #C8F3DC, #D7C4F3);
            font-family: "Inter", sans-serif;
            color: #2b2b2b;
        }

        .task-card {
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.01); /* SUPER subtle for glass feel, not white */
            border: 1px solid rgba(0, 0, 0, 0.10);
            transition: 0.3s ease-in-out;
            min-height: 150px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            border-radius: 14px;

            /* Soft pastel gradient pattern */
            background: linear-gradient(
                135deg,
                rgba(183, 224, 255, 0.35),
                rgba(255, 214, 165, 0.35)
            );
        }

        .task-card:hover {
            transform: translateY(-6px) scale(1.03);
            background: linear-gradient(
                135deg,
                rgba(255, 214, 165, 0.55),
                rgba(166, 227, 233, 0.55)
            );
            border-color: rgba(0, 0, 0, 0.18);
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
        }
    </style>
</head>

<body>

    <!-- HEADER -->
    <header class="py-10 text-center">
        <h1 class="text-4xl font-bold tracking-wide bg-gradient-to-r from-teal-700 via-purple-700 to-pink-700 text-transparent bg-clip-text">
            📘 College ERP — PHP Tasks Dashboard
        </h1>
        <p class="text-gray-700 mt-2 text-lg">Click any task to explore</p>
    </header>

    <!-- TASK GRID -->
    <div class="max-w-7xl mx-auto px-6 pb-16">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-7">

            <?php 
                $tasks = [
                    "1. Student Attendance Percentage" => "attendance.php",
                    "2. Grade Assignment Based on Marks" => "grade_assignment.php",
                    "3. Generate College Email ID" => "generate_email.php",
                    "4. Subject Allotment Checker" => "subject_checker.php",
                    "5. Class Timetable Formatter" => "timetable.php",
                    "6. Staff Salary Slip Generator" => "salary_slip.php",
                    "7. Student Feedback Word Count" => "feedback_wordcount.php",
                    "8. Holiday Calendar Highlighter" => "holiday_checker.php",
                    "9. Rank Students Based on Scores" => "rank_students.php",
                    "10. Unique Student ID Generator" => "student_id_generator.php",
                    "11. Auto-Fill Internal Marks" => "autofill_marks.php",
                    "12. Validate Admission Form" => "form_validation.php",
                    "13. Library Book Due Fine Calculator" => "fine_calculator.php",
                    "14. Faculty Teaching Hours Checker" => "teaching_hours.php",
                    "15. SMS Template Formatter" => "sms_formatter.php"
                ];

                foreach ($tasks as $title => $file) {
                    echo "
                    <a href='tasks/$file' target='_blank'>
                        <div class='task-card p-6 cursor-pointer shadow-md'>
                            <h2 class='text-xl font-semibold mb-2 text-teal-800'>$title</h2>
                            <p class='text-gray-700 text-sm'>Click to open</p>
                        </div>
                    </a>";
                }
            ?>
        </div>
    </div>

    <!-- FOOTER -->
    <footer class="text-center text-gray-800 py-6 text-sm">
        © " . date('Y') . " College ERP | Soft Pastel Dashboard
    </footer>

</body>
</html>
