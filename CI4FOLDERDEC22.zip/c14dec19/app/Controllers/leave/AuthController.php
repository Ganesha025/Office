<?php
namespace App\Controllers\leave;
use CodeIgniter\Controller;
use App\Models\leave\Usermodel;
use App\Models\leave\DatasModel;
use App\Models\leave\FacultyModel;
class AuthController extends Controller
{
    public function login(){
        return view('leave/login');
    }

    public function loginPost(){
        $userModel = model(Usermodel::class);
        $username=$this->request->getPost('username');

        $password=$this->request->getPost('password');
     $user = $userModel->where('email', $username)->first();

if(empty($user)){
    return $this->response->redirect('');
}

if($password == $user['password']){  
    
        $session=session();
        $session->set([
            'username'=>$username,
            'id'=>(int)$user['id'],
            'role'=>$user['role'],
            'dept_name'=>$user['dept_name']
        ]);
        $role=$session->get('role');
        if($role=='hod'){
            $datamodel=model(DatasModel::class);
            $facultymodel=model(FacultyModel::class);
            $userid=$user['id'];
            $depb=$userModel->where('dept_name',$userid)->find(); 
            $id= $userModel->where('role','staff')->where('dept_name',$depb)->first();
            $data_id= $datamodel->where('id', $id)->first();
            $fetcheddata=$facultymodel->where('id',$data_id)->find();
            $data["Fetched_Datas_Hod"]= $fetcheddata;
            return view("leaves/index",$data);
        }
}
else{
            return $this->response->redirect("dff");
        }

    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
