<?php

namespace App\Models\leave;

use CodeIgniter\Model;

class DatasModel extends Model
{
    protected $table = 'datas';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'from_id',
        'to_id'
    ];

   
    protected $useTimestamps = true;
}
