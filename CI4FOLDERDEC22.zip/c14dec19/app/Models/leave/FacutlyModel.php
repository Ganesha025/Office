<?php
namespace App\Models\leave;

use CodeIgniter\Model;

class FacultyModel extends Model
{
    protected $table = 'faculty';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'facul_name', 'dept_name', 'type', 'from_date', 'to_date', 'status', 'data_id'
    ];
}
