<?php
namespace App\Models\ticket;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'userss';  // Table name
    protected $primaryKey = 'id';

    protected $allowedFields = ['username', 'password', 'role'];

    protected $useTimestamps = true; // Automatically manage created_at, updated_at

    protected $validationRules = [
        'username' => 'required|min_length[3]|max_length[50]',
        'password' => 'required|min_length[6]',
        'role'     => 'required|in_list[admin,staff]'
    ];

    protected $validationMessages = [
        'username' => [
            'required' => 'Username is required',
            'min_length' => 'Username must be at least 3 characters'
        ],
        'password' => [
            'required' => 'Password is required',
            'min_length' => 'Password must be at least 6 characters'
        ],
        'role' => [
            'required' => 'Role is required',
            'in_list' => 'Role must be admin or staff'
        ]
    ];
}
