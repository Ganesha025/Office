<?php
namespace App\Models\ticket;
use CodeIgniter\Model;

class TicketModel extends Model
{
    protected $table = 'tickets';
    protected $primaryKey = 'id';
    protected $allowedFields = ['raised_by','issue_type','description','status'];

    protected $validationRules = [
        'raised_by'   => 'required|min_length[3]',
        'issue_type'  => 'required',
        'description' => 'required|min_length[10]'
    ];
}
