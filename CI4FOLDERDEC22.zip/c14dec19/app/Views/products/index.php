<?php helper('form'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
        }

        /* HEADER */
        .header {
            background: #007bff;
            color: #fff;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 22px;
        }

        .profile {
            position: relative;
        }

        .profile button {
            background: none;
            border: none;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        .profile-content {
            display: none;
            position: absolute;
            right: 0;
            background: #fff;
            min-width: 150px;
            box-shadow: 0 2px 8px rgba(0,0,0,.2);
        }

        .profile-content a {
            display: block;
            padding: 10px;
            color: #333;
            text-decoration: none;
        }

        .profile-content a:hover {
            background: #f1f1f1;
        }

        .profile:hover .profile-content {
            display: block;
        }

        /* CONTENT */
        .container {
            padding: 20px;
        }

        .btn {
            padding: 6px 12px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            color: #fff;
        }

        .btn-add { background: #28a745; }
        .btn-edit { background: #007bff; }
        .btn-history { background: #6c757d; }
        .btn-delete { background: #dc3545; }
        .btn-cart { background: #17a2b8; }

        .btn:hover { opacity: 0.85; }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>Product Inventory</h1>

    <div class="profile">
        <button>
            <i class="fas fa-user-circle"></i>
            <?= session()->get('role') ?>
        </button>
        <div class="profile-content">
            <?php if(session()->get('role') === 'Viewer'): ?>
                <a href="/cart">View Cart</a>
            <?php endif; ?>
            <a href="/logout">Logout</a>
        </div>
    </div>
</div>

<div class="container">

    <!-- Flash messages -->
    <?php if(session()->getFlashdata('success')): ?>
        <div style="color:green;margin-bottom:10px;">
            <?= session()->getFlashdata('success') ?>
        </div>
    <?php endif; ?>

    <?php if(session()->getFlashdata('error')): ?>
        <div style="color:red;margin-bottom:10px;">
            <?= session()->getFlashdata('error') ?>
        </div>
    <?php endif; ?>

    <!-- Add Product -->
    <?php if($role != 'Viewer'): ?>
        <a href="/products/create" class="btn btn-add">➕ Add Product</a>
        <br><br>
    <?php endif; ?>

    <!-- PRODUCT TABLE -->
    <table id="productTable" class="display">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>SKU</th>
                <th>Price</th>
                <th>Stock</th>

                <?php if($role != 'Viewer'): ?>
                    <th>Actions</th>
                <?php else: ?>
                    <th>Cart</th>
                <?php endif; ?>
            </tr>
        </thead>

        <tbody>
            <?php foreach($products as $prod): ?>
            <tr>
                <td><?= $prod['id'] ?></td>
                <td><?= $prod['product_name'] ?></td>
                <td><?= $prod['sku'] ?></td>
                <td><?= $prod['price'] ?></td>
                <td><?= $prod['stock'] ?></td>

                <?php if($role != 'Viewer'): ?>
                    <td>
                        <a href="/products/edit/<?= $prod['id'] ?>" class="btn btn-edit">Edit</a>
                        <a href="/products/history/<?= $prod['id'] ?>" class="btn btn-history">History</a>

                        <?php if($role == 'Admin'): ?>
                            <a href="/products/delete/<?= $prod['id'] ?>"
                               class="btn btn-delete"
                               onclick="return confirm('Are you sure?')">Delete</a>
                        <?php endif; ?>
                    </td>
                <?php else: ?>
                    <td>
                        <form action="/products/addtocart/<?= $prod['id'] ?>" method="post">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-cart">Add to Cart</button>
                        </form>
                    </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</div>

<!-- JS -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
$(document).ready(function () {
    $('#productTable').DataTable();
});
</script>

</body>
</html>
