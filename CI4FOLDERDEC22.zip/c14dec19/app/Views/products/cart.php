<?php helper('form'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <!-- Font Awesome for profile icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
        }

        /* Header styles */
        .header {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .profile-dropdown {
            position: relative;
            display: inline-block;
        }

        .profile-dropdown button {
            background: none;
            border: none;
            color: #fff;
            cursor: pointer;
            font-size: 18px;
        }

        .profile-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: #fff;
            min-width: 150px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .profile-dropdown-content a {
            color: #333;
            padding: 10px 15px;
            text-decoration: none;
            display: block;
        }

        .profile-dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .profile-dropdown:hover .profile-dropdown-content {
            display: block;
        }

        /* Table styling */
        .container {
            padding: 20px;
        }
        table {
            width: 100%;
            background: #fff;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: #fff;
        }
    </style>
</head>
<body>

<!-- Header -->
<div class="header">
    <h1>Your Cart</h1>
    <div class="profile-dropdown">
        <button><i class="fas fa-user-circle"></i> <?= session()->get('role') ?></button>
        <div class="profile-dropdown-content">
            <a href="/logout">Logout</a>
        </div>
    </div>
</div>

<div class="container">
    <!-- Flash messages -->
    <?php if(session()->getFlashdata('success')): ?>
        <div style="color:green; margin-bottom: 10px;"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <?php if(session()->getFlashdata('error')): ?>
        <div style="color:red; margin-bottom: 10px;"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <?php if(!empty($products)): ?>
        <table id="cartTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>SKU</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($products as $prod): ?>
                    <tr>
                        <td><?= $prod['id'] ?></td>
                        <td><?= $prod['product_name'] ?></td>
                        <td><?= $prod['sku'] ?></td>
                        <td><?= $prod['price'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Your cart is empty</p>
    <?php endif; ?>

    <br>
    <a href="/products">Back to Products</a>
</div>

<!-- jQuery and DataTables JS -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#cartTable').DataTable({
            paging: true,
            searching: true,
            ordering: true
        });
    });
</script>

</body>
</html>
