<h2>Create Ticket</h2>
<form method="post" action="/tickets/store">
    Issue Type: <input type="text" name="issue_type" required><br>
    Description: <textarea name="description" required></textarea><br>
    <button type="submit">Submit</button>
</form>
