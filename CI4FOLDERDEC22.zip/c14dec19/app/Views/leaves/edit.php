<!DOCTYPE html>
<html>
<head>
    <title>Edit Leave</title>
</head>
<body>

<h2>Edit Leave (Pending Only)</h2>

<form method="post" action="<?= base_url('leaves/update/'.$leave['id']) ?>">
    <?= csrf_field() ?>

    <label>Leave Type</label><br>
    <select name="leave_type" required>
        <option value="Casual" <?= $leave['leave_type']=='Casual'?'selected':'' ?>>Casual</option>
        <option value="Sick" <?= $leave['leave_type']=='Sick'?'selected':'' ?>>Sick</option>
        <option value="On Duty" <?= $leave['leave_type']=='On Duty'?'selected':'' ?>>On Duty</option>
    </select><br><br>

    <label>From Date</label><br>
    <input type="date" name="from_date" value="<?= $leave['from_date'] ?>" required><br><br>

    <label>To Date</label><br>
    <input type="date" name="to_date" value="<?= $leave['to_date'] ?>" required><br><br>

    <button type="submit">Update</button>
</form>

<a href="<?= base_url('leaves') ?>">Back</a>

</body>
</html>
