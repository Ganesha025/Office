<!DOCTYPE html>
<html>
<head>
    <title>Faculty Login</title>
    <style>
        
           body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
        }

        .login-box {
            width: 350px;
            margin: 80px auto;
            padding: 25px;
            background: #fff;
            border-radius: 6px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        /* Password field with eye icon */
        .password-box {
            position: relative;
        }

        .password-box input {
            padding-right: 40px;
        }

        .password-box i {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #666;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 15px;
        }

        button:hover {
            background: #0056b3;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<h2>Faculty / HOD Login</h2>
<div class="login-box">
<form method="post" action="<?= base_url('loginintoleave') ?>">
    <?= csrf_field() ?>
     
    <label>Username</label><br>
    <input type="text" name="username" required><br><br>
    <div class="password-box">
    <label>Password</label><br>
    <input type="password" name="password" id="passsword"  required><br><br>
</div>
    <button type="submit">Login</button>
</form>
</div>
</body>
</html>
