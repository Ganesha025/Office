<?php

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"] ?? "";
    $password = $_POST["password"] ?? "";

    // Demo login check (replace with DB login)
    if ($email === "admin@example.com" && $password === "123456") {
        $_SESSION["user"] = $email;
        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Invalid email or password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mind Blowing Login</title>
<script src="https://cdn.tailwindcss.com"></script>

<style>
    body {
        background: radial-gradient(circle at 20% 20%, #0f0f25, #000000);
    }

    .glow {
        animation: glow 6s infinite alternate ease-in-out;
    }

    @keyframes glow {
        0% { filter: drop-shadow(0 0 10px #4f46e5); }
        100% { filter: drop-shadow(0 0 25px #7c3aed); }
    }

    .floating {
        animation: float 4s infinite ease-in-out;
    }

    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-12px); }
        100% { transform: translateY(0px); }
    }
</style>

</head>
<body class="min-h-screen flex items-center justify-center p-6">

<!-- Background 3D Blobs -->
<div class="absolute top-10 left-10 w-72 h-72 bg-purple-700/30 rounded-full blur-3xl floating"></div>
<div class="absolute bottom-10 right-10 w-72 h-72 bg-indigo-600/30 rounded-full blur-3xl floating" style="animation-delay:1s;"></div>

<!-- LOGIN CARD -->
<div class="w-full max-w-md p-8 bg-white/10 backdrop-blur-xl rounded-2xl shadow-xl border border-white/20 glow">
    <h1 class="text-4xl font-bold text-white mb-6 text-center tracking-wider">Welcome Back</h1>

    <?php if ($error): ?>
        <div class="mb-4 text-red-400 text-center text-sm font-semibold">
            <?= $error ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="space-y-6">

        <div>
            <label class="text-gray-200 font-medium">Email</label>
            <input 
                type="email" 
                name="email" 
                class="w-full p-3 rounded-xl bg-white/20 text-white placeholder-gray-300 border border-white/30 focus:ring-2 focus:ring-purple-400 outline-none"
                placeholder="Enter your email"
                required
            >
        </div>

        <div>
            <label class="text-gray-200 font-medium">Password</label>
            <input 
                type="password" 
                name="password" 
                class="w-full p-3 rounded-xl bg-white/20 text-white placeholder-gray-300 border border-white/30 focus:ring-2 focus:ring-purple-400 outline-none"
                placeholder="Enter your password"
                required
            >
        </div>

        <button 
            type="submit" 
            class="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold rounded-xl transition-all transform hover:scale-105 active:scale-95 shadow-lg">
            Login
        </button>

    </form>

    <p class="text-center text-gray-300 mt-6">
        Don't have an account?
        <a href="#" class="text-purple-400 hover:underline">Register</a>
    </p>
</div>

</body>
</html>
