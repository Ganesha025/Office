<?php
$conn = new mysqli("localhost", "root", "", "companydb");

$total = $conn->query("SELECT COUNT(*) AS total_employees FROM employees")->fetch_assoc();
$max = $conn->query("SELECT MAX(hire_date) AS latest_hire_date FROM employees")->fetch_assoc();
$all = $conn->query("SELECT * FROM employees");
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Employees Info</title></head>
<body>

<h2>Total Employees</h2>
<table border="1">
<tr><th>Total Employees</th></tr>
<tr><td><?php echo $total['total_employees']; ?></td></tr>
</table>

<h2>Latest Hire Date</h2>
<table border="1">
<tr><th>Latest Hire Date</th></tr>
<tr><td><?php echo $max['latest_hire_date']; ?></td></tr>
</table>

<h2>All Employees</h2>
<table border="1">
<tr>
    <th>ID</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Email</th>
    <th>Hire Date</th>
</tr>
<?php while($row = $all->fetch_assoc()) { ?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['first_name']; ?></td>
<td><?php echo $row['last_name']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><?php echo $row['hire_date']; ?></td>
</tr>
<?php } ?>
</table>
</body>
</html>
<?php $conn->close(); ?>