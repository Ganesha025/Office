<?php
session_start();
include "db.php";

$error = "";

if(isset($_POST['verify'])){
    $username = trim($_POST['username']);
    $role     = $_POST['role'];

    if(empty($username) || empty($role)){
        $error = "Please fill all fields";
    } else {
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE username=? AND role=?");
        $stmt->bind_param("ss", $username, $role);
        $stmt->execute();
        $result = $stmt->get_result();

        if($result->num_rows === 1){
            $row = $result->fetch_assoc();
            $_SESSION['reset_user_id'] = $row['user_id'];
            header("Location: reset_password.php");
            exit;
        } else {
            $error = "User not found";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Forgot Password</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background: linear-gradient(135deg,#ff9a9e,#fad0c4,#fad0c4);
    font-family: 'Segoe UI', sans-serif;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
.card {
    width: 100%;
    max-width: 420px;
    padding: 30px;
    border-radius: 15px;
    background: rgba(255,255,255,0.9);
    backdrop-filter: blur(10px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.2);
    text-align: center;
}
h4 { color: #ff6f3c; font-weight: bold; margin-bottom: 20px; }
.btn-primary { background: linear-gradient(135deg,#ff6f3c,#ff8c5a); border:none; }
.btn-primary:hover { transform: scale(1.02); box-shadow: 0 8px 20px rgba(255,111,60,0.4); }
</style>
</head>
<body>

<div class="card">
    <h4>Forgot Password</h4>

    <?php if($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <select name="role" class="form-select" required>
                <option value="">Select Role</option>
                <option value="admin">Admin</option>
                <option value="pantry_manager">Pantry Manager</option>
                <option value="employee">Employee</option>
            </select>
        </div>

        <div class="mb-3">
            <input type="text" name="username" class="form-control"
                   placeholder="Username" required>
        </div>

        <button class="btn btn-primary w-100" name="verify">
            Verify
        </button>
    </form>
</div>

</body>
</html>
