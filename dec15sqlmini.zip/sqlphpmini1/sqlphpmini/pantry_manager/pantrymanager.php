<?php
session_start();
include __DIR__ . "/../db.php";

// Only pantry manager can access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'pantry_manager'){
    header("Location: ../index.php");
    exit;
}

// Fetch stats
$total = $conn->query("SELECT SUM(total_amount) as total FROM purchases")->fetch_assoc()['total'];
$product_count = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'];
$employee_count = $conn->query("SELECT COUNT(*) as count FROM users WHERE role='employee'")->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Pantry Manager Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
body, html {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f0f4f8;
    min-height: 100vh;
}

/* HEADER */
.header {
    background: linear-gradient(90deg, #ff7e5f, #feb47b);
    color: white;
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 10px rgba(0,0,0,0.1);
}
.header h2 { margin: 0; display: flex; align-items: center; gap: 10px; }

/* PROFILE DROPDOWN */
.profile-dropdown {
    position: relative;
}
.profile-dropdown img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: 2px solid white;
    cursor: pointer;
}
.profile-dropdown .dropdown-menu {
    position: absolute;
    top: 50px;
    right: 0;
    background: white;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.15);
    min-width: 150px;
    display: none;
    z-index: 1000;
}
.profile-dropdown .dropdown-menu a {
    display: block;
    padding: 10px 15px;
    color: #333;
    text-decoration: none;
    font-weight: 500;
}
.profile-dropdown .dropdown-menu a:hover {
    background: #ff7e5f;
    color: white;
}

/* LAYOUT */
.container-dashboard {
    display: flex;
    min-height: calc(100vh - 70px);
}

/* SIDEBAR */
.sidebar {
    width: 220px;
    background: #fff;
    box-shadow: 2px 0 5px rgba(0,0,0,0.1);
    padding: 20px;
    display: flex;
    flex-direction: column;
    gap: 15px;
    border-right: 1px solid #ddd;
}
.sidebar a {
    display: flex;
    align-items: center;
    padding: 12px;
    border-radius: 8px;
    text-decoration: none;
    color: #333;
    font-weight: 500;
    transition: 0.3s;
}
.sidebar a i { margin-right: 10px; }
.sidebar a:hover { background: #ff7e5f; color: white; }

/* MAIN CONTENT */
.main-content {
    flex: 1;
    padding: 20px 30px;
    background: #f9f9f9;
}

/* STATS CARDS */
.stats-cards {
    display: flex;
    gap: 20px;
    margin-bottom: 30px;
}
.card {
    flex: 1;
    border-radius: 12px;
    padding: 20px;
    color: white;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
}
.card-total { background: linear-gradient(135deg, #ff7e5f, #feb47b); }
.card-products { background: linear-gradient(135deg, #6a11cb, #2575fc); }
.card-employees { background: linear-gradient(135deg, #43cea2, #185a9d); }

/* MAIN AREA BOXES */
.section-box {
    background: #fff;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}

/* FOOTER */
.footer {
    background: #333;
    color: #fff;
    text-align: center;
    padding: 15px;
}

/* RESPONSIVE */
@media(max-width:576px){
    .header { flex-direction: column; gap: 10px; }
    .stats-cards { flex-direction: column; }
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h2><i class="fa-solid fa-chart-simple"></i> Pantry Manager</h2>

    <!-- PROFILE DROPDOWN -->
    <div class="profile-dropdown">
        <img src="../uploads/admin.jpg" alt="Profile" id="profileBtn">
        <div class="dropdown-menu" id="profileMenu" text=profile>
            
            <a href="../logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i> Logout</a>
        </div>
    </div>
</div>

<div class="container-dashboard">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <a href="add_product.php"><i class="fa-solid fa-box-plus"></i> Add Product</a>
        <a href="products.php"><i class="fa-solid fa-box"></i> Manage Product</a>
        <a href="purchases.php"><i class="fa-solid fa-cart-shopping"></i> View Purchases</a>
        <a href="reports.php"><i class="fa-solid fa-file-chart-column"></i> Reports</a>
        <a href="dept_dashboard.php"><i class="fa-solid fa-building"></i> Department Dashboard</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">

        <!-- STATS CARDS -->
        <div class="stats-cards">
            <div class="card card-total">
                <h4>Total Spend</h4>
                <p>₹<?= $total ?: '0' ?></p>
                <i class="fa-solid fa-money-bill-trend-up fa-2x mt-2"></i>
            </div>
            <div class="card card-products">
                <h4>Products</h4>
                <p><?= $product_count ?></p>
                <i class="fa-solid fa-boxes-stacked fa-2x mt-2"></i>
            </div>
            <div class="card card-employees">
                <h4>Employees</h4>
                <p><?= $employee_count ?></p>
                <i class="fa-solid fa-users fa-2x mt-2"></i>
            </div>
        </div>

        <!-- WHITE SPACE FOR NEW SECTIONS -->
        <div class="section-box">
            <h4>Announcements</h4>
            <p>Place your announcements here...</p>
        </div>

        <div class="section-box">
            <h4>Featured Products</h4>
            <p>Showcase featured products here...</p>
        </div>

        <div class="section-box">
            <h4>Other Info / Updates</h4>
            <p>Add any additional dashboard information here...</p>
        </div>

    </div>
</div>

<!-- FOOTER -->
<div class="footer">
    &copy; <?= date('Y') ?> Office Pantry Monitoring System
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Toggle profile dropdown
document.getElementById("profileBtn").addEventListener("click", function() {
    let menu = document.getElementById("profileMenu");
    menu.style.display = menu.style.display === "block" ? "none" : "block";
});

// Close dropdown if clicked outside
document.addEventListener("click", function(e){
    let menu = document.getElementById("profileMenu");
    let btn = document.getElementById("profileBtn");
    if(!menu.contains(e.target) && e.target !== btn){
        menu.style.display = "none";
    }
});
</script>
</body>
</html>
