<?php
session_start();
include "db.php";

$usernameErr = $passwordErr = $roleErr = $loginErr = "";
$username = $password = $role = "";

if(isset($_POST['login'])){
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role     = $_POST['role'] ?? '';

    // Field validation
    if(empty($role)){
        $roleErr = "Please select role";
    }
    if(empty($username)){
        $usernameErr = "Username is required";
    }
    if(empty($password)){
        $passwordErr = "Password is required";
    }

    if(empty($usernameErr) && empty($passwordErr) && empty($roleErr)){
        $stmt = $conn->prepare("SELECT * FROM users WHERE username=? AND role=?");
        $stmt->bind_param("ss", $username, $role);
        $stmt->execute();
        $result = $stmt->get_result();

        if($result->num_rows > 0){
            $row = $result->fetch_assoc();
            if(password_verify($password, $row['password'])){
                $_SESSION['user_id'] = $row['user_id'];
                $_SESSION['role'] = $row['role'];
                if($row['role'] == 'admin'){
                    header("Location: admin/dashboard.php");
                } 
                elseif($row['role'] == 'pantry_manager'){
                              header("Location: pantry_manager/pantrymanager.php");
                }
                              else {
                    header("Location: employee/dashboard.php");
                }
                exit;
            } else {
                $loginErr = "Invalid username or password";
            }
        } else {
            $loginErr = "Invalid username, password or role";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Office Pantry Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
body {
    min-height: 100vh;
    background: linear-gradient(135deg,#ff9a9e,#fad0c4,#fad0c4);
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: 'Segoe UI', sans-serif;
}
.login-card {
    width: 100%;
    max-width: 420px;
    background: rgba(255,255,255,0.85);
    backdrop-filter: blur(12px);
    border-radius: 18px;
    padding: 35px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.2);
    animation: fadeIn 0.8s ease;
    text-align: center;
}
@keyframes fadeIn {
    from {opacity:0; transform:translateY(20px);}
    to {opacity:1; transform:translateY(0);}
}
.logo { width: 90px; margin-bottom: 10px; }
h2 { color: #ff6f3c; font-weight: bold; }
.input-group-text { background: #fff; border-right: none; color: #ff6f3c; }
.form-control { border-left: none; border-radius: 10px; }
.form-control:focus { box-shadow: none; border-color: #ff6f3c; }
.btn-login {
    background: linear-gradient(135deg,#ff6f3c,#ff8c5a);
    border: none;
    color: white;
    border-radius: 12px;
    padding: 10px;
    font-size: 16px;
    transition: 0.3s;
}
.btn-login:hover { transform: scale(1.02); box-shadow: 0 10px 20px rgba(255,111,60,0.4); }
.toggle-pass { cursor: pointer; color: #ff6f3c; }
.error { color: red; font-size: 13px; margin-top: 3px; text-align: left; }
.required { color:red; }
footer { text-align: center; font-size: 12px; margin-top: 15px; color: #555; }
</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $("#role").focus();

    // Limit username input
    $("#username").on("input", function () {
        let value = $(this).val();
        value = value.replace(/[^a-zA-Z ]/g, "");
        if (value.length > 15) value = value.substring(0, 15);
        $(this).val(value);

        // Remove error dynamically
        if(value.length > 0) $("#usernameErr").text("");
    });

    // Remove role error dynamically
    $("#role").change(function(){
        if($(this).val() != "") $("#roleErr").text("");
    });

    // Remove password error dynamically
    $("#password").on("input", function () {
        if($(this).val().length > 0) $("#passwordErr").text("");
    });

    // Toggle password
    $("#togglePassword").click(function(){
        let pass = $("#password");
        let type = pass.attr("type") === "password" ? "text" : "password";
        pass.attr("type", type);
        $(this).toggleClass("fa-eye fa-eye-slash");
    });
});
</script>
</head>

<body>
<div class="login-card">
    <img src="uploads/logo.jpg" class="logo" alt="Logo">
    <h2>Office Pantry</h2>
    <p class="text-muted mb-4">Select Role and Login</p>

    <?php if($loginErr!=""): ?>
        <div class="alert alert-danger"><?= $loginErr ?></div>
    <?php endif; ?>

    <form method="post" autocomplete="off" novalidate>

        <div class="mb-3 text-start">
            <label class="form-label">Role <span class="required">*</span></label>
            <select class="form-select" id="role" name="role" required>
                <option value="">-- Select Role --</option>
                <option value="admin" <?= $role=="admin"?"selected":"" ?>>Admin</option>
                <option value="employee" <?= $role=="employee"?"selected":"" ?>>Employee</option>
                <option value="pantry_manager" <?= $role=="pantry_manager"?"selected":"" ?>>Pantry Manager</option>

            </select>
            <div class="error" id="roleErr"><?= $roleErr ?></div>
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text"><i class="fa fa-user"></i></span>
            <input type="text" class="form-control" id="username" name="username" placeholder="Username" value="<?= htmlspecialchars($username) ?>" required>
        </div>
        <div class="error" id="usernameErr"><?= $usernameErr ?></div>

        <div class="input-group mb-4">
            <span class="input-group-text"><i class="fa fa-lock"></i></span>
            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
            <span class="input-group-text toggle-pass">
                <i class="fa fa-eye" id="togglePassword"></i>
            </span>
        </div>
        <div class="error" id="passwordErr"><?= $passwordErr ?></div>

        <button type="submit" name="login" class="btn btn-login w-100">
            <i class="fa fa-sign-in-alt"></i> Login
        </button>
        <div class="mt-3 text-center">
            <a href="forgot_password.php" style="color:#ff6f3c; text-decoration:none;">
                Forgot Password?
            </a>
        </div>

    </form>

    <footer>
        © <?= date('Y') ?> Office Pantry Monitoring System
    </footer>
</div>
</body>
</html>
