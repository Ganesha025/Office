<?php
session_start();
require "../db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$message = "";

/* ================= PURCHASE ================= */
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['product_id'], $_POST['quantity'])) {

    $product_id = (int)$_POST['product_id'];
    $quantity   = (int)$_POST['quantity'];

    if ($quantity < 1 || $quantity > 1000) {
        $message = "<div class='alert alert-danger'>Invalid quantity</div>";
    } else {
        $stmt = $conn->prepare("SELECT price FROM products WHERE product_id=?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows) {
            $p = $res->fetch_assoc();
            $total = $quantity * $p['price'];
            $status = ($total > 1000) ? "Pending" : "Approved";

            $stmt2 = $conn->prepare(
                "INSERT INTO purchases (user_id, product_id, quantity, total_amount, purchase_date, status)
                 VALUES (?, ?, ?, ?, CURDATE(), ?)"
            );
            $stmt2->bind_param("iiiis", $user_id, $product_id, $quantity, $total, $status);

            if ($stmt2->execute()) {
                $message = "<div class='alert alert-success'>
                    Purchase successful. Status: <b>$status</b>
                </div>";
            }
        }
    }
}

/* ================= PRODUCTS ================= */
$products = $conn->query("SELECT * FROM products ORDER BY product_name");

/* ================= HISTORY ================= */
$month = date('m');
$year  = date('Y');

$history = $conn->prepare("
    SELECT pr.product_name, p.quantity, p.total_amount, p.status, p.purchase_date
    FROM purchases p
    JOIN products pr ON p.product_id = pr.product_id
    WHERE p.user_id=? AND MONTH(p.purchase_date)=? AND YEAR(p.purchase_date)=?
    ORDER BY p.purchase_date DESC
");
$history->bind_param("iii", $user_id, $month, $year);
$history->execute();
$historyResult = $history->get_result();
?>

<!DOCTYPE html>
<html>
<head>
<title>Employee Pantry Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; font-family:'Segoe UI'; margin-bottom:100px; }

/* Layout */
.dashboard-wrapper { display:flex; justify-content:center; padding-left:80px; padding-right:20px; }
.dashboard-content {
    background:#fff; border-radius:18px; padding:20px;
    box-shadow:0 10px 30px rgba(0,0,0,.08);
    max-width:1400px; width:100%;
}
@media(max-width:768px){ .dashboard-wrapper{padding-left:10px;} }

.split { display:grid; grid-template-columns:2fr 1fr; gap:25px; }

/* Cards */
.card { border-radius:15px; }
.product-img { height:150px; object-fit:cover; }

/* Total field */
.total {
    background:#ecfeff;
    border:2px dashed #06b6d4;
    font-weight:700;
    color:#0f766e;
    text-align:center;
}

/* Purchase panel */
.purchase-panel {
    background:#f8fafc;
    border-left:5px solid #ff9a3c;
    border-radius:15px;
    padding:15px;
}

/* Navbar */
.navbar {
    background:linear-gradient(135deg,#ff7f50,#ff9a3c);
    padding:12px 25px;
    border-radius:0 0 15px 15px;
}

/* Profile */
.profile-img {
    width:42px; height:42px; border-radius:50%;
    border:2px solid #fff; object-fit:cover;
}

/* Search */
.search-box { position:relative; }
.search-clear {
    position:absolute; right:12px; top:50%;
    transform:translateY(-50%); cursor:pointer; color:#999;
}

/* Status badges */
.badge-approved {
    background:#10b981;
    color:#fff;
}
.badge-pending {
    background:#f59e0b;
    color:#fff;
}
.badge-rejected {
    background:#ef4444;
    color:#fff;
}

/* Toast */
#toast {
    position:fixed; top:80px; right:20px;
    display:none; padding:12px 20px;
    background:#f97316; color:#fff;
    border-radius:8px;
}

/* Footer */
.app-footer {
    background:black; color:#fff; text-align:center;
    padding:14px 10px; position:fixed; bottom:0;
    width:100%; font-size:14px;
    border-radius:15px 15px 0 0;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-dark d-flex justify-content-between">
    <span class="navbar-brand fw-bold">PantryHub</span>

    <div class="dropdown">
        <a class="d-flex align-items-center text-white text-decoration-none dropdown-toggle"
           data-bs-toggle="dropdown">
            <img src="../uploads/admin.jpg" class="profile-img me-2">
            My Profile
        </a>
        <ul class="dropdown-menu dropdown-menu-end">
            <li>
                <a class="dropdown-item text-danger" href="../logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="dashboard-wrapper">
<div class="dashboard-content">

<?= $message ?>

<!-- SEARCH -->
<div class="search-box mb-3">
    <input type="text" id="search" class="form-control" placeholder="Search products">
    <span class="search-clear" onclick="clearSearch()">✖</span>
</div>

<div class="split">

<!-- PRODUCTS -->
<div>
<h4 class="mb-3">Available Products</h4>
<div class="row">
<?php while($p=$products->fetch_assoc()){ ?>
<div class="col-md-4 mb-3 product-card">
<div class="card shadow">
<img src="../uploads/<?= $p['image'] ?>" class="product-img">
<div class="card-body">
<h6 class="product-name"><?= $p['product_name'] ?></h6>
<p class="fw-bold">₹<?= $p['price'] ?></p>

<form method="POST" onsubmit="return validateForm(this)">
<input type="hidden" name="product_id" value="<?= $p['product_id'] ?>">
<input type="number" name="quantity" class="form-control qty mb-2"
       data-price="<?= $p['price'] ?>" placeholder="Quantity" required>
<input type="text" class="form-control total mb-2" placeholder="Total ₹" readonly>
<button class="btn btn-primary w-100">Purchase</button>
</form>
</div>
</div>
</div>
<?php } ?>
</div>
</div>

<!-- PURCHASES -->
<div>
<h4 class="mb-3">My Purchases</h4>
<div class="purchase-panel shadow">
<table class="table table-sm">
<thead class="table-dark">
<tr>
<th>Product</th><th>Qty</th><th>Total</th><th>Status</th><th>Date</th>
</tr>
</thead>
<tbody>
<?php if($historyResult->num_rows){ while($r=$historyResult->fetch_assoc()){ ?>
<tr>
<td><?= $r['product_name'] ?></td>
<td><?= $r['quantity'] ?></td>
<td>₹<?= $r['total_amount'] ?></td>
<td>
<span class="badge 
<?= $r['status']=='Approved'?'badge-approved':'' ?>
<?= $r['status']=='Pending'?'badge-pending':'' ?>
<?= $r['status']=='Rejected'?'badge-rejected':'' ?>">
<?= $r['status'] ?>
</span>
</td>
<td><?= date("d M Y", strtotime($r['purchase_date'])) ?></td>
</tr>
<?php }} else { ?>
<tr><td colspan="5" class="text-center">No purchases</td></tr>
<?php } ?>
</tbody>
</table>
</div>
</div>

</div>
</div>
</div>

<script>
document.getElementById("search").focus();

function clearSearch(){
    let s=document.getElementById("search");
    s.value=""; s.focus();
    document.querySelectorAll(".product-card").forEach(c=>c.style.display="block");
}

document.getElementById("search").addEventListener("input",function(){
    let v=this.value.toLowerCase();
    document.querySelectorAll(".product-card").forEach(c=>{
        c.style.display=c.querySelector(".product-name").innerText.toLowerCase().includes(v)?"block":"none";
    });
});

document.querySelectorAll(".qty").forEach(i=>{
    i.addEventListener("input",function(){
        let total=this.dataset.price*this.value;
        this.closest("form").querySelector(".total").value = total ? "₹"+total : "";
    });
});

function validateForm(f){
    let q=f.querySelector(".qty").value;
    if(q<1||q>1000){ alert("Quantity 1–1000 only"); return false; }
    return true;
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<footer class="app-footer">
    © <?= date('Y') ?> Office Pantry Monitoring System · PantryHub
</footer>

</body>
</html>
