<?php
session_start();
require "../db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$id = (int)$_GET['id'];
$message = "";

/* FETCH PRODUCT */
$stmt = $conn->prepare("SELECT product_name, price, image FROM products WHERE product_id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
$data = $res->fetch_assoc();

/* UPDATE PRODUCT */
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $name  = trim($_POST['product_name']);
    $price = (int)$_POST['price'];

    if (!empty($_FILES['image']['name'])) {
        $filename = time().'_'.$_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/".$filename);

        $update = $conn->prepare(
            "UPDATE products SET product_name=?, price=?, image=? WHERE product_id=?"
        );
        $update->bind_param("sisi", $name, $price, $filename, $id);
    } else {
        $update = $conn->prepare(
            "UPDATE products SET product_name=?, price=? WHERE product_id=?"
        );
        $update->bind_param("sii", $name, $price, $id);
    }

    if ($update->execute()) {
        $message = "<div class='alert alert-success'>Product updated successfully!</div>";
    } else {
        $message = "<div class='alert alert-danger'>Update failed</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Edit Product</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5" style="max-width:600px;">
    <div class="card p-4 shadow">
        <h3>Edit Product</h3>

        <?= $message ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Product Name</label>
                <input type="text" name="product_name"
                       value="<?= htmlspecialchars($data['product_name']) ?>"
                       class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Price</label>
                <input type="number" name="price"
                       value="<?= $data['price'] ?>"
                       class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Current Image</label><br>
                <img src="../uploads/<?= $data['image'] ?>" width="100">
            </div>

            <div class="mb-3">
                <label>Change Image</label>
                <input type="file" name="image" class="form-control">
            </div>

            <button class="btn btn-primary w-100">Update Product</button>
        </form>
    </div>
</div>

</body>
</html>
