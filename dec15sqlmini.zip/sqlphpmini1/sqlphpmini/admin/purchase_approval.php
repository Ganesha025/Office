<?php
session_start();
require "../db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

/* ================= ACTION ================= */
if (isset($_GET['action'], $_GET['id'])) {

    $id = (int)$_GET['id'];

    if ($_GET['action'] === 'approve') {
        $conn->query("UPDATE purchases SET status='Approved' WHERE purchase_id=$id");
    }

    if ($_GET['action'] === 'reject') {
        $conn->query("UPDATE purchases SET status='Rejected' WHERE purchase_id=$id");
    }

    header("Location: purchase_approval.php");
    exit;
}

/* ================= FETCH PENDING ================= */
$sql = "
SELECT 
    p.purchase_id,
    u.emp_name,
    u.department,
    pr.product_name,
    p.quantity,
    p.total_amount,
    p.purchase_date
FROM purchases p
JOIN users u ON p.user_id = u.user_id
JOIN products pr ON p.product_id = pr.product_id
WHERE p.status = 'Pending'
  AND p.total_amount > 1000
ORDER BY p.purchase_date DESC
";


$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
<title>Purchase Approval | Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{background:#f8fafc;font-family:'Segoe UI';}
.card{border-radius:15px;}
</style>
</head>

<body>

<nav class="navbar navbar-dark bg-dark px-4">
<span class="navbar-brand">Admin – Purchase Approval</span>
<a href="dashboard.php" class="btn btn-outline-light btn-sm">Dashboard</a>
</nav>

<div class="container mt-4">
<div class="card shadow">
<div class="card-body">

<h4 class="mb-3">Pending Purchases (Above ₹1000)</h4>

<table class="table table-bordered align-middle">
<thead class="table-dark">
<tr>
<th>#</th>
<th>Employee</th>
<th>Product</th>
<th>Qty</th>
<th>Total</th>
<th>Date</th>
<th>Action</th>
</tr>
</thead>

<tbody>
<?php if($result->num_rows){ while($row=$result->fetch_assoc()){ ?>
<tr>
<td><?= $row['purchase_id'] ?></td>
<td><?= $row['emp_name'] ?></td>
<td><?= $row['product_name'] ?></td>
<td><?= $row['quantity'] ?></td>
<td class="fw-bold text-danger">₹<?= $row['total_amount'] ?></td>
<td><?= date("d M Y", strtotime($row['purchase_date'])) ?></td>
<td>
<a href="?action=approve&id=<?= $row['purchase_id'] ?>"
   class="btn btn-success btn-sm">Approve</a>

<a href="?action=reject&id=<?= $row['purchase_id'] ?>"
   class="btn btn-danger btn-sm"
   onclick="return confirm('Reject this purchase?')">Reject</a>
</td>
</tr>
<?php }} else { ?>
<tr>
<td colspan="7" class="text-center text-muted">
No pending approvals
</td>
</tr>
<?php } ?>
</tbody>
</table>

</div>
</div>
</div>

</body>
</html>
