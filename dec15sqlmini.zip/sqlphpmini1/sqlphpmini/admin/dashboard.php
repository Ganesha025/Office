<?php
session_start();
require "../db.php";

/* AUTH CHECK */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

/* ADD EMPLOYEE */
if (isset($_POST['add_employee'])) {
    $name = $_POST['emp_name'];
    $username = $_POST['username'];
    $dept = $_POST['department'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare(
        "INSERT INTO users (emp_name, username, password, role, department)
         VALUES (?, ?, ?, 'employee', ?)"
    );
    $stmt->bind_param("ssss", $name, $username, $password, $dept);
    $stmt->execute();
}

/* STATS */
$total = $conn->query("SELECT SUM(total_amount) total FROM purchases")
        ->fetch_assoc()['total'] ?? 0;

$product_count = $conn->query("SELECT COUNT(*) count FROM products")
        ->fetch_assoc()['count'];

$employee_count = $conn->query("SELECT COUNT(*) count FROM users WHERE role='employee'")
        ->fetch_assoc()['count'];

$pending = $conn->query("SELECT COUNT(*) c FROM purchases WHERE status='pending'")
        ->fetch_assoc()['c'] ?? 0;

/* DEPARTMENT SUMMARY */
$dept_sql = "
SELECT 
    u.department,
    SUM(p.total_amount) dept_total,
    (
        SELECT u2.emp_name FROM users u2
        JOIN purchases p2 ON u2.user_id=p2.user_id
        WHERE u2.department=u.department
        ORDER BY p2.total_amount DESC LIMIT 1
    ) top_spender,
    (
        SELECT pr.product_name FROM purchases p3
        JOIN products pr ON p3.product_id=pr.product_id
        JOIN users u3 ON p3.user_id=u3.user_id
        WHERE u3.department=u.department
        GROUP BY pr.product_name
        ORDER BY COUNT(*) DESC LIMIT 1
    ) frequent_item
FROM users u
LEFT JOIN purchases p ON u.user_id=p.user_id
WHERE u.role='employee'
GROUP BY u.department
";
$dept_result = $conn->query($dept_sql);

/* TOP SPENDERS */
$top_spenders = $conn->query("
SELECT u.emp_name, SUM(p.total_amount) total
FROM purchases p
JOIN users u ON p.user_id=u.user_id
GROUP BY u.user_id
ORDER BY total DESC
LIMIT 5
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body{margin:0;background:#f4f6f9;font-family:'Segoe UI';}

/* HEADER */
.header{
    background:linear-gradient(90deg,#ff7e5f,#feb47b);
    color:white;padding:18px 30px;
    display:flex;justify-content:space-between;align-items:center;
}

/* LAYOUT */
.wrapper{display:flex;min-height:calc(100vh - 120px);}

/* SIDEBAR */
.sidebar{
    width:230px;background:#fff;padding:20px;
    box-shadow:2px 0 10px rgba(0,0,0,.05);
    position:sticky;top:0;height:100vh;
}
.sidebar a{
    display:block;padding:8px 0;
    font-weight:600;color:#333;text-decoration:none;
}
.sidebar a:hover{color:#ff7e5f}

/* MAIN */
.main{flex:1;padding:25px}

/* STATS */
/* STATS - smaller cards */
.stats{display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap}
.stat-box,.action-box{
    background:white;border-radius:12px;
    padding:12px 15px;
    width:180px;
    box-shadow:0 3px 8px rgba(0,0,0,.08);
    text-align:center;
}
.stat-box small{font-size:0.8rem}
.stat-box h4{font-size:1.3rem;margin-top:5px}
.action-box{cursor:pointer}
.action-box i{font-size:1.5rem}
.action-box p{font-size:0.85rem;margin-top:5px}
.action-box:hover{background:#fff1ea}


/* CARD */
.card{border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,.1)}

/* FOOTER */
.footer{
    background:#333;color:#fff;
    text-align:center;padding:15px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <h4><i class="fa-solid fa-chart-simple"></i> Pantry Admin Dashboard</h4>

    <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle"
           data-bs-toggle="dropdown">
            <img src="../uploads/admin.jpg" width="42" height="42"
                 class="rounded-circle border border-white me-2">
            <strong>Admin</strong>
        </a>
        <ul class="dropdown-menu dropdown-menu-end shadow">
            <li>
                <a class="dropdown-item text-danger" href="../logout.php">
                    <i class="fa fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </div>
</div>

<div class="wrapper">

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="products.php"><i class="fa fa-box me-2"></i> Manage Products</a>
    <a href="purchases.php"><i class="fa fa-receipt me-2"></i> Purchases</a>
    <a href="reports.php"><i class="fa fa-chart-line me-2"></i> Reports</a>
    <a href="employee_list.php"><i class="fa fa-users me-2"></i> Employees</a>
    <a href="purchase_approval.php"><i class="fa fa-check-circle me-2"></i> Approvals</a>

    <hr>
    <small class="text-muted fw-bold">Quick Stats</small>
    <div class="mt-2">
        <small>Total Spend</small>
        <div class="fw-bold text-success">₹<?= number_format($total) ?></div>
    </div>
    <div class="mt-2">
        <small>Employees</small>
        <div class="fw-bold text-primary"><?= $employee_count ?></div>
    </div>
</div>

<!-- MAIN -->
<div class="main">



<div class="stats">
    <div class="stat-box">
        <small>Total Spend</small>
        <h4>₹<?= number_format($total) ?></h4>
    </div>
    <div class="stat-box">
        <small>Products</small>
        <h4><?= $product_count ?></h4>
    </div>
    <div class="stat-box">
        <small>Employees</small>
        <h4><?= $employee_count ?></h4>
    </div>

    <div class="action-box text-primary"
         data-bs-toggle="modal"
         data-bs-target="#addEmployeeModal">
        <i class="fa fa-user-plus"></i>
        <p class="mt-1 fw-bold">Add Employee</p>
    </div>
</div>

<div class="card p-4 mb-4">
<h5>Department-wise Purchase Summary</h5>
<table class="table table-bordered mt-3">
<thead class="table-dark">
<tr>
    <th>Department</th>
    <th>Total Spent (₹)</th>
    <th>Top Spender</th>
    <th>Most Frequent Item</th>
</tr>
</thead>
<tbody>
<?php while($row=$dept_result->fetch_assoc()){ ?>
<tr>
    <td><?= $row['department'] ?></td>
    <td><?= number_format($row['dept_total'] ?? 0) ?></td>
    <td><?= $row['top_spender'] ?? '-' ?></td>
    <td><?= $row['frequent_item'] ?? '-' ?></td>
</tr>
<?php } ?>
</tbody>
</table>
</div>

<div class="card p-4">
<h5>Top 5 Spenders</h5>
<table class="table table-sm mt-3">
<?php while($t=$top_spenders->fetch_assoc()){ ?>
<tr>
    <td><?= $t['emp_name'] ?></td>
    <td class="text-end fw-bold">₹<?= number_format($t['total']) ?></td>
</tr>
<?php } ?>
</table>
</div>

</div>
</div>

<div class="footer">
    © <?= date('Y') ?> Office Pantry Monitoring System
</div>

<!-- ADD EMPLOYEE MODAL -->
<div class="modal fade" id="addEmployeeModal">
<div class="modal-dialog">
<form method="post" class="modal-content">
    <div class="modal-header">
        <h5>Add Employee</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
        <input name="emp_name" class="form-control mb-2" placeholder="Full Name" required>
        <input name="username" class="form-control mb-2" placeholder="Username" required>
        <input name="department" class="form-control mb-2" placeholder="Department" required>
        <input name="password" type="password" class="form-control mb-2" placeholder="Password" required>
    </div>
    <div class="modal-footer">
        <button name="add_employee" class="btn btn-success">Add</button>
    </div>
</form>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
