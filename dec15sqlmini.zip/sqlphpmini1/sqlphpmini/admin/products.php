<?php
session_start();
require "../db.php";

/* ONLY ADMIN */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

/* ADD PRODUCT (POPUP FORM) */
if (isset($_POST['add_product'])) {
    $name  = trim($_POST['product_name']);
    $price = (int)$_POST['price'];

    if (!empty($_FILES['image']['name'])) {
        $imageName = time() . "_" . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $imageName);

        $stmt = $conn->prepare(
            "INSERT INTO products (product_name, price, image) VALUES (?, ?, ?)"
        );
        $stmt->bind_param("sis", $name, $price, $imageName);
        $stmt->execute();
    }

    header("Location: products.php");
    exit;
}

/* FETCH PRODUCTS */
$result = $conn->query("SELECT * FROM products ORDER BY product_name ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Product Management</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body{background:#fff8f0;font-family:'Segoe UI';margin-bottom:80px}

/* HEADER */
header{
    background:linear-gradient(135deg,#ff6f3c,#ff8c5a);
    color:#fff;padding:15px 30px;
    display:flex;justify-content:space-between;align-items:center;
}

/* CARD */
.card{
    border-radius:15px;
    box-shadow:0 15px 30px rgba(0,0,0,.1);
}

/* TABLE */
.table thead{background:#000;color:#fff}
.table img{border-radius:8px}

/* BUTTONS */
.btn-add{
    background:linear-gradient(135deg,#28a745,#5fd37b);
    border:none;color:#fff;border-radius:10px;
}
.btn-add:hover{opacity:.9}

/* FOOTER */
footer{
    background:#000;color:#fff;
    text-align:center;padding:15px;
    position:fixed;bottom:0;width:100%;
}
</style>
</head>

<body>

<!-- HEADER -->
<header>
    <h4><i class="fa fa-box"></i> Product Management</h4>
    <a href="dashboard.php" class="text-white">
        <i class="fa fa-home"></i> Dashboard
    </a>
</header>

<!-- CONTENT -->
<div class="container mt-4">
<div class="card p-4">

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4>Available Products</h4>
    <button class="btn btn-add" data-bs-toggle="modal" data-bs-target="#addProductModal">
        <i class="fa fa-plus"></i> Add Product
    </button>
</div>

<div class="table-responsive">
<table class="table table-bordered table-striped align-middle">
<thead>
<tr>
    <th>#</th>
    <th>Image</th>
    <th>Product Name</th>
    <th>Price (₹)</th>
    <th width="160">Actions</th>
</tr>
</thead>
<tbody>

<?php if ($result->num_rows > 0) {
while ($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['product_id'] ?></td>
    <td><img src="../uploads/<?= $row['image'] ?>" width="55"></td>
    <td><?= htmlspecialchars($row['product_name']) ?></td>
    <td><?= number_format($row['price']) ?></td>
    <td>
        <a href="edit_product.php?id=<?= $row['product_id'] ?>"
           class="btn btn-primary btn-sm">
           <i class="fa fa-edit"></i>
        </a>
        <a href="delete_product.php?id=<?= $row['product_id'] ?>"
           class="btn btn-danger btn-sm"
           onclick="return confirm('Delete this product?');">
           <i class="fa fa-trash"></i>
        </a>
    </td>
</tr>
<?php }} else { ?>
<tr>
    <td colspan="5" class="text-center text-muted">
        No products found
    </td>
</tr>
<?php } ?>

</tbody>
</table>
</div>

</div>
</div>

<!-- ADD PRODUCT MODAL -->
<div class="modal fade" id="addProductModal">
<div class="modal-dialog">
<form method="post" enctype="multipart/form-data" class="modal-content">

<div class="modal-header">
    <h5>Add Product</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
    <input type="text" name="product_name" class="form-control mb-2"
           placeholder="Product Name" required>

    <input type="number" name="price" class="form-control mb-2"
           placeholder="Price" required>

    <input type="file" name="image" class="form-control" required>
</div>

<div class="modal-footer">
    <button name="add_product" class="btn btn-success">
        Save Product
    </button>
</div>

</form>
</div>
</div>

<!-- FOOTER -->
<footer>
© <?= date('Y') ?> Office Pantry Monitoring System
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
