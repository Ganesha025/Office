<?php
session_start();
require "../db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $name  = trim($_POST['product_name']);
    $price = trim($_POST['price']);

    // Image upload with JPG validation
    if (!empty($_FILES['image']['name'])) {
        $fileType = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));

        if($fileType != "jpg" && $fileType != "jpeg") {
            $message = "<div class='alert alert-danger'>Only JPG images are allowed!</div>";
            $filename = "";
        } else {
            $filename = time().'_'.$_FILES['image']['name'];
            $target = "../uploads/".$filename;
            move_uploaded_file($_FILES['image']['tmp_name'], $target);
        }
    } else {
        $filename = "";
    }

    if($name && $price && $filename){
        $sql = "INSERT INTO products (product_name, price, image) 
                VALUES ('$name', '$price', '$filename')";
        if ($conn->query($sql)) {
            $message = "<div class='alert alert-success'>Product added successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error: ".$conn->error."</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Product | Office Pantry</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body{ background:#fff8f0; font-family:'Segoe UI',sans-serif; margin-bottom:80px; }
header{ background:linear-gradient(135deg,#ff6f3c,#ff8c5a); color:white; padding:15px 30px; display:flex; justify-content:space-between; align-items:center; border-radius:0 0 12px 12px; }
header a{color:white;text-decoration:none;margin-left:15px}
.card{border-radius:15px; box-shadow:0 15px 30px rgba(0,0,0,0.15);}
.error-text{color:red; font-size:13px; margin-top:4px;}
footer{background:#000; color:white; text-align:center; padding:15px; position:fixed; bottom:0; left:0; width:100%;}
.required{color:red;}
</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){

    $("#product_name").focus();

    function showError(id,msg){ $("#"+id+"-error").text(msg); }
    function clearError(id){ $("#"+id+"-error").text(""); }

    // Product name validation
    $("#product_name").on("input", function(){
        let val = $(this).val().replace(/[^a-zA-Z ]/g,"");
        if(val.length > 15) val = val.substring(0,15);
        $(this).val(val);
        val.length < 1 ? showError("product_name","Product name is required") : clearError("product_name");
    });

    // Price validation
    $("#price").on("input", function(){
        let val = $(this).val().replace(/[^0-9]/g,"");
        if(val > 1000) val = 1000;
        $(this).val(val);
        val < 1 ? showError("price","Price must be between 1 and 1000") : clearError("price");
    });

    // Image validation
    $("#image").on("change", function(){
        let file = $(this).val();
        if(file === ""){
            showError("image","Product image is required");
        } else {
            let ext = file.split('.').pop().toLowerCase();
            if(ext != "jpg" && ext != "jpeg"){
                showError("image","Only JPG images are allowed");
                $(this).val(""); // reset file input
            } else {
                clearError("image");
            }
        }
    });

    // Submit validation
    $("form").submit(function(e){
        let valid = true;
        if($("#product_name").val().trim() === ""){ showError("product_name","Product name is required"); valid=false; }
        if($("#price").val().trim() === ""){ showError("price","Price is required"); valid=false; }
        if($("#image").val() === ""){ showError("image","Product image is required"); valid=false; }
        if(!valid) e.preventDefault();
    });
});
</script>
</head>

<body>
<header>
    <h3><i class="fa fa-plus"></i> Add Product</h3>
    <div>
        <a href="products.php"><i class="fa fa-arrow-left"></i> Products</a>
    </div>
</header>

<div class="container mt-5" style="max-width:600px;">
    <div class="card p-4">
        <h4 class="mb-3">New Product</h4>

        <?= $message ?>

        <form method="POST" enctype="multipart/form-data" novalidate>
            <div class="mb-3">
                <label>Product Name<span class="required">*</span></label>
                <input type="text" id="product_name" name="product_name" class="form-control">
                <div id="product_name-error" class="error-text"></div>
            </div>

            <div class="mb-3">
                <label>Price (₹)<span class="required">*</span></label>
                <input type="text" id="price" name="price" class="form-control">
                <div id="price-error" class="error-text"></div>
            </div>

            <div class="mb-3">
                <label>Product Image<span class="required">*</span></label>
                <input type="file" id="image" name="image" class="form-control" accept=".jpg,.jpeg">
                <div id="image-error" class="error-text"></div>
            </div>

            <button class="btn btn-success w-100">
                <i class="fa fa-save"></i> Add Product
            </button>
        </form>
    </div>
</div>

<footer>
    © <?= date('Y') ?> Office Pantry Monitoring System
</footer>

</body>
</html>
