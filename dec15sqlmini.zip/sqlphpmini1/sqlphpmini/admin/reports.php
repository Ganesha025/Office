<?php
session_start();
require "../db.php";

// Only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// SQL: Employee-wise report
$sql = "SELECT 
            u.emp_name, 
            u.department, 
            SUM(p.total_amount) AS total_spent,
            COUNT(p.purchase_id) AS num_purchases,
            (SELECT pr.product_name 
             FROM purchases p2
             JOIN products pr ON p2.product_id = pr.product_id
             WHERE p2.user_id = u.user_id
             GROUP BY pr.product_name
             ORDER BY COUNT(*) DESC LIMIT 1) AS frequent_item
        FROM users u
        LEFT JOIN purchases p ON u.user_id = p.user_id
        WHERE u.role='employee'
        GROUP BY u.user_id";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Employee-wise Report</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
body, html {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f0f4f8;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* HEADER */
.header {
    background: linear-gradient(90deg, #ff7e5f, #feb47b);
    color: white;
    padding: 20px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 5px 10px rgba(0,0,0,0.1);
}
.header h2 { margin: 0; font-size: 24px; }
.header a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    border: 1px solid white;
    padding: 8px 15px;
    border-radius: 8px;
    transition: 0.3s;
}
.header a:hover { background: rgba(255,255,255,0.2); }

/* MAIN CONTENT */
.main-content {
    flex: 1;
    padding: 20px 30px;
}

/* CARD TABLE WRAPPER */
.card {
    border-radius: 12px;
    padding: 20px;
    background: #fff;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}

/* TABLE */
.table-responsive { margin-top: 15px; }
.table th, .table td { vertical-align: middle; text-align: center; }
.table-danger { background-color: #f8d7da !important; }

/* FOOTER */
.footer {
    background: #333;
    color: #fff;
    text-align: center;
    padding: 15px;
}

/* RESPONSIVE */
@media(max-width:768px){
    .header { flex-direction: column; gap: 10px; }
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h2><i class="fa-solid fa-file-chart-column"></i> Employee-wise Report</h2>
    <a href="dashboard.php"><i class="fa-solid fa-house"></i> Dashboard</a>
</div>

<!-- MAIN CONTENT -->
<div class="main-content">
    <div class="card">
        <h4 class="mb-3">Employee Purchase Summary</h4>
        <div class="table-responsive">
            <table class="table table-hover table-striped table-bordered align-middle text-center">
                <thead class="table-dark">
                    <tr>
                        <th>Employee</th>
                        <th>Department</th>
                        <th>Total Spent</th>
                        <th>No. of Purchases</th>
                        <th>Most Frequent Item</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()){ 
                        $row_class = ($row['total_spent'] > 2000) ? 'table-danger' : '';
                    ?>
                    <tr class="<?= $row_class ?>">
                        <td><?= $row['emp_name'] ?></td>
                        <td><?= $row['department'] ?></td>
                        <td>₹<?= $row['total_spent'] ?? 0 ?></td>
                        <td><?= $row['num_purchases'] ?></td>
                        <td><?= $row['frequent_item'] ?? '-' ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- FOOTER -->
<div class="footer">
    &copy; 2025 Office Pantry System
</div>

</body>
</html>
