<?php
session_start();
require "../db.php";

// Only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// Fetch employees
$sql = "SELECT * FROM users WHERE role='employee' ORDER BY emp_name ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Employees | Office Pantry</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body{
    background:#fff8f0;
    font-family:'Segoe UI',sans-serif;
    margin-bottom:80px;
}

/* HEADER */
header{
    background:linear-gradient(135deg,#ff6f3c,#ff8c5a);
    color:white;
    padding:15px 30px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    border-radius:0 0 12px 12px;
}
header h3{
    margin:0;
    font-weight:bold;
}
header a{
    color:white;
    text-decoration:none;
    margin-left:15px;
}

/* CARD */
.card{
    border-radius:15px;
    box-shadow:0 15px 30px rgba(0,0,0,0.12);
}

/* TABLE */
.table thead{
    background:#000;
    color:white;
}
.table td, .table th{
    vertical-align:middle;
}

/* FOOTER */
footer{
    background:#000;
    color:white;
    text-align:center;
    padding:15px;
    position:fixed;
    bottom:0;
    left:0;
    width:100%;
}
</style>
</head>

<body>

<!-- HEADER -->
<header>
    <h3><i class="fa-solid fa-users"></i> Manage Employees</h3>
    <div>
        <a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
       
    </div>
</header>

<!-- CONTENT -->
<div class="container mt-4">
    <div class="card p-4">

        <h4 class="mb-3">Employee List</h4>

        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Employee Name</th>
                        <th>Department</th>
                        <th>Username</th>
                        <th width="170">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                if ($result->num_rows > 0) {
                    $i = 1;
                    while ($row = $result->fetch_assoc()) {
                ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= htmlspecialchars($row['emp_name']) ?></td>
                        <td><?= htmlspecialchars($row['department']) ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td>
                            <a href="edit_employee.php?id=<?= $row['user_id'] ?>"
                               class="btn btn-primary btn-sm">
                               <i class="fa fa-edit"></i> Edit
                            </a>
                            <a href="delete_employee.php?id=<?= $row['user_id'] ?>"
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Are you sure you want to delete this employee?');">
                               <i class="fa fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                <?php
                    }
                } else {
                ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">
                            No employees found
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<!-- FOOTER -->
<footer>
    © <?= date('Y') ?> Office Pantry Monitoring System
</footer>

</body>
</html>
