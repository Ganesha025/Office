<?php
// Always define message first to avoid warning
$message = "";

// Example logic (you can adjust as per your backend)
if (isset($_POST['reset'])) {
    $password = $_POST['password'];
    $confirm  = $_POST['confirm'];

    if ($password !== $confirm) {
        $message = "Passwords do not match!";
    } else {
        // Password reset logic here
        // password_hash(), update query, etc.
        $message = "Password reset successful!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Reset Password</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg,#ff9a9e,#fad0c4,#fad0c4);
    font-family: 'Segoe UI', sans-serif;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
.card {
    width: 100%;
    max-width: 420px;
    padding: 30px;
    border-radius: 15px;
    background: rgba(255,255,255,0.9);
    backdrop-filter: blur(10px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.2);
}
h4 {
    color: #ff6f3c;
    font-weight: bold;
    text-align: center;
    margin-bottom: 20px;
}
.toggle {
    cursor: pointer;
    color: #ff6f3c;
}
.btn-success {
    background: linear-gradient(135deg,#10b981,#34d399);
    border: none;
}
.btn-success:hover {
    transform: scale(1.02);
    box-shadow: 0 8px 20px rgba(16,185,129,0.4);
}
</style>
</head>

<body>

<div class="card">
    <h4>Reset Password</h4>

    <?php if (!empty($message)): ?>
        <div class="alert alert-danger"><?= $message ?></div>
    <?php endif; ?>

    <form method="post">

        <!-- New Password (WITH eye icon) -->
        <div class="input-group mb-3">
            <input type="password" id="newPass" name="password"
                   class="form-control" placeholder="New Password" required>
            <span class="input-group-text toggle" onclick="togglePass('newPass', this)">
                <i class="fa fa-eye"></i>
            </span>
        </div>

        <!-- Confirm Password (NO eye icon) -->
        <div class="mb-3">
            <input type="password" id="confirmPass" name="confirm"
                   class="form-control" placeholder="Confirm Password" required>
        </div>

        <button class="btn btn-success w-100" name="reset">
            Reset Password
        </button>
    </form>
</div>

<script>
function togglePass(id, el) {
    let input = document.getElementById(id);
    let icon = el.querySelector("i");

    if (input.type === "password") {
        input.type = "text";
        icon.classList.replace("fa-eye", "fa-eye-slash");
    } else {
        input.type = "password";
        icon.classList.replace("fa-eye-slash", "fa-eye");
    }
}
</script>

</body>
</html>
