<?php if(session()->getFlashdata('error')): ?>
<div class="bg-red-100 text-red-700 p-2 rounded mb-2">
    <?= session()->getFlashdata('error') ?>
</div>
<?php endif; ?>

<form action="/loginPage" method="post">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
</form>