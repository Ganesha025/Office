<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Admin</h1>

    <a href="<?= base_url('/logout') ?>">Logout</a>
    <a href="<?= site_url('/admin/manageuser') ?>">Manage Users</a>
    <a href="<?= site_url('/admin/Tickets') ?>">Tickets</a>

</body>
</html>
