<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Users</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
</head>
<body class="p-6 bg-gray-100">
<div class="max-w-3xl mx-auto">
<div class="bg-white p-6 rounded-lg shadow mb-6">
<h2 class="text-xl font-bold mb-4">Add User</h2>
<?php if(session()->getFlashdata('success')): ?><div class="bg-green-100 text-green-700 p-2 rounded mb-2"><?= session()->getFlashdata('success') ?></div><?php endif; ?>
<?php if(session()->getFlashdata('error')): ?><div class="bg-red-100 text-red-700 p-2 rounded mb-2"><?= session()->getFlashdata('error') ?></div><?php endif; ?>
<form action="/admin/saveUser" method="post" class="space-y-3" id="userForm">
<input type="hidden" name="id" id="userId">
<input type="text" name="name" id="name" placeholder="Name" required class="w-full p-2 border rounded" autofocus>
<input type="email" name="email" id="email" placeholder="Email" required class="w-full p-2 border rounded">
<input type="password" name="password" id="password" placeholder="Password" class="w-full p-2 border rounded">
<select name="role" id="role" required class="w-full p-2 border rounded">
<option value="">Select Role</option>
<option value="hr">HR</option>
<option value="manager">Manager</option>
</select>
<select name="department" id="department" required class="w-full p-2 border rounded">
<option value="">Select Department</option>
<option value="IT">IT</option>
<option value="Sales">Sales</option>
<option value="HR">HR</option>
</select>
<button type="submit" class="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700" id="saveBtn">Save User</button>
<button type="button" class="w-full bg-gray-400 text-white p-2 rounded hover:bg-gray-500 hidden" id="cancelBtn">Cancel</button>
</form>
</div>

<div class="bg-white p-6 rounded-lg shadow">
<h2 class="text-xl font-bold mb-4">Existing Users</h2>
<table id="usersTable" class="min-w-full border rounded">
<thead class="bg-gray-200">
<tr>
<th class="border px-2 py-1">Name</th>
<th class="border px-2 py-1">Email</th>
<th class="border px-2 py-1">Password</th>
<th class="border px-2 py-1">Role</th>
<?php if(isset($role) && $role != 'manager'): ?><th class="border px-2 py-1">Department</th><?php endif; ?>
<th class="border px-2 py-1">Created At</th>
<th class="border px-2 py-1">Actions</th>
</tr>
</thead>
<tbody>
<?php foreach($users as $u): ?>
<tr data-id="<?= $u['id'] ?>">
<td class="border px-2 py-1 name"><?= $u['name'] ?></td>
<td class="border px-2 py-1 email"><?= $u['email'] ?></td><td class="border px-2 py-1"><?= str_repeat('*', 8) ?></td>
<td class="border px-2 py-1 role"><?= $u['role'] ?></td>
<?php if(isset($role) && $role != 'manager'): ?><td class="border px-2 py-1 department"><?= $u['department'] ?></td><?php endif; ?>
<td class="border px-2 py-1"><?= $u['created_at'] ?></td>
<td class="border px-2 py-1 flex gap-2">
<?php if($u['role'] != 'admin'): ?>
<button class="editInline bg-yellow-500 text-white px-2 py-1 rounded">Edit</button>
<button class="saveInline bg-green-500 text-white px-2 py-1 rounded hidden">Save</button>
<button class="cancelInline bg-gray-400 text-white px-2 py-1 rounded hidden">Cancel</button>
<a href="/admin/deleteUser/<?= $u['id'] ?>" class="bg-red-500 text-white px-2 py-1 rounded" onclick="return confirm('Delete user?')">Delete</a>
<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</div>

<script>
$(document).ready(function () {
    $('#usersTable').DataTable();

    let oldData = {};

    $(document).on('click', '.editInline', function () {
        let row = $(this).closest('tr');

        oldData[row.data('id')] = {
            name: row.find('.name').text(),
            email: row.find('.email').text(),
            role: row.find('.role').text(),
            department: row.find('.department').text()
        };

        row.find('.editInline').hide();
        row.find('.saveInline,.cancelInline').show();

        row.find('.name').html('<input class="w-full border p-1 rounded" value="' + oldData[row.data('id')].name + '">');
        row.find('.email').html('<input class="w-full border p-1 rounded" value="' + oldData[row.data('id')].email + '">');

        row.find('.role').html(
            '<select class="w-full border p-1 rounded">' +
            '<option value="hr">HR</option>' +
            '<option value="manager">Manager</option>' +
            '</select>'
        ).find('select').val(oldData[row.data('id')].role);

        row.find('.department').html(
            '<select class="w-full border p-1 rounded">' +
            '<option value="IT">IT</option>' +
            '<option value="Sales">Sales</option>' +
            '<option value="HR">HR</option>' +
            '</select>'
        ).find('select').val(oldData[row.data('id')].department);
    });

    $(document).on('click', '.cancelInline', function () {
        let row = $(this).closest('tr');
        let data = oldData[row.data('id')];

        row.find('.name').text(data.name);
        row.find('.email').text(data.email);
        row.find('.role').text(data.role);
        row.find('.department').text(data.department);

        row.find('.saveInline,.cancelInline').hide();
        row.find('.editInline').show();
    });

    $(document).on('click', '.saveInline', function () {
        let row = $(this).closest('tr');

        let payload = {
            id: row.data('id'),
            name: row.find('.name input').val(),
            email: row.find('.email input').val(),
            role: row.find('.role select').val(),
            department: row.find('.department select').val()
        };

        $.ajax({
            url: '/admin/updateUser',
            type: 'POST',
            dataType: 'json',
            data: payload,
            success: function (res) {
                if (res.status === 'success') {
                    row.find('.name').text(payload.name);
                    row.find('.email').text(payload.email);
                    row.find('.role').text(payload.role);
                    row.find('.department').text(payload.department);

                    row.find('.saveInline,.cancelInline').hide();
                    row.find('.editInline').show();
                } else {
                    alert('Update failed');
                }
            },
            error: function () {
                alert('Server error');
            }
        });
    });
});
</script>
</body>
</html>
