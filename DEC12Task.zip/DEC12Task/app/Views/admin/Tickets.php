<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Tickets</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
</head>

<body class="bg-gray-100 p-6">
<div class="max-w-4xl mx-auto">

<!-- ADD TICKET -->
<div class="bg-white p-6 rounded shadow mb-6">
<h2 class="text-xl font-bold mb-4">Add Ticket</h2>
<form id="/tickets/save" method="post" class="space-y-3">
<input type="text" name="ticket_name" placeholder="Ticket Name" required class="w-full border p-2 rounded">
<textarea name="description" placeholder="Description" required class="w-full border p-2 rounded"></textarea>
<button class="bg-blue-600 text-white px-4 py-2 rounded w-full">Add Ticket</button>
</form>
</div>

<!-- TICKETS TABLE -->
<div class="bg-white p-6 rounded shadow">
<h2 class="text-xl font-bold mb-4">Tickets</h2>

<table id="ticketsTable" class="w-full border">
<thead class="bg-gray-200">
<tr>
<th>ID</th>
<th>Ticket</th>
<th>Description</th>
<th>Created</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach($tickets as $t): ?>
<tr data-id="<?= $t['id'] ?>">
<td><?= $t['id'] ?></td>
<td class="ticket_name"><?= esc($t['ticket_name']) ?></td>
<td class="description"><?= esc($t['description']) ?></td>
<td><?= $t['created_at'] ?></td>
<td class="flex gap-2">
<button class="edit bg-yellow-500 text-white px-2 py-1 rounded">Edit</button>
<button class="save bg-green-600 text-white px-2 py-1 rounded hidden">Save</button>
<button class="cancel bg-gray-500 text-white px-2 py-1 rounded hidden">Cancel</button>
<a href="/admin/deleteTicket/<?= $t['id'] ?>" class="bg-red-500 text-white px-2 py-1 rounded" onclick="return confirm('Delete user?')">Delete</a>

</td>
</tr>
<?php endforeach; ?>
<select name="hr_user" class="w-full border p-2 rounded">
    <option value="">Select HR</option>
    <?php foreach($HR as $h): ?>
        <option value="<?= $h['id'] ?>"><?= esc($h['name']) ?> (<?= esc($h['department']) ?>)</option>
    <?php endforeach; ?>
</select>

</tbody>
</table>
</div>

</div>

<script>
$(document).ready(function () {

    $('#ticketsTable').DataTable();

    // ADD
    $('#addTicketForm').submit(function(e){
        e.preventDefault();
        $.post('/admin/ticket/save', $(this).serialize(), function(res){
            if(res.status === 'exists'){
                alert('Ticket already exists');
            } else {
                location.reload();
            }
        }, 'json');
    });
    $(document).on('click','.edit',function(){
        let row = $(this).closest('tr');
        row.find('.edit').hide();
        row.find('.save,.cancel').removeClass('hidden');

        row.find('.ticket_name').html('<input class="border p-1 w-full" value="'+row.find('.ticket_name').text()+'">');
        row.find('.description').html('<input class="border p-1 w-full" value="'+row.find('.description').text()+'">');
    });

    // CANCEL
    $(document).on('click','.cancel',function(){
        location.reload();
    });

    // SAVE
    $(document).on('click','.save',function(){
        let row = $(this).closest('tr');
        $.post('/ticket/update',{
            id: row.data('id'),
            ticket_name: row.find('.ticket_name input').val(),
            description: row.find('.description input').val()
        },function(){
            location.reload();
        },'json');
    });

    // DELETE
    $(document).on('click','.delete',function(){
        if(!confirm('Delete ticket?')) return;
        let row = $(this).closest('tr');
        $.ajax({
            url:'/admin/ticket/delete/'+row.data('id'),
            type:'DELETE',
            success:function(){
                row.remove();
            }
        });
    });

});
</script>
</body>
</html>
