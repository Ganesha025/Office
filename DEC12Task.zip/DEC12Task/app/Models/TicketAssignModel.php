<?php
namespace App\Models;

use CodeIgniter\Model;

class TicketAssignModel extends Model
{
    protected $table = 'ticket_assign';
    protected $primaryKey = 'id';
    protected $allowedFields = ['ticket_id', 'employee_id', 'assigned_at'];
    protected $useTimestamps = true;
    protected $createdField  = 'assigned_at';
    protected $updatedField  = '';

    // Get tickets assigned to a user with status
    public function getTicketsByUser($userId)
    {
        return $this->select('tickets.id as ticket_id, tickets.ticket_name, tickets.description, 
                              ticket_status.status, ticket_status.updated_at as status_updated_at')
                    ->join('tickets', 'tickets.id = ticket_assign.ticket_id')->join('ticket_status', 'ticket_status.ticket_assign_id = ticket_assign.id', 'left')->where('ticket_assign.employee_id', $userId)->findAll();
    }

    // Assign ticket to employee
    public function assignTicket($ticketId, $employeeId)
    {
        $this->insert([
            'ticket_id' => $ticketId,
            'employee_id' => $employeeId,
            'assigned_at' => date('Y-m-d H:i:s')
        ]);
        return $this->getInsertID();
    }

    // Update ticket status
    public function updateTicketStatus($assignId, $status)
    {
        $db = db_connect();
        $builder = $db->table('ticket_status');
        $builder->insert([
            'ticket_assign_id' => $assignId,
            'status' => $status,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
        return $db->insertID();
    }public function assignTasksToHR($hr_id,$task_ids){
    foreach($task_ids as $task_id){
        $exists=$this->db->table('task_assign')->where(['hr_id'=>$hr_id,'task_id'=>$task_id])->countAllResults();
        if(!$exists){
            $this->db->table('task_assign')->insert(['hr_id'=>$hr_id,'task_id'=>$task_id,'assigned_at'=>date('Y-m-d H:i:s')]);
        }
    }
    return true;
}

}
?>
