<?php
namespace App\Controllers;
use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\TicketsModel;
use App\Models\TicketAssignModel;
class AdminController extends BaseController {

    // Dashboard
    public function index(){
        return view("admin/index");
    }
    public function manageUsers() {
        $role = session()->get('role'); 
        $model = model(UserModel::class); 

        $data['users'] = $model->findAll();
        $data['role'] = $role;

        return view('admin/manageuser', $data);
    }public function saveUser(){
        $session = session();
        $role = $session->get('role');
        $data = [
            'name'       => $this->request->getPost('name'),
            'email'      => $this->request->getPost('email'),
            'password'   => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'role'       => $this->request->getPost('role'),
            'department' => $this->request->getPost('department'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $model = model(UserModel::class);
        $model->insert($data);

        $session->setFlashdata('success', 'User added successfully!');
        return redirect()->to('/admin/manageuser');
    }
public function updateUser(){
    $id = $this->request->getPost('id');

    if (!$id) {
        return $this->response->setJSON(['status' => 'error']);
    }

    $data = [
        'name'       => $this->request->getPost('name'),
        'email'      => $this->request->getPost('email'),
        'password'=> password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        'role'       => $this->request->getPost('role'),
        'department' => $this->request->getPost('department'),
        'updated_at' => date('Y-m-d H:i:s')
    ];

    $model = model(UserModel::class);
    $model->update($id, $data);

    return $this->response->setJSON(['status' => 'success']);
}public function deleteUser($id){    $model = model(UserModel::class);
    $model->delete($id);
    return redirect()->to('/admin/manageuser');
}public function TicketLoad() {
    $ticketModel = model(TicketsModel::class); 
    $userModel   = model(UserModel::class);

    $data['tickets'] = $ticketModel->findAll();
    $data['HR']      = $userModel->select('id, name, department')->where('role', 'hr')->findAll();
    return view('admin/Tickets', $data);
}
    public function saveTicket(){
    $model = model(TicketsModel::class);

    $model->insert([
        'ticket_name' => $this->request->getPost('ticket_name'),
        'description' => $this->request->getPost('description')
    ]);
        $ticketModel = model(TicketsModel::class); 
    $userModel   = model(UserModel::class);

    $data['tickets'] = $ticketModel->findAll();
    $data['HR']      = $userModel->select('id, name, department')->where('role', 'hr')->findAll();
    return view('admin/Tickets', $data);
}
public function updateTicket(){
    $id = $this->request->getPost('id');
    if (!$id) return $this->response->setJSON(['status'=>'error']);

    $model = model(TicketsModel::class);
    $model->update($id, [
        'ticket_name' => $this->request->getPost('ticket_name'),
        'description' => $this->request->getPost('description'),
        'updated_at'  => date('Y-m-d H:i:s')
    ]);

    return $this->response->setJSON(['status'=>'success']);
}
// // public function deleteTicket()
// // {
// //     $id = $this->request->getPost('id');
// //     model(TicketsModel::class)->delete($id);
// //     return $this->response->setJSON(['status'=>'success']);
// }

public function deleteTicket($id){    
    $model = model(TicketsModel::class);
    $model->delete($id);
    return redirect()->to('/admin/Tickets');
}

public function assignTicket()
{
    $ticketId   = $this->request->getPost('ticket_id');
    $employeeId = $this->request->getPost('employee_id');

    $model = model(TicketAssignModel::class);
    $model->assignTicket($ticketId, $employeeId);

    return $this->response->setJSON(['status'=>'success']);
}public function assign(){
    $hr_id=$this->request->getPost('hr_id');
    $task_ids=$this->request->getPost('task_ids');
    $model=new TicketsModel();
    $model->assignTasksToHR($hr_id,$task_ids);
    return $this->response->setJSON(['status'=>'success']);
}


}
?>
