<?php
namespace App\Controllers;
use \App\Controllers\BaseController;
use \App\Models\UserModel;

class UserController extends BaseController{

    public function index(){
        return view("login");
    }
 public function login(){
    $s = session();
    $u = model(UserModel::class)
          ->db->table('users')
          ->where('email', $this->request->getPost('email'))
          ->get()->getRow();

    if($u && password_verify($this->request->getPost('password'), $u->password)){
        $s->set([
            'email' => $u->email,
            'role'  => $u->role,
            'loggedIn' => true
        ]);

        $redirect = [
            'admin' => '/admin/index',
            'hr' => '/hr/index',
            'manager' => '/manager/index'
        ][$u->role] ?? '/login';

        return redirect()->to($redirect);
    }

    $s->setFlashdata('error', 'Invalid credentials');
    return redirect()->to('/login');
}

public function logout(){
    session()->destroy();
    return redirect()->to('/login');
}
}
?>