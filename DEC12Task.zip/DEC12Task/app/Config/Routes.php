<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'UserController::index');
$routes->get('/login', 'UserController::index');
$routes->post('/loginPage','UserController::login');


$routes->get('/hr/index', 'HrController::index');
$routes->get('/manager/index', 'ManagerController::index');
$routes->get('/logout','UserController::logout');

$routes->get('/admin/manageuser', 'AdminController::manageUsers');
$routes->get('admin/Tickets','AdminController::TicketLoad');
$routes->post('admin/Tickets','AdminController::saveTicket');

$routes->get('/admin/index', 'AdminController::index');

$routes->post('/admin/saveUser', 'AdminController::saveUser');
$routes->post('/admin/updateUser', 'AdminController::updateUser');
$routes->get('/admin/deleteUser/(:num)', 'AdminController::deleteUser/$1');

$routes->post('/admin/saveUser', 'AdminController::saveUser');
$routes->post('/tickets/save', 'AdminController::saveTicket');
$routes->post('/ticket/update', 'AdminController::updateTicket');
$routes->get('/admin/deleteTicket/(:num)', 'AdminController::deleteTicket/$1');
$routes->post('/admin/ticket/assign','AdminController::assign');