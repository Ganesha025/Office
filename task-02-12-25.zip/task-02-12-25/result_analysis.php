<?php
session_start();

// Process form submission
$stats = [];
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $marksInput = $_POST['marks'] ?? '';
    $rawMarks = array_map('trim', explode(',', $marksInput));

    $marks = [];

    foreach ($rawMarks as $m) {
        if ($m === '' || !is_numeric($m)) continue;

        $num = intval($m);

        // Auto-correct values above 100 or below 0
        if ($num > 100) $num = 100;
        if ($num < 0) $num = 0;

        $marks[] = $num;
    }

    // Validate student count (max 60)
    if (count($marks) > 60) {
        $_SESSION['error'] = "You cannot enter more than 60 marks.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    if (count($marks) > 0) {
        $totalStudents = count($marks);
        $average = round(array_sum($marks)/$totalStudents,2);
        $highest = max($marks);
        $lowest = min($marks);
        $passCount = count(array_filter($marks, fn($m) => $m >= 40));
        $passPercent = round(($passCount/$totalStudents)*100,2);

        $_SESSION['stats'] = [
            'average'=>$average,
            'highest'=>$highest,
            'lowest'=>$lowest,
            'passPercent'=>$passPercent,
            'marks'=>$marks
        ];

        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        $_SESSION['error'] = "Please enter valid marks.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

$stats = $_SESSION['stats'] ?? [];
$error = $_SESSION['error'] ?? '';
unset($_SESSION['stats'], $_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Semester Result Analysis Dashboard</title>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>

<style>
body {
    background: linear-gradient(to right, #4ade80, #fcd34d);
}
input:focus {
    outline: none;
    border-color: #f59e0b;
    box-shadow: 0 0 8px #fbbf24;
}
#marks,#departmentName{
    margin-bottom: 20px;
}
.bar-container { display:flex; align-items:flex-end; gap:6px; margin-top:20px; }
.bar { width:36px; background:linear-gradient(to top,#f97316,#fb923c); color:#fff; text-align:center; border-radius:6px 6px 0 0; position:relative; }
.bar span { display:block; padding:4px 0; font-size:12px; font-weight:600; }
.bar:hover::after { content: attr(data-mark); position:absolute; top:-28px; left:50%; transform:translateX(-50%); background:#f97316; color:white; padding:2px 6px; border-radius:4px; font-size:12px; }
.star{
    color:red;
}
</style>
</head>

<body class="min-h-screen flex items-center justify-center p-4">

<div class="w-full max-w-4xl bg-white rounded-3xl shadow-2xl p-10">

    <h2 class="text-4xl font-extrabold text-center text-amber-800 mb-8">
        Semester Result Analysis Dashboard
    </h2>

    <form id="marksForm" method="POST" class="space-y-6">
        <div>
            <label class="font-semibold text-gray-700 text-lg">
                Enter Department Name<span class="star">*</span>
            </label>

            <input type="text" name="departmentName" id="departmentName"
                   placeholder="e.g. Computer Applications"
                   class="mt-2 w-full p-4 border-2 border-gray-300 rounded-2xl text-lg">

            <div id="departmentNameError" class="text-red-600 text-sm mt-1"><?= $error ?></div>

            <label class="font-semibold text-gray-700 text-lg">
                Enter Student Marks (comma separated, max 60 students)<span class="star">*</span>
            </label>

            <input type="text" name="marks" id="marks"
                   placeholder="e.g. 55, 78, 90, 89"
                   class="mt-2 w-full p-4 border-2 border-gray-300 rounded-2xl text-lg">

            <div id="marksError" class="text-red-600 text-sm mt-1"><?= $error ?></div>
        </div>

        <button type="submit"
                class="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-white py-4 text-xl font-bold rounded-2xl hover:from-amber-600 hover:to-orange-600 transition-all shadow-lg">
            Analyze Results
        </button>
    </form>

    <?php if($stats): ?>
        <div class="mt-10 grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="bg-teal-50 rounded-2xl p-6 shadow-lg">
                <h3 class="text-lg font-semibold text-teal-700 mb-2">Average Marks</h3>
                <p class="text-2xl font-bold text-teal-900"><?= $stats['average'] ?></p>
            </div>
            <div class="bg-orange-50 rounded-2xl p-6 shadow-lg">
                <h3 class="text-lg font-semibold text-orange-700 mb-2">Highest Marks</h3>
                <p class="text-2xl font-bold text-orange-900"><?= $stats['highest'] ?></p>
            </div>
            <div class="bg-red-50 rounded-2xl p-6 shadow-lg">
                <h3 class="text-lg font-semibold text-red-700 mb-2">Lowest Marks</h3>
                <p class="text-2xl font-bold text-red-900"><?= $stats['lowest'] ?></p>
            </div>
            <div class="bg-yellow-50 rounded-2xl p-6 shadow-lg">
                <h3 class="text-lg font-semibold text-yellow-700 mb-2">Pass Percentage</h3>
                <p class="text-2xl font-bold text-yellow-900"><?= $stats['passPercent'] ?>%</p>
            </div>
        </div>

        <h3 class="text-xl font-bold text-amber-800 mt-10 mb-4">Bar Chart</h3>

        <div class="bar-container">
            <?php foreach($stats['marks'] as $m): $height = $m * 2; ?>
                <div class="bar" style="height:<?= $height ?>px;" data-mark="<?= $m ?>">
                    <span><?= $m ?></span>
                </div>
            <?php endforeach; ?>
        </div>

    <?php endif; ?>

</div>

<script>
$(document).ready(function(){

    $("#departmentName").focus();

    // Live correction & clearing error
    $("#departmentName").on("input", function() {
        let val = $(this).val();
        val = val.replace(/[^A-Za-z\s]/g, ''); // remove numbers & special chars
        val = val.substring(0,30); // limit to 30 chars
        $(this).val(val);

        if(val.length > 0){
            $("#departmentNameError").text('');
        }
    });

    $("#marks").on("input", function() {
        let text = $(this).val();
        let parts = text.split(',').map(s => s.trim());

        let corrected = parts.map(p => {
            if (p === "" || isNaN(p)) return p;
            let num = parseInt(p);
            if (num > 100) num = 100;  
            if (num < 0) num = 0;      
            return num;
        });

        $(this).val(corrected.join(', '));

        // Clear marks error if length <= 60
        let nonEmptyMarks = corrected.filter(p => p !== '');
        if(nonEmptyMarks.length <= 60 && nonEmptyMarks.length > 0){
            $("#marksError").text('');
        }
    });

    // Form validation on submit
    $("#marksForm").submit(function(e){
        let valid = true;

        // Check department name
        let deptVal = $("#departmentName").val().trim();
        if(deptVal === ''){
            $("#departmentNameError").text('This field is required');
            valid = false;
        }

        // Check marks
        let numbers = $("#marks").val().trim().split(',').map(s => s.trim()).filter(s => s !== '');
        if(numbers.length === 0){
            $("#marksError").text('This field is required');
            valid = false;
        } else if(numbers.length > 60){
            $("#marksError").text('You cannot enter more than 60 marks.');
            valid = false;
        }

        if(!valid) e.preventDefault();
    });

});
</script>



</body>
</html>
