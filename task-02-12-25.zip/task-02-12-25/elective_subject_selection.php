<?php
session_start();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentName = $_POST['studentName'] ?? '';
    $selected = $_POST['subjects'] ?? [];

    // Only store result if fields are filled
    if (!empty($studentName) && count($selected) > 0) {
        $nameSafe = htmlspecialchars($studentName);
        $_SESSION['result'] = "<div class='result'>Student Name: <b>{$nameSafe}</b><br>Selected Subjects: <b>".implode(', ', $selected)."</b></div>";
    }

    // Redirect to prevent POST resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Get result from session and clear it
$result = $_SESSION['result'] ?? '';
unset($_SESSION['result']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Elective Subject Selection</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<style>
* {margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;}
body {background: linear-gradient(135deg, #c3ecff, #f0f4f8);display:flex;justify-content:center;align-items:center;min-height:100vh;padding:20px;}
.container {background:white;width:100%;max-width:520px;padding:40px;border-radius:25px;box-shadow:0 12px 30px rgba(0,0,0,0.15);border:2px solid #3f51b5;}
h2 {text-align:center;margin-bottom:30px;font-size:28px;color:#3f51b5;font-weight:700;text-shadow:1px 1px 2px #a0a0a0;}
.form-group {margin-bottom:20px;position:relative;}
label {display:block;margin-bottom:8px;font-weight:500;color:#333;}
.star {color:red;margin-left:5px;}
input[type=text] {width:100%;padding:12px;border:1px solid #b0bec5;border-radius:12px;font-size:16px;transition:0.2s;background:#f9fcff;}
input[type=text]:focus {border-color:#3f51b5;outline:none;box-shadow:0 0 6px rgba(63,81,181,0.3);}
.checkbox-group {display:flex;flex-wrap:wrap;gap:15px;margin-top:10px;}
.checkbox-group label {flex:1 1 45%;display:flex;align-items:center;gap:10px;font-weight:500;color:#333;}
.btn {width:100%;padding:15px;background:#3f51b5;border:none;color:white;font-size:17px;border-radius:12px;font-weight:600;cursor:pointer;transition:0.3s;margin-top:20px;}
.btn:hover {background:#2c3b9e;}
.result {margin-top:25px;padding:20px;border-radius:15px;text-align:center;font-size:18px;font-weight:500;display:block;background:#d1ecf1;color:#0c5460;border:1px solid #bee5eb;}
.error {color:red;font-size:14px;margin-top:5px;position:absolute;bottom:-20px;}
</style>
</head>
<body>
<div class="container">
    <h2>Elective Subject Selection</h2>

    <form id="electiveForm" method="POST">
        <div class="form-group">
            <label>Student Name <span class="star">*</span></label>
            <input type="text" id="studentName" name="studentName" placeholder="Enter your name (letters only)" maxlength="15" autocomplete="off">
            <div class="error" id="nameError"></div>
        </div>

        <div class="form-group">
            <label>Select Your Elective Subjects (Max 3) <span class="star">*</span></label>
            <div class="checkbox-group">
                <label><input type="checkbox" name="subjects[]" value="Mathematics"> Mathematics</label>
                <label><input type="checkbox" name="subjects[]" value="Physics"> Physics</label>
                <label><input type="checkbox" name="subjects[]" value="Chemistry"> Chemistry</label>
                <label><input type="checkbox" name="subjects[]" value="Biology"> Biology</label>
                <label><input type="checkbox" name="subjects[]" value="Computer Science"> Computer Science</label>
                <label><input type="checkbox" name="subjects[]" value="Economics"> Economics</label>
                <label><input type="checkbox" name="subjects[]" value="History"> History</label>
                <label><input type="checkbox" name="subjects[]" value="Geography"> Geography</label>
                <label><input type="checkbox" name="subjects[]" value="Political Science"> Political Science</label>
                <label><input type="checkbox" name="subjects[]" value="Psychology"> Psychology</label>
            </div>
            <div class="error" id="subjectError"></div>
        </div>

        <button type="submit" class="btn">Submit</button>
    </form>

    <?php if($result != "") echo $result; ?>
</div>

<script>
$(document).ready(function(){
    // Focus on first input
    $('#studentName').focus();

    // Reset form and errors only if there is no result
    if($('.result').length === 0){
        $('#electiveForm')[0].reset();
        $('.error').text('');
    }

    // Student name validation
    $('#studentName').on('input', function(){
        let val = $(this).val();
        val = val.replace(/[^a-zA-Z\s]/g,''); // letters + space only
        if(val.length > 15) val = val.substring(0,15);
        $(this).val(val);
        if(val.length > 0) $('#nameError').text('');
    });

    // Limit checkbox selection to max 3
    $("input[type='checkbox']").on('change', function(){
        let checkedCount = $("input[type='checkbox']:checked").length;
        if(checkedCount >= 3){
            $("input[type='checkbox']:not(:checked)").prop('disabled', true);
        } else {
            $("input[type='checkbox']").prop('disabled', false);
        }
        if(checkedCount > 0) $('#subjectError').text('');
    });

    // Form submit validation
    $('#electiveForm').on('submit', function(e){
        let valid = true;
        let nameVal = $('#studentName').val().trim();
        let checkedCount = $("input[type='checkbox']:checked").length;

        if(nameVal === ''){
            $('#nameError').text('Student name is required');
            valid = false;
        }
        if(checkedCount === 0){
            $('#subjectError').text('Please select at least one subject');
            valid = false;
        }

        if(!valid) e.preventDefault();
    });
});
</script>
</body>
</html>
