<?php
$totalStudents = '';
$seatsPerRoom = '';
$seatingChart = [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Exam Seating Arrangement</title>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
<style>
/* Remove number input arrows */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
input[type=number] {
    -moz-appearance: textfield;
}

/* Scrollable table container */
.scroll-table {
    overflow-x: auto;
}

@media (min-width: 768px) {
    .grid-cols-dynamic {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 1.5rem;
    }
}
</style>
</head>
<body class="bg-gradient-to-r from-green-50 via-teal-50 to-cyan-50 min-h-screen flex flex-col items-center justify-start py-12 px-4">

<!-- Header -->
<h1 class="text-4xl font-extrabold text-gray-800 mb-10 text-center drop-shadow-lg">
    Exam Seating Arrangement
</h1>

<!-- Form -->
<div class="bg-white shadow-2xl rounded-2xl p-8 w-full max-w-md">
    <form id="seatingForm" class="space-y-6" novalidate>
        <div>
            <label class="block text-gray-700 font-semibold mb-2">Total Students <span class="text-red-500">*</span></label>
            <input type="number" id="total_students" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none" placeholder="Enter total number of students (0-1000)">
            <span id="totalError" class="text-red-500 text-sm mt-1"></span>
        </div>
        <div>
            <label class="block text-gray-700 font-semibold mb-2">Seats per Room <span class="text-red-500">*</span></label>
            <input type="number" id="seats_per_room" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none" placeholder="Enter seats per room (0-50)">
            <span id="seatsError" class="text-red-500 text-sm mt-1"></span>
        </div>
        <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg transition duration-300 shadow-lg">
            Generate Seating Chart
        </button>
    </form>
</div>

<!-- Seating Chart -->
<div id="chartContainer" class="mt-12 w-full max-w-6xl scroll-table"></div>

<script>
$(document).ready(function(){
    $('#total_students').focus();

    function generateSeatingChart(totalStudents, seatsPerRoom){
        const container = $('#chartContainer');
        container.empty();

        if(totalStudents === 0 || seatsPerRoom === 0) return;

        let roomsNeeded = Math.ceil(totalStudents / seatsPerRoom);
        let roll = 1;

        let chartHTML = '<h2 class="text-2xl font-bold mb-6 text-center text-gray-800">Seating Chart</h2>';
        chartHTML += '<div class="grid-cols-dynamic">';

        for(let room = 1; room <= roomsNeeded; room++){
            chartHTML += `<div class="bg-white p-6 rounded-xl shadow-lg border border-gray-200">`;
            chartHTML += `<h3 class="text-xl font-semibold mb-4 text-green-700">Room ${room}</h3>`;
            chartHTML += `<div class="grid grid-cols-4 gap-3">`;

            for(let seat = 1; seat <= seatsPerRoom; seat++){
                if(roll > totalStudents) break;
                chartHTML += `<div class="bg-green-50 border border-green-200 rounded-md text-center py-2 font-medium hover:bg-green-100 transition">Roll ${roll}</div>`;
                roll++;
            }

            chartHTML += `</div></div>`;
        }

        chartHTML += '</div>';
        container.html(chartHTML);
    }

    // Limit inputs and clear errors dynamically
    $('#total_students').on('input', function(){
        let val = parseInt($(this).val());
        if(isNaN(val) || val < 0) val = 0;
        if(val > 1000) val = 1000;
        $(this).val(val);
        if(val >= 0 && val <= 1000) $('#totalError').text('');
    });

    $('#seats_per_room').on('input', function(){
        let val = parseInt($(this).val());
        if(isNaN(val) || val < 0) val = 0;
        if(val > 50) val = 50;
        $(this).val(val);
        if(val >= 0 && val <= 50) $('#seatsError').text('');
    });

    $('#seatingForm').on('submit', function(e){
        e.preventDefault();
        $('#totalError').text('');
        $('#seatsError').text('');

        let total = parseInt($('#total_students').val());
        let seats = parseInt($('#seats_per_room').val());
        let valid = true;

        if(isNaN(total) || total < 0 || total > 1000){
            $('#totalError').text('Enter a valid number of students (0-1000).');
            valid = false;
        }
        if(isNaN(seats) || seats < 0 || seats > 50){
            $('#seatsError').text('Enter a valid number of seats per room (0-50).');
            valid = false;
        }

        if(valid){
            generateSeatingChart(total, seats);
        }
    });
});
</script>

</body>
</html>
