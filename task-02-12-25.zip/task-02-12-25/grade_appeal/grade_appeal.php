<?php
$name = $_POST['name'] ?? '';
$reg = $_POST['regno'] ?? '';
$subject = $_POST['subject'] ?? '';
$grade = $_POST['grade'] ?? '';
$reason = $_POST['reason'] ?? '';

// Check eligibility: only B, C, Fail are allowed
$eligibleGrades = ["B", "C", "Fail"];
$eligible = in_array($grade, $eligibleGrades);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Appeal Summary</title>
<style>
body {
    font-family: 'Poppins', sans-serif;
    background: #f5f5f5;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    min-height: 100vh;
    margin: 0;
    padding: 50px 20px;
}

.container {
    width: 550px;
    background: #ffffff;
    padding: 45px 50px;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.12);
    border-left: 6px solid #555555;
}

h2 {
    text-align: center;
    color: #333333;
    margin-bottom: 35px;
    font-size: 28px;
    font-weight: 700;
    letter-spacing: 1px;
}

p {
    font-size: 16px;
    margin: 16px 0;
    color: #333;
    line-height: 1.5;
}

p strong {
    font-weight: 600;
}

.status {
    font-weight: 600;
    color: #155724;
    background: #d4edda;
    padding: 10px 15px;
    border-radius: 10px;
    margin-top: 20px;
    text-align: center;
}

.ineligible {
    font-weight: 600;
    color: #721c24;
    background: #f8d7da;
    padding: 10px 15px;
    border-radius: 10px;
    margin-top: 20px;
    text-align: center;
}

.print-btn {
    width: 100%;
    background: #333333;
    padding: 14px;
    color: #fff;
    border: 0;
    border-radius: 12px;
    font-size: 17px;
    font-weight: 600;
    margin-top: 30px;
    cursor: pointer;
    transition: 0.3s;
}

.print-btn:hover {
    background: #111111;
}
</style>
</head>
<body>

<div class="container">
    <h2>Grade Appeal Summary</h2>

    <p><strong>Student Name:</strong> <?= htmlspecialchars($name) ?></p>
    <p><strong>Register Number:</strong> <?= htmlspecialchars($reg) ?></p>
    <p><strong>Subject:</strong> <?= htmlspecialchars($subject) ?></p>
    <p><strong>Current Grade:</strong> <?= htmlspecialchars($grade) ?></p>
    <p><strong>Reason for Appeal:</strong> <?= nl2br(htmlspecialchars($reason)) ?></p>

    <?php if($eligible): ?>
        <p class="status">Your appeal is eligible and submitted successfully.</p>
    <?php else: ?>
        <p class="ineligible">Your grade is not eligible for appeal. Only grades B, C, or Fail can be appealed.</p>
    <?php endif; ?>

    <button class="print-btn" onclick="window.print()">Print Appeal Summary</button>
</div>

</body>
</html>
