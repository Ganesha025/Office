<?php
$student_name = $_POST['student_name'];
$subjects = $_POST['subject'];
$attendance = $_POST['attendance'];
$subjectCount = count($subjects);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Attendance Pattern</title>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-r from-blue-100 via-purple-100 to-pink-100 min-h-screen flex items-center justify-center">

<div class="w-full max-w-4xl bg-white rounded-3xl shadow-2xl p-10 relative overflow-hidden">
    <!-- Decorative gradient circles -->
    <div class="absolute -top-20 -left-20 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>
    <div class="absolute -bottom-20 -right-20 w-96 h-96 bg-pink-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>

    <h2 class="text-3xl font-extrabold text-center text-blue-800 mb-6">📊 Attendance Pattern for <?= htmlspecialchars($student_name) ?></h2>

    <div class="overflow-x-auto">
        <table class="w-full border-collapse text-left rounded-lg overflow-hidden shadow-lg">
            <thead class="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                <tr>
                    <th class="p-3">Subject</th>
                    <th class="p-3 cursor-pointer" id="sortAttendance">Attendance % &#x25B2;&#x25BC;</th>
                    <th class="p-3">Status</th>
                </tr>
            </thead>
            <tbody id="attendanceBody">
                <?php for($i=0;$i<$subjectCount;$i++):
                    $status = ($attendance[$i] < 75) ? "Low" : "OK";
                    $rowClass = ($attendance[$i] < 75) ? "bg-red-200 font-semibold" : "bg-white";
                ?>
                <tr class="<?= $rowClass ?> hover:bg-gray-100 transition">
                    <td class="p-3"><?= htmlspecialchars($subjects[$i]) ?></td>
                    <td class="p-3"><?= htmlspecialchars($attendance[$i]) ?>%</td>
                    <td class="p-3"><?= $status ?></td>
                </tr>
                <?php endfor; ?>
            </tbody>
        </table>
    </div>

    <!--<button onclick="window.print()" class="w-full mt-6 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 font-bold rounded-2xl hover:from-blue-700 hover:to-purple-700 transition-all">Print Attendance</button>-->
</div>

<script>
// jQuery sorting by Attendance %
$("#sortAttendance").click(function(){
    let rows = $("#attendanceBody tr").get();

    rows.sort(function(a, b){
        let A = parseInt($(a).children("td").eq(1).text());
        let B = parseInt($(b).children("td").eq(1).text());
        return B - A; // descending order
    });

    $.each(rows, function(index, row){
        $("#attendanceBody").append(row);
    });
});
</script>

</body>
</html>
