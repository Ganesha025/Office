<?php
$reg = $_POST['regno'];
$dept = $_POST['department'];
$sem = $_POST['semester'];

$subjects = [
    "BCA" => [
        "1" => ["C Programming","Digital Logic","Maths–I","Office Automation","Communicative English","IT Fundamentals"],
        "2" => ["OOPs with Java","Database Management","Statistics–I","OS Concepts","Web Tech Basics","Value Education"],
        "3" => ["DSA","Python Programming","Computer Networks","Software Engineering","Maths–II","Linux Admin"],
        "4" => ["Java Advanced","Web Development","Data Mining","Operating Systems","Mobile App Development","Professional Ethics"],
        "5" => ["Cloud Computing","Big Data Analytics","AI Basics","Software Testing","Entrepreneurship","Project Management"],
        "6" => ["Cybersecurity","Machine Learning","Internet of Things","Advanced Database","UI/UX Design","Capstone Project"]
    ],
    "CS" => [
        "1" => ["C Programming","Physics","Maths–I","Unix Basics","English","ICT Skills"],
        "2" => ["C++","Data Structures","DBMS","Computer Architecture","Statistics","Communication Skills"],
        "3" => ["Java","Discrete Maths","OS","Networks","RDBMS","Aptitude–I"],
        "4" => ["Algorithms","Web Technologies","Computer Graphics","Software Engg","AI Intro","Soft Skills"],
        "5" => ["Data Mining","Cloud Computing","Machine Learning","Cybersecurity","Project Management","Ethics"],
        "6" => ["Advanced AI","Big Data","IoT","Robotics","UI/UX Design","Capstone Project"]
    ],
    "IT" => [
        "1" => ["Basic Electronics","Programming in C","Maths–I","English","Computer Basics","Environmental Studies"],
        "2" => ["Web Development","Database Systems","Java Fundamentals","Statistics","OS Concepts","Soft Skills"],
        "3" => ["Python","Cloud Fundamentals","Networks","Data Structures","OS Lab","Aptitude–I"],
        "4" => ["Software Dev","Web App Design","DBMS Advanced","AI Basics","Networking","Professional Ethics"],
        "5" => ["Cybersecurity","Mobile App Dev","Big Data","Machine Learning","Entrepreneurship","Project Management"],
        "6" => ["Cloud Computing","IoT","Advanced AI","Robotics","UI/UX Design","Capstone Project"]
    ]
];

$subList = $subjects[$dept][$sem];

// Generate future exam dates starting from 10 days from now
$examDates = [];
$startDate = strtotime("+10 days");
foreach ($subList as $index => $subject) {
    $examDates[$subject] = date("d-M-Y", strtotime("+$index days", $startDate));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Hall Ticket</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-r from-blue-100 via-purple-100 to-pink-100 min-h-screen flex items-center justify-center">

<div class="w-full max-w-3xl bg-white rounded-3xl shadow-2xl p-10 relative overflow-hidden">
    <!-- Decorative Gradient Circles -->
    <div class="absolute -top-32 -left-32 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>
    <div class="absolute -bottom-32 -right-32 w-96 h-96 bg-pink-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>

    <h2 class="text-4xl font-extrabold text-center text-blue-800 mb-6">🎟️ Exam Hall Ticket</h2>

    <div class="space-y-2 text-gray-700">
        <p><span class="font-semibold text-gray-800">Register Number:</span> <?= htmlspecialchars($reg) ?></p>
        <p><span class="font-semibold text-gray-800">Department:</span> <?= htmlspecialchars($dept) ?></p>
        <p><span class="font-semibold text-gray-800">Semester:</span> <?= htmlspecialchars($sem) ?></p>
    </div>

    <h3 class="mt-6 text-2xl font-semibold text-blue-700 mb-4">Subjects & Exam Dates</h3>

    <table class="w-full text-left border-collapse">
        <thead>
            <tr class="bg-blue-600 text-white">
                <th class="py-3 px-4 rounded-tl-xl">S.No</th>
                <th class="py-3 px-4">Subject Name</th>
                <th class="py-3 px-4 rounded-tr-xl">Exam Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            foreach ($subList as $subject) {
                echo "<tr class='border-b border-gray-200 even:bg-blue-50'>";
                echo "<td class='py-2 px-4'>$i</td>";
                echo "<td class='py-2 px-4'>$subject</td>";
                echo "<td class='py-2 px-4'>{$examDates[$subject]}</td>";
                echo "</tr>";
                $i++;
            }
            ?>
        </tbody>
    </table>

    <button class="mt-6 w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 font-bold rounded-2xl hover:from-blue-700 hover:to-purple-700 transition-all" onclick="window.print()" autofocus>Print Hall Ticket</button>
</div>

</body>
</html>
