<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Hall Ticket Generator</title>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-r from-blue-200 via-purple-200 to-pink-200 min-h-screen flex items-center justify-center">

<div class="w-full max-w-lg bg-white rounded-3xl shadow-2xl p-10 relative overflow-hidden">
    <!-- Decorative Gradient Circles -->
    <div class="absolute -top-32 -left-32 w-72 h-72 bg-purple-400 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>
    <div class="absolute -bottom-32 -right-32 w-96 h-96 bg-pink-400 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>

    <h2 class="text-3xl font-extrabold text-center text-blue-800 mb-8">🎟️ Hall Ticket Generator</h2>

    <form id="hallForm" method="post" action="hall_ticket.php" class="space-y-6">

        <!-- Register Number -->
        <div class="flex flex-col relative">
            <label class="font-semibold text-gray-700">Register Number <span class="text-red-600">*</span></label>
            <input type="text" name="regno" id="regno" placeholder="e.g., 22UCA120" class="p-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" autofocus>
            <span class="error text-red-600 text-sm mt-1 hidden"></span>
        </div>

        <!-- Department -->
        <div class="flex flex-col relative">
            <label class="font-semibold text-gray-700">Department <span class="text-red-600">*</span></label>
            <select name="department" id="department" class="p-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Select Department</option>
                <option value="BCA">BCA</option>
                <option value="CS">Computer Science</option>
                <option value="IT">Information Technology</option>
            </select>
            <span class="error text-red-600 text-sm mt-1 hidden"></span>
        </div>

        <!-- Semester -->
        <div class="flex flex-col relative">
            <label class="font-semibold text-gray-700">Semester <span class="text-red-600">*</span></label>
            <select name="semester" id="semester" class="p-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Select Semester</option>
                <option value="1">1st Semester</option>
                <option value="2">2nd Semester</option>
                <option value="3">3rd Semester</option>
                <option value="4">4th Semester</option>
                <option value="5">5th Semester</option>
                <option value="6">6th Semester</option>
            </select>
            <span class="error text-red-600 text-sm mt-1 hidden"></span>
        </div>

        <!-- Subjects Box -->
        <div id="subjects-box" class="bg-blue-50 p-6 rounded-xl border-l-4 border-blue-600 hidden">
            <h4 class="text-lg font-semibold text-blue-700 mb-3">Subjects:</h4>
            <ul id="subject-list" class="list-disc list-inside text-gray-700 space-y-1"></ul>
        </div>

        <button type="submit" class="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 font-bold rounded-2xl hover:from-blue-700 hover:to-purple-700 transition-all">Generate Hall Ticket</button>

    </form>
</div>

<script>
// Subjects for 6 semesters
const subjects = {
    "BCA": {
        "1": ["C Programming","Digital Logic","Maths–I","Office Automation","Communicative English","IT Fundamentals"],
        "2": ["OOPs with Java","Database Management","Statistics–I","OS Concepts","Web Tech Basics","Value Education"],
        "3": ["DSA","Python Programming","Computer Networks","Software Engineering","Maths–II","Linux Admin"],
        "4": ["Java Advanced","Web Development","Data Mining","Operating Systems","Mobile App Development","Professional Ethics"],
        "5": ["Cloud Computing","Big Data Analytics","AI Basics","Software Testing","Entrepreneurship","Project Management"],
        "6": ["Cybersecurity","Machine Learning","Internet of Things","Advanced Database","UI/UX Design","Capstone Project"]
    },
    "CS": {
        "1": ["C Programming","Physics","Maths–I","Unix Basics","English","ICT Skills"],
        "2": ["C++","Data Structures","DBMS","Computer Architecture","Statistics","Communication Skills"],
        "3": ["Java","Discrete Maths","OS","Networks","RDBMS","Aptitude–I"],
        "4": ["Algorithms","Web Technologies","Computer Graphics","Software Engg","AI Intro","Soft Skills"],
        "5": ["Data Mining","Cloud Computing","Machine Learning","Cybersecurity","Project Management","Ethics"],
        "6": ["Advanced AI","Big Data","IoT","Robotics","UI/UX Design","Capstone Project"]
    },
    "IT": {
        "1": ["Basic Electronics","Programming in C","Maths–I","English","Computer Basics","Environmental Studies"],
        "2": ["Web Development","Database Systems","Java Fundamentals","Statistics","OS Concepts","Soft Skills"],
        "3": ["Python","Cloud Fundamentals","Networks","Data Structures","OS Lab","Aptitude–I"],
        "4": ["Software Dev","Web App Design","DBMS Advanced","AI Basics","Networking","Professional Ethics"],
        "5": ["Cybersecurity","Mobile App Dev","Big Data","Machine Learning","Entrepreneurship","Project Management"],
        "6": ["Cloud Computing","IoT","Advanced AI","Robotics","UI/UX Design","Capstone Project"]
    }
};

// Show subjects dynamically
$("#department, #semester").on("change", function () {
    const dept = $("#department").val();
    const sem = $("#semester").val();
    if(dept && sem){
        $("#subject-list").html("");
        subjects[dept][sem].forEach(sub => $("#subject-list").append(`<li>${sub}</li>`));
        $("#subjects-box").slideDown();
    } else {
        $("#subjects-box").slideUp();
    }
});

// Live Register Number Validation
$("#regno").on("input", function(){
    let val = $(this).val().toUpperCase().replace(/[^A-Za-z0-9]/g,"").substring(0,8);
    $(this).val(val);

    const pattern = /^[0-9]{2}[A-Za-z]{3}[0-9]{3}$/;
    const error = $(this).siblings(".error");
    if(val.length === 8 && !pattern.test(val)){
        error.text("Invalid format").show();
    } else {
        error.hide();
    }
});

// Live Department/Semester validation
$("#department, #semester").on("change", function(){
    $(this).siblings(".error").hide();
});

// Form submit validation
$("#hallForm").submit(function(e){
    let firstInvalid = null;
    let valid = true;

    // Register
    const regVal = $("#regno").val().trim();
    const regPattern = /^[0-9]{2}[A-Za-z]{3}[0-9]{3}$/;
    if(regVal === ""){
        $("#regno").siblings(".error").text("Register number required").show();
        valid = false;
        firstInvalid = firstInvalid || "#regno";
    } else if(!regPattern.test(regVal)){
        $("#regno").siblings(".error").text("Invalid format").show();
        valid = false;
        firstInvalid = firstInvalid || "#regno";
    }

    // Department
    if($("#department").val() === ""){
        $("#department").siblings(".error").text("Please select department").show();
        valid = false;
        firstInvalid = firstInvalid || "#department";
    }

    // Semester
    if($("#semester").val() === ""){
        $("#semester").siblings(".error").text("Please select semester").show();
        valid = false;
        firstInvalid = firstInvalid || "#semester";
    }

    if(!valid){
        e.preventDefault();
        $(firstInvalid).focus();
    }
});
</script>

</body>
</html>
