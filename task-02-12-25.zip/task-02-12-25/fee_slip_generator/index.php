<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>Fee Slip Generator</title>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>

<style>
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; }
input[type=number] { -moz-appearance: textfield; }
.star{
    color:red;
}
</style>
</head>

<body class="bg-gradient-to-br from-blue-100 to-blue-200 min-h-screen flex justify-center py-10 px-4">

<div class="bg-white/90 p-8 rounded-2xl shadow-2xl w-full max-w-xl border">

<h1 class="text-3xl font-extrabold text-center text-blue-800 mb-6">
    Fee Slip Generator
</h1>

<form id="feeForm" action="slip.php" method="POST" target="_blank" class="space-y-5" novalidate>

    <!-- Student Name -->
    <div>
        <label class="font-semibold text-gray-700">Student Name<span class="star">*</span></label>
        <input type="text" name="student" class="field w-full border p-3 rounded-lg" id="name" autofocus>
        <p class="error text-red-600 text-sm hidden">Enter student name</p>
    </div>

    <!-- Tuition Fee -->
    <div>
        <label class="font-semibold text-gray-700">Tuition Fee<span class="star">*</span></label>
        <input type="number" name="tuition" class="field w-full border p-3 rounded-lg" id="tuition_fee">
        <p class="error text-red-600 text-sm hidden">Enter valid amount</p>
    </div>

    <!-- Exam Fee -->
    <div>
        <label class="font-semibold text-gray-700">Exam Fee<span class="star">*</span></label>
        <input type="number" name="exam" class="field w-full border p-3 rounded-lg" id="exam_fee">
        <p class="error text-red-600 text-sm hidden">Enter valid amount</p>
    </div>

    <!-- Lab Fee -->
    <div>
        <label class="font-semibold text-gray-700">Lab Fee<span class="star">*</span></label>
        <input type="number" name="lab" class="field w-full border p-3 rounded-lg" id="lab_fee">
        <p class="error text-red-600 text-sm hidden">Enter valid amount</p>
    </div>

    <!-- Category -->
    <div>
        <label class="font-semibold text-gray-700">Category<span class="star">*</span></label>
        <select name="category" id="category" class="field w-full border p-3 rounded-lg">
            <option value="">Select Category</option>
            <option value="Day Scholar">Day Scholar</option>
            <option value="Hosteller">Hosteller</option>
        </select>
        <p class="error text-red-600 text-sm hidden">Select a category</p>
    </div>

    <!-- Hostel Fields -->
    <div id="hostelFields" class="hidden">
        <div>
            <label class="font-semibold text-gray-700">Hostel Fee<span class="star">*</span></label>
            <input type="number" name="hostel" class="hostel field w-full border p-3 rounded-lg" id="hostel_fee">
            <p class="error text-red-600 text-sm hidden">Enter hostel fee</p>
        </div>
        <div>
            <label class="font-semibold text-gray-700">Mess Fee<span class="star">*</span></label>
            <input type="number" name="mess" class="hostel field w-full border p-3 rounded-lg" id="mess_fee">
            <p class="error text-red-600 text-sm hidden">Enter mess fee</p>
        </div>
    </div>

    <button class="w-full bg-blue-700 text-white p-3 rounded-xl text-lg font-semibold hover:bg-blue-800 transition">
        Generate Fee Slip
    </button>
</form>
</div>

<script>
$(document).ready(function () {

    $("#name").on("input", function() {
        let val = $(this).val();
        val = val.replace(/[^A-Za-z\s]/g, ''); // remove numbers & special chars
        val = val.substring(0,15); // limit to 15 chars
        $(this).val(val);
        $(this).next(".error").remove();
    });

    // ---------- Restrict Marks Input ----------
    $("#tuition_fee").on("input", function() {
        let val = $(this).val();
        val = val.replace(/[^0-9]/g, ''); // remove letters & special chars
        
        if(val > 100000) val = '100000'; // max 100
        $(this).val(val);
        $(this).next(".error").remove();
    });

    // ---------- Restrict Marks Input ----------
    $("#exam_fee").on("input", function() {
        let val = $(this).val();
        val = val.replace(/[^0-9]/g, '');
        
        if(val > 10000) val = '10000'; 
        $(this).val(val);
        $(this).next(".error").remove();
    });

    // ---------- Restrict Marks Input ----------
    $("#lab_fee").on("input", function() {
        let val = $(this).val();
        val = val.replace(/[^0-9]/g, '');
         
        if(val > 3000) val = '3000'; 
        $(this).val(val);
        $(this).next(".error").remove();
    });

    $("#hostel_fee").on("input", function() {
        let val = $(this).val();
        val = val.replace(/[^0-9]/g, '');
         
        if(val > 30000) val = '30000'; 
        $(this).val(val);
        $(this).next(".error").remove();
    });

    $("#mess_fee").on("input", function() {
        let val = $(this).val();
        val = val.replace(/[^0-9]/g, '');
         
        if(val > 10000) val = '10000'; 
        $(this).val(val);
        $(this).next(".error").remove();
    });

    // Show/Hide hostel section
    $("#category").change(function () {
        if ($(this).val() === "Hosteller") {
            $("#hostelFields").slideDown();
        } else {
            $("#hostelFields").slideUp();
            $(".hostel").val(""); // reset hostel inputs
        }
    });

    // Clear error on select change
    $("#category").on("change", function() {
        const err = $(this).next(".error");
        if ($(this).val() !== "") {
            err.addClass("hidden"); // hide error when valid option selected
        }
    });


    // Form validation
    $("#feeForm").submit(function (e) {

        let valid = true;
        $(".error").addClass("hidden");

        // validate non-hostel fields
        $(".field").not(".hostel").each(function () {
            const value = $(this).val().trim();
            const err = $(this).next(".error");

            if (value === "" || (this.type === "number" && value < 0)) {
                err.removeClass("hidden");
                valid = false;
            }
        });

        // validate hostel fields ONLY when Hosteller
        if ($("#category").val() === "Hosteller") {
            $(".hostel").each(function () {
                const value = $(this).val().trim();
                const err = $(this).next(".error");

                if (value === "" || value < 0) {
                    err.removeClass("hidden");
                    valid = false;
                }
            });
        }

        if (!valid) {
            e.preventDefault();
        }
    });

});
</script>

</body>
</html>
