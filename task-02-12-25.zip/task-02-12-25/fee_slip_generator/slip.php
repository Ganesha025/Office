<?php


$name = htmlspecialchars($_POST["student"]);
$tuition = intval($_POST["tuition"]);
$exam = intval($_POST["exam"]);
$lab = intval($_POST["lab"]);
$category = $_POST["category"];

$hostel = ($category === "Hosteller") ? intval($_POST["hostel"]) : 0;
$mess   = ($category === "Hosteller") ? intval($_POST["mess"]) : 0;

$total = $tuition + $exam + $lab + $hostel + $mess;
$date = date("d-m-Y");

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Fee Slip</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
body {
    background: linear-gradient(to bottom right, #bfdbfe, #dbeafe); /* match index gradient */
    font-family: sans-serif;
}
.slip-wrapper {
    width: 700px;
    background: white;
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15); /* soft shadow like index */
}
.table-row td {
    padding: 10px 0;
    border-bottom: 1px dashed #93c5fd; /* light blue dashed like theme */
}
.slip-title {
    letter-spacing: 1px;
    font-size: 22px;
    color: #1d4ed8; /* dark blue title */
}
.text-info {
    color: #1e40af; /* medium dark blue */
}
.total-amount {
    color: #1e3a8a; /* darker blue for total */
    font-size: 20px;
}
hr {
    border-color: #60a5fa; /* light blue hr */
}
</style>
</head>

<body class="flex justify-center py-10">

<div class="slip-wrapper">

    <!-- Header -->
    <div class="text-center mb-6">
        <h1 class="slip-title font-extrabold">VELLALAR COLLEGE FOR WOMEN</h1>
        <p class="text-sm text-info">Accredited with A+ Grade | Affiliated to Bharathiyar University</p>
        <hr class="mt-4">
        <h2 class="text-lg font-bold mt-3 text-info">FEE PAYMENT SLIP</h2>
        <p class="text-sm text-info">Date: <?= $date ?></p>
    </div>

    <!-- Student Details Box -->
    <div class="border border-blue-300 p-4 rounded mb-6 bg-blue-50">
        <p><strong>Student Name:</strong> <?= $name ?></p>
        <p><strong>Category:</strong> <?= $category ?></p>
    </div>

    <!-- Fees Table -->
    <table class="w-full text-left">
        <tr class="table-row">
            <td><strong>Tuition Fee</strong></td>
            <td class="text-right text-info">₹<?= $tuition ?></td>
        </tr>
        <tr class="table-row">
            <td><strong>Exam Fee</strong></td>
            <td class="text-right text-info">₹<?= $exam ?></td>
        </tr>
        <tr class="table-row">
            <td><strong>Lab Fee</strong></td>
            <td class="text-right text-info">₹<?= $lab ?></td>
        </tr>

        <?php if ($category === "Hosteller") : ?>
        <tr class="table-row">
            <td><strong>Hostel Fee</strong></td>
            <td class="text-right text-info">₹<?= $hostel ?></td>
        </tr>
        <tr class="table-row">
            <td><strong>Mess Fee</strong></td>
            <td class="text-right text-info">₹<?= $mess ?></td>
        </tr>
        <?php endif; ?>

        <tr>
            <td class="pt-5 text-lg font-bold total-amount"><strong>Total Payable</strong></td>
            <td class="pt-5 text-lg font-extrabold text-right total-amount">₹<?= $total ?></td>
        </tr>
    </table>

    <!-- Footer Section -->
    <hr class="mt-8">

    <div class="flex justify-between mt-8 text-sm text-info">
        <p><strong>Student Signature:</strong> _____________________</p>
        <p><strong>Office Seal:</strong> _____________________</p>
    </div>

    <p class="text-center text-xs text-info mt-6">
        * This is a system-generated slip. No handwritten corrections allowed.
    </p>

</div>

</body>
</html>
