<?php
session_start();

// Handle POST submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Store in session
    $_SESSION['studentName'] = trim($_POST['student_name'] ?? '');
    $_SESSION['subjects'] = $_POST['subjects'] ?? [];
    $_SESSION['credits'] = $_POST['credits'] ?? [];

    // Redirect to avoid resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Initialize variables
$result = '';
$missingCredits = 0;
$studentName = $_SESSION['studentName'] ?? '';
$subjects = $_SESSION['subjects'] ?? [];
$credits = $_SESSION['credits'] ?? [];

// Calculate result if data exists
if (!empty($studentName) && !empty($credits)) {
    $totalCredits = array_sum(array_map('intval', $credits));

    if ($totalCredits >= 120) {
        $result = "🎉 $studentName is Eligible for Graduation";
    } else {
        $missingCredits = 120 - $totalCredits;
        $result = "⚠ $studentName is Pending – Missing Credits: $missingCredits";
    }

    // Clear session after showing result once
    unset($_SESSION['studentName']);
    unset($_SESSION['subjects']);
    unset($_SESSION['credits']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Graduation Credit Checker</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>

<style>
.section-title { font-weight: 600; }
.subject-card { background: #f3e8ff; border-left: 4px solid #7c3aed; padding: 16px; border-radius: 8px; }
.subject-row { display: grid; grid-template-columns: 1fr 120px 50px; gap: 16px; align-items: center; }
.error-text { color: #dc2626; font-size: 13px; margin-top: 3px; }
.required-star { color: red; }
</style>
</head>
<body class="bg-purple-50 min-h-screen flex items-center justify-center p-6">

<div class="bg-white shadow-2xl rounded-2xl p-8 w-full max-w-2xl border border-purple-200">

    <!-- Header -->
    <h1 class="text-3xl font-bold text-center text-purple-700 mb-6">
        Graduation Credit Eligibility Checker
    </h1>

    <div class="bg-purple-100 text-purple-900 p-3 rounded-md mb-6 text-sm text-center">
        Minimum <strong>120 Credits</strong> are required to graduate.
    </div>

    <!-- FORM -->
    <form id="creditForm" method="POST" novalidate>

        <!-- Student Name -->
        <div class="mb-5">
            <label class="font-medium">Student Name <span class="required-star">*</span></label>
            <input type="text" name="student_name" id="studentName" class="border rounded-lg p-2 w-full mt-1" placeholder="Enter your Name">
            <p class="error-text hidden"></p>
        </div>

        <h2 class="section-title text-lg mb-3">Enter Subjects & Credits</h2>

        <div id="subjectsContainer" class="space-y-3">

            <div class="subject-card rounded-lg">
                <div class="subject-row">

                    <div>
                        <label class="font-medium">Subject Name <span class="required-star">*</span></label>
                        <input type="text" name="subjects[]" class="subject-input border rounded-lg p-2 w-full" id="subject" placeholder="Enter the Subject Name">
                        <p class="error-text hidden"></p>
                    </div>

                    <div>
                        <label class="font-medium">Credits <span class="required-star">*</span></label>
                        <input type="text" name="credits[]" class="credit-input border rounded-lg p-2 w-full" id="credits" placeholder="1-30">
                        <p class="error-text hidden"></p>
                    </div>

                    <button type="button" class="addSubject bg-purple-600 text-white px-3 py-1 rounded-lg hover:bg-purple-700">+</button>

                </div>
            </div>

        </div>

        <button type="submit" class="w-full mt-6 bg-purple-600 text-white py-3 rounded-lg text-lg font-semibold hover:bg-purple-700">
            Check Eligibility
        </button>

    </form>

    <!-- RESULT -->
    <?php if ($result): ?>
        <div class="mt-6 p-4 rounded-lg text-center 
            <?= $missingCredits > 0 ? 'bg-red-100 text-red-900' : 'bg-green-100 text-green-900' ?>">
            <strong><?= $result ?></strong>
        </div>
    <?php endif; ?>

</div>

<script>
$(document).ready(function() {

    // Focus first field
    $("#studentName").focus();

     // ---------- Restrict Student Name Input ----------
    $("#studentName,#subject").on("input", function() {
        let val = $(this).val();
        val = val.replace(/[^A-Za-z\s]/g, ''); // remove numbers & special chars
        val = val.substring(0,15); // limit to 15 chars
        $(this).val(val);
        $(this).next(".error").remove();
    });
  
    $("#credits").on("input", function() {
        let val = $(this).val();
        val = val.replace(/[^0-9]/g, ''); // remove letters & special chars
        if(val > 30) val = '30'; 
        $(this).val(val);
        $(this).next(".error").remove();
    });

    // Add subject row
    $(document).on("click", ".addSubject", function() {
        let newField = `
        <div class="subject-card rounded-lg">
            <div class="subject-row">
                <div>
                    <label class="font-medium">Subject Name <span class="required-star">*</span></label>
                    <input type="text" name="subjects[]" class="subject-input border rounded-lg p-2 w-full">
                    <p class="error-text hidden"></p>
                </div>
                <div>
                    <label class="font-medium">Credits <span class="required-star">*</span></label>
                    <input type="text" name="credits[]" class="credit-input border rounded-lg p-2 w-full">
                    <p class="error-text hidden"></p>
                </div>
                <button type="button" class="removeSubject bg-red-600 text-white px-3 py-1 rounded-lg hover:bg-red-700">-</button>
            </div>
        </div>`;
        $("#subjectsContainer").append(newField);
    });

    // Remove row
    $(document).on("click", ".removeSubject", function() {
        $(this).closest(".subject-card").remove();
    });

    // Clear error on typing
    $(document).on("input", ".subject-input, .credit-input, #studentName", function() {
        $(this).siblings(".error-text").addClass("hidden").text("");
    });

    // Validation
    $("#creditForm").submit(function(e) {

        let valid = true;
        $(".error-text").text("").addClass("hidden");

        // Validate Student Name
        if ($("#studentName").val().trim() === "") {
            $("#studentName").siblings(".error-text").removeClass("hidden").text("Student name is required.");
            valid = false;
        }

        // Validate Subject Name
        $(".subject-input").each(function() {
            if ($(this).val().trim() === "") {
                $(this).siblings(".error-text").removeClass("hidden").text("Subject name is required.");
                valid = false;
            }
        });

        // Validate Credits
        $(".credit-input").each(function() {
            let value = $(this).val().trim();
            if (value === "") {
                $(this).siblings(".error-text").removeClass("hidden").text("Credits are required.");
                valid = false;
            } else if (isNaN(value)) {
                $(this).siblings(".error-text").removeClass("hidden").text("Credits must be a number.");
                valid = false;
            } else if (parseInt(value) < 0) {
                $(this).siblings(".error-text").removeClass("hidden").text("Credits cannot be negative.");
                valid = false;
            }
        });

        if (!valid) e.preventDefault();
    });
});
</script>

</body>
</html>
