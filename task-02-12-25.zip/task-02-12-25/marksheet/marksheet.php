<?php
$name = $_POST['name'];
$m1 = $_POST['m1'];
$m2 = $_POST['m2'];
$m3 = $_POST['m3'];
$m4 = $_POST['m4'];
$m5 = $_POST['m5'];

$subject_names = ["Tamil", "C Programming", "C Programming Lab", "Elective", "English"];
$credits = [3,3,4,2,3];
$marks   = [$m1,$m2,$m3,$m4,$m5];

$totalCredits = array_sum($credits);

$weightedTotal = 0;
$breakdown = [];

for($i=0;$i<5;$i++){
    $contribution = ($marks[$i] * $credits[$i]) / $totalCredits;
    $weightedTotal += $marks[$i] * $credits[$i];
    $breakdown[$i] = round($contribution,2);
}

$weightedAverage = round($weightedTotal / $totalCredits,2);

if($weightedAverage >= 75)      $grade = "A";
else if($weightedAverage >= 60) $grade = "B";
else if($weightedAverage >= 50) $grade = "C";
else                            $grade = "Fail";
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Marksheet</title>

<style>
/* ---------- Global Styles ---------- */
body {
    font-family: 'Poppins', sans-serif;
    background: #e0e7ff;
    padding: 50px;
}

.ticket {
    width: 720px;
    margin: 50px auto;
    background: #ffffff;
    padding: 40px 45px;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    border-top: 6px solid #007bff;
}

h2 {
    text-align: center;
    color: #003366;
    margin-bottom: 20px;
    font-weight: 700;
}

h3 {
    color: #003366;
    margin-top: 15px;
    margin-bottom: 10px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table, th, td {
    border: 1px solid #444;
    padding: 12px;
    text-align: center;
}

th {
    background: #007bff;
    color: #fff;
}

.print-btn {
    width: 100%;
    background: #007bff;
    padding: 12px;
    color: #fff;
    border: 0;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    margin-top: 25px;
    cursor: pointer;
    transition: 0.3s;
}

.print-btn:hover {
    background: #0056b3;
}

.student-info {
    font-size: 16px;
    margin-bottom: 15px;
}
td.subject-name {
    text-align: left;
    padding-left: 10px; /* optional: some spacing from the border */
}

</style>
</head>
<body>

<div class="ticket">
    <h2>Student Marksheet</h2>

    <div class="student-info"><h3>Student Name: <?= htmlspecialchars($name) ?></h3></div>

    <h3>Weighted Average: <?= $weightedAverage ?></h3>
    <h3>Grade: <?= $grade ?></h3>

    <h3>Subject Contribution Breakdown</h3>

    <table>
        <tr>
            <th>Subject</th>
            <th>Marks</th>
            <th>Credit</th>
            <th>Contribution</th>
        </tr>

        <?php
        for($i=0;$i<5;$i++){
            echo "<tr>
                    <td class=\"subject-name\">{$subject_names[$i]}</td>
                    <td>{$marks[$i]}</td>
                    <td>{$credits[$i]}</td>
                    <td>{$breakdown[$i]}</td>
                  </tr>";
        }
        ?>
    </table>

    <button class="print-btn" onclick="window.print()">Print Marksheet</button>
</div>

</body>
</html>
