<?php
session_start();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $total = 120;
    $present = (int)($_POST['present'] ?? 0);
    if ($present > 120) $present = 120;
    $percentage = ($present >= 0) ? ($present / $total) * 100 : 0;
    $percentage = round($percentage,2);

    if ($percentage < 75) {
        $_SESSION['result'] = "<div class='result not-eligible'>Not Eligible (".$percentage."%)</div>";
    } else {
        $_SESSION['result'] = "<div class='result eligible'>Eligible (".$percentage."%)</div>";
    }

    // Redirect to same page to prevent POST resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Get result from session
$result = $_SESSION['result'] ?? '';
unset($_SESSION['result']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Attendance Eligibility Checker</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<style>
* {margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;}
body {background:#e8efff;display:flex;justify-content:center;align-items:center;min-height:100vh;padding:20px;}
.container {background:white;width:100%;max-width:480px;padding:35px;border-radius:20px;box-shadow:0 10px 25px rgba(0,0,0,0.12);}    
h2 {text-align:center;margin-bottom:25px;font-size:26px;color:#1a237e;font-weight:600;}
.form-group {margin-bottom:20px;position:relative;}
label {display:flex;align-items:center;margin-bottom:8px;font-weight:500;color:#333;}
.star {color:red;margin-left:5px;font-size:18px;}
input {width:100%;padding:12px;border:1px solid #b0bec5;border-radius:12px;font-size:16px;transition:0.2s;background:#f9fcff;}
input:focus {border-color:#3f51b5;outline:none;box-shadow:0 0 5px rgba(63,81,181,0.3);} 
input[readonly] {background:#eceff1;color:#555;}
.btn {width:100%;padding:14px;background:#3f51b5;border:none;color:white;font-size:17px;border-radius:12px;font-weight:600;cursor:pointer;transition:0.2s;margin-top:10px;}
.btn:hover {background:#2c3b9e;}
.preview-box {margin-top:12px;text-align:center;font-size:16px;font-weight:500;color:#444;}
.result {margin-top:22px;padding:18px;border-radius:12px;text-align:center;font-size:19px;font-weight:600;display:block;}
.eligible {background:#d4edda;color:#155724;border:1px solid #c3e6cb;}
.not-eligible {background:#f8d7da;color:#721c24;border:1px solid #f5c6cb;}
.error-msg {color:red;font-size:14px;position:absolute;bottom:-20px;left:0;}
</style>
</head>
<body>
<div class="container">
    <h2>Attendance Eligibility Checker</h2>

    <form id="attendanceForm" method="POST">
        <div class="form-group">
            <label>Student Name <span class="star">*</span></label>
            <input type="text" id="name" name="name" autocomplete="off" placeholder="Enter your name" autofocus>
        </div>

        <div class="form-group">
            <label>Total Working Days</label>
            <input type="text" id="total" name="total" value="120" readonly>
        </div>

        <div class="form-group">
            <label>Present Days <span class="star">*</span></label>
            <input type="text" id="present" name="present" autocomplete="off" placeholder="Enter 1 to 120" >
        </div>

        <div class="preview-box" id="preview">Percentage: 0%</div>

        <button type="submit" class="btn">Check Eligibility</button>
    </form>

    <?php
    if($result != "") {
        echo $result;
    }
    ?>
</div>

<script>
$(document).ready(function(){
    // Reset present days and preview on page load
    $("#present").val('');
    $("#preview").text("Percentage: 0%");

    // Calculate and update percentage
    function calculate() {
        let total = 120;
        let present = parseInt($("#present").val()) || 0;
        if(present > 120) present = 120;
        let percent = (present >= 0) ? (present / total * 100).toFixed(2) : 0;
        $("#preview").text("Percentage: " + percent + "%");
    }

    // Live input restriction for Present Days
    $("#present").on("input", function(){
        let val = $(this).val();
        val = val.replace(/\D/g, "");
        if(val !== "" && parseInt(val) > 120) val = "120";
        $(this).val(val);
        calculate();
    });

    // ---------- Restrict Student Name Input ----------
    $("#name").on("input", function() {
        let val = $(this).val();
        val = val.replace(/[^A-Za-z\s]/g, ''); // remove numbers & special chars
        val = val.substring(0,15); // limit to 15 chars
        $(this).val(val);
        $(this).next(".error").remove();
    });

    // Remove error message on input
    $("#name, #present").on("input", function(){
        $(this).next(".error-msg").remove();
    });

    // Form submit validation
    $("#attendanceForm").submit(function(e){
        let valid = true;

        if($("#name").val().trim() === ""){
            if($("#name").next(".error-msg").length === 0)
                $("#name").after('<span class="error-msg">This field is required</span>');
            valid = false;
        }
        if($("#present").val().trim() === ""){
            if($("#present").next(".error-msg").length === 0)
                $("#present").after('<span class="error-msg">This field is required</span>');
            valid = false;
        }

        if(!valid){
            e.preventDefault();
            // Focus first invalid field
            if($("#name").val().trim() === "") $("#name").focus();
            else $("#present").focus();
        }
    });
});
</script>
</body>
</html>
