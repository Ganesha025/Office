<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('exam/start', 'Exam::start');
$routes->post('exam/submit', 'Exam::submit');

$routes->get('/exam/compiler', 'Exam::compiler');
$routes->post('/exam/executeQuery', 'Exam::executeQuery');
$routes->get('/exam/fetchTables', 'Exam::fetchTables');
$routes->post('exam/getSchemaAjax', 'Exam::getSchemaAjax');
