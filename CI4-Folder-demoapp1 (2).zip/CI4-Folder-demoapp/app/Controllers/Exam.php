<?php
namespace App\Controllers;

use CodeIgniter\Controller;

class Exam extends Controller
{
    protected $db;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
    }

    // Load compiler view
    public function compiler()
    {
        $schema = $this->getSchema();
        return view('compiler', ['schema' => $schema]);
    }

    // Get schema for all tables
    // private function getSchema()
    // {
    //     $schema = [];
    //     $tables = $this->db->listTables();
    //     foreach ($tables as $table) {
    //         $fields = $this->db->getFieldNames($table);
    //         $schema[$table] = $fields;
    //     }
    //     return $schema;
    // }
   
    public function getSchemaAjax()
    {
        $db = \Config\Database::connect();

        $tables = $db->listTables();
        $schema = [];

        foreach ($tables as $table) {
            $fields = $db->getFieldNames($table);
            $schema[$table] = $fields;
        }

        echo json_encode($schema);
        exit;
    }



        public function executeQuery()
    {
        $query = $this->request->getPost('query');
        $response = ['result_html' => '', 'error_msg' => ''];

        try {
            $result = $this->db->query($query);

            // Only show SELECT query results in table format
            if (strpos(strtoupper($query), 'SELECT') === 0) {
                $rows = $result->getResultArray();
                if (count($rows) > 0) {
                    $fields = array_keys($rows[0]);
                    $html = '<table class="min-w-full"><thead class="bg-blue-600 dark:bg-blue-800 text-white"><tr>';
                    foreach ($fields as $f) {
                        $html .= "<th class='px-4 py-2 border border-blue-300 dark:border-blue-600'>$f</th>";
                    }
                    $html .= '</tr></thead><tbody>';
                    foreach ($rows as $row) {
                        $html .= "<tr class='hover:bg-blue-50 dark:hover:bg-slate-700'>";
                        foreach ($fields as $f) {
                            $html .= "<td class='px-4 py-2 border border-blue-200 dark:border-blue-700'>{$row[$f]}</td>";
                        }
                        $html .= '</tr>';
                    }
                    $html .= '</tbody></table>';
                    $response['result_html'] = $html;
                } else {
                    $response['result_html'] = '<p>No results found.</p>';
                }
            } else {
                $response['result_html'] = '<p>Query executed successfully.</p>';
            }

        } catch (\Exception $e) {
            $response['error_msg'] = $e->getMessage();
        }

        return $this->response->setJSON($response);
    }

        public function fetchTables()
    {
        $tables = [];
        $tableNames = $this->db->listTables();
        foreach ($tableNames as $table) {
            $result = $this->db->table($table)->limit(50)->get()->getResultArray();
            $fields = $this->db->getFieldNames($table);
            $tables[] = [
                'name' => $table,
                'fields' => $fields,
                'rows' => $result
            ];
        }
        return $this->response->setJSON($tables);
    }

    public function submit()
{
    $data = $this->request->getJSON();
    $code = $data->code ?? '';

    // For now, just return it as JSON to test
    return $this->response->setJSON([
        'status' => 'success',
        'received_code' => $code
    ]);

    // Later, you can save $code to DB or file if needed
}

}

