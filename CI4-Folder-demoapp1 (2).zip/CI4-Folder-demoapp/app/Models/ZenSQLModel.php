<?php namespace App\Models;

use CodeIgniter\Model;

class ZenSQLModel extends Model
{
    protected $table = 'ZenSQLHistory';
    protected $allowedFields = [
        'query_text',
        'status',
        'error_message'
    ];
}
