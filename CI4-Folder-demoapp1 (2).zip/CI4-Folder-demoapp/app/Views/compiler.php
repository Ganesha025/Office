<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZenSQL Compiler</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" href="https://reactnative.dev/img/header_logo.svg">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />


    <script>
        tailwind.config = { darkMode: 'class' }
    </script>

    <style>
        *{outline:none;transition:all .15s ease}
        textarea{scrollbar-width:none;-ms-overflow-style:none}
        textarea::-webkit-scrollbar{display:none}
        .editor-container{position:relative}
        #queryInput{background:transparent;position:relative;z-index:2;color:transparent;caret-color:#1e293b;resize:none}
        .dark #queryInput{caret-color:#e2e8f0}
        #highlight{position:absolute;top:0;left:0;padding:1rem;white-space:pre-wrap;word-wrap:break-word;pointer-events:none;z-index:1;font-family:monospace;font-size:0.875rem;line-height:1.25rem;overflow:hidden}
        .sql-keyword{color:#dc2626;font-weight:600}
        .dark .sql-keyword{color:#f87171}
    </style>
</head>
<body class="bg-blue-50 dark:bg-slate-900 min-h-screen p-4 sm:p-6 transition-colors duration-150">

<div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-blue-600 dark:text-blue-400">ZenSQL Compiler</h1>
        <button onclick="toggleDarkMode()" class="px-3 py-1 rounded bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-blue-400">
            Toggle Dark
        </button>
    </div>

    <!-- Query Editor -->
    <form id="queryForm">
        <div class="relative mb-4">
            <div class="editor-container bg-white dark:bg-slate-800 border border-blue-200 dark:border-blue-700 rounded-lg relative overflow-hidden flex">
                <div id="lineNumbers" class="w-12 text-right pr-2 pt-4 text-gray-400 dark:text-gray-500 font-mono text-sm select-none bg-transparent dark:bg-slate-900"></div>
                <div class="relative flex-1">
                    <div id="highlight" class="text-gray-900 dark:text-gray-100 font-mono text-sm pl-4 absolute top-0 left-0 w-full h-full pointer-events-none whitespace-pre-wrap break-words"></div>
                    <textarea id="queryInput" name="query" placeholder="Enter SQL query here..."
                              class="w-full h-full p-4 pl-4 font-mono text-sm bg-transparent outline-none resize-none overflow-auto"
                              rows="10" spellcheck="false"></textarea>
                </div>
            </div>
            <div id="suggestions" class="hidden fixed z-50 bg-white dark:bg-slate-800 border border-blue-200 dark:border-blue-700 rounded-lg shadow-lg max-h-60 overflow-y-auto text-sm text-gray-900 dark:text-gray-100"></div>
        </div>

        <button type="submit" class="bg-blue-600 dark:bg-blue-700 text-white px-6 py-2 rounded-lg hover:bg-blue-700 dark:hover:bg-blue-600 flex items-center gap-2">
            <span class="material-icons text-lg">play_arrow</span> Execute
        </button>
    </form>

    <div id="queryResult" class="mt-6"></div>

    <h2 class="text-xl font-semibold text-blue-900 dark:text-blue-300 mt-8 mb-4 flex items-center gap-2">
        <span class="material-icons">storage</span> Your Tables
    </h2>
    <div id="tablesContainer" class="grid grid-cols-1 gap-4"></div>
</div>

<script>
    // 🌟 Schema and SQL keywords from controller
    const schema = <?= json_encode($schema) ?>;
    const sqlKeywords = [
        'SELECT','FROM','WHERE','INSERT','UPDATE','DELETE','CREATE','ALTER','DROP','TABLE','INDEX','VIEW',
        'JOIN','INNER','LEFT','RIGHT','FULL','OUTER','CROSS','ON','AND','OR','NOT','IN','BETWEEN','LIKE','IS','NULL',
        'AS','DISTINCT','ORDER','BY','ASC','DESC','GROUP','HAVING','LIMIT','OFFSET','UNION','EXISTS','CASE','WHEN','THEN','ELSE','END'
    ];

    let allSuggestions = [...sqlKeywords];
    for (const table in schema) {
        allSuggestions.push(table);
        allSuggestions = allSuggestions.concat(schema[table]);
    }

    // Highlighting SQL keywords
    function highlightSQL(text) {
        const pattern = new RegExp('\\b(' + sqlKeywords.join('|') + ')\\b', 'gi');
        return text.replace(/[<>&]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;'}[c]))
                   .replace(pattern, '<span class="sql-keyword">$1</span>');
    }

    // Update line numbers and highlight
    const textarea = document.getElementById('queryInput');
    const lineNumbers = document.getElementById('lineNumbers');
    const highlight = document.getElementById('highlight');

    function updateLineNumbers() {
        const lines = textarea.value.split("\n").length;
        lineNumbers.innerHTML = Array.from({length: lines}, (_, i) => i + 1).join("<br>");
    }

    function syncScroll() {
        lineNumbers.scrollTop = textarea.scrollTop;
        highlight.scrollTop = textarea.scrollTop;
    }

    function updateHighlight() {
        highlight.innerHTML = highlightSQL(textarea.value) + "\n";
    }

    textarea.addEventListener("input", () => { updateLineNumbers(); updateHighlight(); });
    textarea.addEventListener("scroll", syncScroll);
    window.addEventListener("resize", updateLineNumbers);
    updateLineNumbers(); updateHighlight();

    // Dark mode toggle
    function toggleDarkMode() {
        document.documentElement.classList.toggle('dark');
    }

    // Execute query via AJAX
    $('#queryForm').on('submit', function(e) {
        e.preventDefault();
        const query = $('#queryInput').val();

        $.ajax({
            url: '/exam/executeQuery',
            method: 'POST',
            data: { query },
            dataType: 'json',
            success: function(res) {
                let html = '';
                if(res.error_msg) {
                    html += `<div class="p-3 mb-4 bg-red-50 dark:bg-red-900/50 text-red-700 dark:text-red-200 border border-red-200 dark:border-red-700 rounded-lg flex items-start gap-2">
                                <span class="material-icons text-lg">error</span>
                                <span>${res.error_msg}</span>
                            </div>`;
                }
                if(res.result_html) html += res.result_html;
                $('#queryResult').html(html);
                refreshTables();
            },
            error: function(xhr, status, error) {
                $('#queryResult').html(`<div class="p-3 mb-4 bg-red-50 dark:bg-red-900/50 text-red-700 dark:text-red-200 border border-red-200 dark:border-red-700 rounded-lg flex items-start gap-2">
                                            <span class="material-icons text-lg">error</span>
                                            <span>AJAX error: ${error}</span>
                                        </div>`);
            }
        });
    });

    // Refresh tables
    function refreshTables() {
        $.ajax({
            url: '/exam/fetchTables',
            method: 'GET',
            dataType: 'json',
            success: function(tables) {
                const container = $('#tablesContainer');
                container.empty();
                tables.forEach((table, index) => {
                    let html = `<div class="bg-white dark:bg-slate-800 border border-blue-200 dark:border-blue-700 rounded-lg shadow-md hover:shadow-lg transition-all duration-150">
                        <button onclick="toggleTable(${index})" class="w-full text-left px-4 py-3 font-semibold text-blue-900 dark:text-blue-300 flex justify-between items-center">
                            <span class="flex items-center gap-2">
                                <span class="material-icons text-lg">table_chart</span>${table.name}
                            </span>
                            <span class="material-icons text-blue-600 dark:text-blue-400 -rotate-180" id="expand-icon-${index}">expand_more</span>
                        </button>
                        <div id="table-${index}" class="overflow-x-auto hidden transition-all duration-200">`;
                    if(table.rows.length > 0) {
                        html += `<table class="min-w-full"><thead class="bg-blue-600 dark:bg-blue-800 text-white"><tr>`;
                        table.fields.forEach(f => html += `<th class='px-4 py-2 text-left text-sm border border-blue-300 dark:border-blue-600'>${f}</th>`);
                        html += `</tr></thead><tbody>`;
                        table.rows.forEach(row => {
                            html += `<tr class='hover:bg-blue-50 dark:hover:bg-slate-700 transition-colors duration-150'>`;
                            table.fields.forEach(f => html += `<td class='px-4 py-2 border border-blue-200 dark:border-blue-700 text-sm text-gray-900 dark:text-gray-100'>${row[f]}</td>`);
                            html += `</tr>`;
                        });
                        html += `</tbody></table>`;
                    } else {
                        html += `<p class="p-4 text-blue-500 dark:text-blue-400 flex items-center gap-2"><span class="material-icons">info</span>Table is empty.</p>`;
                    }
                    html += `</div></div>`;
                    container.append(html);
                });
            }
        });
    }

    function toggleTable(index) {
        const table = document.getElementById('table-' + index);
        const icon = document.getElementById('expand-icon-' + index);
        table.classList.toggle('hidden');
        icon.classList.toggle('-rotate-180');
    }

    // Initial fetch of tables
    refreshTables();
</script>
</body>
</html>
