<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
/*$routes->get('/', function() {
    return view('welcome_message');  // loads dashboard.php from app/Views/
});
$routes->get('/students/create', 'task1\StudentController::index');

$routes->post('/students/save', 'task1\StudentController::save');
$routes->get('/students/list', 'task1\StudentController::list');

$routes->get('/employees/create', 'task1\EmployeeController::create');
$routes->post('/employees/store', 'task1\EmployeeController::store'); 
$routes->get('/employees', 'task1\EmployeeController::index');   


$routes->get('/courses/create', 'task1\CourseController::create'); 
$routes->post('/courses/store', 'task1\CourseController::store'); 
$routes->get('/courses', 'task1\CourseController::index');   

$routes->get('/products/create', 'task1\ProductController::create');
$routes->post('/products/store', 'task1\ProductController::store');
$routes->get('/products', 'task1\ProductController::index');

$routes->get('/incidents/add', 'task1\IncidentController::add');
$routes->post('/incidents/save', 'task1\IncidentController::saveIncident');
$routes->get('/incidents', 'task1\IncidentController::viewIncidents');*/


$routes->get('/', 'helpersessiontask\AuthController::loginForm');
$routes->post('/loginCheck', 'helpersessiontask\AuthController::loginCheck');

$routes->get('/dashboard', 'helpersessiontask\AuthController::dashboard');
$routes->get('/logout', 'helpersessiontask\AuthController::logout');

$routes->post('/feedback/save', 'helpersessiontask\FeedbackController::saveFeedback');
$routes->post('/theme/apply', 'helpersessiontask\ThemeController::applyTheme');


$routes->get('cart-form', 'CartController::showForm');
$routes->post('add-cart', 'CartController::addToCart');
$routes->get('cart', 'CartController::viewCart');
$routes->get('remove/(:num)', 'CartController::removeItem/$1');



$routes->get('/login', 'RoleController::login');
$routes->post('/setRole', 'RoleController::setRole');
$routes->get('/adminPage', 'RoleController::adminPage');
$routes->get('/userPage', 'RoleController::userPage');
$routes->get('roll/login', 'RoleController::logout');
