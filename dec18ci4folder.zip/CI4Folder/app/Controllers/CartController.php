<?php
namespace App\Controllers;

use App\Models\ProductModel;
use CodeIgniter\Controller;

class CartController extends Controller
{
    // Show products from DB
    public function showForm()
    {
        helper(['form','url']);

        $model = new ProductModel();

        // ✅ CORRECT METHOD
        $data['products'] = $model->findAll();

        return view('cart_form', $data);
    }

    public function addToCart()
    {
        helper(['form','url']);
        $session = session();

        $item = [
            'name'     => $this->request->getPost('product_name'),
            'price'    => (int)$this->request->getPost('price'),
            'quantity' => (int)$this->request->getPost('quantity')
        ];

        if (!is_array($session->get('cart'))) {
            $session->set('cart', []);
        }

        $cart = $session->get('cart');
        $cart[] = $item;
        $session->set('cart', $cart);

        return redirect()->to('/cart');
    }

    public function viewCart()
    {
        helper(['form','url']);
        $data['cart'] = session()->get('cart') ?? [];
        return view('cart_view', $data);
    }

    public function removeItem($key)
    {
        $session = session();
        $cart = $session->get('cart');

        if (isset($cart[$key])) {
            unset($cart[$key]);
            $session->set('cart', array_values($cart));
        }

        return redirect()->to('/cart');
    }
}
