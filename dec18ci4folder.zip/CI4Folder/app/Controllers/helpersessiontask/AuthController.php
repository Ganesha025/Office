<?php
namespace App\Controllers\helpersessiontask;

use CodeIgniter\Controller;
use App\Models\helpersessiontask\UserModel;

class AuthController extends Controller
{
    public function loginForm()
    {
        helper(['form','url']);
        return view('helpersessiontask/login');
    }

    public function loginCheck()
    {
        $session = session();
        $model = new UserModel();

        $user = $model->where('email', $this->request->getPost('email'))->first();

        if ($user && $user['password'] == $this->request->getPost('password')) {

            $session->set([
                'user_id'   => $user['id'],
                'email'     => $user['email'],
                'role'      => $user['role'],
                'logged_in' => true
            ]);

            return redirect()->to('/dashboard');
        }

        return redirect()->back()->with('error','Invalid Login');
    }

    public function dashboard()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/');
        }

        return view('helpersessiontask/dashboard');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
}
