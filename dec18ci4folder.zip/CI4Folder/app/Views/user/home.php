<h2>User Page</h2>
<a href="<?= site_url('/logout') ?>">Logout</a>
<h3>Products</h3>

<table border="1" cellpadding="10">
    <tr>
        <th>Name</th>
        <th>Price</th>
        <th>Action</th>
    </tr>
    <?php foreach($products as $p): ?>
    <tr>
        <td><?= $p['name'] ?></td>
        <td><?= $p['price'] ?></td>
        <td>
            <a href="<?= site_url('addToCart/'.$p['id']) ?>">Add to Cart</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<h3>Cart</h3>
<table border="1" cellpadding="10">
    <tr>
        <th>Name</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Total</th>
        <th>Action</th>
    </tr>
    <?php if(!empty($cart)): ?>
        <?php foreach($cart as $item): ?>
        <tr>
            <td><?= $item['name'] ?></td>
            <td><?= $item['price'] ?></td>
            <td><?= $item['quantity'] ?></td>
            <td><?= $item['price'] * $item['quantity'] ?></td>
            <td>
                <a href="<?= site_url('removeItem/'.$item['id']) ?>">Remove</a>
            </td>
        </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr><td colspan="5">Cart is empty</td></tr>
    <?php endif; ?>
</table>
