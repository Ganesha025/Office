<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:90%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#343a40; color:#fff; }
    </style>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
</head>
<body>

<h2 style="text-align:center;">Product List</h2>

<table id="productslist">
    <thead>
    <tr>
        <th>ID</th>
        <th>Product Name</th>
        <th>Category</th>
        <th>Price</th>
        <th>Stock</th>
        <th>Description</th>
    </tr>
    </thead>
<tbody>
    <?php foreach ($products as $row): ?>
    <tr>
        <td><?= $row['product_id'] ?></td>
        <td><?= $row['product_name'] ?></td>
        <td><?= $row['category'] ?></td>
        <td><?= $row['price'] ?></td>
        <td><?= $row['stock_quantity'] ?></td>
        <td><?= $row['description'] ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<script>
$(document).ready(function(){
        $('#productslist').DataTable({
            paging:true,
            searching:true,
            ordering:true,
            info:true

        });
    });
    </script>

</body>
</html>
