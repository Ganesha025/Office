<!DOCTYPE html>
<html>
<head>
    <title>Success</title>
</head>
<body>

<h3>✅ Your message has been sent successfully!</h3>

<a href="<?= base_url('contact') ?>">Send another message</a>

</body>
</html>
