<?php helper(['url']); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1f4037, #99f2c8);
            margin: 0;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #fff;
            margin-bottom: 30px;
        }

        .cart-container {
            max-width: 900px;
            margin: auto;
            background: #ffffff;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 12px 30px rgba(0,0,0,0.2);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th {
            background: #2c3e50;
            color: #fff;
            padding: 12px;
            text-align: center;
        }

        td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #eee;
        }

        tr:hover {
            background-color: #f7f7f7;
        }

        .price {
            color: #27ae60;
            font-weight: bold;
        }

        .subtotal {
            font-weight: bold;
            color: #333;
        }

        .remove-btn {
            text-decoration: none;
            padding: 6px 12px;
            background: linear-gradient(135deg, #ff512f, #dd2476);
            color: #fff;
            border-radius: 6px;
            font-size: 14px;
            transition: transform 0.2s ease;
        }

        .remove-btn:hover {
            transform: scale(1.05);
        }

        .total-row td {
            font-size: 18px;
            font-weight: bold;
            background: #f1f1f1;
        }

        .actions {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
        }

        .btn {
            padding: 12px 20px;
            border-radius: 25px;
            font-weight: bold;
            text-decoration: none;
            color: #fff;
            transition: background 0.3s ease;
        }

        .btn-add {
            background: #2c3e50;
        }

        .btn-add:hover {
            background: #000;
        }

        .btn-checkout {
            background: linear-gradient(135deg, #ff512f, #dd2476);
        }

        .btn-checkout:hover {
            background: linear-gradient(135deg, #dd2476, #ff512f);
        }

        .empty {
            text-align: center;
            font-size: 18px;
            padding: 30px;
            color: #555;
        }
    </style>
</head>
<body>

<h2>🛒 Your Shopping Cart</h2>

<div class="cart-container">

<?php
$total = 0;

if (!empty($cart) && is_array($cart)):
?>
<table>
    <tr>
        <th>Product</th>
        <th>Price</th>
        <th>Qty</th>
        <th>Subtotal</th>
        <th>Action</th>
    </tr>

<?php foreach ($cart as $key => $item):
    $sub = $item['price'] * $item['quantity'];
    $total += $sub;
?>
    <tr>
        <td><?= esc($item['name']) ?></td>
        <td class="price">₹ <?= esc($item['price']) ?></td>
        <td><?= esc($item['quantity']) ?></td>
        <td class="subtotal">₹ <?= $sub ?></td>
        <td>
            <a class="remove-btn" href="<?= site_url('remove/'.$key) ?>">Remove</a>
        </td>
    </tr>
<?php endforeach; ?>

    <tr class="total-row">
        <td colspan="3">Total</td>
        <td colspan="2">₹ <?= $total ?></td>
    </tr>
</table>

<div class="actions">
    <a class="btn btn-add" href="<?= site_url('cart-form') ?>">➕ Add More</a>
    <a class="btn btn-checkout" href="#">Checkout</a>
</div>

<?php else: ?>
    <div class="empty">
        🛍️ Your cart is empty
        <br><br>
        <a class="btn btn-add" href="<?= site_url('cart-form') ?>">Start Shopping</a>
    </div>
<?php endif; ?>

</div>

</body>
</html>
