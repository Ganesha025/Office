<?php include "db.php";

if(!isset($_SESSION['user_id'])) die("Login required");

$uid = $_SESSION['user_id'];
$to = $_GET['u'];
?>
<html>
<body>

<div id="status"></div>

<div id="messages" style="height:300px;overflow:auto;border:1px solid #ccc"></div>

<div id="typing"></div>

<input id="msg" onkeyup="typing()" placeholder="Type...">
<button onclick="sendMsg()">Send</button>

<script>
function loadMessages(){
    fetch("loadmsg.php?u=<?php echo $to ?>")
    .then(r=>r.text())
    .then(d=>{
        document.getElementById("messages").innerHTML = d;
        messages.scrollTop = messages.scrollHeight;
    });
}

function sendMsg(){
    let m = document.getElementById("msg").value;
    fetch("send.php?u=<?php echo $to ?>&m="+encodeURIComponent(m));
    document.getElementById("msg").value = "";
}

function typing(){
    fetch("typing.php?to=<?php echo $to ?>&t=1");
    clearTimeout(window.typingTimeout);
    window.typingTimeout = setTimeout(()=>{
        fetch("typing.php?to=<?php echo $to ?>&t=0");
    },1000);
}

function checkTyping(){
    fetch("gettyping.php?u=<?php echo $to ?>")
    .then(r=>r.text())
    .then(d=> document.getElementById("typing").innerHTML = d);
}

function checkStatus(){
    fetch("status.php?u=<?php echo $to ?>")
    .then(r=>r.text())
    .then(d=> document.getElementById("status").innerHTML = d);
}

setInterval(loadMessages,1000);
setInterval(checkTyping,500);
setInterval(checkStatus,2000);
</script>

</body>
</html>
