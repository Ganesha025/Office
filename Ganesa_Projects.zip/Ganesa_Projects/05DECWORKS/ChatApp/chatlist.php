<?php include "db.php";

if(!isset($_SESSION['user_id'])) die("Login required");

$uid = $_SESSION['user_id'];
?>
<html>
<body>
<h3>Search User</h3>
<input id="search" onkeyup="searchUser(this.value)" placeholder="Search Zen1234">

<div id="suggestions"></div>

<h3>Chats</h3>
<div id="chatlist"></div>

<script>
function searchUser(txt){
    fetch("search.php?q="+txt)
    .then(r=>r.text())
    .then(d=> document.getElementById('suggestions').innerHTML=d);
}

function loadChats(){
    fetch("chatlist_ajax.php")
    .then(r=>r.text())
    .then(d=> document.getElementById('chatlist').innerHTML=d);
}
setInterval(loadChats,2000);
loadChats();
</script>
</body>
</html>
