<?php
session_start();

$conn = new mysqli("localhost", "root", "", "chatapps");
$conn->query("CREATE DATABASE IF NOT EXISTS chatapps");
$conn->select_db("chatapps");
$conn->query("CREATE TABLE IF NOT EXISTS users(
  id INT AUTO_INCREMENT PRIMARY KEY,
  userid VARCHAR(20) UNIQUE,
  username VARCHAR(200),
  password VARCHAR(200),
  last_active DATETIME
)");

$conn->query("CREATE TABLE IF NOT EXISTS chats(
  id INT AUTO_INCREMENT PRIMARY KEY,
  sender_id INT,
  receiver_id INT,
  message TEXT,
  timestamp DATETIME
)");

$conn->query("CREATE TABLE IF NOT EXISTS typing(
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  to_user INT,
  is_typing TINYINT(1)
)");

if(isset($_SESSION['user_id'])){
  $uid = $_SESSION['user_id'];
  $conn->query("UPDATE users SET last_active=NOW() WHERE id=$uid");
}
?>
