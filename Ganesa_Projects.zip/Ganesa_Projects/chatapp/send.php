<?php include "db.php";
$uid=$_SESSION['user_id'];
$toid=$conn->query("SELECT id FROM users WHERE userid='".$_GET['u']."'")->fetch_assoc()['id'];
$msg=$_GET['m'];
$conn->query("INSERT INTO chats(sender_id,receiver_id,message,timestamp)
 VALUES($uid,$toid,'$msg',NOW())");
?>