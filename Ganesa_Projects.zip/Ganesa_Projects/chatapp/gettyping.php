<?php include "db.php";
$uid=$_SESSION['user_id'];
$fid=$conn->query("SELECT id FROM users WHERE userid='".$_GET['u']."'")->fetch_assoc()['id'];
$q=$conn->query("SELECT * FROM typing WHERE user_id=$fid AND to_user=$uid");
if($q->num_rows) echo "<small>Typing...</small>";
?>