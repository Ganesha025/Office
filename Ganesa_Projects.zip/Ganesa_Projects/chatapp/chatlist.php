<?php 
include "db.php"; 
if(!isset($_SESSION['user_id'])) die("Login required");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">

<!-- Tailwind & Google Icons -->
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<title>Zen1234 Chat</title>
</head>

<body class="bg-gray-100 h-screen flex overflow-hidden">

<!-- LEFT SIDEBAR (Chats + Search) -->
<div class="w-full md:w-1/3 lg:w-1/4 bg-white border-r shadow-xl flex flex-col">

    <!-- Header -->
    <div class="p-4 border-b flex items-center justify-between bg-white">
        <h2 class="text-xl font-bold text-gray-700">Zen1234</h2>
        <span class="material-icons text-gray-600 cursor-pointer hover:text-black">more_vert</span>
    </div>

    <!-- Search Bar -->
    <div class="p-3 border-b">
        <div class="flex items-center bg-gray-100 rounded-full px-4 py-2">
            <span class="material-icons text-gray-400">search</span>
            <input id="search" 
                onkeyup="searchUser(this.value)" 
                placeholder="Search users..."
                class="ml-2 bg-transparent outline-none w-full text-gray-700">
        </div>
        <div id="suggestions" class="mt-2 text-sm"></div>
    </div>

    <!-- Chat List (Auto Reload) -->
    <div id="chatlist" class="flex-1 overflow-y-auto p-2"></div>
</div>


<!-- RIGHT PANEL (placeholder when no chat opened) -->
<div class="hidden md:flex flex-1 items-center justify-center text-gray-400 text-xl">
    <div class="text-center">
        <span class="material-icons text-6xl mb-4">forum</span>
        <p>Select a chat to start messaging</p>
    </div>
</div>


<script>
// Search Suggestions
function searchUser(txt) {
    fetch("search.php?q=" + encodeURIComponent(txt))
        .then(r => r.text())
        .then(d => document.getElementById("suggestions").innerHTML = d);
}

// Load Chat List
function loadChats() {
    fetch("chatlist_ajax.php")
        .then(r => r.text())
        .then(d => document.getElementById("chatlist").innerHTML = d);
}
setInterval(loadChats, 2000);
loadChats();
</script>

</body>
</html>
