<?php include "db.php";
$q=$_GET['q']??'';
if($q==""){echo"";exit;}
$res=$conn->query("SELECT userid,username FROM users WHERE userid LIKE '%$q%' LIMIT 5");
while($u=$res->fetch_assoc()){
 echo "<div><a href='chatscreen.php?u=".$u['userid']."'>".$u['userid']." - ".$u['username']."</a></div>";
}
?>