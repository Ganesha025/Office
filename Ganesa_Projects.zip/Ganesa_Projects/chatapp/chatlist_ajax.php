<?php include "db.php";
$uid=$_SESSION['user_id'];
$q=$conn->query("SELECT * FROM chats WHERE id IN (
 SELECT MAX(id) FROM chats WHERE sender_id=$uid OR receiver_id=$uid 
 GROUP BY LEAST(sender_id,receiver_id), GREATEST(sender_id,receiver_id)
) ORDER BY id DESC");
while($c=$q->fetch_assoc()){
 $other=($c['sender_id']==$uid)?$c['receiver_id']:$c['sender_id'];
 $u=$conn->query("SELECT userid,username FROM users WHERE id=$other")->fetch_assoc();
 echo "<div><a href='chatscreen.php?u=".$u['userid']."'>".$u['userid']." - ".$u['username']."</a></div>";
}
?>