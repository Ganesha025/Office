<?php include "db.php";
$msg = "";
if(isset($_POST['signup'])){
    $userid = "Zen" . rand(1000,9999);
    $username = $_POST['username'];
    $pass = md5($_POST['password']);
    $conn->query("INSERT INTO users(userid,username,password,last_active)
                  VALUES('$userid','$username','$pass',NOW())");
    $msg = "Signup successful! Your ID: $userid";
}
if(isset($_POST['login'])){
    $userid = $_POST['userid'];
    $pass = md5($_POST['password']);
    $q = $conn->query("SELECT * FROM users WHERE userid='$userid' AND password='$pass'");
    if($q->num_rows){
       $u = $q->fetch_assoc();
       $_SESSION['user_id'] = $u['id'];
       header("Location: chatlist.php");
       exit;
    } else $msg = "Invalid login";
}
?>
<html><body>
<p><?php echo $msg; ?></p>
<form method="post">
  <input name="username" placeholder="Name">
  <input name="password" type="password">
  <button name="signup">Signup</button>
</form>
<form method="post">
  <input name="userid" placeholder="Zen1234">
  <input name="password" type="password">
  <button name="login">Login</button>
</form>
</body></html>