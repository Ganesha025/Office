<?php include "db.php";
$uid=$_SESSION['user_id'];
$tid=$conn->query("SELECT id FROM users WHERE userid='".$_GET['to']."'")->fetch_assoc()['id'];
$t=$_GET['t'];
$conn->query("DELETE FROM typing WHERE user_id=$uid AND to_user=$tid");
$conn->query("INSERT INTO typing(user_id,to_user,is_typing) VALUES($uid,$tid,$t)");
?>