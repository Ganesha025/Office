<?php
include "db.php";
$uid = $_SESSION['user_id'];
$toid = $conn->query("SELECT id FROM users WHERE userid='".$_GET['u']."'")->fetch_assoc()['id'];

$q = $conn->query("SELECT * FROM chats WHERE 
(sender_id=$uid AND receiver_id=$toid) OR 
(sender_id=$toid AND receiver_id=$uid)
ORDER BY id ASC");

while($m = $q->fetch_assoc()) {

    $me = ($m['sender_id'] == $uid);

    $align = $me ? "justify-end" : "justify-start";
    $bubble = $me ? "bg-green-500 text-white" : "bg-white text-gray-800 border";
    $rounded = $me ? "rounded-2xl rounded-br-none" : "rounded-2xl rounded-bl-none";

    echo '
    <div class="flex '.$align.' mb-2 px-2">
        <div class="max-w-[75%] '.$bubble.' '.$rounded.' px-4 py-2 shadow">
            '.nl2br(htmlspecialchars($m["message"])).'
        </div>
    </div>
    ';
}
?>
