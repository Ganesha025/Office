<?php 
include "db.php";
if(!isset($_SESSION['user_id'])) die("Login required");
$to = $_GET['u'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<title>Chat</title>
</head>
<body class="bg-gray-100 h-screen flex flex-col">

<div class="bg-white shadow p-4 flex items-center gap-3 border-b">
    <span onclick="history.back()" class="material-icons text-gray-600 cursor-pointer hover:text-black">arrow_back</span>
    <div class="flex flex-col leading-tight">
        <span class="font-semibold text-gray-800 text-lg"><?php echo $to; ?></span>
        <span id="status" class="text-sm text-gray-500"></span>
    </div>
</div>

<div id="messages" class="flex-1 overflow-y-auto p-4 space-y-3"></div>

<div id="typing" class="text-sm text-gray-500 px-4 pb-2 h-5"></div>

<div class="bg-white p-3 border-t flex items-center gap-3">
    <input id="msg" onkeyup="typing()" placeholder="Type a message..." class="flex-1 bg-gray-100 rounded-full px-4 py-2 outline-none focus:ring-2 focus:ring-blue-400 text-gray-700">
    <button onclick="sendMsg()" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-full shadow flex items-center gap-1">
        <span class="material-icons text-white">send</span>
    </button>
</div>

<script>
function loadMessages(){
    fetch("loadmsg.php?u=<?php echo $to ?>")
    .then(r=>r.text())
    .then(d=>{
        document.getElementById("messages").innerHTML = d;
        let box = document.getElementById("messages");
        box.scrollTop = box.scrollHeight;
    });
}

function sendMsg(){
    let m = document.getElementById("msg").value;
    if(m.trim()==="") return;
    fetch("send.php?u=<?php echo $to ?>&m=" + encodeURIComponent(m));
    document.getElementById("msg").value="";
}

function typing(){
    fetch("typing.php?to=<?php echo $to ?>&t=1");
    clearTimeout(window.t);
    window.t = setTimeout(()=>{
        fetch("typing.php?to=<?php echo $to ?>&t=0");
    },1000);
}

function checkTyping(){
    fetch("gettyping.php?u=<?php echo $to ?>")
    .then(r=>r.text())
    .then(d=>document.getElementById("typing").innerHTML=d);
}

function checkStatus(){
    fetch("status.php?u=<?php echo $to ?>")
    .then(r=>r.text())
    .then(d=>document.getElementById("status").innerHTML=d);
}

setInterval(loadMessages,1000);
setInterval(checkTyping,500);
setInterval(checkStatus,2000);
</script>

</body>
</html>
