<?php include "db.php";
$u=$_GET['u'];
$data=$conn->query("SELECT last_active FROM users WHERE userid='$u'")->fetch_assoc();
$diff=time()-strtotime($data['last_active']);
echo ($diff<10)?"<b style='color:green'>Online</b>":"<b style='color:red'>Offline</b>";
?>