<?php
include 'db.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}function showTable($conn, $title, $sql) {
    echo "<h2>$title</h2>";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "<table border='1' cellpadding='8' cellspacing='0'><tr>";
        while ($field = $result->fetch_field()) {
            echo "<th>" . $field->name . "</th>";
        }echo "</tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            foreach ($row as $col) echo "<td>$col</td>";
            echo "</tr>";
        }
        echo "</table><br>";
    } else {echo "<p>No results</p>";}}
showTable($conn, "Students with Department Names","SELECT Name,(SELECT DeptName 
FROM Departments WHERE Departments.DepartmentID = Students.DepartmentID) AS DeptName FROM Students;");
showTable($conn, "Courses with Department Names","SELECT CourseName, DeptName FROM Courses C
JOIN Departments D ON C.DepartmentID = D.DepartmentID");

showTable($conn, "Students with Courses & Grades","SELECT S.Name, C.CourseName, E.Grade FROM Enrollments E
JOIN Students S ON E.StudentID = S.StudentID JOIN Courses C ON E.CourseID = C.CourseID");

showTable($conn, "Courses with Enrollment Count","SELECT C.CourseName, COUNT(E.EnrollmentID) AS TotalEnrollments
 FROM Courses C LEFT JOIN Enrollments E ON C.CourseID = E.CourseID GROUP BY C.CourseID, C.CourseName");

showTable($conn, "Total Students per Department","SELECT D.DeptName, COUNT(S.StudentID) AS TotalStudents
 FROM Departments D LEFT JOIN Students S ON D.DepartmentID = S.DepartmentID GROUP BY D.DepartmentID, D.DeptName");

showTable($conn, "Average Age per Department","SELECT D.DeptName,ROUND((SELECT AVG(S.Age) FROM Students S 
WHERE S.DepartmentID = D.DepartmentID), 0) AS AvgAge FROM Departments D;");

showTable($conn, "Courses with >2 Students","SELECT C.CourseName, COUNT(E.StudentID) AS TotalStudents FROM Courses C
 JOIN Enrollments E ON C.CourseID = E.CourseID GROUP BY C.CourseID, C.CourseName HAVING COUNT(E.StudentID) > 2");

showTable($conn, "Average Grade per Department","SELECT DeptName,(SELECT AVG(
CASE E.Grade WHEN 'A' THEN 4 WHEN 'B' THEN 3 WHEN 'C' THEN 2 WHEN 'D' THEN 1 WHEN 'F' THEN 0 END)
FROM Students S JOIN Enrollments E ON S.StudentID = E.StudentID
WHERE S.DepartmentID = D.DepartmentID) AS AvgGrade FROM Departments D");

showTable($conn, "Highest Grade Student per Course","SELECT C.CourseName, S.Name, E.Grade FROM Enrollments E JOIN Students S ON E.StudentID = S.StudentID JOIN Courses C ON E.CourseID = C.CourseID WHERE E.Grade = (
SELECT MIN(Grade) FROM Enrollments E2 WHERE E2.CourseID = E.CourseID)");

showTable($conn, "Department with Max Enrolled Students","SELECT DeptName,(SELECT COUNT(E.StudentID)
FROM Students S JOIN Enrollments E ON S.StudentID = E.StudentID WHERE S.DepartmentID = D.DepartmentID) AS Total
FROM Departments D ORDER BY Total DESC");

showTable($conn, "Students Not Enrolled","SELECT Name FROM Students S
WHERE NOT EXISTS (SELECT 1 FROM Enrollments E WHERE E.StudentID = S.StudentID)");
showTable($conn, "Students Enrolled in ALL Dept Courses","SELECT S.Name FROM Students S
WHERE NOT EXISTS (SELECT C.CourseID FROM Courses C
WHERE C.DepartmentID = S.DepartmentID AND C.CourseID NOT IN (
SELECT E.CourseID FROM Enrollments E WHERE E.StudentID = S.StudentID))");
$conn->close();
?>