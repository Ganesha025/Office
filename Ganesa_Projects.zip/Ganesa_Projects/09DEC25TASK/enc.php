<?php
$plaintext = "http://localhost/Ganesa_Projects/09DEC25task/enc.php";
$key = openssl_random_pseudo_bytes(32);
$iv = openssl_random_pseudo_bytes(16);
$ciphertext = openssl_encrypt($plaintext, 'aes-256-gcm', $key, 0, $iv, $tag);
$decrypted = openssl_decrypt($ciphertext, 'aes-256-gcm', $key, 0, $iv, $tag);
echo "Plaintext: $plaintext<br><br>";
echo "Ciphertext: " . bin2hex($ciphertext) . "<br><br>";
echo "Decrypted: $decrypted <br>";?>