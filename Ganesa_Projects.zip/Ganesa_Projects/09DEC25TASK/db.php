<?php
$server = "localhost";
$user = "root";
$pass = "";
$dbname = "UniversityDatabase";
$conn = new mysqli($server, $user, $pass);
$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");
$conn->select_db($dbname);
$conn->query("CREATE TABLE IF NOT EXISTS Departments (DepartmentID INT PRIMARY KEY,DeptName VARCHAR(100) NOT NULL)");

$conn->query("CREATE TABLE IF NOT EXISTS Students ( StudentID INT PRIMARY KEY, Name VARCHAR(100) NOT NULL, 
Age INT CHECK (Age > 15), Gender CHAR(1) CHECK (Gender IN ('M','F')), DepartmentID INT, 
FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID))");

$conn->query("CREATE TABLE IF NOT EXISTS Courses ( CourseID INT PRIMARY KEY, CourseName VARCHAR(100) NOT NULL,
DepartmentID INT, FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID))");

$conn->query("CREATE TABLE IF NOT EXISTS Enrollments ( EnrollmentID INT PRIMARY KEY, StudentID INT, 
CourseID INT, Grade CHAR(1) CHECK (Grade IN ('A','B','C','D','F')), FOREIGN KEY (StudentID) REFERENCES Students(StudentID), 
FOREIGN KEY (CourseID) REFERENCES Courses(CourseID))");
?>