<?php
session_start();
include 'config.php';

$message = "";

// Handle Signup
if(isset($_POST['signup'])){
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if($username != "" && $password != ""){
        $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if($result->num_rows > 0){
            $message = "Username already exists!";
        } else {
            $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $hashed_pass);
            if($stmt->execute()){
                $message = "Signup successful! You can login now.";
            } else {
                $message = "Signup failed. Try again.";
            }
        }
    } else {
        $message = "Please enter username and password.";
    }
}

// Handle Login
if(isset($_POST['login'])){
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){
        $user = $result->fetch_assoc();
        if(password_verify($password, $user['password'])){
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $conn->query("UPDATE users SET online_status=1 WHERE id=".$user['id']);
            header("Location: index.php");
            exit;
        } else {
            $message = "Incorrect password!";
        }
    } else {
        $message = "User not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login / Signup</title>
<style>
body { font-family: Arial, sans-serif; background: #f0f0f0; }
.container { max-width: 400px; margin: 50px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc; }
input { width: 100%; padding: 10px; margin: 5px 0; }
button { width: 49%; padding: 10px; margin: 5px 1%; cursor: pointer; }
.message { color: red; margin-bottom: 10px; }
</style>
</head>
<body>
<div class="container">
    <h2>Login / Signup</h2>
    <?php if($message != "") echo "<div class='message'>$message</div>"; ?>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required />
        <input type="password" name="password" placeholder="Password" required />
        <div style="display: flex;">
            <button type="submit" name="login">Login</button>
            <button type="submit" name="signup">Signup</button>
        </div>
    </form>
</div>
</body>
</html>
