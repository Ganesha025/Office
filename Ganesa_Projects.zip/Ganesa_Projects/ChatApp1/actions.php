<?php
session_start();
include 'config.php';

if(!isset($_SESSION['user_id'])){
    echo json_encode(['error'=>'Not logged in']);
    exit;
}

$current_user_id = $_SESSION['user_id'];

// Logout
if(isset($_GET['action']) && $_GET['action'] == 'logout'){
    $conn->query("UPDATE users SET online_status=0 WHERE id=$current_user_id");
    session_destroy();
    header("Location: login.php");
    exit;
}

// Send message
if(isset($_POST['action']) && $_POST['action'] == 'send_message'){
    $receiver_id = intval($_POST['receiver_id']);
    $message = trim($_POST['message']);
    if($receiver_id && $message){
        $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $current_user_id, $receiver_id, $message);
        $stmt->execute();
    }
    exit;
}

// Typing indicator
if(isset($_POST['action']) && $_POST['action'] == 'typing'){
    $receiver_id = intval($_POST['receiver_id']);
    if($receiver_id){
        $stmt = $conn->prepare("INSERT INTO typing_status (sender_id, receiver_id, is_typing) VALUES (?, ?, 1)
        ON DUPLICATE KEY UPDATE is_typing=1, last_update=CURRENT_TIMESTAMP");
        $stmt->bind_param("ii", $current_user_id, $receiver_id);
        $stmt->execute();
    }
    exit;
}

// Stop typing
if(isset($_POST['action']) && $_POST['action'] == 'stop_typing'){
    $receiver_id = intval($_POST['receiver_id']);
    if($receiver_id){
        $stmt = $conn->prepare("INSERT INTO typing_status (sender_id, receiver_id, is_typing) VALUES (?, ?, 0)
        ON DUPLICATE KEY UPDATE is_typing=0, last_update=CURRENT_TIMESTAMP");
        $stmt->bind_param("ii", $current_user_id, $receiver_id);
        $stmt->execute();
    }
    exit;
}

// Fetch messages
if(isset($_GET['action']) && $_GET['action'] == 'fetch_messages'){
    $user_id = intval($_GET['user_id']);
    $messages = [];
    $typing_user = '';

    if($user_id){
        $res = $conn->query("SELECT * FROM messages 
            WHERE (sender_id=$current_user_id AND receiver_id=$user_id) 
            OR (sender_id=$user_id AND receiver_id=$current_user_id) 
            ORDER BY created_at ASC");

        while($row = $res->fetch_assoc()){
            $messages[] = $row;
        }

        $res2 = $conn->query("SELECT is_typing FROM typing_status WHERE sender_id=$user_id AND receiver_id=$current_user_id");
        if($res2 && $row2 = $res2->fetch_assoc()){
            if($row2['is_typing'] == 1){
                $stmt = $conn->prepare("SELECT username FROM users WHERE id=?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $stmt->bind_result($typing_user);
                $stmt->fetch();
            }
        }
    }

    echo json_encode(['messages'=>$messages, 'typing'=>$typing_user]);
    exit;
}

// Optional: update online_status periodically
$conn->query("UPDATE users SET online_status=1 WHERE id=$current_user_id");
?>
