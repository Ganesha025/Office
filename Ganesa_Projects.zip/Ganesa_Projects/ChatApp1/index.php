<?php
session_start();
include 'config.php';

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$current_user_id = $_SESSION['user_id'];
$current_username = $_SESSION['username'];

$users = $conn->query("SELECT id, username, online_status FROM users WHERE id != $current_user_id ORDER BY username ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Chat App</title>
<style>
body { font-family: Arial, sans-serif; margin:0; padding:0; background:#f0f0f0; }
.container { display:flex; height: 100vh; }
.user-list { width: 25%; background:#fff; border-right:1px solid #ccc; overflow-y:auto; padding:10px; }
.chat-box { flex:1; display:flex; flex-direction:column; }
.messages { flex:1; padding:10px; overflow-y:auto; background:#e8e8e8; }
.message { padding:5px 10px; margin:5px 0; border-radius:5px; max-width:70%; }
.sent { background:#4caf50; color:#fff; margin-left:auto; }
.received { background:#fff; margin-right:auto; }
input[type=text] { width: calc(100% - 100px); padding:10px; }
button { width:80px; padding:10px; }
.typing { font-size:12px; color:#555; margin:5px 0; }
.user-item { cursor:pointer; padding:5px; border-bottom:1px solid #eee; display:flex; justify-content:space-between; }
.user-item:hover { background:#f5f5f5; }
.online { color:green; font-weight:bold; }
.offline { color:red; font-weight:bold; }
#searchUser { width:100%; padding:5px; margin-bottom:10px; }
</style>
</head>
<body>

<div class="container">
    <div class="user-list">
        <input type="text" id="searchUser" placeholder="Search user..." />
        <div id="users">
            <?php while($row = $users->fetch_assoc()): ?>
            <div class="user-item" data-id="<?= $row['id']; ?>">
                <span><?= $row['username']; ?></span>
                <span class="<?= $row['online_status'] ? 'online' : 'offline'; ?>"><?= $row['online_status'] ? 'Online' : 'Offline'; ?></span>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
    <div class="chat-box">
        <div class="messages" id="messages"></div>
        <div class="typing" id="typing"></div>
        <div style="display:flex; border-top:1px solid #ccc; padding:5px; background:#fff;">
            <input type="text" id="messageInput" placeholder="Type a message..." autocomplete="off" />
            <button id="sendBtn">Send</button>
        </div>
        <div style="padding:5px; background:#fff; border-top:1px solid #ccc;">
            Logged in as <b><?= $current_username; ?></b> | <a href="actions.php?action=logout">Logout</a>
        </div>
    </div>
</div>

<script>
let currentUserId = <?= $current_user_id ?>;
let selectedUserId = null;
let typingTimeout;

document.querySelectorAll('.user-item').forEach(item => {
    item.addEventListener('click', () => {
        selectedUserId = item.getAttribute('data-id');
        document.getElementById('messages').innerHTML = '';
        fetchMessages();
    });
});

document.getElementById('sendBtn').addEventListener('click', () => {
    let msg = document.getElementById('messageInput').value.trim();
    if(msg == "" || !selectedUserId) return;
    fetch('actions.php', {
        method:'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: 'action=send_message&receiver_id='+selectedUserId+'&message='+encodeURIComponent(msg)
    }).then(()=>{ document.getElementById('messageInput').value=''; fetchMessages(); });
});

document.getElementById('messageInput').addEventListener('input', () => {
    if(!selectedUserId) return;
    fetch('actions.php', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'action=typing&receiver_id='+selectedUserId });
    clearTimeout(typingTimeout);
    typingTimeout = setTimeout(() => {
        fetch('actions.php', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'action=stop_typing&receiver_id='+selectedUserId });
    }, 2000);
});

setInterval(() => {
    if(selectedUserId) fetchMessages();
}, 1500);

function fetchMessages(){
    fetch('actions.php?action=fetch_messages&user_id='+selectedUserId)
    .then(res => res.json())
    .then(data => {
        let html = '';
        data.messages.forEach(msg => {
            html += `<div class="message ${msg.sender_id == currentUserId ? 'sent' : 'received'}">${msg.message}</div>`;
        });
        document.getElementById('messages').innerHTML = html;
        document.getElementById('messages').scrollTop = document.getElementById('messages').scrollHeight;

        if(data.typing) document.getElementById('typing').innerText = data.typing+' is typing...';
        else document.getElementById('typing').innerText = '';
    });
}

document.getElementById('searchUser').addEventListener('input', () => {
    let filter = document.getElementById('searchUser').value.toLowerCase();
    document.querySelectorAll('.user-item').forEach(item => {
        let name = item.querySelector('span:first-child').innerText.toLowerCase();
        item.style.display = name.includes(filter) ? 'flex' : 'none';
    });
});
</script>

</body>
</html>
