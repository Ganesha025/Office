<?php
/***********************
 * SHOW MOUSE TRACKS
 ***********************/
$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "mouse_tracker_db";

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS);
$conn->select_db($DB_NAME);

// Get session parameter or show latest session
$session_id = isset($_GET['session']) ? $conn->real_escape_string($_GET['session']) : null;
$sql = $session_id 
    ? "SELECT x, y, recorded_at FROM mouse_tracks WHERE session_id = '$session_id' ORDER BY recorded_at ASC"
    : "SELECT session_id, COUNT(*) as point_count FROM mouse_tracks GROUP BY session_id ORDER BY MAX(recorded_at) DESC LIMIT 20";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mouse Movement Visualization</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        canvas {
            border: 2px solid #333;
            background: #f8f9fa;
            cursor: crosshair;
            max-width: 100%;
            height: auto;
        }
        .sessions {
            margin: 20px 0;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .session-btn {
            padding: 8px 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        .session-btn:hover {
            background: #0056b3;
        }
        .session-btn.active {
            background: #28a745;
        }
        .stats {
            display: flex;
            gap: 20px;
            margin: 10px 0;
            font-size: 14px;
        }
        .controls {
            margin: 20px 0;
        }
        button {
            padding: 10px 20px;
            margin-right: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .play { background: #28a745; color: white; }
        .pause { background: #ffc107; color: #212529; }
        .reset { background: #6c757d; color: white; }
    </style>
</head>
<body>
    <h1>🐭 Mouse Movement Visualization</h1>
    
    <div class="sessions" id="sessionsList">
        <?php if (!$session_id): ?>
            <h3>Recent Sessions:</h3>
        <?php endif; ?>
    </div>

    <div class="controls">
        <button class="play" onclick="togglePlay()">▶ Play</button>
        <button class="pause" onclick="togglePlay()" id="pauseBtn" style="display:none;">⏸ Pause</button>
        <button class="reset" onclick="resetAnimation()">🔄 Reset</button>
        <div class="stats" id="stats">
            <span>Points: <span id="pointCount">0</span></span>
            <span>Speed: <span id="speed">1x</span></span>
            <span>Progress: <span id="progress">0%</span></span>
        </div>
    </div>

    <canvas id="mouseCanvas" width="1000" height="600"></canvas>

    <script>
        let tracks = [];
        let currentSessionId = null;
        let isPlaying = false;
        let animationId = null;
        let currentIndex = 0;
        let speedMultiplier = 1;
        let lastFrameTime = 0;

        const canvas = document.getElementById('mouseCanvas');
        const ctx = canvas.getContext('2d');
        const sessionsList = document.getElementById('sessionsList');

        // Normalize coordinates to canvas size
        function normalizePoint(x, y) {
            return {
                x: (x / window.innerWidth) * canvas.width,
                y: (y / window.innerHeight) * canvas.height
            };
        }

        // Draw path
        function drawPath() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            // Draw trail
            ctx.strokeStyle = 'rgba(255, 0, 150, 0.6)';
            ctx.lineWidth = 3;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.shadowBlur = 10;
            ctx.shadowColor = 'rgba(255, 0, 150, 0.5)';
            
            ctx.beginPath();
            for (let i = 0; i < Math.min(currentIndex + 1, tracks.length); i++) {
                const point = normalizePoint(tracks[i].x, tracks[i].y);
                if (i === 0) {
                    ctx.moveTo(point.x, point.y);
                } else {
                    ctx.lineTo(point.x, point.y);
                }
            }
            ctx.stroke();
            ctx.shadowBlur = 0;

            // Draw current position dot
            if (currentIndex < tracks.length) {
                const point = normalizePoint(tracks[currentIndex].x, tracks[currentIndex].y);
                ctx.fillStyle = '#ff008a';
                ctx.beginPath();
                ctx.arc(point.x, point.y, 8, 0, Math.PI * 2);
                ctx.fill();
                
                ctx.fillStyle = 'white';
                ctx.font = '12px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(`${currentIndex + 1}`, point.x, point.y - 20);
            }
        }

        // Animation loop
        function animate(currentTime) {
            if (!isPlaying || tracks.length === 0) return;

            const deltaTime = currentTime - lastFrameTime;
            if (deltaTime > 50 / speedMultiplier) {
                if (currentIndex < tracks.length) {
                    currentIndex++;
                    updateStats();
                    drawPath();
                } else {
                    pauseAnimation();
                }
                lastFrameTime = currentTime;
            }
            
            animationId = requestAnimationFrame(animate);
        }

        function togglePlay() {
            isPlaying = !isPlaying;
            document.querySelector('.play').style.display = isPlaying ? 'none' : 'inline-block';
            document.getElementById('pauseBtn').style.display = isPlaying ? 'inline-block' : 'none';
            
            if (isPlaying) {
                lastFrameTime = performance.now();
                animationId = requestAnimationFrame(animate);
            } else {
                cancelAnimationFrame(animationId);
            }
        }

        function pauseAnimation() {
            isPlaying = false;
            document.querySelector('.play').style.display = 'inline-block';
            document.getElementById('pauseBtn').style.display = 'none';
            cancelAnimationFrame(animationId);
        }

        function resetAnimation() {
            pauseAnimation();
            currentIndex = 0;
            updateStats();
            drawPath();
        }

        function updateStats() {
            document.getElementById('pointCount').textContent = currentIndex + 1;
            document.getElementById('progress').textContent = 
                Math.round((currentIndex / tracks.length) * 100) + '%';
        }

        // Load tracks for a session
        function loadSession(sessionId) {
            fetch(`?session=${sessionId}`)
                .then(res => res.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const scriptTag = doc.querySelector('script[data-tracks]');
                    if (scriptTag) {
                        tracks = JSON.parse(scriptTag.dataset.tracks);
                        currentSessionId = sessionId;
                        resetAnimation();
                        drawPath();
                        
                        // Update active button
                        document.querySelectorAll('.session-btn').forEach(btn => {
                            btn.classList.remove('active');
                        });
                        document.querySelector(`[data-session="${sessionId}"]`).classList.add('active');
                    }
                });
        }

        // Initialize
        window.addEventListener('load', function() {
            // Populate sessions list
            <?php if (!$session_id): ?>
                sessionsList.innerHTML += `
                    <?php 
                    if ($result && $result->num_rows > 0):
                        while($row = $result->fetch_assoc()): 
                    ?>
                    <button class="session-btn" data-session="<?= $row['session_id'] ?>" 
                            onclick="loadSession(this.dataset.session)">
                        Session <?= substr($row['session_id'], 0, 8) ?>...
                        (<?= $row['point_count'] ?> pts)
                    </button>
                    <?php endwhile; endif; ?>
                `;
            <?php else: ?>
                // Load specific session data
                <?php 
                $tracks = [];
                if ($result && $result->num_rows > 0):
                    while($row = $result->fetch_assoc()): 
                        $tracks[] = ['x' => $row['x'], 'y' => $row['y']];
                    endwhile;
                endif;
                ?>
                tracks = <?= json_encode($tracks) ?>;
                drawPath();
            <?php endif; ?>

            // Handle window resize
            window.addEventListener('resize', () => {
                canvas.width = 1000;
                canvas.height = 600;
                drawPath();
            });
        });
    </script>

    <?php if ($session_id): ?>
    <!-- Inline data for specific session -->
    <script data-tracks="<?= htmlspecialchars(json_encode($tracks)) ?>"></script>
    <?php endif; ?>

</body>
</html>

<?php $conn->close(); ?>
