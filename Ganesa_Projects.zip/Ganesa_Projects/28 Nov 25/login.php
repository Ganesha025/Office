<?php
// SIMPLE LOGIN CHECK
require "./track.php";
startMouseTracker();
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if ($email === "admin@example.com" && $password === "Admin@123") {
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid login credentials!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>

    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex items-center justify-center min-h-screen">

    <div class="bg-white p-8 rounded-2xl shadow-xl w-full max-w-sm">
        <h2 class="text-2xl font-bold text-gray-700 text-center mb-6">
            Login to Your Account
        </h2>

        <?php if ($error): ?>
            <div class="mb-4 bg-red-100 text-red-600 px-4 py-2 rounded-lg">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-5">

            <div>
                <label class="block text-gray-600 font-medium">Email</label>
                <input type="email" name="email" required
                    class="w-full mt-1 px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <div>
                <label class="block text-gray-600 font-medium">Password</label>
                <input type="password" name="password" required
                    class="w-full mt-1 px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <button type="submit"
                class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition">
                Login
            </button>

        </form>

        <p class="text-sm text-center text-gray-500 mt-4">
            Developed by <span class="font-semibold text-blue-600">SavageInfo</span>
        </p>

    </div>

</body>
</html>
