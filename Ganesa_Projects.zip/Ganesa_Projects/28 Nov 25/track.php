<?php
/****************************
 * AUTO DATABASE CREATION
 ****************************/
function initMouseTrackerDB() {
    $DB_HOST = "localhost";
    $DB_USER = "root";
    $DB_PASS = "";
    $DB_NAME = "mouse_tracker_db";

    $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS);
    $conn->query("CREATE DATABASE IF NOT EXISTS $DB_NAME");
    $conn->select_db($DB_NAME);

    $conn->query("
        CREATE TABLE IF NOT EXISTS mouse_tracks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            session_id VARCHAR(64) NOT NULL,
            x INT NOT NULL,
            y INT NOT NULL,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX(session_id)
        )
    ");

    return $conn;
}


/****************************
 * AJAX HANDLER
 ****************************/
function handleMouseTrackerAjax($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST'  
        && isset($_POST['x']) 
        && isset($_POST['y']) 
        && isset($_POST['session_id'])
    ) {
        $x = intval($_POST['x']);
        $y = intval($_POST['y']);
        $session_id = $conn->real_escape_string($_POST['session_id']);

        $stmt = $conn->prepare("INSERT INTO mouse_tracks (session_id, x, y) VALUES (?, ?, ?)");
        $stmt->bind_param("sii", $session_id, $x, $y);
        $stmt->execute();
        exit; // Stop HTML output
    }
}


/****************************
 * MAIN PUBLIC FUNCTION
 ****************************/
function startMouseTracker() {

    // Start DB setup + handle AJAX
    $conn = initMouseTrackerDB();
    handleMouseTrackerAjax($conn);

    // Output tracking script
    echo '
    <style>
        .track-status { padding:10px; margin-top:20px; background:#f0f0f0; width:fit-content;}
        .active { background:#90EE90; }
        .inactive { background:#FFB6C6; }
    </style>

    <script>
        function mouseTracker_generateSessionId() {
            return Date.now() + "-" + Math.random().toString(36).substr(2, 9);
        }

        let mt_sessionId = mouseTracker_generateSessionId();
        let mt_lastSent = 0;
        let mt_tracking = true;
        let mt_sessionCount = 1;

        const mt_status = document.getElementById("trackStatus");
        const mt_info = document.getElementById("trackSessionInfo");

        function mouseTracker_updateUI() {
            if (mt_tracking) {
                mt_status.textContent = "Tracking mouse movement...";
                mt_status.className = "track-status active";
                mt_info.textContent = "Session #" + mt_sessionCount + " - ID: " + mt_sessionId;
            } else {
                mt_status.textContent = "Paused (window not focused)";
                mt_status.className = "track-status inactive";
            }
        }

        document.addEventListener("mousemove", function(e) {
            if (!mt_tracking) return;

            const now = Date.now();
            if (now - mt_lastSent < 100) return;
            mt_lastSent = now;

            fetch("", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "x=" + e.clientX + "&y=" + e.clientY + "&session_id=" + mt_sessionId
            });
        });

        window.addEventListener("blur", function() {
            mt_tracking = false;
            mouseTracker_updateUI();
        });

        window.addEventListener("focus", function() {
            mt_sessionId = mouseTracker_generateSessionId();
            mt_sessionCount++;
            mt_tracking = true;
            mouseTracker_updateUI();
        });

        mouseTracker_updateUI();
    </script>
    ';
}
?>
