<?php
include 'db.php';

$connection->query("DELETE FROM Students WHERE marks < 40");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $department_name = trim($_POST['department_name']);
    $student_name = trim($_POST['student_name']);
    $email = trim($_POST['email']);
    $marks = intval($_POST['marks'] * 1.1);
    if ($marks > 100) $marks = 100;

    $result = $connection->query("SELECT id FROM Departments WHERE name='$department_name'");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $department_id = $row['id'];
    } else {
        $connection->query("INSERT INTO Departments (name) VALUES ('$department_name')");
        $department_id = $connection->insert_id;
    }
$msg="";
    $result = $connection->query("SELECT id FROM Students WHERE name='$student_name' AND department_id=$department_id AND email='$email'");
    if ($result->num_rows > 0) {
        $msg = "Student already exists in this department.";
    } else {
        $connection->query("INSERT INTO Students (name, department_id, email, marks) VALUES ('$student_name', $department_id, '$email', $marks)");
        $msg = "Student and Department inserted successfully.";
    }
}
$select_dept = $connection->query("SELECT name FROM Departments");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Student</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen">
    <div class="w-full max-w-md p-8 bg-white rounded-2xl shadow-lg">
        <h1 class="text-3xl font-bold text-gray-800 text-center mb-6">Add Student</h1>
        <form method="POST" action="" class="space-y-5">
            <div>
                <label for="department_name" class="block text-gray-700 font-semibold mb-2">Department Name:</label>
                <select id="department_name" name="department_name" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <?php while($row = $select_dept->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($row['name']); ?>">
                            <?php echo htmlspecialchars($row['name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div>
                <label for="student_name" class="block text-gray-700 font-semibold mb-2">Student Name:</label>
                <input type="text" id="student_name" name="student_name" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
            </div>
            <div>
                <label for="email" class="block text-gray-700 font-semibold mb-2">Email:</label>
                <input type="email" id="email" name="email" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
            </div>
            <div>
                <label for="marks" class="block text-gray-700 font-semibold mb-2">Marks:</label>
                <input type="number" id="marks" name="marks" min="0" max="100" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
            </div>
            <button type="submit" class="w-full py-3 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700 transition duration-300">Submit</button>
        </form>
    </div>
    <?php if (isset($msg)): ?>
        <div class="fixed bottom-5 left-1/2 transform -translate-x-1/2 bg-white border border-gray-300 rounded-lg shadow-lg px-6 py-4">
            <p class="text-gray-800"><?php echo htmlspecialchars($msg); ?></p>
        </div>
    <?php endif; ?>
</body>
</html>
