<?php
include 'db.php';
$query = 'SELECT Students.name AS student_name, Departments.name AS dept_name
          FROM Students
          INNER JOIN Departments ON Students.department_id = Departments.id
          WHERE Students.marks > 50';
$result = $connection->query($query);
$query2 = 'SELECT d.name AS dept_name, COUNT(s.id) AS student_count
           FROM Departments d
           LEFT JOIN Students s ON d.id = s.department_id
           GROUP BY d.name';
$result2 = $connection->query($query2);
$alldata = $connection->query("
    SELECT Students.name AS student_name, Departments.name AS dept_name, Students.email, Students.marks
    FROM Students, Departments
    WHERE Students.department_id = Departments.id
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800 font-sans">
    <div class="container mx-auto p-6">
        <h1 class="text-4xl font-bold text-teal-600 text-center mb-10">Student Dashboard</h1>

        <section class="mb-12">
            <h2 class="text-2xl font-semibold text-teal-500 mb-6">Marks &gt; 50</h2>
            <ul class="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php
            while ($row = $result->fetch_assoc()) {
                echo "<li class='bg-white p-5 rounded-lg shadow hover:shadow-xl transition hover:border-teal-400 border border-transparent'>
                        <span class='font-medium text-gray-800'>" . htmlspecialchars($row['student_name']) . "</span> - 
                        <span class='text-gray-600'>" . htmlspecialchars($row['dept_name']) . "</span>
                      </li>";
            }
            ?>
            </ul>
        </section>

        <section class="mb-12">
            <h2 class="text-2xl font-semibold text-teal-500 mb-6">Departments with Student Count</h2>
            <ul class="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php
            while ($row2 = $result2->fetch_assoc()) {
                echo "<li class='bg-white p-5 rounded-lg shadow hover:shadow-xl transition hover:border-teal-400 border border-transparent'>
                        <span class='font-medium text-gray-800'>" . htmlspecialchars($row2['dept_name']) . "</span>: 
                        <span class='text-gray-600'>" . htmlspecialchars($row2['student_count']) . "</span>
                      </li>";
            }
            ?>
            </ul>
        </section>

        <section>
            <h2 class="text-2xl font-semibold text-teal-500 mb-6">All Students Data</h2>
            <ul class="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php
            while ($row3 = $alldata->fetch_assoc()) {
                echo "<li class='bg-white p-6 rounded-xl shadow hover:shadow-2xl transition hover:border-teal-400 border border-transparent'>
                        <p><span class='font-semibold text-gray-800'>Student:</span> " . htmlspecialchars($row3['student_name']) . "</p>
                        <p><span class='font-semibold text-gray-800'>Department:</span> " . htmlspecialchars($row3['dept_name']) . "</p>
                        <p><span class='font-semibold text-gray-800'>Email:</span> " . htmlspecialchars($row3['email']) . "</p>
                        <p><span class='font-semibold text-gray-800'>Marks:</span> " . htmlspecialchars($row3['marks']) . "</p>
                      </li>";
            }
            ?>
            </ul>
        </section>
    </div>
</body>
</html>
