<?php
include 'db.php';
$result = $connection->query('SELECT Students.name AS student_name, Departments.name AS department_name, Students.marks 
    FROM Students  
    JOIN Departments ON Students.department_id = Departments.id
    ORDER BY Students.marks DESC LIMIT 3');

$BCA_dept_student_name=$connection->query("SELECT Students.name AS student_name
FROM Students
JOIN Departments ON Students.department_id = Departments.id
WHERE Departments.name = 'BCA'");

$student_with_their_dept=$connection->query("SELECT students.name AS student_name, Departments.name AS department_name 
FROM Students
JOIN Departments ON Students.department_id = Departments.id");
$departments_without_students=$connection->query("SELECT Departments.name AS department_name
FROM Departments
LEFT JOIN Students ON Departments.id = Students.department_id
WHERE Students.id IS NULL");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 text-gray-800 font-sans">

<div class="container mx-auto px-4 py-10">
    <h1 class="text-4xl font-extrabold text-center mb-10 text-indigo-600">Student Dashboard</h1>

    <section class="mb-10">
        <h2 class="text-2xl font-semibold mb-4 text-gray-900 border-b-2 border-indigo-600 inline-block">Top 3 Students with Highest Marks</h2>
        <div class="grid md:grid-cols-3 gap-6 mt-4">
            <?php while ($row = $result->fetch_assoc()) { ?>
            <div class="bg-white shadow-lg rounded-lg p-6 hover:scale-105 transition-transform duration-300">
                <h3 class="text-xl font-bold text-indigo-500"><?php echo $row['student_name']; ?></h3>
                <p class="text-gray-700">Department: <span class="font-medium text-gray-900"><?php echo $row['department_name']; ?></span></p>
                <p class="text-gray-700">Marks: <span class="font-medium text-gray-900"><?php echo $row['marks']; ?></span></p>
            </div>
            <?php } ?>
        </div>
    </section>

    <section class="mb-10">
        <h2 class="text-2xl font-semibold mb-4 text-gray-900 border-b-2 border-green-500 inline-block">Students in BCA Department</h2>
        <ul class="bg-white shadow-md rounded-lg p-6 space-y-2">
            <?php while ($row = $BCA_dept_student_name->fetch_assoc()) { ?>
            <li class="text-gray-800 hover:text-green-600 transition-colors duration-200"><?php echo $row['student_name']; ?></li>
            <?php } ?>
        </ul>
    </section>

    <section class="mb-10">
        <h2 class="text-2xl font-semibold mb-4 text-gray-900 border-b-2 border-blue-500 inline-block">Students with their Departments</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white shadow-md rounded-lg">
                <thead class="bg-blue-500 text-white">
                    <tr>
                        <th class="py-3 px-6 text-left">Student Name</th>
                        <th class="py-3 px-6 text-left">Department</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $student_with_their_dept->fetch_assoc()) { ?>
                    <tr class="border-b hover:bg-blue-50">
                        <td class="py-3 px-6"><?php echo $row['student_name']; ?></td>
                        <td class="py-3 px-6"><?php echo $row['department_name']; ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </section>

</div>

</body>
</html>
