<?php
$connection = new mysqli('localhost', 'root', '', 'savage_college');
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
$connection->query('CREATE DATABASE IF NOT EXISTS savage_college');
$connection->select_db('savage_college');
$connection->query("
    CREATE TABLE IF NOT EXISTS Departments(
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL UNIQUE
    )
");
$connection->query("
    CREATE TABLE IF NOT EXISTS Students(
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        department_id INT(11),
        email VARCHAR(100) NOT NULL,
        marks FLOAT(3),
        FOREIGN KEY (department_id) REFERENCES Departments(id) ON DELETE SET NULL
    )
");
?>
