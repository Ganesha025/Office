<?php
include 'db.php';

$encryption_key = "12345678901234567890123456789030"; // 32-byte key
$message = '';
$action = $_POST['action'] ?? 'login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'signup') {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Generate IV
        $iv = openssl_random_pseudo_bytes(16);
        $iv_hex = bin2hex($iv);

        // Encrypt all fields
        $enc_username = base64_encode(openssl_encrypt($username, "AES-256-CBC", $encryption_key, OPENSSL_RAW_DATA, $iv));
        $enc_email = base64_encode(openssl_encrypt($email, "AES-256-CBC", $encryption_key, OPENSSL_RAW_DATA, $iv));
        $enc_password = base64_encode(openssl_encrypt($password, "AES-256-CBC", $encryption_key, OPENSSL_RAW_DATA, $iv));

        // Insert into DB
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, iv) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $enc_username, $enc_email, $enc_password, $iv_hex);

        $message = $stmt->execute() ? "Signup successful!" : "Error: " . $stmt->error;
        $stmt->close();

    } elseif ($action === 'login') {
        $username_input = $_POST['username'];
        $password_input = $_POST['password'];

        // Fetch all users
        $result = $conn->query("SELECT id, username, password, iv FROM users");

        $found = false;
        while ($row = $result->fetch_assoc()) {
            $iv = hex2bin($row['iv']);
            $dec_username = openssl_decrypt(base64_decode($row['username']), "AES-256-CBC", $encryption_key, OPENSSL_RAW_DATA, $iv);
            $dec_password = openssl_decrypt(base64_decode($row['password']), "AES-256-CBC", $encryption_key, OPENSSL_RAW_DATA, $iv);

            if ($username_input === $dec_username && $password_input === $dec_password) {
                $message = "Login successful! Welcome, " . htmlspecialchars($dec_username);
                $found = true;
                break;
            }
        }
        if (!$found) $message = "Invalid credentials!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Signup & Login</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans p-6">
<div class="max-w-md mx-auto bg-white p-6 rounded-xl shadow">
    <h1 class="text-2xl font-bold mb-4 text-center">Signup / Login</h1>
    <?php if(!empty($message)) echo "<p class='mb-4 text-center'>$message</p>"; ?>

    <div class="flex justify-center mb-4">
        <button onclick="showForm('login')" id="loginBtn" class="px-4 py-2 bg-green-600 text-white rounded-l hover:bg-green-700">Login</button>
        <button onclick="showForm('signup')" id="signupBtn" class="px-4 py-2 bg-blue-600 text-white rounded-r hover:bg-blue-700">Signup</button>
    </div>

    <!-- Login Form -->
    <form id="loginForm" method="post" class="space-y-4">
        <input type="hidden" name="action" value="login">
        <input type="text" name="username" placeholder="Username" class="w-full p-2 border rounded" required>
        <input type="password" name="password" placeholder="Password" class="w-full p-2 border rounded" required>
        <button type="submit" class="w-full bg-green-600 text-white p-2 rounded hover:bg-green-700">Login</button>
    </form>

    <!-- Signup Form -->
    <form id="signupForm" method="post" class="space-y-4 hidden">
        <input type="hidden" name="action" value="signup">
        <input type="text" name="username" placeholder="Username" class="w-full p-2 border rounded" required>
        <input type="email" name="email" placeholder="Email" class="w-full p-2 border rounded" required>
        <input type="password" name="password" placeholder="Password" class="w-full p-2 border rounded" required>
        <button type="submit" class="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">Signup</button>
    </form>
</div>

<script>
function showForm(form) {
    document.getElementById('loginForm').classList.add('hidden');
    document.getElementById('signupForm').classList.add('hidden');
    if(form === 'login') document.getElementById('loginForm').classList.remove('hidden');
    if(form === 'signup') document.getElementById('signupForm').classList.remove('hidden');
}
</script>
</body>
</html>
