<?php
include 'db.php';

$encryption_key = "12345678901234567890123456789030"; // same key

// Fetch all users
$result = $conn->query("SELECT id, username, email, password, created_at, iv FROM users");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Users</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans p-6">

<div class="max-w-6xl mx-auto bg-white p-6 rounded-xl shadow">
    <h1 class="text-2xl font-bold mb-6 text-center">All Users (Decrypted)</h1>

    <table class="min-w-full bg-white border rounded-lg overflow-hidden">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">ID</th>
                <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Username</th>
                <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Email</th>
                <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Password</th>
                <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Created At</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200 bg-white">
            <?php while($row = $result->fetch_assoc()): 
                $iv = hex2bin($row['iv']);
                $dec_username = openssl_decrypt(base64_decode($row['username']), "AES-256-CBC", $encryption_key, OPENSSL_RAW_DATA, $iv);
                $dec_email = openssl_decrypt(base64_decode($row['email']), "AES-256-CBC", $encryption_key, OPENSSL_RAW_DATA, $iv);
                $dec_password = openssl_decrypt(base64_decode($row['password']), "AES-256-CBC", $encryption_key, OPENSSL_RAW_DATA, $iv);
            ?>
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-2"><?= $row['id'] ?></td>
                <td class="px-4 py-2"><?= htmlspecialchars($dec_username) ?></td>
                <td class="px-4 py-2"><?= htmlspecialchars($dec_email) ?></td>
                <td class="px-4 py-2"><?= htmlspecialchars($dec_password) ?></td>
                <td class="px-4 py-2"><?= $row['created_at'] ?></td>
                
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>
