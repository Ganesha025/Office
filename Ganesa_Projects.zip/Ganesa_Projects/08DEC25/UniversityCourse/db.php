<?php
$servername = "localhost";
$username = "root";  
$password = "";          
$dbname = "UniversityCourse";
$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    // echo "Database '$dbname' exists or created successfully.<br>";
} else {
    die("Error creating database: " . $conn->error);
}
$conn->select_db($dbname);
$sqlStudents = "CREATE TABLE IF NOT EXISTS Students (
    StudentID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    EnrollmentDate DATE NOT NULL,
    Major VARCHAR(50) NOT NULL
)";

if ($conn->query($sqlStudents) === TRUE) {
    // echo "Table 'Students' exists or created successfully.<br>";
} else {
    die("Error creating Students table: " . $conn->error);
}
$sqlEnrollments = "CREATE TABLE IF NOT EXISTS Enrollments (
    EnrollmentID INT AUTO_INCREMENT PRIMARY KEY,
    StudentID INT NOT NULL,
    CourseName VARCHAR(100) NOT NULL,
    EnrollmentDate DATE NOT NULL,
    Grade CHAR(2),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID) ON DELETE CASCADE
)";

if ($conn->query($sqlEnrollments) === TRUE) {
    // echo "Table 'Enrollments' exists or created successfully.<br>";
} else {
    die("Error creating Enrollments table: " . $conn->error);
}

// echo "Database and tables are ready!";
?>