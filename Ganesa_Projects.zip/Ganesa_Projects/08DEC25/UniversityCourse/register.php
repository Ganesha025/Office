<?php
include 'db.php';

$courses = ["Mathematics", "Physics", "Chemistry", "Biology", "Computer Science", "History", "English"];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $enrollmentDate = $_POST['enrollmentDate'];
    $major = $_POST['major'];

    $stmt = $conn->prepare("INSERT INTO Students (FirstName, LastName, EnrollmentDate, Major) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $firstName, $lastName, $enrollmentDate, $major);
    $stmt->execute();
    $studentId = $stmt->insert_id;
    $stmt->close();

    if (!empty($_POST['courses'])) {
        $stmt2 = $conn->prepare("INSERT INTO Enrollments (StudentID, CourseName, EnrollmentDate, Grade) VALUES (?, ?, ?, ?)");
        foreach ($_POST['courses'] as $course) {
            $courseName = $course;
            $enrollDate = date('Y-m-d');
            $grade = NULL;
            $stmt2->bind_param("isss", $studentId, $courseName, $enrollDate, $grade);
            $stmt2->execute();
        }
        $stmt2->close();
    }

    // echo "<p class='text-green-600 text-center text-lg font-semibold'>Student registered successfully!</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register Student</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<script src="https://unpkg.com/@phosphor-icons/web"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="./valid.js"></script>
<style>
    body { font-family: 'Poppins', sans-serif; }
</style>
</head>

<body class="bg-gray-100 min-h-screen flex items-center justify-center p-6">

<div class="w-full max-w-3xl bg-white rounded-3xl shadow-xl p-10 border border-gray-200">
    <h2 class="text-3xl font-semibold mb-8 text-gray-800 text-center flex items-center justify-center gap-3">
        <i class="ph ph-user-plus text-3xl text-indigo-600"></i>
        Register course
    </h2>

    <form method="POST" action="" class="space-y-8">

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-gray-700 mb-2 font-medium">First Name</label>
                <input type="text" id="InputFocus" name="firstName" required placeholder="Enter first name"
                    class="val-username w-full border border-gray-300 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none">
            </div>

            <div>
                <label class="block text-gray-700 mb-2 font-medium">Last Name</label>
                <input type="text" name="lastName" required placeholder="Enter last name"
                    class="val-username w-full border border-gray-300 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none">
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-gray-700 mb-2 font-medium">Enrollment Date</label>
                <input type="date" name="enrollmentDate" required
                    class="w-full border border-gray-300 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none">
            <script>
                $(document).ready(function() {
                    $("#InputFocus").focus();
                });
                    const today = new Date().toISOString().split('T')[0];
                    document.querySelector('input[name="enrollmentDate"]').setAttribute('min', today);
                    const maxDate = new Date();
                    maxDate.setFullYear(maxDate.getFullYear() + 1);
                    document.querySelector('input[name="enrollmentDate"]').setAttribute('max', maxDate.toISOString().split('T')[0]);
            </script>
                </div>

            <div>
                <label class="block text-gray-700 mb-2 font-medium">Major</label>
                <input type="text" name="major" required placeholder="Enter major"
                    class="val-com-name w-full border border-gray-300 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none">
            </div>
        </div>

        <div>
            <label class="block text-gray-700 mb-3 font-medium flex items-center gap-2">
                <i class="ph ph-books text-xl text-indigo-600"></i>
                Select Courses
            </label>

            <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
                <?php foreach ($courses as $course): ?>
                    <label class="flex items-center gap-2 text-gray-700 text-lg">
                        <input type="checkbox" name="courses[]" value="<?= $course ?>"
                               class="w-5 h-5 text-indigo-600 rounded">
                        <?= $course ?>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>

        <button type="submit"
            class="w-full bg-indigo-600 text-white py-3.5 rounded-[22px] text-lg font-semibold shadow-md hover:bg-indigo-700 transition-all">
            Register
        </button>

    </form>
</div>
</body>
</html>
