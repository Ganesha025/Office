<?php
include 'db.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "
SELECT 
    p.category AS product_category,
    SUM(od.quantity * p.price) AS total_sales
FROM OrderDetails od
JOIN Orders o ON od.order_id = o.order_id
JOIN Products p ON od.product_id = p.product_id
WHERE YEAR(o.order_date) = YEAR(CURDATE())
GROUP BY p.category
ORDER BY total_sales DESC
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Product Sales Analysis</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        table { border-collapse: collapse; width: 60%; margin: auto; background-color: #fff; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: center; }
        th { background-color: #4CAF50; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        h2 { text-align: center; }
    </style>
</head>
<body>
    <h2>Product Sales </h2>
    <table>
        <tr>
            <th>Product Category</th>
            <th>Total Revenue </th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['product_category']) . "</td>";
                echo "<td>" . number_format($row['total_sales'], 2) . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='2'>No sales data found for the current year.</td></tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
$conn->close();
?>
