<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ProductSalesAnalysis";

$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) !== TRUE) {
    echo "Error creating database: " . $conn->error;
}

$conn->select_db($dbname);

$sql = "CREATE TABLE IF NOT EXISTS Products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL
)";
$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS Orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    order_date DATE NOT NULL
)";
$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS OrderDetails (
    order_detail_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES Products(product_id) ON DELETE CASCADE
)";
$conn->query($sql);

$products = [
    ['Laptop', 'Electronics', 800],
    ['Smartphone', 'Electronics', 500],
    ['Tablet', 'Electronics', 300],
    ['Headphones', 'Electronics', 50],
    ['Charger', 'Electronics', 20],
    ['Desk Chair', 'Furniture', 150],
    ['Dining Table', 'Furniture', 400],
    ['Sofa', 'Furniture', 600],
    ['Bookshelf', 'Furniture', 120],
    ['Bed', 'Furniture', 700],
    ['Notebook', 'Stationery', 5],
    ['Pen', 'Stationery', 2],
    ['Marker', 'Stationery', 3],
    ['Stapler', 'Stationery', 10],
    ['Paper Pack', 'Stationery', 8],
    ['T-shirt', 'Clothing', 25],
    ['Jeans', 'Clothing', 40],
    ['Jacket', 'Clothing', 60],
    ['Sneakers', 'Clothing', 80],
    ['Hat', 'Clothing', 15],
    ['Watch', 'Accessories', 100],
    ['Belt', 'Accessories', 30]
];

foreach ($products as $p) {
    $stmt = $conn->prepare("INSERT INTO Products (product_name, category, price) VALUES (?, ?, ?)");
    $stmt->bind_param("ssd", $p[0], $p[1], $p[2]);
    $stmt->execute();
}

for ($i = 1; $i <= 20; $i++) {
    $month = rand(1, 12);
    $day = rand(1, 28);
    $date = date("Y-m-d", strtotime(date("Y") . "-$month-$day"));
    $stmt = $conn->prepare("INSERT INTO Orders (order_date) VALUES (?)");
    $stmt->bind_param("s", $date);
    $stmt->execute();
}

for ($i = 1; $i <= 50; $i++) {
    $order_id = rand(1, 20);
    $product_id = rand(1, count($products));
    $quantity = rand(1, 10);
    $stmt = $conn->prepare("INSERT INTO OrderDetails (order_id, product_id, quantity) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $order_id, $product_id, $quantity);
    $stmt->execute();
}

?>
