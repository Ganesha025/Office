<?php
include 'db.php'; // Include database connection
$sql = "
SELECT e.sales_rep_id AS sales_rep_id,e.sales_rep_name AS sales_rep_name,SUM(s.amount) AS total_sales_revenue
FROM Sales s JOIN Employees e ON s.sales_rep_id = e.sales_rep_id
WHERE s.sale_date >= DATE_FORMAT(CURDATE() ,'%Y-01-01') AND s.sale_date <= DATE_FORMAT(CURDATE() ,'%Y-12-31')
GROUP BY e.sales_rep_id, e.sales_rep_name
ORDER BY total_sales_revenue DESC";
$result = $conn->query($sql);
if (!$result) {
    die("SQL Error: " . $conn->error);
}
if ($result->num_rows > 0) {
    echo "<h2>Sales Performance Report (Current Year)</h2>";
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>Sales Rep ID</th><th>Sales Rep Name</th><th>Total Sales Revenue</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row['sales_rep_id']."</td>";
        echo "<td>".$row['sales_rep_name']."</td>";
        echo "<td>".$row['total_sales_revenue']."</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No sales data found for current year.";
}

$conn->close();
?>