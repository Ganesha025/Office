<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = ""; // your MySQL password
$dbname = "SalesPerformanceAnalysis";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");
$conn->select_db($dbname);

// Create Employees table
$conn->query("
CREATE TABLE IF NOT EXISTS Employees (
    sales_rep_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
)
");

// Create Sales table
$conn->query("
CREATE TABLE IF NOT EXISTS Sales (
    sale_id INT AUTO_INCREMENT PRIMARY KEY,
    sales_rep_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    sale_date DATE NOT NULL,
    FOREIGN KEY (sales_rep_id) REFERENCES Employees(sales_rep_id)
)
");
$result = $conn->query("SELECT COUNT(*) as count FROM Employees");
$row = $result->fetch_assoc();
if ($row['count'] == 0) {
    $employees = ['Arun', 'Karthik', 'Priya', 'Divya', 'Ravi', 'Sundar', 'Meena', 'Lakshmi', 'Vikram', 'Anitha'];
    foreach ($employees as $name) {
        $conn->query("INSERT INTO Employees (name) VALUES ('$name')");
    }
}
$result2 = $conn->query("SELECT COUNT(*) as count FROM Sales");
$row2 = $result2->fetch_assoc();
if ($row2['count'] == 0) {
    // Current year
    $currentYear = date("Y");
    for ($i = 1; $i <= 10; $i++) { // for each employee
        for ($j = 1; $j <= 5; $j++) { // 5 sales per employee
            $amount = rand(1000, 10000); // random sales amount
            $month = rand(1, 12);
            $day = rand(1, 28);
            $date = "$currentYear-$month-$day";
            $conn->query("INSERT INTO Sales (sales_rep_id, amount, sale_date) VALUES ($i, $amount, '$date')");
        }
    }
}

// echo "Database and tables created, sample data inserted successfully!";
?>
