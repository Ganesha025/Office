<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "OnlineRetailStore";

$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
$conn->query($sql);

$conn->select_db($dbname);

$sqlCustomers = "CREATE TABLE IF NOT EXISTS Customers (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    JoinDate DATE NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE
)";
$conn->query($sqlCustomers);

$sqlPurchases = "CREATE TABLE IF NOT EXISTS Purchases (
    PurchaseID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT NOT NULL,
    Product VARCHAR(100) NOT NULL,
    PurchaseDate DATE NOT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID) ON DELETE CASCADE
)";
$conn->query($sqlPurchases);
?>
