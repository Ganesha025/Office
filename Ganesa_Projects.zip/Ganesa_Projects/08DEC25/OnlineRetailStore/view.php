<?php
include 'db.php';

$sql = "SELECT c.FirstName, c.LastName, IFNULL(SUM(p.Amount),0) AS TotalAmount
        FROM Customers c
        LEFT JOIN Purchases p ON c.CustomerID = p.CustomerID
        GROUP BY c.CustomerID
        ORDER BY TotalAmount DESC";
$result = $conn->query($sql);
$sql1 = "SELECT c.FirstName, c.LastName, p.Amount
         FROM Customers c
         LEFT JOIN Purchases p ON c.CustomerID = p.CustomerID
         ORDER BY c.CustomerID";
$result1 = $conn->query($sql1);
$sql2 = "SELECT c.FirstName, c.LastName, p.Amount
         FROM Customers c
         LEFT JOIN Purchases p ON c.CustomerID = p.CustomerID
         GROUP BY c.CustomerID";
$result2 = $conn->query($sql2);
$sql3 = "SELECT c.FirstName, c.LastName, SUM(p.Amount) AS TotalSpent
         FROM Customers c
         JOIN Purchases p ON c.CustomerID = p.CustomerID
         GROUP BY purchaseID";
$result3 = $conn->query($sql3);
$sql4 = "SELECT c.FirstName, c.LastName, AVG(p.Amount) AS AvgSpent
         FROM Customers c
         JOIN Purchases p ON c.CustomerID = p.CustomerID
         GROUP BY c.CustomerID";
$result4 = $conn->query($sql4);
$sql5 = "SELECT c.FirstName, c.LastName, SUM(p.Amount) AS TotalSpent
         FROM Customers c
         JOIN Purchases p ON c.CustomerID = p.CustomerID
         GROUP BY c.CustomerID
         HAVING SUM(p.Amount) > 1000";
$result5 = $conn->query($sql5);
$sql6 = "SELECT Product, COUNT(*) AS PurchaseCount
         FROM Purchases
         GROUP BY Product
         HAVING COUNT(*) > 10";
$result6 = $conn->query($sql6);
$sql7 = "SELECT c.FirstName, c.LastName, SUM(p.Amount) AS TotalSpent
         FROM Customers c
         JOIN Purchases p ON c.CustomerID = p.CustomerID
         GROUP BY c.CustomerID
         ORDER BY TotalSpent DESC";
$result7 = $conn->query($sql7);
$sql8 = "SELECT c.FirstName, c.LastName, COUNT(p.PurchaseID) AS PurchaseCount, SUM(p.Amount) AS TotalSpent
         FROM Customers c
         JOIN Purchases p ON c.CustomerID = p.CustomerID
         GROUP BY c.CustomerID
         HAVING COUNT(p.PurchaseID) >= 5";
$result8 = $conn->query($sql8);
$sql9 = "SELECT Product, SUM(Amount) AS TotalSales
         FROM Purchases
         GROUP BY Product
         ORDER BY TotalSales DESC
         LIMIT 1";
$result9 = $conn->query($sql9);
$chart2_labels = [];
$chart2_data = [];
$result2->data_seek(0);
while($row = $result2->fetch_assoc()){
    $chart2_labels[] = $row['FirstName']." ".$row['LastName'];
    $chart2_data[] = $row['Amount'] ? $row['Amount'] : 0;
}

$result1 = $conn->query("SELECT c.FirstName,c.LastName,p.Amount FROM Customers c LEFT JOIN Purchases p ON c.CustomerID=p.CustomerID ORDER BY c.CustomerID");
$result_total = $conn->query("SELECT c.FirstName,c.LastName,IFNULL(SUM(p.Amount),0) AS TotalSpent FROM Customers c LEFT JOIN Purchases p ON c.CustomerID=p.CustomerID GROUP BY c.CustomerID ORDER BY TotalSpent DESC");

$chart3_labels=[];$chart3_data=[];
$result_total->data_seek(0);
while($row=$result_total->fetch_assoc()){$chart3_labels[]=$row['FirstName']." ".$row['LastName'];$chart3_data[]=(float)$row['TotalSpent'];}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Retail Store Analytics</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans">

<div class="container mx-auto p-4">

    <h1 class="text-3xl font-bold mb-6 text-center text-gray-800">Online Retail Store Analytics</h1>

    <!-- Charts Section -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
   <table class="min-w-full bg-white rounded-xl shadow mb-8">
    <thead class="bg-gray-50">
        <tr>
            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Customer</th>
            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Purchase Amount</th>
        </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
        <?php while($row = $result1->fetch_assoc()) { ?>
        <tr class="hover:bg-gray-50">
            <td class="px-4 py-2"><?= htmlspecialchars($row['FirstName']." ".$row['LastName']) ?></td>
            <td class="px-4 py-2"><?= $row['Amount'] !== null ? number_format($row['Amount'],2) : '0.00' ?></td>
        </tr>
        <?php } ?>
    </tbody>
</table>
        <div class="bg-white rounded-xl shadow p-4">
            <h2 class="text-xl font-semibold mb-4">Customers and Purchase Amounts</h2>
            <canvas id="chart2" class="w-full h-64"></canvas>
        </div>

        <div class="bg-white rounded-xl shadow p-4">
            <h2 class="text-xl font-semibold mb-4">Total Amount Spent by Customers</h2>
            <canvas id="chart3" class="w-full h-64"></canvas>
        </div>

<table class="min-w-full bg-white rounded-xl shadow mb-8">
    <thead class="bg-gray-50">
        <tr>
            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Customer</th>
            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Total Purchase Amount</th>
        </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
        <?php while($row = $result->fetch_assoc()) { ?>
        <tr class="hover:bg-gray-50">
            <td class="px-4 py-2"><?= htmlspecialchars($row['FirstName'] . " " . $row['LastName']) ?></td>
            <td class="px-4 py-2"><?= number_format($row['TotalAmount'], 2) ?></td>
        </tr>
        <?php } ?>
    </tbody>
</table>    </div>

    <!-- Tables Section -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="bg-white rounded-xl shadow p-4 overflow-x-auto">
            <h3 class="text-lg font-semibold mb-4">Average Amount Spent Per Purchase</h3>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Customer</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Average Spent</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php while($row = $result4->fetch_assoc()) { ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-2"><?= $row['FirstName']." ".$row['LastName'] ?></td>
                        <td class="px-4 py-2"><?= number_format($row['AvgSpent'],2) ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div class="bg-white rounded-xl shadow p-4 overflow-x-auto">
            <h3 class="text-lg font-semibold mb-4">Customers Who Spent > 1000</h3>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Customer</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Total Spent</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php while($row = $result5->fetch_assoc()) { ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-2"><?= $row['FirstName']." ".$row['LastName'] ?></td>
                        <td class="px-4 py-2"><?= number_format($row['TotalSpent'],2) ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- More Tables -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        <div class="bg-white rounded-xl shadow p-4 overflow-x-auto">
            <h3 class="text-lg font-semibold mb-4">Products Purchased > 10 Times</h3>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Product</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Purchase Count</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php while($row = $result6->fetch_assoc()) { ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-2"><?= $row['Product'] ?></td>
                        <td class="px-4 py-2"><?= $row['PurchaseCount'] ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div class="bg-white rounded-xl shadow p-4 overflow-x-auto">
            <h3 class="text-lg font-semibold mb-4">Total Spent Per Customer Descending</h3>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Customer</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Total Spent</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php while($row = $result7->fetch_assoc()) { ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-2"><?= $row['FirstName']." ".$row['LastName'] ?></td>
                        <td class="px-4 py-2"><?= number_format($row['TotalSpent'],2) ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        <div class="bg-white rounded-xl shadow p-4 overflow-x-auto">
            <h3 class="text-lg font-semibold mb-4">Customers With At Least 5 Purchases</h3>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Customer</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Purchase Count</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Total Spent</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php while($row = $result8->fetch_assoc()) { ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-2"><?= $row['FirstName']." ".$row['LastName'] ?></td>
                        <td class="px-4 py-2"><?= $row['PurchaseCount'] ?></td>
                        <td class="px-4 py-2"><?= number_format($row['TotalSpent'],2) ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div class="bg-white rounded-xl shadow p-4 overflow-x-auto">
            <h3 class="text-lg font-semibold mb-4">Product With Highest Total Sales</h3>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Product</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Total Sales</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php while($row = $result9->fetch_assoc()) { ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-2"><?= $row['Product'] ?></td>
                        <td class="px-4 py-2"><?= number_format($row['TotalSales'],2) ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
// Pie Chart 2
const labels2 = <?= json_encode($chart2_labels) ?>;
// Function to generate a color from a string (customer name)
function stringToColor(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    const r = (hash >> 0) & 0xFF;
    const g = (hash >> 8) & 0xFF;
    const b = (hash >> 16) & 0xFF;
    return `rgba(${r}, ${g}, ${b}, 0.6)`;
}

const data2 = {
    labels: labels2,
    datasets: [{
        label: 'Purchase Amount',
        data: <?= json_encode($chart2_data) ?>,
        backgroundColor: labels2.map(name => stringToColor(name)), // same name → same color
        borderWidth: 1,
    }],options: {title : {display: true,text: 'Customers and Purchase Amounts'}}
};

new Chart(document.getElementById('chart2'), { type: 'pie', data: data2});

// Pie Chart 3
const labels3 = <?= json_encode($chart3_labels) ?>;
const data3 = {
    labels: labels3,
    datasets: [{
        label: 'Total Spent',
        data: <?= json_encode($chart3_data) ?>,
        backgroundColor: labels3.map(() => 'rgba(' + Math.floor(Math.random()*255) + ',' + Math.floor(Math.random()*255) + ',' + Math.floor(Math.random()*255) + ',0.6)'),
        borderWidth: 1
    }]
};
new Chart(document.getElementById('chart3'), { type: 'line', data: data3, });
</script>

</body>
</html>
