<?php
$encrypted_text = '';
$decrypted_text = '';
$key = "12345678901234567890123456789030";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $plaintext = $_POST['plaintext'] ?? '';

    // Encrypt
    $iv = openssl_random_pseudo_bytes(16);
    $ciphertext = openssl_encrypt($plaintext, "AES-256-CBC", $key, OPENSSL_RAW_DATA, $iv);
    $encrypted_text = base64_encode($iv . $ciphertext);

    // Decrypt immediately
    $data = base64_decode($encrypted_text);
    $iv2 = substr($data, 0, 16);
    $ciphertext_raw = substr($data, 16);
    $decrypted_text = openssl_decrypt($ciphertext_raw, "AES-256-CBC", $key, OPENSSL_RAW_DATA, $iv2);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AES-256 Encrypt & Decrypt</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans p-6">

    <div class="max-w-xl mx-auto bg-white shadow rounded-xl p-6">
        <h1 class="text-2xl font-bold mb-4 text-center">AES-256 Encrypt & Decrypt</h1>

        <form method="post" class="space-y-4">
            <div>
                <label class="block mb-1 font-semibold">Enter Message</label>
                <input type="text" name="plaintext" class="w-full border rounded p-2" placeholder="Type something..." required>
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">Encrypt & Decrypt</button>
        </form>

        <?php if($encrypted_text): ?>
        <div class="mt-6">
            <h2 class="font-semibold mb-1">Encrypted (Base64)</h2>
            <textarea class="w-full border rounded p-2" rows="3" readonly><?= htmlspecialchars($encrypted_text) ?></textarea>
        </div>
        <div class="mt-4">
            <h2 class="font-semibold mb-1">Decrypted</h2>
            <textarea class="w-full border rounded p-2" rows="2" readonly><?= htmlspecialchars($decrypted_text) ?></textarea>
        </div>
        <?php endif; ?>
    </div>

</body>
</html>
