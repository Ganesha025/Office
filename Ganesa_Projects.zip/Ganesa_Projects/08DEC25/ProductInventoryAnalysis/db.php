<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ProductInventoryAnalysis";
$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    // echo "Database created or already exists.<br>";
} else {
    die("Error creating database: " . $conn->error);
}
$conn->select_db($dbname);
$table_sql = "CREATE TABLE IF NOT EXISTS Products (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(255) NOT NULL,
    ProductCategory VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($table_sql) === TRUE) {
    // echo "Table created or already exists.<br>";
} else {
    die("Error creating table: " . $conn->error);
}
?>
