<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Realtime Product Inventory</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@3.3.3/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script src="https://cdn.tailwindcss.com"></script>

    <style>
        body { font-family: 'Roboto', sans-serif; }
        .loading-overlay {
            position: fixed;
            top:0; left:0; right:0; bottom:0;
            background: rgba(255,255,255,0.7);
            display:flex;
            justify-content:center;
            align-items:center;
            z-index:1000;
            display:none;
        }
        .loading-spinner {
            border: 6px solid #f3f3f3;
            border-top: 6px solid #3b82f6;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
        }
        @keyframes spin { 100% { transform: rotate(360deg); } }
        table.dataTable th, table.dataTable td { text-align: center; }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">

<div class="loading-overlay" id="loadingOverlay">
    <div class="loading-spinner"></div>
</div>

<div class="container mx-auto p-4">
    <h2 class="text-3xl font-semibold mb-6 text-center text-gray-800">Realtime Product Inventory</h2>

    <div class="bg-white shadow-md rounded-lg p-6 mb-8">
        <h3 class="text-xl font-medium mb-4 text-gray-700">Add Product</h3>
        <form id="addProductForm" class="flex flex-col md:flex-row gap-4">
            <div class="flex items-center border rounded-md px-3 py-2 bg-gray-50 focus-within:ring-2 focus-within:ring-blue-500">
                <span class="material-icons text-gray-400 mr-2">inventory_2</span>
                <input type="text" name="product_name" placeholder="Product Name" class="bg-transparent outline-none w-full text-gray-700" required>
            </div>
            <div class="flex items-center border rounded-md px-3 py-2 bg-gray-50 focus-within:ring-2 focus-within:ring-blue-500">
                <span class="material-icons text-gray-400 mr-2">category</span>
                <input type="text" name="product_category" placeholder="Product Category" class="bg-transparent outline-none w-full text-gray-700" required>
            </div>
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition w-full md:w-auto flex items-center justify-center">
                <span class="material-icons mr-2">add</span> Add Product
            </button>
        </form>
    </div>

    <div class="bg-white shadow-md rounded-lg p-6 mb-8">
        <h3 class="text-xl font-medium mb-4 text-gray-700">Inventory Table</h3>
        <div class="overflow-x-auto">
            <table id="inventoryTable" class="display w-full text-gray-700"></table>
        </div>
    </div>

    <div class="bg-white shadow-md rounded-lg p-6 mb-8">
        <h3 class="text-xl font-medium mb-4 text-gray-700">Category Distribution</h3>
        <canvas id="categoryChart" class="w-full h-64 md:h-96"></canvas>
    </div>
</div>

<script>
const loadingOverlay = $('#loadingOverlay');

let table = $('#inventoryTable').DataTable({
    "ajax": 'fetch_inventory.php',
    "columns": [
        { "title": "Product Category", "data": "Product Category" },
        { "title": "Number of Products", "data": "Number of Products" }
    ],
    "ordering": true,
    "searching": true,
    "paging": true,
    "info": false,
    "responsive": true
});

let ctx = document.getElementById('categoryChart').getContext('2d');
let categoryChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: [],
        datasets: [{
            label: 'Number of Products',
            data: [],
            backgroundColor: 'rgba(59, 130, 246, 0.6)',
            borderColor: 'rgba(59, 130, 246, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});

function loadInventory() {
    loadingOverlay.show();
    $.ajax({
        url: 'fetch_inventory_chart.php',
        method: 'GET',
        success: function(response) {
            let data = JSON.parse(response);

            table.clear().rows.add(data).draw();

            let labels = data.map(item => item['Product Category']);
            let values = data.map(item => parseInt(item['Number of Products']));

            categoryChart.data.labels = labels;
            categoryChart.data.datasets[0].data = values;
            categoryChart.update();

            loadingOverlay.hide();
        },
        error: function() {
            alert("Failed to fetch inventory data.");
            loadingOverlay.hide();
        }
    });
}

$('#addProductForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: 'add.php',
        method: 'POST',
        data: $(this).serialize(),
        beforeSend: () => loadingOverlay.show(),
        success: function() {
            $('#addProductForm')[0].reset();
            loadInventory();
        },
        error: function() {
            alert("Failed to add product.");
            loadingOverlay.hide();
        }
    });
});

loadInventory();
setInterval(loadInventory, 50000);
</script>

</body>
</html>
