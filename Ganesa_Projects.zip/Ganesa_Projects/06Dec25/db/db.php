<!-- <?php
// db/db.php

// Database credentials
$host = "localhost";
$user = "root";
$pass = ""; // set your MySQL root password
$db_name = "college_exam";

// Create connection to MySQL server
$conn = new mysqli($host, $user, $pass);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if not exists
$sql = "CREATE DATABASE IF NOT EXISTS $db_name";
if ($conn->query($sql) === FALSE) {
    die("Error creating database: " . $conn->error);
}

// Select the database
$conn->select_db($db_name);

// ------------------------
// Create tables if not exists
// ------------------------

// 1. Departments
$conn->query("
CREATE TABLE IF NOT EXISTS departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dept_code VARCHAR(10) UNIQUE NOT NULL,
    dept_name VARCHAR(100) NOT NULL
) ENGINE=InnoDB;
");

// 2. Students
$conn->query("
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reg_no VARCHAR(20) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    department_id INT NOT NULL,
    semester INT DEFAULT 1,
    attendance FLOAT DEFAULT 0,
    internal_marks FLOAT DEFAULT 0,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE
) ENGINE=InnoDB;
");

// 3. Subjects
$conn->query("
CREATE TABLE IF NOT EXISTS subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dept_id INT NOT NULL,
    sub_name VARCHAR(100) NOT NULL,
    qp_code VARCHAR(20) UNIQUE NOT NULL,
    credits INT NOT NULL,
    FOREIGN KEY (dept_id) REFERENCES departments(id) ON DELETE CASCADE
) ENGINE=InnoDB;
");

// 4. Student Subjects (marks/status)
$conn->query("
CREATE TABLE IF NOT EXISTS student_subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    status ENUM('pass','fail') DEFAULT 'fail',
    external_marks FLOAT DEFAULT 0,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB;
");

// 5. Exam Dates
$conn->query("
CREATE TABLE IF NOT EXISTS exam_dates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject_id INT NOT NULL,
    exam_date DATE NOT NULL,
    UNIQUE(subject_id),
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB;
");

// 6. Hall Tickets
$conn->query("
CREATE TABLE IF NOT EXISTS hall_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    hall_ticket_id VARCHAR(50) UNIQUE NOT NULL,
    center VARCHAR(100) NOT NULL,
    exam_date DATE NOT NULL,
    subjects_list TEXT NOT NULL,
    downloaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;
");

// 7. Admin credentials (optional initial data)
$conn->query("
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
) ENGINE=InnoDB;
");

// Insert default admin if not exists
$default_admin = "admin";
$default_pass = password_hash("admin@123", PASSWORD_DEFAULT);

$stmt = $conn->prepare("SELECT id FROM admins WHERE username = ?");
$stmt->bind_param("s", $default_admin);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    $insert = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
    $insert->bind_param("ss", $default_admin, $default_pass);
    $insert->execute();
    $insert->close();
}

$stmt->close();
?> -->
