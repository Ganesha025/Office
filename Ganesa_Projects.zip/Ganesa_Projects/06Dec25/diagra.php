project_root/
│
├── admin/                  # Admin module pages
│   ├── dashboard.php
│   ├── add_student.php
│   ├── department.php
│   ├── subject.php
│   ├── mark.php
│   ├── exam.php
│   ├── hallticket.php
│   ├── halltick_dup_download_logs.php
│   └── includes/           # Optional: shared files for admin
│       ├── header.php
│       ├── footer.php
│       └── functions.php   # Admin-specific helper functions
│
├── student/                # Student module pages
│   ├── dashboard.php       # Optional: student landing page
│   ├── view_hallticket.php
│   └── includes/           # Shared student files
│       ├── header.php
│       └── footer.php
│
├── auth/                   # Authentication
│   ├── login.php
│   ├── logout.php
│   └── functions.php       # Login & session validation
│
├── db/                     # Database connection
│   └── db.php
│
├── assets/                 # CSS, JS, Images
│   ├── css/
│   ├── js/
│   └── images/
│
├── config/                 # Configuration files
│   └── config.php          # DB credentials, constants
│
├── index.php               # Optional: redirect to login/dashboard
└── README.md
