<?php
session_start();
include '../db/db.php';
include './includes/functions.php';
requireAdmin();

$students_count = $conn->query("SELECT COUNT(*) AS c FROM students")->fetch_assoc()['c'];
$dept_count = $conn->query("SELECT COUNT(*) AS c FROM departments")->fetch_assoc()['c'];
$subject_count = $conn->query("SELECT COUNT(*) AS c FROM subjects")->fetch_assoc()['c'];
$exam_count = $conn->query("SELECT COUNT(*) AS c FROM exams")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Dashboard - College ERP</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Inter',sans-serif;background: #9ecfffff}
.card{background:#fff;border:1px solid #e0e0e0;transition:all .2s}
.card:hover{border-color:#1565c0;box-shadow:0 2px 8px rgba(21,101,192,.08)}
.stat-num{font-size:2rem;font-weight:700;color:#212121}
.stat-label{font-size:.875rem;color:#616161;font-weight:500}
.nav-btn{background:#fff;border:1px solid #e0e0e0;transition:all .2s}
.nav-btn:hover{background:#1565c0;border-color:#1565c0}
.nav-btn:hover .nav-icon{color:#fff}
.nav-btn:hover .nav-text{color:#fff}
.nav-icon{color:#1565c0;transition:color .2s}
.nav-text{color:#212121;font-weight:500;font-size:.875rem}
.material-icons{font-size:28px}
</style>
</head>
<body>

<nav class="bg-white border-b border-gray-300 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
<div class="flex items-center gap-3">
<span class="material-icons text-blue-700" style="font-size:32px">school</span>
<div>
<div class="text-lg font-bold text-gray-900">College ERP System</div>
<div class="text-xs text-gray-600">Administrator Portal</div>
</div>
</div>
<a href="logout.php" class="px-4 py-2 bg-red-600 text-white rounded text-sm font-medium hover:bg-red-700 transition">Logout</a>
</div>
</nav>

<div class="max-w-7xl mx-auto px-6 py-8">

<div class="mb-8">
<h1 class="text-2xl font-bold text-gray-900 mb-1">Dashboard Overview</h1>
<p class="text-sm text-gray-600">Welcome back, Administrator</p>
</div>

<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">

<div class="card rounded-[10px] p-6">
<div class="flex items-start justify-between mb-4">
<div class="w-12 h-12 bg-blue-50 rounded flex items-center justify-center">
<span class="material-icons text-blue-700">group</span>
</div>
</div>
<div class="stat-num count" data-target="<?php echo $students_count;?>">0</div>
<div class="stat-label">Total Students</div>
</div>

<div class="card rounded-[10px] p-6">
<div class="flex items-start justify-between mb-4">
<div class="w-12 h-12 bg-blue-50 rounded flex items-center justify-center">
<span class="material-icons text-blue-700">domain</span>
</div>
</div>
<div class="stat-num count" data-target="<?php echo $dept_count;?>">0</div>
<div class="stat-label">Departments</div>
</div>

<div class="card rounded-[10px] p-6">
<div class="flex items-start justify-between mb-4">
<div class="w-12 h-12 bg-blue-50 rounded flex items-center justify-center">
<span class="material-icons text-blue-700">menu_book</span>
</div>
</div>
<div class="stat-num count" data-target="<?php echo $subject_count;?>">0</div>
<div class="stat-label">Subjects</div>
</div>

<div class="card rounded-[10px] p-6">
<div class="flex items-start justify-between mb-4">
<div class="w-12 h-12 bg-blue-50 rounded flex items-center justify-center">
<span class="material-icons text-blue-700">event</span>
</div>
</div>
<div class="stat-num count" data-target="<?php echo $exam_count;?>">0</div>
<div class="stat-label">Exam Schedules</div>
</div>

</div>

<div class="mb-6">
<h2 class="text-xl font-bold text-gray-900 mb-4">Quick Actions</h2>
</div>

<div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">

<a href="add_student.php" class="nav-btn rounded-[15px] p-5 flex flex-col items-center gap-3">
<span class="material-icons nav-icon">person_add</span>
<span class="nav-text">Add Student</span>
</a>

<a href="department.php" class="nav-btn rounded-[15px] p-5 flex flex-col items-center gap-3">
<span class="material-icons nav-icon">domain</span>
<span class="nav-text">Departments</span>
</a>

<a href="subject.php" class="nav-btn rounded-[15px] p-5 flex flex-col items-center gap-3">
<span class="material-icons nav-icon">menu_book</span>
<span class="nav-text">Subjects</span>
</a>

<a href="mark.php" class="nav-btn rounded-[15px] p-5 flex flex-col items-center gap-3">
<span class="material-icons nav-icon">assignment</span>
<span class="nav-text">Assign Marks</span>
</a>

<a href="exam.php" class="nav-btn rounded-[15px] p-5 flex flex-col items-center gap-3">
<span class="material-icons nav-icon">event_note</span>
<span class="nav-text">Exam Dates</span>
</a>

<a href="hallticket.php" class="nav-btn rounded-[15px] p-5 flex flex-col items-center gap-3">
<span class="material-icons nav-icon">confirmation_number</span>
<span class="nav-text">Hall Tickets</span>
</a>

<a href="halltick_dup_download_logs.php" class="nav-btn rounded-[15px] p-5 flex flex-col items-center gap-3">
<span class="material-icons nav-icon">download</span>
<span class="nav-text">Download Logs</span>
</a>

<a href="view_request.php" class="nav-btn rounded-[15px] p-5 flex flex-col items-center gap-3">
<span class="material-icons nav-icon">inbox</span>
<span class="nav-text">Requests</span>
</a>

</div>

</div>

<script>
const counters=document.querySelectorAll('.count');
counters.forEach(c=>{
const t=+c.getAttribute('data-target');
let n=0;
const inc=t/80;
const u=()=>{
n+=inc;
if(n<t){
c.innerText=Math.ceil(n);
requestAnimationFrame(u);
}else{
c.innerText=t;
}
};
setTimeout(u,100);
});
</script>

</body>
</html>