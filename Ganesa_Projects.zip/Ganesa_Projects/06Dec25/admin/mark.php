<?php
session_start();
include '../db/db.php';
include '../functions.php';
ensureAdmin();
$message = "";
$dept_query = $conn->query("SELECT * FROM departments ORDER BY dept_code ASC");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $student_id = $_POST['student_id'] ?? "";
    $subject_id = $_POST['subject_id'] ?? "";
    $attendance = trim($_POST['attendance']);
    $internal   = trim($_POST['internal']);
    $external   = trim($_POST['external']);
    if ($student_id == "" || $subject_id == "" || $attendance === "" || $internal === "" || $external === "") {
        // $message = alert("All fields are required.", "danger");
        $message = "<p style='color:red;'>All fields are required.</p>";
    } 
    else if ($attendance < 0 || $attendance > 100) {
        $message="<p style='color:red;'>Attendance must be between 0 and 100.</p>";
    }
    else if ($internal < 0 || $internal > 50) {
        $message = "<p style='color:red;'>Internal marks must be between 0 and 50.</p>";
    }
    else if ($external < 0 || $external > 100) {
        $message = "<p style='color:red;'>External marks must be between 0 and 100.</p>";
    }
    else {
        $check = $conn->prepare("SELECT id FROM marks WHERE student_id=? AND subject_id=?");
        $check->bind_param("ii", $student_id, $subject_id);
        $check->execute();
        $check->store_result();
        if ($check->num_rows > 0) {
            $stmt = $conn->prepare("UPDATE marks SET attendance=?, internal=?, external=? WHERE student_id=? AND subject_id=?");
            $stmt->bind_param("iiiii", $attendance, $internal, $external, $student_id, $subject_id);
            $stmt->execute();
            $message = "<p style='color:green;'>Marks updated successfully!</p>";
        } else {
            $stmt = $conn->prepare("INSERT INTO marks(student_id, subject_id, attendance, internal, external) VALUES(?,?,?,?,?)");
            $stmt->bind_param("iiiii", $student_id, $subject_id, $attendance, $internal, $external);
            $stmt->execute();
            $message = "<p style='color:green;'>Marks added successfully!</p>";
        }
    }
}

if (isset($_GET['get_students'])) {
    $dept_code = $_GET['get_students'];
    $data = $conn->query("SELECT * FROM students WHERE dept_code='$dept_code' ORDER BY username ASC");
    while ($s = $data->fetch_assoc()) {
        echo "<option value='{$s['id']}'>{$s['username']} ({$s['regno']})</option>";
    }
    exit;
}

if (isset($_GET['get_subjects'])) {
    $dept_code = $_GET['get_subjects'];
    $data = $conn->query("SELECT * FROM subjects WHERE dept_code='$dept_code' ORDER BY sub_name ASC");
    while ($s = $data->fetch_assoc()) {
        echo "<option value='{$s['id']}'>{$s['sub_name']} ({$s['qp_code']})</option>";
    }
    exit;
}

if (isset($_POST['inline_update'])) {
    $id = $_POST['id'];
    $field = $_POST['field'];
    $value = $_POST['value'];
    $allowed = ['attendance','internal','external'];
    if (!in_array($field,$allowed)) exit('Invalid field');
    if ($field == "attendance" && ($value < 0 || $value > 100)) exit('Invalid attendance');
    if ($field == "internal" && ($value < 0 || $value > 50)) exit('Invalid internal');
    if ($field == "external" && ($value < 0 || $value > 100)) exit('Invalid external');
    $stmt = $conn->prepare("UPDATE marks SET $field=? WHERE id=?");
    $stmt->bind_param("ii",$value,$id);
    if ($stmt->execute()) echo "Updated";
    else echo "Error: ".$conn->error;
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assign Marks</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="../valid.js"></script>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark px-3">
    <span class="navbar-brand">Admin - Assign Marks</span>
    <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
</nav>
<div class="container mt-4">
<h3>Assign / Update Marks</h3>
<hr>
<?= $message ?>
<form method="POST" class="card p-4 shadow-sm border-0">
    <input type="hidden" name="action" value="add">
    <div class="mb-3">
        <label class="form-label">Department *</label>
        <select name="dept_code" class="form-select" required onchange="loadStudents(this.value)">
            <option value="">Select Department</option>
            <?php while ($d = $dept_query->fetch_assoc()): ?>
                <option value="<?= $d['dept_code'] ?>"><?= $d['dept_code']." - ".$d['dept_name'] ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Student *</label>
        <select name="student_id" class="form-select" id="studentSelect" required>
            <option value="">Select Student</option>
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Subject *</label>
        <select name="subject_id" class="form-select" id="subjectSelect" required>
            <option value="">Select Subject</option>
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Attendance (%) *</label>
        <input type="number" name="attendance" class="form-control val-mark" placeholder="0 - 100" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Internal Marks (0-50) *</label>
        <input type="number" name="internal" class="form-control val-internal-marks" required>
    </div>
    <div class="mb-3">
        <label class="form-label">External Marks (0-100) *</label>
        <input type="number" name="external" class="form-control val-external-marks" required>
    </div>
    <button class="btn btn-primary px-4">Save Marks</button>
</form>

<hr>
<h4>All Marks</h4>
<div id="marksTable">
<table class="table table-bordered table-striped">
<thead>
<tr>
    <th>Student</th>
    <th>Subject</th>
    <th>Attendance</th>
    <th>Internal</th>
    <th>External</th>
    <th>Action</th>
</tr>
</thead>
<tbody>
<?php
$res = $conn->query("SELECT m.id, s.username, sub.sub_name, m.attendance, m.internal, m.external 
                     FROM marks m 
                     JOIN students s ON m.student_id=s.id 
                     JOIN subjects sub ON m.subject_id=sub.id
                     ORDER BY s.username ASC");
while ($row = $res->fetch_assoc()):
?>
<tr>
    <td><?= $row['username'] ?></td>
    <td><?= $row['sub_name'] ?></td>
    <td><input type="number" class="form-control val-mark" value="<?= $row['attendance'] ?>" data-id="<?= $row['id'] ?>" data-field="attendance" disabled></td>
    <td><input type="number" class="form-control val-internal-marks" value="<?= $row['internal'] ?>" data-id="<?= $row['id'] ?>" data-field="internal" disabled></td>
    <td><input type="number" class="form-control val-external-marks" value="<?= $row['external'] ?>" data-id="<?= $row['id'] ?>" data-field="external" disabled></td>
    <td>
        <button class="btn btn-sm btn-warning edit-btn">Edit</button>
        <button class="btn btn-sm btn-success save-btn" style="display:none;">Save</button>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>

<script>
function loadStudents(dept_code){
    fetch("mark.php?get_students="+dept_code).then(res=>res.text()).then(data=>{document.getElementById("studentSelect").innerHTML="<option value=''>Select Student</option>"+data;});
    fetch("mark.php?get_subjects="+dept_code).then(res=>res.text()).then(data=>{document.getElementById("subjectSelect").innerHTML="<option value=''>Select Subject</option>"+data;});
}

$(document).on('click','.edit-btn',function(){
    let row = $(this).closest('tr');
    row.find('input').prop('disabled',false);
    $(this).hide();
    row.find('.save-btn').show();
});

$(document).on('click','.save-btn',function(){
    let row = $(this).closest('tr');
    let updated = true;
    row.find('input').each(function(){
        let input = $(this);
        let value = parseInt(input.val().trim());
        if (isNaN(value)) {updated=false; return false;}
        let id = input.data('id');
        let field = input.data('field');
        $.ajax({url:'mark.php',type:'POST',async:false,data:{inline_update:1,id:id,field:field,value:value},success:function(res){if(res!="Updated"){updated=false;}}});
    });
    if(updated){
        row.find('input').prop('disabled',true);
        row.find('.edit-btn').show();
        row.find('.save-btn').hide();
    }
});
</script>
</body>
</html>
