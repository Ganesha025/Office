<?php
session_start();
include '../db/db.php';
include '../functions.php';
ensureAdmin();

$message = "";

$dept_query = $conn->query("SELECT * FROM departments ORDER BY dept_code ASC");
$departments = [];
while ($row = $dept_query->fetch_assoc()) {
    $departments[] = $row;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $sub_name  = trim($_POST['sub_name']);
    $qp_code   = strtoupper(trim($_POST['qp_code']));
    $credits   = trim($_POST['credits']);
    $dept_code = trim($_POST['dept_code']);

    if ($sub_name == "" || $qp_code == "" || $credits == "" || $dept_code == "") {
        $message = alert("All fields are required!", "danger");
    } 
    else if (!ctype_digit($credits) || $credits > 10) {
        $message = alert("Credits must be a valid number (max 10)!", "danger");
    } 
    else {
        $full_qp_code = $dept_code.$qp_code;
        $check = $conn->prepare("SELECT id FROM subjects WHERE qp_code=?");
        if (!$check) {
            die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
        }
        $check->bind_param("s", $full_qp_code);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $message = "<p style='color: red; font-weight: bold;'>QP Code already exists!!</p>";
        } else {
            $stmt = $conn->prepare("INSERT INTO subjects(sub_name, qp_code, credits, dept_code) VALUES (?, ?, ?, ?)");
            if (!$stmt) {
                die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
            }
            $stmt->bind_param("ssis", $sub_name, $full_qp_code, $credits, $dept_code);
            if ($stmt->execute()) {
                $message="<p style='color: green; font-weight: bold;'>Subject added successfully!</p>";
            } else {
                $message = "<p style='color: red; font-weight: bold;'>Error: " . $conn->error . "</p>";
            }
        }
    }
}

$list = $conn->query("
    SELECT s.*, d.dept_name 
    FROM subjects s 
    LEFT JOIN departments d ON s.dept_code = d.dept_code
    ORDER BY s.dept_code, s.sub_name ASC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Subjects</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" ></script>
     <script src="../valid.js"></script>
</head>
<body class="bg-light">
<script>
    $(document).ready(function() {
       $("#InputFocus").focus();
    });
</script>
<nav class="navbar navbar-dark bg-dark px-3">
    <span class="navbar-brand">Admin - Manage Subjects</span>
    <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
</nav>

<div class="container mt-4">

    <h3>Add Subject</h3>
    <hr>

    <?php echo $message; ?>

    <form method="POST" class="card p-4 shadow-sm border-0">
        <div class="mb-3">
            <label class="form-label">Department *</label>
            <select id="dept_select" name="dept_code" class="form-select" required>
                <option value="">Select Department</option>
                <?php foreach($departments as $d): ?>
                    <option value="<?php echo $d['dept_code']; ?>"><?php echo $d['dept_code']." - ".$d['dept_name']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">QP Code *</label>
            <div class="input-group">
                <span class="input-group-text" id="dept_prefix"></span>
                <input type="text" id="InputFocus" name="qp_code" class="form-control val-dept-codes" required>
            </div>
            <small class="text-muted">Example: 101, 201 (will be prefixed by Dept Code)</small>
        </div>

        <div class="mb-3">
            <label class="form-label">Subject Name *</label>
            <input type="text" name="sub_name" class="form-control val-subject-name" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Credits *</label>
            <input type="number" name="credits" class="form-control val-credits" max="10" required>
        </div>

        <button class="btn btn-primary px-4">Add Subject</button>
    </form>

    <hr class="mt-5">

    <h4>Subject List</h4>

    <table class="table table-striped table-bordered mt-3">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Subject Name</th>
                <th>QP Code</th>
                <th>Credits</th>
                <th>Dept Code</th>
                <th>Department Name</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $i=1; 
            while($row = $list->fetch_assoc()):
            ?>
            <tr>
                <td><?= $i++; ?></td>
                <td><?= $row['sub_name']; ?></td>
                <td><?= $row['qp_code']; ?></td>
                <td><?= $row['credits']; ?></td>
                <td><?= $row['dept_code']; ?></td>
                <td><?= $row['dept_name']; ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</div>

<script>
    const deptSelect = document.getElementById('dept_select');
    const deptPrefix = document.getElementById('dept_prefix');
    deptSelect.addEventListener('change', function() {
        deptPrefix.textContent = this.value;
    });
</script>

</body>
</html>
