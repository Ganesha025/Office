<?php
session_start();
include '../db/db.php';
include '../functions.php';

ensureAdmin();

$message = "";

// Fetch departments
$dept_query = $conn->query("SELECT * FROM departments ORDER BY dept_code ASC");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $dept_code   = trim($_POST['dept_code']);
    $subject_id  = trim($_POST['subject_id']);
    $exam_date   = trim($_POST['exam_date']);

    if ($dept_code == "" || $subject_id == "" || $exam_date == "") {
        $message = alert("All fields are required.", "danger");
    } else {
        // Check if another exam is already scheduled for this department on the same date
        $check_date = $conn->prepare("SELECT id FROM exams WHERE dept_code=? AND exam_date=? AND subject_id<>?");
        $check_date->bind_param("ssi", $dept_code, $exam_date, $subject_id);
        $check_date->execute();
        $check_date->store_result();

        if ($check_date->num_rows > 0) {
            $message .= "<p style='color:red;'>Please choose a different date.</p>";
        } else {
            // Check existing exam record for this subject+dept
            $check = $conn->prepare("SELECT id FROM exams WHERE subject_id=? AND dept_code=?");
            $check->bind_param("is", $subject_id, $dept_code);
            $check->execute();
            $check->store_result();

            if ($check->num_rows > 0) {
                // UPDATE exam date
                $stmt = $conn->prepare("UPDATE exams SET exam_date=? WHERE subject_id=? AND dept_code=?");
                $stmt->bind_param("sis", $exam_date, $subject_id, $dept_code);

                if ($stmt->execute())
                    $message = "<p style='color:green;'>Exam date updated successfully!</p>";
                else
                    $message = "<p style='color:red;'>Error updating record: " . $conn->error . "</p>";
            } else {
                // INSERT new record
                $stmt = $conn->prepare("INSERT INTO exams(subject_id, dept_code, exam_date) VALUES (?,?,?)");
                $stmt->bind_param("iss", $subject_id, $dept_code, $exam_date);

                if ($stmt->execute())
                    $message="<p style='color:green;'>Exam scheduled successfully!</p>";
                else
                    $message = alert("Error inserting: " . $conn->error, "danger");
            }
        }
    }
}

// AJAX: fetch subjects by department
if (isset($_GET['get_subjects'])) {
    $dept_code = $_GET['get_subjects'];
    $data = $conn->query("SELECT * FROM subjects WHERE dept_code='$dept_code' ORDER BY sub_name ASC");

    while ($s = $data->fetch_assoc()) {
        echo "<option value='{$s['id']}'>{$s['sub_name']} ({$s['qp_code']})</option>";
    }
    exit;
}

// Fetch all exam schedules
$list = $conn->query("
    SELECT e.*, s.sub_name, s.qp_code, d.dept_name 
    FROM exams e
    LEFT JOIN subjects s ON e.subject_id = s.id
    LEFT JOIN departments d ON e.dept_code = d.dept_code
    ORDER BY e.exam_date ASC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Exam Scheduling</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" ></script>
     <script src="../valid.js"></script>
    <script>
        function loadSubjects(dept_code) {
            fetch("exam.php?get_subjects=" + dept_code)
            .then(res => res.text())
            .then(data => {
                document.getElementById("subjectSelect").innerHTML =
                    "<option value=''>Select Subject</option>" + data;
            });
        }
    </script>
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-dark px-3">
    <span class="navbar-brand">Admin - Exam Scheduling</span>
    <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
</nav>

<div class="container mt-4">

    <h3>Schedule / Update Exam Date</h3>
    <hr>

    <?= $message ?>

    <form method="POST" class="card p-4 shadow-sm border-0">

        <div class="mb-3">
            <label class="form-label">Department *</label>
            <select name="dept_code" class="form-select" onchange="loadSubjects(this.value)" required>
                <option value="">Select Department</option>
                <?php while($d = $dept_query->fetch_assoc()): ?>
                    <option value="<?= $d['dept_code'] ?>">
                        <?= $d['dept_code'] . " - " . $d['dept_name'] ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Subject *</label>
            <select name="subject_id" class="form-select" id="subjectSelect" required>
                <option value="">Select Subject</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Exam Date *</label>
            <input type="date" name="exam_date" class="form-control val-exam-date" required>
        </div>

        <button class="btn btn-primary px-4">Save Exam Date</button>
    </form>

    <hr class="mt-5">

    <h4>Scheduled Exams</h4>

    <table class="table table-striped table-bordered mt-3">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Department</th>
                <th>Subject</th>
                <th>QP Code</th>
                <th>Exam Date</th>
            </tr>
        </thead>

        <tbody>
            <?php 
            $i = 1;
            while ($row = $list->fetch_assoc()):
            ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= $row['dept_code'] . " - " . $row['dept_name'] ?></td>
                <td><?= $row['sub_name'] ?></td>
                <td><?= $row['qp_code'] ?></td>
                <td><?= $row['exam_date'] ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>

    </table>

</div>

</body>
</html>
