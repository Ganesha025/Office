<?php
session_start();
include '../db/db.php';
include '../functions.php';

ensureAdmin();

$message = "";

// Fetch all students
$students = $conn->query("SELECT * FROM students ORDER BY regno");

// When admin submits hallticket generate
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = intval($_POST['student_id']);

    // Fetch student info
    $student = $conn->query("SELECT * FROM students WHERE id = $student_id")->fetch_assoc();

    if (!$student) {
        $message = "<p class='error'>Invalid student selected.</p>";
    } else {
        $reg  = $student['regno'];
        $name = $student['username']; // assuming 'username' as student name
        $dept = $student['dept_code'];
        $sem  = 1; // default semester, change if you have column

        // Fetch marks for this student
        $marks_res = $conn->query("SELECT m.*, s.credits FROM marks m 
                                   JOIN subjects s ON m.subject_id = s.id
                                   WHERE m.student_id = $student_id");

        if ($marks_res->num_rows == 0) {
            $message = "<p class='error'>Marks not updated for this student.</p>";
        } else {
            $total_credits = 0;
            $eligible = true;

            while ($row = $marks_res->fetch_assoc()) {
                $total_credits += $row['credits'];

                if ($row['attendance'] < 75 || $row['internal'] < 40) {
    $eligible = false;
}

            }

            if ($total_credits < 20) $eligible = false;

            if (!$eligible) {
                $message = "<p class='error'>You are not eligible to receive a hall ticket due to attendance/marks criteria.</p>";
            } else {
                // Check if hall ticket already generated
                $exists = $conn->query("SELECT * FROM halltickets WHERE student_id = $student_id")->num_rows;

                if ($exists > 0) {
                    $message = "<p class='error'>Hall Ticket already generated for $name ($reg)</p>";
                } else {
                    // Generate Hall Ticket ID
                    $ht_id = "HT-" . $sem . strtoupper($reg);

                    // Insert hallticket
                    $stmt = $conn->prepare("INSERT INTO halltickets(student_id, hallticket_id) VALUES(?,?)");
                    $stmt->bind_param("is", $student_id, $ht_id);

                    if ($stmt->execute()) {
                        $message = "<p class='success'>Hall Ticket generated for $name (Reg: $reg).<br>Hall Ticket ID: <b>$ht_id</b><br>Total Credits Earned: $total_credits</p>";
                    } else {
                        $message = "<p class='error'>Error generating hall ticket.</p>";
                    }
                }
            }
        }
    }
}

// Fetch all generated hall tickets
$halltickets = $conn->query("
    SELECT h.hallticket_id, s.username AS name, s.regno, s.dept_code 
    FROM halltickets h 
    JOIN students s ON h.student_id = s.id
    ORDER BY h.id DESC
");

?>

<!DOCTYPE html>
<html>
<head>
    <title>Generate Hall Ticket</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .box { margin: 20px 0; padding: 20px; border: 1px solid #ccc; }
        .success { color: green; }
        .error { color: red; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #aaa; padding: 8px; }
    </style>
</head>
<body>

<h2>Generate Hall Ticket</h2>

<?= $message; ?>

<div class="box">
    <form method="POST">
        <label>Select Student:</label><br>
        <select name="student_id" required>
            <option value="">-- Select --</option>
            <?php while ($row = $students->fetch_assoc()): ?>
                <option value="<?= $row['id']; ?>">
                    <?= $row['username']; ?> (<?= $row['regno']; ?> - <?= $row['dept_code']; ?>)
                </option>
            <?php endwhile; ?>
        </select>
        <br><br>
        <button type="submit">Generate Hall Ticket</button>
    </form>
</div>

<h3>Generated Hall Tickets</h3>

<table>
    <tr>
        <th>Hall Ticket ID</th>
        <th>Name</th>
        <th>Register No</th>
        <th>Department</th>
        <th>Action</th>
    </tr>

    <?php while ($ht = $halltickets->fetch_assoc()): ?>
    <tr>
        <td><?= $ht['hallticket_id']; ?></td>
        <td><?= $ht['name']; ?></td>
        <td><?= $ht['regno']; ?></td>
        <td><?= $ht['dept_code']; ?></td>
        <td><a href="view_hallticket.php?id=<?= $ht['hallticket_id']; ?>">View</a></td>
    </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
