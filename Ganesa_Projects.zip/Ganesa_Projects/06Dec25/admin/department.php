<?php
session_start();
include '../db/db.php';
include '../functions.php';

// Ensure only admin can access
ensureAdmin();

$message = "";

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $dept_name = trim($_POST['dept_name']);
    $dept_code = strtoupper(trim($_POST['dept_code']));

    if ($dept_name == "" || $dept_code == "") {
        $message = alert("Both fields are required!", "danger");
    } else {
        // Check duplicate dept_code
        $check = $conn->prepare("SELECT id FROM departments WHERE dept_code=?");
        $check->bind_param("s", $dept_code);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $message = "<p style='color: red; font-weight: bold;'>Department code already exists!</p>";

        } else {
            // Insert
            $stmt = $conn->prepare("INSERT INTO departments(dept_name, dept_code) VALUES(?, ?)");
            $stmt->bind_param("ss", $dept_name, $dept_code);

            if ($stmt->execute()) {
            $message = "<div class='alert-box error'><span class='material-icons'>success</span><span>Department added successfully!</span></div>";

            } else {
            $message = "<div class='alert-box error'><span class='material-icons'>danger</span><span>. $conn->error</span></div>";
            }
        }
    }
}

// Fetch list
$list = $conn->query("SELECT * FROM departments ORDER BY dept_code ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Departments</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
     <script src="https://code.jquery.com/jquery-3.7.1.min.js" ></script>
     <script src="../valid.js"></script>
     <style>
        button:disabled{
            cursor: not-allowed;
            opacity: 0.5;
        }
     </style>
</head>

<body class="bg-light">
<script>
    $(document).ready(function() {
       $("#InputFocus").focus();
    });
</script>
<nav class="navbar navbar-dark bg-dark px-3">
    <span class="navbar-brand">Admin - Manage Departments</span>
    <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
</nav>

<div class="container mt-4">

    <h3>Add New Department</h3>
    <hr>

    <?php echo $message; ?>

    <form method="POST" class="card p-4 shadow-sm border-0">
        <div class="mb-3">
            <label class="form-label">Department Name *</label>
            <input type="text" id="InputFocus" name="dept_name" class="form-control val-department" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Department Code *</label>
            <input type="text" name="dept_code" class="form-control val-dept-code" required>
            <small class="text-muted">
                Example: CSE, ECE, MECH, BCOM
            </small>
        </div>

        <button class="btn btn-primary px-4" id="SubmitButton" disabled >Add</button>
    </form>
<script>
    document.addEventListener("DOMContentLoaded", function () {
    const button = document.getElementById('SubmitButton'); 
    const requiredFields = document.querySelectorAll('input[name="dept_name"], input[name="dept_code"]');

    function checkFields() {
        let allFilled = true;

        requiredFields.forEach(field => {
            if (field.value.trim() === "") {
                allFilled = false;
            }
        });

        button.disabled = !allFilled;
    }

    requiredFields.forEach(field => {
        field.addEventListener("input", checkFields);
        field.addEventListener("change", checkFields);
    });
});

</script>
    <hr class="mt-5">
    <h4>Department List</h4>

    <table class="table table-striped table-bordered mt-3">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Department Code</th>
                <th>Department Name</th>
            </tr>
        </thead>

        <tbody>
            <?php 
            $i = 1; 
            while ($row = $list->fetch_assoc()): 
            ?>
            <tr>
                <td><?= $i++; ?></td>
                <td><?= $row['dept_code']; ?></td>
                <td><?= $row['dept_name']; ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>

    </table>

</div>
<script>
    // Enable/disable submit button based on validation
    $(document).ready(function() {
        function toggleSubmit() {
            const isDeptValid = $('.val-department').val().trim() !== '';
            const isCodeValid = $('.val-dept-code').val().trim() !== '';
            $('button[type="submit"]').prop('disabled', !(isDeptValid && isCodeValid));
        }

        $('.val-department, .val-dept-code').on('input', toggleSubmit);
        toggleSubmit(); // Initial check
    });
</script>
</body>
</html>
