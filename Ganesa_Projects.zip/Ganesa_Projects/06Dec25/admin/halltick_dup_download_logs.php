<?php
session_start();
include '../db/db.php';
include '../functions.php';

// Check admin
if (!isAdmin()) {
    header("Location: ../login.php");
    exit;
}

// Fetch all logs
$logs = $conn->query("
    SELECT l.*, s.name, s.regno, s.dept_code
    FROM hallticket_download_logs l
    JOIN students s ON l.student_id = s.id
    ORDER BY l.id DESC
");

// Count downloads per student
$counts = [];
$countQuery = $conn->query("
    SELECT student_id, COUNT(*) AS total
    FROM hallticket_download_logs
    GROUP BY student_id
");

while ($row = $countQuery->fetch_assoc()) {
    $counts[$row['student_id']] = $row['total'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hall Ticket Download Logs</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #888; padding: 10px; text-align: left; }
        th { background: #f0f0f0; }
        h2 { margin-bottom: 20px; }
    </style>
</head>
<body>

<h2>Hall Ticket Duplicate Download Logs</h2>

<table>
    <tr>
        <th>#</th>
        <th>Name</th>
        <th>Register No</th>
        <th>Department</th>
        <th>Hall Ticket ID</th>
        <th>Downloaded At</th>
        <th>Total Downloads</th>
    </tr>

    <?php 
    $i = 1; 
    while ($row = $logs->fetch_assoc()): 
        $sid = $row['student_id'];
    ?>
    <tr>
        <td><?= $i++; ?></td>
        <td><?= htmlspecialchars($row['name']); ?></td>
        <td><?= htmlspecialchars($row['regno']); ?></td>
        <td><?= htmlspecialchars($row['dept_code']); ?></td>
        <td><?= htmlspecialchars($row['hallticket_id']); ?></td>
        <td><?= $row['downloaded_at']; ?></td>
        <td><?= isset($counts[$sid]) ? $counts[$sid] : 1; ?></td>
    </tr>
    <?php endwhile; ?>

</table>

</body>
</html>
