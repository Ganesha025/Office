<?php
session_start();
include '../db/db.php';
include '../functions.php';

ensureAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $request_id = intval($_POST['request_id']);
    $new_status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE request_hallticket SET status=? WHERE id=?");
    $stmt->bind_param("si", $new_status, $request_id);
    $stmt->execute();
    $stmt->close();
    header("Location: view_request.php");
    exit;
}

$requests = $conn->query("
    SELECT r.id, s.username, s.regno, s.dept_code, r.status, r.request_date
    FROM request_hallticket r
    JOIN students s ON r.student_id = s.id
    ORDER BY r.request_date DESC
");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hall Ticket Requests</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container mt-4">
    <h3>Hall Ticket Requests</h3>
    <hr>

    <?php if (!$requests || $requests->num_rows == 0): ?>
        <p>No hall ticket requests submitted yet.</p>
    <?php else: ?>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Reg No</th>
                    <th>Department</th>
                    <th>Status</th>
                    <th>Request Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; while($r = $requests->fetch_assoc()): ?>
                <tr>
                    <td><?= $i++ ?></td>
                    <td><?= htmlspecialchars($r['username']) ?></td>
                    <td><?= htmlspecialchars($r['regno']) ?></td>
                    <td><?= htmlspecialchars($r['dept_code']) ?></td>
                    <td><?= ucfirst($r['status']) ?></td>
                    <td><?= $r['request_date'] ?></td>
                    <td>
                        <form method="POST" class="d-flex gap-1">
                            <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                            <select name="status" class="form-select form-select-sm" required>
                                <option value="pending" <?= $r['status']=='pending'?'selected':'' ?>>Pending</option>
                                <option value="approved" <?= $r['status']=='approved'?'selected':'' ?>>Approved</option>
                                <option value="rejected" <?= $r['status']=='rejected'?'selected':'' ?>>Rejected</option>
                            </select>
                            <button class="btn btn-sm btn-primary">Update</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php endif; ?>

</div>
</body>
</html>
