<?php
session_start();
include '../db/db.php';
include '../functions.php';
ensureAdmin();

$message = "";

$dept_query = $conn->query("SELECT * FROM departments ORDER BY dept_code ASC");
$departments = [];
while ($row = $dept_query->fetch_assoc()) {
    $departments[] = $row;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $regno = trim($_POST['regno']);
    $dept_code = trim($_POST['dept_code']);

    if ($username == "" || $password == "" || $regno == "" || $dept_code == "") {
        $message = "<div class='alert-box error'><span class='material-icons'>error</span><span>All fields are required!</span></div>";
    } else {
        $full_regno = $dept_code . $regno;

        $check = $conn->prepare("SELECT id FROM students WHERE username=? OR regno=?");
        $check->bind_param("ss", $username, $full_regno);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $message = "<div class='alert-box error'><span class='material-icons'>error</span><span>Username or RegNo already exists!</span></div>";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO students(username, password, regno, dept_code) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $username, $hashed, $full_regno, $dept_code);
            if ($stmt->execute()) {
                $message = "<div class='alert-box success'><span class='material-icons'>check_circle</span><span>Student added successfully!</span></div>";
            } else {
                $message = "<div class='alert-box error'><span class='material-icons'>error</span><span>Error: " . $conn->error . "</span></div>";
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update') {
    $id = $_POST['id'];
    $username = trim($_POST['username']);
    $regno = trim($_POST['regno']);
    $dept_code = trim($_POST['dept_code']);

    $full_regno = $dept_code . $regno;

    $check = $conn->prepare("SELECT id FROM students WHERE regno=? AND id!=?");
    $check->bind_param("si", $full_regno, $id);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $message = "<div class='alert-box error'><span class='material-icons'>error</span><span>RegNo already exists!</span></div>";
    } else {
        $stmt = $conn->prepare("UPDATE students SET username=?, regno=?, dept_code=? WHERE id=?");
        $stmt->bind_param("sssi", $username, $full_regno, $dept_code, $id);
        $stmt->execute();
        $message = "<div class='alert-box success'><span class='material-icons'>check_circle</span><span>Student updated successfully!</span></div>";
    }
}

$students_result = $conn->query("SELECT s.id, s.username, s.regno, s.dept_code, d.dept_name FROM students s LEFT JOIN departments d ON s.dept_code=d.dept_code ORDER BY s.id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Manage Students - College ERP</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="../valid.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Inter',sans-serif;background:#9ecfffff}
.card{background:#fff;border:1px solid #e0e0e0;border-radius:4px}
.form-input,.form-select{width:100%;padding:.625rem .875rem;border:1px solid #d1d5db;font-size:.875rem;transition:all .2s;border-radius:14px;}
.form-input:focus,.form-select:focus{outline:none;border-color:#1565c0;box-shadow:0 0 0 3px rgba(21,101,192,.1)}
.btn{padding:.625rem 1.25rem;border-radius:4px;font-weight:500;font-size:.875rem;cursor:pointer;transition:all .2s;border:none}
.btn-primary{background:#1565c0;color:#fff}
/* .btn-primary:hover{background:#0d47a1} */
.btn-success{background:#2e7d32;color:#fff}
.btn-success:hover{background:#1b5e20}
.btn-danger{background:#c62828;color:#fff}
.btn-danger:hover{background:#b71c1c}
.table{width:100%;border-collapse:collapse}
.table th{background:#f5f5f5;padding:.75rem;text-align:left;font-weight:600;font-size:.813rem;color:#424242;border-bottom:2px solid #e0e0e0}
.table td{padding:.75rem;border-bottom:1px solid #e0e0e0;font-size:.875rem}
.table tbody tr:hover{background:#fafafa}
.input-group{display:flex;align-items:stretch}
.input-group-text{background:#f5f5f5;border:1px solid #d1d5db;border-right:none;padding:.625rem .875rem;font-size:.875rem;color:#616161;border-radius:4px 0 0 4px}
.input-group .form-input{border-radius:0 4px 4px 0}
.alert-box{display:flex;align-items:center;gap:.75rem;padding:1rem;border-radius:4px;margin-bottom:1rem;font-size:.875rem}
.alert-box.success{background:#e8f5e9;color:#2e7d32;border:1px solid #c8e6c9}
.alert-box.error{background:#ffebee;color:#c62828;border:1px solid #ffcdd2}
.alert-box .material-icons{font-size:20px}
.material-icons{vertical-align:middle}
label{display:block;margin-bottom:.375rem;font-weight:500;font-size:.875rem;color:#424242}
.text-muted{font-size:.75rem;color:#757575;margin-top:.25rem;display:block}button:disabled{background:#bdbdbd;cursor:not-allowed}
</style>
</head>
<body>

<nav class="bg-white border-b border-gray-300 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
<div class="flex items-center gap-3">
<span class="material-icons text-blue-700" style="font-size:32px">school</span>
<div>
<div class="text-lg font-bold text-gray-900">College ERP System</div>
<div class="text-xs text-gray-600">Student Management</div>
</div>
</div>
<a href="logout.php" class="btn btn-danger">Logout</a>
</div>
</nav>

<div class="max-w-7xl mx-auto px-6 py-8">

<div class="flex items-center justify-between mb-6">
<div>
<h1 class="text-2xl font-bold text-gray-900 mb-1">Student Management</h1>
<p class="text-sm text-gray-600">Add and manage student records</p>
</div>
<a href="index.php" class="btn btn-primary flex items-center gap-2">
<span class="material-icons" style="font-size:18px">dashboard</span>
Back to Dashboard
</a>
</div>

<?php echo $message; ?>

<div class="card p-6 mb-8 rounded-[10px]">
<h2 class="text-lg font-bold text-gray-900 mb-4">Add New Student</h2>
<form method="POST" class="space-y-4">
<input type="hidden" name="action" value="add">
<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
<div>
<label>Department *</label>
<select id="dept_select" name="dept_code" class="form-select"  >
<option value="">Select Department</option>
<?php foreach ($departments as $d): ?>
<option value="<?php echo $d['dept_code']; ?>"><?php echo $d['dept_code'] . " - " . $d['dept_name']; ?></option>
<?php endforeach; ?>
</select>
</div>
<div>
<label>Registration Number *</label>
<div class="input-group">
<span class="input-group-text" id="dept_prefix"></span>
<input type="text" name="regno" id="InputFocus" class="form-input val-mark" placeholder="Enter number">
</div>
<span class="text-muted">Enter unique number after department prefix</span>
</div>
</div>
<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
<div>
<label>Username *</label>
<input type="text" name="username" class="form-input val-username" placeholder="Enter username" >
</div>
<div>
<label>Password *</label>
<input type="text" name="password" class="form-input val-password" placeholder="Enter password" >
</div>
</div>
<button class="btn btn-primary flex items-center gap-2 rounded-[15px]" disabled>
<span class="material-icons" style="font-size:18px">person_add</span>
Add Student
</button>
</form>
</div>

<div class="card p-6 rounded-[20px]">
<h2 class="text-lg font-bold text-gray-900 mb-4">Students List</h2>
<div class="overflow-x-auto">
<table class="table">
<thead>
<tr>
<th>ID</th>
<th>Username</th>
<th>Registration No</th>
<th>Department</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php while ($s = $students_result->fetch_assoc()): 
    $prefix = $s['dept_code'];
    $reg_number = str_replace($prefix, "", $s['regno']);
?>
<tr>
<form method="POST">
<input type="hidden" name="action" value="update">
<input type="hidden" name="id" value="<?php echo $s['id']; ?>">
<td><?php echo $s['id']; ?></td>
<td><input type="text" name="username" class="form-input val-username" value="<?php echo $s['username']; ?>"></td>
<td>
<div class="input-group">
<span class="input-group-text"><?php echo $prefix; ?></span>
<input type="text" name="regno" class="form-input val-mark" value="<?php echo $reg_number; ?>">
</div>
</td>
<td>
<select name="dept_code" class="form-select update-dept">
<?php foreach ($departments as $d): ?>
<option value="<?php echo $d['dept_code']; ?>" <?php echo ($d['dept_code'] == $s['dept_code']) ? 'selected' : ''; ?>>
<?php echo $d['dept_code'] . " - " . $d['dept_name']; ?>
</option>
<?php endforeach; ?>
</select>
</td>
<td><button class="btn btn-success rounded-[15px]">Update</button></td>
</form>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>

</div>

<script>
$(document).ready(function(){
$("#InputFocus").focus();
});

const deptSelect = document.getElementById('dept_select');
const deptPrefix = document.getElementById('dept_prefix');
deptSelect.addEventListener('change', function(){
deptPrefix.textContent = this.value;
});

document.querySelectorAll('.update-dept').forEach(function(select){
select.addEventListener('change', function(){
const inputGroup = this.closest('tr').querySelector('input[name="regno"]').previousElementSibling;
inputGroup.textContent = this.value;
});
});
</script>
<script>
$(document).ready(function() {
    
    $('form[action="add"]').submit(function(e){
        let valid = true;
        let dept = $('#dept_select').val();
        let regno = $('input[name="regno"]').val().trim();
        let username = $('input[name="username"]').val().trim();
        let password = $('input[name="password"]').val().trim();

        // Reset error borders
        $('.form-input, .form-select').css('border', '1px solid #d1d5db');

        if (dept === "") {
            $('#dept_select').css('border', '2px solid red');
            valid = false;
        }
        if (regno === "") {
            $('input[name="regno"]').css('border', '2px solid red');
            valid = false;
        }
        if (username === "") {
            $('input[name="username"]').css('border', '2px solid red');
            valid = false;
        }
        if (password === "") {
            $('input[name="password"]').css('border', '2px solid red');
            valid = false;
        }

        if (!valid) {
            e.preventDefault();
            alert("Please fill all required fields.");
        }
    });


    // Validate Update Student Form
    $('form').on('submit', function(e){
        if ($(this).find('input[name="action"]').val() !== "update") return;

        let valid = true;
        let username = $(this).find('input[name="username"]').val().trim();
        let regno = $(this).find('input[name="regno"]').val().trim();

        $(this).find('.form-input').css('border', '1px solid #d1d5db');

        if (username === "") {
            $(this).find('input[name="username"]').css('border', '2px solid red');
            valid = false;
        }
        if (regno === "") {
            $(this).find('input[name="regno"]').css('border', '2px solid red');
            valid = false;
        }

        if (!valid) {
            e.preventDefault();
            alert("Please fill all fields before updating.");
        }
    });

});
document.addEventListener("DOMContentLoaded", function () {
    const button = document.querySelector("button.btn-primary"); 
    const requiredFields = document.querySelectorAll(
        'select[name="dept_code"], input[name="regno"], input[name="username"], input[name="password"]'
    );

    function checkFields() {
        let allFilled = true;

        requiredFields.forEach(field => {
            if (field.value.trim() === "") {
                allFilled = false;
            }
        });

        button.disabled = !allFilled;
    }

    requiredFields.forEach(field => {
        field.addEventListener("input", checkFields);
        field.addEventListener("change", checkFields);
    });
});

</script>

</body>
</html>