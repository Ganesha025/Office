<?php
// functions.php (common functions for auth, admin & student)

session_start();

// ------------------------------
// 1. CHECK ADMIN LOGIN
// ------------------------------
function checkAdmin()
{
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
        header("Location: ../login.php");
        exit;
    }
}

// ------------------------------
// 2. CHECK STUDENT LOGIN
// ------------------------------
function checkStudent()
{
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
        header("Location: ../login.php");
        exit;
    }
}

// ------------------------------
// 3. REDIRECT IF LOGGED IN ALREADY
// ------------------------------
function redirectIfLoggedIn()
{
    if (isset($_SESSION['role'])) {
        if ($_SESSION['role'] === 'admin') {
            header("Location: admin/dashboard.php");
            exit;
        } elseif ($_SESSION['role'] === 'student') {
            header("Location: student/dashboard.php");
            exit;
        }
    }
}

// ------------------------------
// 4. CLEAN INPUT
// ------------------------------
function cleanInput($data)
{
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// ------------------------------
// 5. GENERATE HALL TICKET ID
// Format: HT-{SEM}{REGNO}
// Example: HT-5CSE1234
// ------------------------------
function generateHallTicketID($semester, $regNo)
{
    return "HT-" . $semester . $regNo;
}

// ------------------------------
// 6. CHECK ELIGIBILITY
// Conditions:
// Attendance >= 75
// Internal >= 40
// ------------------------------
function isEligible($attendance, $internal)
{
    if ($attendance >= 75 && $internal >= 40) {
        return true;
    }
    return false;
}

// ------------------------------
// 7. CHECK IF HALL TICKET ALREADY GENERATED
// ------------------------------
function hallTicketExists($conn, $student_id)
{
    $stmt = $conn->prepare("SELECT id FROM hall_tickets WHERE student_id = ?");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $stmt->store_result();

    $exists = $stmt->num_rows > 0;

    $stmt->close();
    return $exists;
}

// ------------------------------
// 8. GET TOTAL CREDITS PASSED
// (Used for Task 2: Credit Validation)
// ------------------------------
function getTotalEarnedCredits($conn, $student_id)
{
    $query = "
        SELECT SUM(subjects.credits) 
        FROM student_subjects
        INNER JOIN subjects ON student_subjects.subject_id = subjects.id
        WHERE student_subjects.student_id = ? AND student_subjects.status = 'pass'
    ";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $stmt->bind_result($credits);
    $stmt->fetch();
    $stmt->close();

    return $credits ?? 0;
}

// ------------------------------
// 9. CHECK IF EXAM DATE ALREADY EXISTS
// ------------------------------
function examDateExists($conn, $subject_id)
{
    $stmt = $conn->prepare("SELECT id FROM exam_dates WHERE subject_id = ?");
    $stmt->bind_param("i", $subject_id);
    $stmt->execute();
    $stmt->store_result();

    $exists = $stmt->num_rows > 0;
    $stmt->close();

    return $exists;
}

// ------------------------------
// 10. LOG HALL TICKET DOWNLOAD
// ------------------------------
function logHallTicketDownload($conn, $student_id)
{
    $stmt = $conn->prepare("
        INSERT INTO hall_ticket_logs (student_id, downloaded_at)
        VALUES (?, NOW())
    ");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $stmt->close();
}
?>
