<?php
session_start();
include '../db/db.php';  

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT id, password FROM admins WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($admin_id, $admin_pass);
        $stmt->fetch();
        if (password_verify($password, $admin_pass)) {
            $_SESSION['user_id'] = $admin_id;
            $_SESSION['username'] = $username;
            $_SESSION['role'] = "admin";
            header("Location: ../admin/dashboard.php");
            exit;
        }
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT id, regno, password FROM students WHERE username = ?");
    if ($stmt) {
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows === 1) {
            $stmt->bind_result($stu_id, $stu_reg, $stu_pass);
            $stmt->fetch();
            if (password_verify($password, $stu_pass)) {
                $_SESSION['user_id'] = $stu_id;
                $_SESSION['reg_no'] = $stu_reg;
                $_SESSION['username'] = $username;
                $_SESSION['role'] = "student";
                header("Location: ../student/dashboard.php");
                exit;
            }
        }
        $stmt->close();
    } else {
        die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
    }

    $message = "Invalid username or password.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body { font-family: 'Inter', sans-serif; background-color: #2776d7; }
.glass-card { 
  backdrop-filter: blur(12px); 
  background: rgba(255, 255, 255, 0.15); 
  border-radius: 1rem; 
  box-shadow: 0 8px 32px rgba(0,0,0,0.25); 
  transition: all 0.3s ease; 
}
.glass-card:hover { transform: translateY(-5px) scale(1.02); }
.password-toggle { cursor: pointer; position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: #ffffff; }
input::placeholder { color: rgba(255,255,255,0.7); }
input:focus { outline: none; border: 2px solid #aee0f7; }
</style>
</head>
<body class="flex items-center justify-center min-h-screen">

<div class="glass-card p-8 w-11/12 sm:w-96">
    <h2 class="text-3xl font-bold text-white text-center mb-6">Login</h2>

    <?php if ($message): ?>
        <div class="bg-red-600 bg-opacity-30 text-white p-3 rounded mb-4 text-center"><?= $message ?></div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">

        <div>
            <label class="block mb-1 text-white font-semibold">Username</label>
            <input type="text" name="username" required placeholder="Enter username" class="w-full p-3 rounded bg-white bg-opacity-10 text-white placeholder-white">
        </div>

        <div class="relative">
            <label class="block mb-1 text-white font-semibold">Password</label>
            <input type="password" id="password" name="password" required placeholder="Enter password" class="w-full p-3 rounded bg-white bg-opacity-10 text-white placeholder-white">
            <span class="material-icons password-toggle" onclick="togglePassword()">visibility</span>
        </div>

        <button type="submit" class="w-full p-3 rounded text-white font-semibold bg-[#aee0f7] hover:bg-opacity-90 transition">Login</button>

    </form>
</div>

<script>
function togglePassword() {
    const pass = document.getElementById('password');
    const icon = document.querySelector('.password-toggle');
    if (pass.type === 'password') {
        pass.type = 'text';
        icon.innerText = 'visibility_off';
    } else {
        pass.type = 'password';
        icon.innerText = 'visibility';
    }
}
</script>
</body>
</html>
