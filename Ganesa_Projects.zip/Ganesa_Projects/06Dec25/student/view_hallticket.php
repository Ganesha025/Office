<?php
session_start();
include '../db/db.php';
include '../functions.php';

// Check if logged in (student or admin)
if (!isStudent() && !isAdmin()) {
    header("Location: ../login.php");
    exit;
}

$ht_id = $_GET['id'] ?? '';
$ht_id = $conn->real_escape_string($ht_id);

if (!$ht_id) {
    die("Invalid Hall Ticket ID.");
}

// Fetch hallticket info
$hallticket = $conn->query("
    SELECT h.*, s.username, s.regno, s.dept_code
    FROM halltickets h
    JOIN students s ON h.student_id = s.id
    WHERE h.hallticket_id = '$ht_id'
")->fetch_assoc();

if (!$hallticket) {
    die("Hall Ticket not found.");
}

$student_id = $hallticket['student_id'];

// Fetch subjects & marks for this student
$subjects = $conn->query("
    SELECT s.sub_name, s.qp_code, s.credits, m.attendance, m.internal, m.external
    FROM marks m
    JOIN subjects s ON m.subject_id = s.id
    WHERE m.student_id = $student_id
");

$total_credits = 0;
$eligible = true;
$subject_data = [];

while ($row = $subjects->fetch_assoc()) {
    $subject_data[] = $row;
    $total_credits += $row['credits'];
    if ($row['attendance'] < 75 || $row['internal'] < 40) {
        $eligible = false;
    }
}
if ($total_credits < 20) $eligible = false;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hall Ticket - <?= htmlspecialchars($hallticket['username']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        @media print {
            .no-print { display: none !important; }
            body { background: white !important; }
            .hallticket-container { 
                box-shadow: none !important;
                border: 2px solid #000 !important;
            }
        }
    </style>
</head>
<body class="bg-slate-100 min-h-screen py-8">

    <!-- Back Button (hidden on print) -->
    <div class="max-w-4xl mx-auto px-4 mb-4 no-print">
        <a href="javascript:history.back()" class="inline-flex items-center space-x-2 text-indigo-600 hover:text-indigo-800 font-medium transition duration-200">
            <span class="material-symbols-outlined">arrow_back</span>
            <span>Back to Dashboard</span>
        </a>
    </div>

    <!-- Hall Ticket Container -->
    <div class="max-w-4xl mx-auto px-4">
        <div class="hallticket-container bg-white rounded-2xl shadow-2xl overflow-hidden">
            
            <!-- Header Section -->
            <div class="bg-indigo-600 text-white px-8 py-6">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-4">
                        <div class="bg-white bg-opacity-20 p-3 rounded-full">
                            <span class="material-symbols-outlined text-4xl">school</span>
                        </div>
                        <div>
                            <h1 class="text-3xl font-bold">HALL TICKET</h1>
                            <p class="text-indigo-100 text-sm mt-1">Examination Admit Card</p>
                        </div>
                    </div>
                    <div class="bg-white bg-opacity-20 px-4 py-2 rounded-lg">
                        <span class="material-symbols-outlined text-5xl">qr_code_2</span>
                    </div>
                </div>
            </div>

            <!-- Student Information -->
            <div class="px-8 py-6 bg-slate-50 border-b-4 border-indigo-200">
                <div class="grid md:grid-cols-2 gap-6">
                    <div class="space-y-4">
                        <div class="flex items-start space-x-3">
                            <span class="material-symbols-outlined text-indigo-600 text-2xl">confirmation_number</span>
                            <div>
                                <p class="text-xs text-gray-500 uppercase tracking-wide">Hall Ticket ID</p>
                                <p class="text-lg font-bold text-gray-800"><?= htmlspecialchars($hallticket['hallticket_id']); ?></p>
                            </div>
                        </div>
                        <div class="flex items-start space-x-3">
                            <span class="material-symbols-outlined text-blue-600 text-2xl">person</span>
                            <div>
                                <p class="text-xs text-gray-500 uppercase tracking-wide">Student Name</p>
                                <p class="text-lg font-bold text-gray-800"><?= htmlspecialchars($hallticket['username']); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="space-y-4">
                        <div class="flex items-start space-x-3">
                            <span class="material-symbols-outlined text-purple-600 text-2xl">badge</span>
                            <div>
                                <p class="text-xs text-gray-500 uppercase tracking-wide">Registration Number</p>
                                <p class="text-lg font-bold text-gray-800"><?= htmlspecialchars($hallticket['regno']); ?></p>
                            </div>
                        </div>
                        <div class="flex items-start space-x-3">
                            <span class="material-symbols-outlined text-emerald-600 text-2xl">apartment</span>
                            <div>
                                <p class="text-xs text-gray-500 uppercase tracking-wide">Department</p>
                                <p class="text-lg font-bold text-gray-800"><?= htmlspecialchars($hallticket['dept_code']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Subjects Table -->
            <div class="px-8 py-6">
                <div class="flex items-center space-x-3 mb-4">
                    <span class="material-symbols-outlined text-indigo-600 text-2xl">menu_book</span>
                    <h2 class="text-xl font-bold text-gray-800">Examination Subjects</h2>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full border-2 border-gray-300">
                        <thead>
                            <tr class="bg-indigo-100">
                                <th class="border border-gray-300 px-4 py-3 text-center text-sm font-semibold text-gray-800 w-16">#</th>
                                <th class="border border-gray-300 px-4 py-3 text-left text-sm font-semibold text-gray-800">Subject Name</th>
                                <th class="border border-gray-300 px-4 py-3 text-center text-sm font-semibold text-gray-800">QP Code</th>
                                <th class="border border-gray-300 px-4 py-3 text-center text-sm font-semibold text-gray-800">Credits</th>
                                <th class="border border-gray-300 px-4 py-3 text-center text-sm font-semibold text-gray-800">Attendance</th>
                                <th class="border border-gray-300 px-4 py-3 text-center text-sm font-semibold text-gray-800">Internal</th>
                                <th class="border border-gray-300 px-4 py-3 text-center text-sm font-semibold text-gray-800">External</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($subject_data as $i => $sub): ?>
                            <tr class="<?= $i % 2 == 0 ? 'bg-white' : 'bg-gray-50'; ?>">
                                <td class="border border-gray-300 px-4 py-3 text-center text-gray-800 font-medium"><?= $i+1 ?></td>
                                <td class="border border-gray-300 px-4 py-3 text-gray-800 font-medium"><?= htmlspecialchars($sub['sub_name']) ?></td>
                                <td class="border border-gray-300 px-4 py-3 text-center text-gray-700"><?= htmlspecialchars($sub['qp_code']) ?></td>
                                <td class="border border-gray-300 px-4 py-3 text-center">
                                    <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm font-semibold"><?= $sub['credits'] ?></span>
                                </td>
                                <td class="border border-gray-300 px-4 py-3 text-center">
                                    <span class="<?= $sub['attendance'] >= 75 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?> px-2 py-1 rounded text-sm font-semibold">
                                        <?= $sub['attendance'] ?>%
                                    </span>
                                </td>
                                <td class="border border-gray-300 px-4 py-3 text-center">
                                    <span class="<?= $sub['internal'] >= 40 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?> px-2 py-1 rounded text-sm font-semibold">
                                        <?= $sub['internal'] ?>
                                    </span>
                                </td>
                                <td class="border border-gray-300 px-4 py-3 text-center text-gray-800 font-semibold"><?= $sub['external'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Credits Summary -->
                <div class="mt-6 flex items-center justify-between bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
                    <div class="flex items-center space-x-3">
                        <span class="material-symbols-outlined text-blue-600 text-3xl">workspace_premium</span>
                        <div>
                            <p class="text-sm text-gray-600">Total Credits Earned</p>
                            <p class="text-2xl font-bold text-blue-600"><?= $total_credits ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Eligibility Status -->
            <div class="px-8 py-6 bg-slate-50">
                <?php if ($eligible): ?>
                    <div class="bg-green-50 border-2 border-green-300 rounded-xl p-6">
                        <div class="flex items-center space-x-4">
                            <div class="bg-green-100 p-3 rounded-full">
                                <span class="material-symbols-outlined text-green-600 text-4xl">check_circle</span>
                            </div>
                            <div>
                                <h3 class="text-xl font-bold text-green-800">ELIGIBLE</h3>
                                <p class="text-green-700 mt-1">Candidate is eligible to appear for the examination.</p>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="bg-red-50 border-2 border-red-300 rounded-xl p-6">
                        <div class="flex items-center space-x-4">
                            <div class="bg-red-100 p-3 rounded-full">
                                <span class="material-symbols-outlined text-red-600 text-4xl">cancel</span>
                            </div>
                            <div>
                                <h3 class="text-xl font-bold text-red-800">NOT ELIGIBLE</h3>
                                <p class="text-red-700 mt-1">Candidate does not meet the eligibility criteria (attendance/marks/credits).</p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Instructions -->
            <div class="px-8 py-6 bg-amber-50 border-t-4 border-amber-300">
                <div class="flex items-start space-x-3 mb-3">
                    <span class="material-symbols-outlined text-amber-600 text-2xl">info</span>
                    <h3 class="text-lg font-bold text-gray-800">Important Instructions</h3>
                </div>
                <ul class="space-y-2 text-sm text-gray-700 ml-9">
                    <li class="flex items-start">
                        <span class="text-amber-600 mr-2">•</span>
                        <span>Bring this hall ticket along with a valid photo ID to the examination center.</span>
                    </li>
                    <li class="flex items-start">
                        <span class="text-amber-600 mr-2">•</span>
                        <span>Report to the examination center at least 30 minutes before the scheduled time.</span>
                    </li>
                    <li class="flex items-start">
                        <span class="text-amber-600 mr-2">•</span>
                        <span>Electronic devices, books, and notes are not allowed inside the examination hall.</span>
                    </li>
                    <li class="flex items-start">
                        <span class="text-amber-600 mr-2">•</span>
                        <span>Follow all examination rules and regulations strictly.</span>
                    </li>
                </ul>
            </div>

            <!-- Footer -->
            <div class="px-8 py-6 bg-gray-100 border-t-2 border-gray-300">
                <div class="flex items-center justify-between">
                    <div class="text-sm text-gray-600">
                        <p class="font-medium">Date of Issue: <?= date('d-m-Y'); ?></p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm text-gray-600 mb-1">Authorized Signature</p>
                        <div class="border-t-2 border-gray-400 w-48"></div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Action Buttons (hidden on print) -->
        <div class="flex items-center justify-center space-x-4 mt-6 no-print">
            <button onclick="window.print()" class="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-lg transition duration-200 shadow-lg font-medium">
                <span class="material-symbols-outlined">print</span>
                <span>Print Hall Ticket</span>
            </button>
            <button onclick="window.history.back()" class="flex items-center space-x-2 bg-gray-600 hover:bg-gray-700 text-white px-8 py-3 rounded-lg transition duration-200 shadow-lg font-medium">
                <span class="material-symbols-outlined">close</span>
                <span>Close</span>
            </button>
        </div>
    </div>

</body>
</html>