<?php
session_start();
include '../db/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

$student_id = $_SESSION['user_id'];

$student = $conn->query("SELECT * FROM students WHERE id = $student_id")->fetch_assoc();

$request_exists = $conn->query("SELECT * FROM request_hallticket WHERE student_id = $student_id")->fetch_assoc();

$message = "";
$message_type = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$request_exists) {
        $stmt = $conn->prepare("INSERT INTO request_hallticket(student_id) VALUES(?)");
        $stmt->bind_param("i", $student_id);
        if ($stmt->execute()) {
            $message = "Your hall ticket request has been submitted successfully. The admin will review your request shortly.";
            $message_type = "success";
            $request_exists = true; // Update state
        } else {
            $message = "Error submitting request. Please try again or contact support.";
            $message_type = "error";
        }
        $stmt->close();
    } else {
        $message = "You have already submitted a request. Please wait for admin approval.";
        $message_type = "warning";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Hall Ticket</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
    </style>
</head>
<body class="bg-slate-50 min-h-screen">

    <!-- Navbar -->
    <nav class="bg-white shadow-md border-b-4 border-amber-500">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center space-x-3">
                    <span class="material-symbols-outlined text-amber-600 text-3xl">request_quote</span>
                    <span class="text-2xl font-bold text-gray-800">Request Hall Ticket</span>
                </div>
                <a href="dashboard.php" class="flex items-center space-x-2 bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition duration-200 shadow-md">
                    <span class="material-symbols-outlined text-xl">arrow_back</span>
                    <span class="font-medium">Back to Dashboard</span>
                </a>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        <!-- Student Info Card -->
        <div class="bg-white rounded-2xl shadow-lg p-6 mb-6 border-l-8 border-indigo-500">
            <div class="flex items-center space-x-4">
                <div class="bg-indigo-100 p-3 rounded-full">
                    <span class="material-symbols-outlined text-indigo-600 text-3xl">person</span>
                </div>
                <div>
                    <h2 class="text-xl font-bold text-gray-800"><?= htmlspecialchars($student['username']); ?></h2>
                    <div class="flex items-center space-x-4 mt-1 text-gray-600">
                        <div class="flex items-center space-x-1">
                            <span class="material-symbols-outlined text-sm">badge</span>
                            <span class="text-sm">Reg No: <strong><?= htmlspecialchars($student['regno']); ?></strong></span>
                        </div>
                        <div class="flex items-center space-x-1">
                            <span class="material-symbols-outlined text-sm">apartment</span>
                            <span class="text-sm">Dept: <strong><?= htmlspecialchars($student['dept_code']); ?></strong></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Message Display -->
        <?php if ($message): ?>
            <?php if ($message_type === 'success'): ?>
                <div class="bg-green-50 border-l-4 border-green-500 rounded-lg p-6 mb-6 shadow-md">
                    <div class="flex items-start space-x-3">
                        <span class="material-symbols-outlined text-green-600 text-3xl">check_circle</span>
                        <div class="flex-1">
                            <h3 class="text-lg font-bold text-green-800 mb-1">Request Submitted Successfully!</h3>
                            <p class="text-green-700"><?= $message ?></p>
                        </div>
                    </div>
                </div>
            <?php elseif ($message_type === 'warning'): ?>
                <div class="bg-amber-50 border-l-4 border-amber-500 rounded-lg p-6 mb-6 shadow-md">
                    <div class="flex items-start space-x-3">
                        <span class="material-symbols-outlined text-amber-600 text-3xl">warning</span>
                        <div class="flex-1">
                            <h3 class="text-lg font-bold text-amber-800 mb-1">Request Already Submitted</h3>
                            <p class="text-amber-700"><?= $message ?></p>
                        </div>
                    </div>
                </div>
            <?php elseif ($message_type === 'error'): ?>
                <div class="bg-red-50 border-l-4 border-red-500 rounded-lg p-6 mb-6 shadow-md">
                    <div class="flex items-start space-x-3">
                        <span class="material-symbols-outlined text-red-600 text-3xl">error</span>
                        <div class="flex-1">
                            <h3 class="text-lg font-bold text-red-800 mb-1">Submission Failed</h3>
                            <p class="text-red-700"><?= $message ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <!-- Main Content Card -->
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden border-l-8 border-amber-500">
            
            <!-- Header -->
            <div class="bg-amber-50 border-b-2 border-amber-200 px-8 py-6">
                <div class="flex items-center space-x-3">
                    <div class="bg-amber-100 p-3 rounded-full">
                        <span class="material-symbols-outlined text-amber-600 text-3xl">confirmation_number</span>
                    </div>
                    <div>
                        <h2 class="text-2xl font-bold text-gray-800">Hall Ticket Request</h2>
                        <p class="text-gray-600 mt-1">Submit a request for special consideration</p>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="px-8 py-8">
                
                <?php if (!$request_exists): ?>
                    <!-- Request Information -->
                    <div class="mb-8">
                        <div class="bg-blue-50 border-l-4 border-blue-400 rounded-lg p-6 mb-6">
                            <div class="flex items-start space-x-3">
                                <span class="material-symbols-outlined text-blue-600 text-2xl">info</span>
                                <div>
                                    <h3 class="font-bold text-blue-900 mb-2">About Hall Ticket Requests</h3>
                                    <p class="text-blue-800 text-sm leading-relaxed">
                                        If you don't meet the standard eligibility criteria (attendance below 75% or internal marks below 40), 
                                        you can submit a special request. The admin will review your case and make a decision.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="space-y-4">
                            <h3 class="text-lg font-bold text-gray-800 flex items-center space-x-2">
                                <span class="material-symbols-outlined text-amber-600">checklist</span>
                                <span>Request Guidelines</span>
                            </h3>
                            <ul class="space-y-3 text-gray-700">
                                <li class="flex items-start space-x-3">
                                    <span class="material-symbols-outlined text-emerald-500 text-xl mt-0.5">check_circle</span>
                                    <span>Requests are reviewed on a case-by-case basis by the administration</span>
                                </li>
                                <li class="flex items-start space-x-3">
                                    <span class="material-symbols-outlined text-emerald-500 text-xl mt-0.5">check_circle</span>
                                    <span>Valid reasons include medical emergencies, family circumstances, or technical issues</span>
                                </li>
                                <li class="flex items-start space-x-3">
                                    <span class="material-symbols-outlined text-emerald-500 text-xl mt-0.5">check_circle</span>
                                    <span>You will be notified once the admin makes a decision on your request</span>
                                </li>
                                <li class="flex items-start space-x-3">
                                    <span class="material-symbols-outlined text-emerald-500 text-xl mt-0.5">check_circle</span>
                                    <span>Processing typically takes 2-3 business days</span>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <!-- Submit Form -->
                    <form method="POST" class="mt-8">
                        <div class="bg-gray-50 border-2 border-dashed border-gray-300 rounded-xl p-8 text-center">
                            <span class="material-symbols-outlined text-amber-500 text-6xl mb-4 inline-block">send</span>
                            <p class="text-gray-700 mb-6">
                                By clicking the button below, you confirm that you want to submit a hall ticket request for administrative review.
                            </p>
                            <button type="submit" class="flex items-center space-x-3 bg-amber-500 hover:bg-amber-600 text-white px-8 py-4 rounded-lg transition duration-200 shadow-lg font-bold text-lg mx-auto">
                                <span class="material-symbols-outlined text-2xl">request_quote</span>
                                <span>Submit Hall Ticket Request</span>
                            </button>
                        </div>
                    </form>

                <?php else: ?>
                    <!-- Request Already Submitted -->
                    <div class="text-center py-12">
                        <div class="bg-amber-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
                            <span class="material-symbols-outlined text-amber-600 text-6xl">pending</span>
                        </div>
                        <h3 class="text-2xl font-bold text-gray-800 mb-3">Request Pending</h3>
                        <p class="text-gray-600 mb-6 max-w-md mx-auto">
                            Your hall ticket request has been submitted and is currently under review by the administration. 
                            You will be notified once a decision has been made.
                        </p>
                        <div class="bg-blue-50 border-2 border-blue-200 rounded-lg p-6 max-w-md mx-auto">
                            <div class="flex items-center justify-center space-x-3 text-blue-800">
                                <span class="material-symbols-outlined text-2xl">schedule</span>
                                <span class="font-medium">Estimated Review Time: 2-3 Business Days</span>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

            </div>

            <!-- Footer -->
            <div class="bg-gray-50 border-t-2 border-gray-200 px-8 py-6">
                <div class="flex items-start space-x-3">
                    <span class="material-symbols-outlined text-gray-500 text-xl">help</span>
                    <div class="text-sm text-gray-600">
                        <p class="font-medium text-gray-800 mb-1">Need Help?</p>
                        <p>If you have questions about the request process, please contact the examination office or your department coordinator.</p>
                    </div>
                </div>
            </div>

        </div>

    </div>

</body>
</html>