<?php
session_start();
include '../db/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

$student_id = $_SESSION['user_id'];

$student = $conn->query("SELECT * FROM students WHERE id = $student_id");
if (!$student || $student->num_rows == 0) die("Student not found.");
$student = $student->fetch_assoc();

$marks_data = [];
$total_credits = 0;
$eligible = true;

$marks = $conn->query("
    SELECT s.sub_name, s.qp_code, s.credits, m.attendance, m.internal, m.external
    FROM marks m
    JOIN subjects s ON m.subject_id = s.id
    WHERE m.student_id = $student_id
");

if ($marks && $marks->num_rows > 0) {
    while ($row = $marks->fetch_assoc()) {
        $marks_data[] = $row;
        $total_credits += $row['credits'];
        if ($row['attendance'] < 75 || $row['internal'] < 40) $eligible = false;
    }
}

if ($total_credits < 20) $eligible = false;

$hallticket = $conn->query("SELECT * FROM halltickets WHERE student_id = $student_id");
$hallticket = ($hallticket && $hallticket->num_rows > 0) ? $hallticket->fetch_assoc() : null;

$exams = $conn->query("
    SELECT e.exam_date, s.sub_name, s.qp_code
    FROM exams e
    JOIN subjects s ON e.subject_id = s.id
    WHERE s.dept_code = '".$student['dept_code']."'
    ORDER BY e.exam_date ASC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
    </style>
</head>
<body class="bg-slate-50 min-h-screen">

    <!-- Navbar -->
    <nav class="bg-white shadow-md border-b-4 border-indigo-500">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center space-x-3">
                    <span class="material-symbols-outlined text-indigo-600 text-3xl">school</span>
                    <span class="text-2xl font-bold text-gray-800">Student Portal</span>
                </div>
                <a href="../logout.php" class="flex items-center space-x-2 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition duration-200 shadow-md">
                    <span class="material-symbols-outlined text-xl">logout</span>
                    <span class="font-medium">Logout</span>
                </a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Welcome Card -->
        <div class="bg-white rounded-2xl shadow-lg p-8 mb-8 border-l-8 border-indigo-500">
            <div class="flex items-start space-x-4">
                <div class="bg-indigo-100 p-4 rounded-full">
                    <span class="material-symbols-outlined text-indigo-600 text-4xl">person</span>
                </div>
                <div class="flex-1">
                    <h1 class="text-3xl font-bold text-gray-800 mb-2">Welcome, <?= htmlspecialchars($student['username']); ?>!</h1>
                    <div class="flex flex-wrap gap-4 text-gray-600">
                        <div class="flex items-center space-x-2">
                            <span class="material-symbols-outlined text-blue-500">badge</span>
                            <span><strong>Reg No:</strong> <?= $student['regno']; ?></span>
                        </div>
                        <div class="flex items-center space-x-2">
                            <span class="material-symbols-outlined text-purple-500">apartment</span>
                            <span><strong>Department:</strong> <?= $student['dept_code']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Marks & Attendance Card -->
        <div class="bg-white rounded-2xl shadow-lg p-8 mb-8 border-l-8 border-emerald-500">
            <div class="flex items-center space-x-3 mb-6">
                <div class="bg-emerald-100 p-3 rounded-full">
                    <span class="material-symbols-outlined text-emerald-600 text-3xl">bar_chart</span>
                </div>
                <h2 class="text-2xl font-bold text-gray-800">Marks & Attendance</h2>
            </div>
            
            <?php if (count($marks_data) == 0): ?>
                <div class="flex items-center space-x-3 bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <span class="material-symbols-outlined text-amber-500 text-2xl">info</span>
                    <p class="text-amber-700">No marks available yet.</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="bg-emerald-50 border-b-2 border-emerald-200">
                                <th class="px-6 py-4 text-left text-sm font-semibold text-emerald-900">Subject</th>
                                <th class="px-6 py-4 text-left text-sm font-semibold text-emerald-900">QP Code</th>
                                <th class="px-6 py-4 text-center text-sm font-semibold text-emerald-900">Credits</th>
                                <th class="px-6 py-4 text-center text-sm font-semibold text-emerald-900">Attendance (%)</th>
                                <th class="px-6 py-4 text-center text-sm font-semibold text-emerald-900">Internal</th>
                                <th class="px-6 py-4 text-center text-sm font-semibold text-emerald-900">External</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php foreach($marks_data as $m): ?>
                            <tr class="hover:bg-gray-50 transition duration-150">
                                <td class="px-6 py-4 text-gray-800 font-medium"><?= htmlspecialchars($m['sub_name']); ?></td>
                                <td class="px-6 py-4 text-gray-600"><?= htmlspecialchars($m['qp_code']); ?></td>
                                <td class="px-6 py-4 text-center">
                                    <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-semibold"><?= $m['credits']; ?></span>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <span class="<?= $m['attendance'] >= 75 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?> px-3 py-1 rounded-full text-sm font-semibold">
                                        <?= $m['attendance']; ?>%
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <span class="<?= $m['internal'] >= 40 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?> px-3 py-1 rounded-full text-sm font-semibold">
                                        <?= $m['internal']; ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-center text-gray-800 font-semibold"><?= $m['external']; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="mt-6 flex items-center justify-between flex-wrap gap-4">
                    <div class="flex items-center space-x-3 bg-blue-50 border border-blue-200 rounded-lg px-6 py-3">
                        <span class="material-symbols-outlined text-blue-600 text-2xl">workspace_premium</span>
                        <div>
                            <p class="text-sm text-gray-600">Total Earned Credits</p>
                            <p class="text-2xl font-bold text-blue-600"><?= $total_credits; ?></p>
                        </div>
                    </div>
                    
                    <?php if (!$eligible): ?>
                        <div class="flex items-center space-x-3 bg-red-50 border border-red-200 rounded-lg px-6 py-3">
                            <span class="material-symbols-outlined text-red-600 text-2xl">error</span>
                            <p class="text-red-700 font-medium">Not eligible for hall ticket due to attendance/marks criteria</p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Exam Schedule Card -->
        <div class="bg-white rounded-2xl shadow-lg p-8 mb-8 border-l-8 border-purple-500">
            <div class="flex items-center space-x-3 mb-6">
                <div class="bg-purple-100 p-3 rounded-full">
                    <span class="material-symbols-outlined text-purple-600 text-3xl">calendar_month</span>
                </div>
                <h2 class="text-2xl font-bold text-gray-800">Exam Schedule</h2>
            </div>
            
            <?php if (!$exams || $exams->num_rows == 0): ?>
                <div class="flex items-center space-x-3 bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <span class="material-symbols-outlined text-amber-500 text-2xl">info</span>
                    <p class="text-amber-700">No exams scheduled yet.</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="bg-purple-50 border-b-2 border-purple-200">
                                <th class="px-6 py-4 text-left text-sm font-semibold text-purple-900">Subject</th>
                                <th class="px-6 py-4 text-left text-sm font-semibold text-purple-900">QP Code</th>
                                <th class="px-6 py-4 text-left text-sm font-semibold text-purple-900">Exam Date</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php while($e = $exams->fetch_assoc()): ?>
                            <tr class="hover:bg-gray-50 transition duration-150">
                                <td class="px-6 py-4 text-gray-800 font-medium"><?= htmlspecialchars($e['sub_name']); ?></td>
                                <td class="px-6 py-4 text-gray-600"><?= htmlspecialchars($e['qp_code']); ?></td>
                                <td class="px-6 py-4 text-gray-800 flex items-center space-x-2">
                                    <span class="material-symbols-outlined text-purple-500 text-xl">event</span>
                                    <span><?= $e['exam_date']; ?></span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Hall Ticket Card -->
        <div class="bg-white rounded-2xl shadow-lg p-8 border-l-8 border-amber-500">
            <div class="flex items-center space-x-3 mb-6">
                <div class="bg-amber-100 p-3 rounded-full">
                    <span class="material-symbols-outlined text-amber-600 text-3xl">confirmation_number</span>
                </div>
                <h2 class="text-2xl font-bold text-gray-800">Hall Ticket</h2>
            </div>
            
            <?php if ($eligible && $hallticket): ?>
                <div class="bg-green-50 border-2 border-green-200 rounded-xl p-6">
                    <div class="flex items-center justify-between flex-wrap gap-4">
                        <div class="flex items-center space-x-3">
                            <span class="material-symbols-outlined text-green-600 text-3xl">check_circle</span>
                            <div>
                                <p class="text-sm text-gray-600 mb-1">Your Hall Ticket ID</p>
                                <p class="text-2xl font-bold text-green-700"><?= htmlspecialchars($hallticket['hallticket_id']); ?></p>
                            </div>
                        </div>
                        <a href="view_hallticket.php?id=<?= urlencode($hallticket['hallticket_id']); ?>" class="flex items-center space-x-2 bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg transition duration-200 shadow-md font-medium">
                            <span class="material-symbols-outlined">visibility</span>
                            <span>View Hall Ticket</span>
                        </a>
                    </div>
                </div>
            <?php elseif (!$eligible): ?>
                <div class="bg-red-50 border-2 border-red-200 rounded-xl p-6">
                    <div class="flex items-center justify-between flex-wrap gap-4">
                        <div class="flex items-center space-x-3">
                            <span class="material-symbols-outlined text-red-600 text-3xl">cancel</span>
                            <p class="text-red-700 font-medium">You are not eligible to receive a hall ticket due to attendance/marks criteria.</p>
                        </div>
                        <a href="request.php" class="flex items-center space-x-2 bg-amber-500 hover:bg-amber-600 text-white px-6 py-3 rounded-lg transition duration-200 shadow-md font-medium">
                            <span class="material-symbols-outlined">send</span>
                            <span>Request Hall Ticket</span>
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <div class="bg-amber-50 border-2 border-amber-200 rounded-xl p-6">
                    <div class="flex items-center space-x-3">
                        <span class="material-symbols-outlined text-amber-600 text-3xl">pending</span>
                        <p class="text-amber-700 font-medium">Hall ticket not generated yet. Please check back later.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    </div>

</body>
</html>