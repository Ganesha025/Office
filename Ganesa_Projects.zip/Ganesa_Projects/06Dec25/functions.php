<?php
// Common functions for Admin Module

// -----------------------------
// Check if Admin is logged in
// -----------------------------
function isAdmin() {
    return (isset($_SESSION['user_id']) && isset($_SESSION['role']) && $_SESSION['role'] === 'admin');
}

// -----------------------------
// Secure Redirect if not admin
// -----------------------------
function ensureAdmin() {
    if (!isAdmin()) {
        header("Location: ../auth/login.php");
        exit;
    }
}
function isStudent() {
    return (isset($_SESSION['user_id']) && isset($_SESSION['role']) && $_SESSION['role'] === 'student');
}

// -----------------------------
// Secure Redirect if not student
// -----------------------------
function ensureStudent() {
    if (!isStudent()) {
        header("Location: ../auth/login.php");
        exit;
    }
}
// -----------------------------
// Sanitize Output
// -----------------------------
function clean($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

// -----------------------------
// Quick DB-safe POST fetch
// -----------------------------
function post($key) {
    return isset($_POST[$key]) ? trim($_POST[$key]) : "";
}

// -----------------------------
// Quick DB-safe GET fetch
// -----------------------------
function get($key) {
    return isset($_GET[$key]) ? trim($_GET[$key]) : "";
}

// -----------------------------
// Show Success Message
// -----------------------------
function success($msg) {
    return "<p style='color: green; font-weight: bold;'>$msg</p>";
}

// -----------------------------
// Show Error Message
// -----------------------------
function error($msg) {
    return "<p style='color: red; font-weight: bold;'>$msg</p>";
}

// -----------------------------
// Check if a value already exists in a table
// -----------------------------
function existsInDB($conn, $table, $column, $value) {
    $value = $conn->real_escape_string($value);
    $sql = "SELECT id FROM $table WHERE $column='$value' LIMIT 1";
    $result = $conn->query($sql);
    return ($result && $result->num_rows > 0);
}

// -----------------------------
// Fetch All Rows (Helper)
// -----------------------------
function fetchAll($conn, $query) {
    $res = $conn->query($query);
    $list = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $list[] = $row;
        }
    }
    return $list;
}

// -----------------------------
// Hall Ticket ID Generator
// Format: HT-{SEM}{REGNO}
// Example: HT-5CSE1234
// -----------------------------
function generateHallTicketID($semester, $regno) {
    return "HT-" . $semester . strtoupper($regno);
}

?>
