<?php
// admin/grade_appeal.php
require_once '../config/db.php';

$students = $conn->query("SELECT reg_no, name FROM students ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
$subjects = $conn->query("SELECT id, subject_name FROM subjects ORDER BY subject_name ASC")->fetch_all(MYSQLI_ASSOC);

$message = '';
$appeal_summary = null;

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $reg_no = $_POST['student'] ?? '';
    $subject_id = $_POST['subject'] ?? '';
    $reason = trim($_POST['reason'] ?? '');

    if(!$reg_no || !$subject_id || !$reason){
        $message = "Please fill all required fields.";
    } else {
        // Fetch student name
        $student = $conn->query("SELECT name FROM students WHERE reg_no='$reg_no'")->fetch_assoc();

        // Fetch current grade
        $grade = $conn->query("SELECT grade FROM results WHERE reg_no='$reg_no' AND semester_id=(SELECT semester_id FROM students WHERE reg_no='$reg_no') AND subject_id=$subject_id")->fetch_assoc();
        $current_grade = $grade['grade'] ?? 'N/A';

        // Check eligibility (only B or below)
        if(!in_array($current_grade,['A','B','C','Fail'])){
            $eligible = true;
        } elseif($current_grade=='A'){
            $eligible = false;
            $message = "Grade A is not eligible for appeal.";
        } else {
            $eligible = true;
        }

        if($eligible){
            // Insert appeal
            $stmt = $conn->prepare("INSERT INTO grade_appeals (reg_no, subject_id, current_grade, reason) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("siss", $reg_no, $subject_id, $current_grade, $reason);
            $stmt->execute();

            $appeal_summary = [
                'student'=>$student['name'],
                'reg_no'=>$reg_no,
                'subject'=>array_filter($subjects,function($s) use ($subject_id){ return $s['id']==$subject_id; }),
                'current_grade'=>$current_grade,
                'reason'=>$reason
            ];
            $message = "Appeal submitted successfully!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Grade Appeal Request</title>
<style>
body { font-family: Arial; margin: 20px; background: #f4f4f4; }
h1 { text-align: center; }
form, .summary { max-width: 600px; margin: 20px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
label { display: block; margin-top: 10px; }
input, select, textarea { width: 100%; padding: 8px; margin-top: 5px; }
button { margin-top: 15px; padding: 10px 20px; cursor: pointer; }
.message { text-align: center; margin: 10px 0; color: green; }
.error { color: red; }
</style>
</head>
<body>
<h1>Grade Appeal Request Form</h1>

<form method="POST">
    <label>Select Student</label>
    <select name="student" required>
        <option value="">Select Student</option>
        <?php foreach($students as $s): ?>
            <option value="<?= $s['reg_no'] ?>" <?= (isset($reg_no) && $reg_no==$s['reg_no'])?'selected':'' ?>><?= $s['name'] ?> (<?= $s['reg_no'] ?>)</option>
        <?php endforeach; ?>
    </select>

    <label>Select Subject</label>
    <select name="subject" required>
        <option value="">Select Subject</option>
        <?php foreach($subjects as $sub): ?>
            <option value="<?= $sub['id'] ?>" <?= (isset($subject_id) && $subject_id==$sub['id'])?'selected':'' ?>><?= $sub['subject_name'] ?></option>
        <?php endforeach; ?>
    </select>

    <label>Reason for Appeal</label>
    <textarea name="reason" rows="4" required><?= $_POST['reason'] ?? '' ?></textarea>

    <button type="submit">Submit Appeal</button>
</form>

<?php if($message): ?>
<p class="<?= (strpos($message,'success')!==false)?'message':'error' ?>"><?= $message ?></p>
<?php endif; ?>

<?php if($appeal_summary): ?>
<div class="summary">
    <h2>Appeal Summary</h2>
    <p><strong>Student:</strong> <?= $appeal_summary['student'] ?> (<?= $appeal_summary['reg_no'] ?>)</p>
    <p><strong>Subject:</strong> <?= array_values($appeal_summary['subject'])[0]['subject_name'] ?></p>
    <p><strong>Current Grade:</strong> <?= $appeal_summary['current_grade'] ?></p>
    <p><strong>Reason:</strong> <?= $appeal_summary['reason'] ?></p>
</div>
<?php endif; ?>
</body>
</html>
