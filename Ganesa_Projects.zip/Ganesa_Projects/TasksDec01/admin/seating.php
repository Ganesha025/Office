<?php
// admin/seating.php
require_once '../config/db.php';

$students = $conn->query("SELECT reg_no, name FROM students ORDER BY reg_no ASC")->fetch_all(MYSQLI_ASSOC);
$rooms = $conn->query("SELECT * FROM rooms ORDER BY id ASC")->fetch_all(MYSQLI_ASSOC);

$seating_chart = [];
$message = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $seats_per_room = (int)$_POST['seats_per_room'];
    if($seats_per_room <= 0){
        $message = "Seats per room must be greater than 0.";
    } else {
        // Clear previous seating allotment
        $conn->query("TRUNCATE TABLE seating_allotment");

        $room_index = 0;
        $seat_no = 1;

        foreach($students as $s){
            $room_id = $rooms[$room_index]['id'];
            $stmt = $conn->prepare("INSERT INTO seating_allotment (room_id, reg_no, seat_no, exam_session) VALUES (?, ?, ?, ?)");
            $exam_session = date('Y-m-d'); // example session
            $stmt->bind_param("isis", $room_id, $s['reg_no'], $seat_no, $exam_session);
            $stmt->execute();

            // Prepare seating chart for display
            $seating_chart[$rooms[$room_index]['room_no']][] = [
                'seat_no'=>$seat_no,
                'reg_no'=>$s['reg_no'],
                'name'=>$s['name']
            ];

            $seat_no++;
            if($seat_no > $seats_per_room){
                $seat_no = 1;
                $room_index++;
                if($room_index >= count($rooms)){
                    $message = "Not enough rooms for all students!";
                    break;
                }
            }
        }
        if(!$message){
            $message = "Seating allotment completed!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Exam Seating Arrangement</title>
<style>
body { font-family: Arial; margin: 20px; background: #f4f4f4; }
h1 { text-align: center; }
form, .chart { max-width: 900px; margin: 20px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
label, input, button { display: block; margin-top: 10px; }
input, button { padding: 8px; width: 100%; max-width: 200px; }
table { width: 100%; border-collapse: collapse; margin-top: 15px; }
th, td { border: 1px solid #333; padding: 8px; text-align: center; }
.message { text-align: center; margin: 10px 0; color: green; }
.error { color: red; }
</style>
</head>
<body>
<h1>Exam Seating Arrangement</h1>

<form method="POST">
    <label>Seats per Room</label>
    <input type="number" name="seats_per_room" min="1" required value="<?= $_POST['seats_per_room'] ?? 5 ?>">
    <button type="submit">Generate Seating</button>
</form>

<?php if($message): ?>
<p class="<?= (strpos($message,'completed')!==false)?'message':'error' ?>"><?= $message ?></p>
<?php endif; ?>

<?php if($seating_chart): ?>
<div class="chart">
    <h2>Seating Chart</h2>
    <?php foreach($seating_chart as $room_no=>$students_in_room): ?>
        <h3>Room: <?= $room_no ?></h3>
        <table>
            <tr>
                <th>Seat No</th>
                <th>Reg No</th>
                <th>Name</th>
            </tr>
            <?php foreach($students_in_room as $stu): ?>
            <tr>
                <td><?= $stu['seat_no'] ?></td>
                <td><?= $stu['reg_no'] ?></td>
                <td><?= $stu['name'] ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php endforeach; ?>
</div>
<?php endif; ?>
</body>
</html>
