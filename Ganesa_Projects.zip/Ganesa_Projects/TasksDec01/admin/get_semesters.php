<?php
// admin/get_semesters.php
require_once '../config/db.php';

if(isset($_POST['department_id'])){
    $dept_id = $_POST['department_id'];
    $semesters = $conn->query("SELECT * FROM semesters WHERE program_id IN (SELECT program_id FROM students WHERE department_id=$dept_id) ORDER BY sem_number ASC");
    foreach($semesters as $sem){
        echo "<option value='".$sem['id']."'>Semester ".$sem['sem_number']."</option>";
    }
}
?>
