<?php
require_once '../config/db.php';

$marksheet_result = null;
$class_stats = null;

$students = $conn->query("SELECT reg_no, name, semester_id FROM students ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['student'])){
    $reg_no = $conn->real_escape_string($_POST['student']);

    // If marks submitted, update or insert marks in DB
    if(isset($_POST['marks'])){
        foreach($_POST['marks'] as $subject_id => $marks_data){
            $subject_id = (int)$subject_id;
            $internal1 = (int)$marks_data['internal1'];
            $internal2 = (int)$marks_data['internal2'];
            $assignment = (int)$marks_data['assignment'];
            $external = (int)$marks_data['external'];

            $existing_internal = $conn->query("SELECT id FROM internal_marks WHERE reg_no='$reg_no' AND subject_id=$subject_id")->fetch_assoc();
            if($existing_internal){
                $conn->query("UPDATE internal_marks SET internal1=$internal1, internal2=$internal2, assignment=$assignment WHERE id=".$existing_internal['id']);
            } else {
                $conn->query("INSERT INTO internal_marks (reg_no, subject_id, internal1, internal2, assignment) VALUES ('$reg_no', $subject_id, $internal1, $internal2, $assignment)");
            }

            $existing_external = $conn->query("SELECT id FROM external_marks WHERE reg_no='$reg_no' AND subject_id=$subject_id")->fetch_assoc();
            if($existing_external){
                $conn->query("UPDATE external_marks SET marks=$external WHERE id=".$existing_external['id']);
            } else {
                $conn->query("INSERT INTO external_marks (reg_no, subject_id, marks) VALUES ('$reg_no', $subject_id, $external)");
            }
        }
    }

    $student = $conn->query("SELECT * FROM students WHERE reg_no='$reg_no'")->fetch_assoc();
    if($student){
        $semester_id = $student['semester_id'];
        $subjects = $conn->query("SELECT id, subject_name, credit FROM subjects WHERE semester_id=$semester_id")->fetch_all(MYSQLI_ASSOC);

        $total_weighted = 0;
        $total_credits = 0;
        $subject_contributions = [];

        foreach($subjects as $sub){
            $sub_id = $sub['id'];
            $internal = $conn->query("SELECT internal1, internal2, assignment FROM internal_marks WHERE reg_no='$reg_no' AND subject_id=$sub_id")->fetch_assoc();
            $internal_total = ($internal) ? ($internal['internal1'] + $internal['internal2'] + $internal['assignment']) : 0;
            $external = $conn->query("SELECT marks FROM external_marks WHERE reg_no='$reg_no' AND subject_id=$sub_id")->fetch_assoc();
            $external_marks = ($external) ? $external['marks'] : 0;

            $total_marks = $internal_total + $external_marks;
            $weighted = $total_marks * $sub['credit'];

            $subject_contributions[] = [
                'id' => $sub_id,
                'name' => $sub['subject_name'],
                'marks' => $total_marks,
                'credit' => $sub['credit'],
                'weighted' => $weighted,
                'internal1' => $internal ? $internal['internal1'] : 0,
                'internal2' => $internal ? $internal['internal2'] : 0,
                'assignment' => $internal ? $internal['assignment'] : 0,
                'external' => $external_marks
            ];

            $total_weighted += $weighted;
            $total_credits += $sub['credit'];
        }

        $weighted_avg = ($total_credits > 0) ? $total_weighted / $total_credits : 0;

        if($weighted_avg >= 75) $grade = 'A';
        elseif($weighted_avg >= 60) $grade = 'B';
        elseif($weighted_avg >= 40) $grade = 'C';
        else $grade = 'Fail';

        $marksheet_result = [
            'student' => $student,
            'weighted_avg' => round($weighted_avg,2),
            'grade' => $grade,
            'subjects' => $subject_contributions
        ];

        $students_in_sem = $conn->query("SELECT reg_no FROM students WHERE semester_id=$semester_id")->fetch_all(MYSQLI_ASSOC);
        $class_marks = [];
        foreach($students_in_sem as $s){
            $total = 0;
            $credits = 0;
            foreach($subjects as $sub){
                $sub_id = $sub['id'];
                $internal = $conn->query("SELECT internal1, internal2, assignment FROM internal_marks WHERE reg_no='{$s['reg_no']}' AND subject_id=$sub_id")->fetch_assoc();
                $internal_total = ($internal) ? ($internal['internal1'] + $internal['internal2'] + $internal['assignment']) : 0;
                $external = $conn->query("SELECT marks FROM external_marks WHERE reg_no='{$s['reg_no']}' AND subject_id=$sub_id")->fetch_assoc();
                $external_marks = ($external) ? $external['marks'] : 0;
                $total += ($internal_total + $external_marks) * $sub['credit'];
                $credits += $sub['credit'];
            }
            $avg = ($credits>0) ? $total/$credits : 0;
            $class_marks[] = round($avg,2);
        }

        $average = round(array_sum($class_marks)/count($class_marks),2);
        $highest = max($class_marks);
        $lowest = min($class_marks);
        $pass_count = count(array_filter($class_marks,function($m){ return $m>=40; }));
        $pass_percent = round(($pass_count/count($class_marks))*100,2);

        $class_stats = [
            'average'=>$average,
            'highest'=>$highest,
            'lowest'=>$lowest,
            'pass_percent'=>$pass_percent,
            'marks'=>$class_marks
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Marksheet & Class Analysis</title>
<style>
body { font-family: Arial; margin: 20px; background: #f4f4f4; }
h1, h2 { text-align: center; }
form, .results { max-width: 800px; margin: 20px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
select, table { width: 100%; margin-top: 10px; }
table { border-collapse: collapse; }
th, td { border: 1px solid #333; padding: 8px; text-align: left; }
input[type=number] { width: 60px; }
.bar { height: 20px; background-color: #4CAF50; margin: 2px 0; color: #fff; text-align: right; padding-right: 5px; }
</style>
</head>
<body>
<h1>Marksheet Generator & Class Analysis</h1>

<form method="POST">
    <h2>Select Student</h2>
    <select name="student" required>
        <option value="">Select Student</option>
        <?php foreach($students as $s): ?>
            <option value="<?= htmlspecialchars($s['reg_no']) ?>" <?= (isset($reg_no) && $reg_no==$s['reg_no'])?'selected':'' ?>><?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['reg_no']) ?>)</option>
        <?php endforeach; ?>
    </select>
    <button type="submit">Show Marksheet</button>
</form>

<?php if($marksheet_result): ?>
<form method="POST">
<input type="hidden" name="student" value="<?= htmlspecialchars($marksheet_result['student']['reg_no']) ?>">
<div class="results">
    <h2>Marksheet: <?= htmlspecialchars($marksheet_result['student']['name']) ?> (<?= htmlspecialchars($marksheet_result['student']['reg_no']) ?>)</h2>
    <table>
        <tr>
            <th>Subject</th>
            <th>Internal 1</th>
            <th>Internal 2</th>
            <th>Assignment</th>
            <th>External</th>
            <th>Total Marks</th>
            <th>Credit</th>
            <th>Weighted Contribution</th>
        </tr>
        <?php foreach($marksheet_result['subjects'] as $sub): ?>
        <tr>
            <td><?= htmlspecialchars($sub['name']) ?></td>
            <td><input type="number" name="marks[<?= $sub['id'] ?>][internal1]" min="0" max="100" value="<?= $sub['internal1'] ?>"></td>
            <td><input type="number" name="marks[<?= $sub['id'] ?>][internal2]" min="0" max="100" value="<?= $sub['internal2'] ?>"></td>
            <td><input type="number" name="marks[<?= $sub['id'] ?>][assignment]" min="0" max="100" value="<?= $sub['assignment'] ?>"></td>
            <td><input type="number" name="marks[<?= $sub['id'] ?>][external]" min="0" max="100" value="<?= $sub['external'] ?>"></td>
            <td><?= $sub['marks'] ?></td>
            <td><?= $sub['credit'] ?></td>
            <td><?= $sub['weighted'] ?></td>
        </tr>
        <?php endforeach; ?>
        <tr>
            <td colspan="7" style="text-align:right"><strong>Total Weighted Average</strong></td>
            <td><strong><?= $marksheet_result['weighted_avg'] ?></strong></td>
        </tr>
        <tr>
            <td colspan="7" style="text-align:right"><strong>Grade</strong></td>
            <td><strong><?= $marksheet_result['grade'] ?></strong></td>
        </tr>
    </table>
    <button type="submit">Update Marks</button>
</div>
</form>

<div class="results">
    <h2>Class Result Analysis (Semester <?= $marksheet_result['student']['semester_id'] ?>)</h2>
    <p>Average Marks: <?= $class_stats['average'] ?></p>
    <p>Highest Marks: <?= $class_stats['highest'] ?></p>
    <p>Lowest Marks: <?= $class_stats['lowest'] ?></p>
    <p>Pass Percentage: <?= $class_stats['pass_percent'] ?>%</p>

    <h3>Marks Distribution</h3>
    <?php foreach($class_stats['marks'] as $m): ?>
        <div class="bar" style="width: <?= $m ?>%;"><?= $m ?></div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
</body>
</html>
