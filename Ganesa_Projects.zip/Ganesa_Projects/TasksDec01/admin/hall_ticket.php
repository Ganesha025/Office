<?php
// admin/hall_ticket.php
require_once '../config/db.php';

// Handle form submission
$hall_ticket = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reg_no = $_POST['reg_no'] ?? '';
    $department_id = $_POST['department'] ?? '';
    $semester_id = $_POST['semester'] ?? '';

    if ($reg_no && $department_id && $semester_id) {
        // Fetch student info
        $stmt = $conn->prepare("SELECT * FROM students WHERE reg_no=? AND department_id=? AND semester_id=?");
        $stmt->bind_param("sii", $reg_no, $department_id, $semester_id);
        $stmt->execute();
        $student = $stmt->get_result()->fetch_assoc();

        if ($student) {
            // Fetch 6 subjects for this department + semester
            $stmt2 = $conn->prepare("SELECT * FROM subjects WHERE department_id=? AND semester_id=? LIMIT 6");
            $stmt2->bind_param("ii", $department_id, $semester_id);
            $stmt2->execute();
            $subjects = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);

            $hall_ticket = [
                'student' => $student,
                'subjects' => $subjects
            ];
        } else {
            $error = "Student not found with this Department/Semester combination.";
        }
    } else {
        $error = "Please fill all fields.";
    }
}

// Fetch all departments
$departments = $conn->query("SELECT * FROM departments ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hall Ticket Generator</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f9f9f9; }
        h1 { text-align: center; margin-bottom: 20px; }
        form { max-width: 500px; margin: auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        label { display: block; margin-top: 10px; }
        select, input { width: 100%; padding: 8px; margin-top: 5px; }
        button { margin-top: 15px; padding: 10px 20px; cursor: pointer; }
        .ticket { max-width: 700px; margin: 30px auto; padding: 20px; border: 2px solid #333; border-radius: 8px; background: #fff; }
        .ticket h2 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #333; padding: 8px; text-align: left; }
        .error { color: red; text-align: center; }
    </style>
</head>
<body>
    <h1>Dynamic Hall Ticket Generator</h1>

    <?php if(!empty($error)) echo "<p class='error'>$error</p>"; ?>

    <form method="POST">
        <label>Register Number</label>
        <input type="text" name="reg_no" required>

        <label>Department</label>
        <select name="department" id="department" required>
            <option value="">Select Department</option>
            <?php foreach($departments as $dept): ?>
                <option value="<?= $dept['id'] ?>"><?= $dept['name'] ?></option>
            <?php endforeach; ?>
        </select>

        <label>Semester</label>
        <select name="semester" id="semester" required>
            <option value="">Select Semester</option>
        </select>

        <button type="submit">Generate Hall Ticket</button>
    </form>

    <?php if($hall_ticket): ?>
        <div class="ticket">
            <h2>Hall Ticket</h2>
            <p><strong>Register Number:</strong> <?= $hall_ticket['student']['reg_no'] ?></p>
            <p><strong>Name:</strong> <?= $hall_ticket['student']['name'] ?></p>
            <p><strong>Department:</strong> <?= $conn->query("SELECT name FROM departments WHERE id=".$hall_ticket['student']['department_id'])->fetch_assoc()['name'] ?></p>
            <p><strong>Semester:</strong> <?= $conn->query("SELECT sem_number FROM semesters WHERE id=".$hall_ticket['student']['semester_id'])->fetch_assoc()['sem_number'] ?></p>

            <table>
                <tr>
                    <th>Sl. No</th>
                    <th>Subject Code</th>
                    <th>Subject Name</th>
                </tr>
                <?php foreach($hall_ticket['subjects'] as $i => $sub): ?>
                    <tr>
                        <td><?= $i+1 ?></td>
                        <td><?= $sub['subject_code'] ?></td>
                        <td><?= $sub['subject_name'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    <?php endif; ?>

<script>
$(document).ready(function(){
    // Load semesters dynamically based on department
    $('#department').change(function(){
        var dept_id = $(this).val();
        $('#semester').html('<option value="">Select Semester</option>');
        if(dept_id){
            $.ajax({
                url: 'get_semesters.php',
                type: 'POST',
                data: { department_id: dept_id },
                success: function(data){
                    $('#semester').append(data);
                }
            });
        }
    });
});
</script>
</body>
</html>
