<?php
// admin/index.php
require_once '../config/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body class="bg-gray-100 min-h-screen font-sans">

    <!-- Navigation -->
    <nav class="bg-white shadow-md">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <span class="font-bold text-xl text-indigo-600">College Admin</span>
                </div>
                <div class="hidden md:flex space-x-6 items-center">
                    <a href="index.php" class="text-gray-700 hover:text-indigo-600 font-semibold">Dashboard</a>
                    <a href="hall_ticket.php" class="text-gray-700 hover:text-indigo-600 font-semibold">Hall Ticket</a>
                    <a href="attendance.php" class="text-gray-700 hover:text-indigo-600 font-semibold">Attendance</a>
                    <a href="marksheet.php" class="text-gray-700 hover:text-indigo-600 font-semibold">Marksheet</a>
                    <a href="electives.php" class="text-gray-700 hover:text-indigo-600 font-semibold">Electives</a>
                    <a href="grade_appeal.php" class="text-gray-700 hover:text-indigo-600 font-semibold">Grade Appeals</a>
                    <a href="seating.php" class="text-gray-700 hover:text-indigo-600 font-semibold">Seating</a>
                    <a href="fee_slip.php" class="text-gray-700 hover:text-indigo-600 font-semibold">Fee Slip</a>
                </div>

                <!-- Mobile Menu Button -->
                <div class="flex md:hidden items-center">
                    <button id="mobile-menu-btn" class="text-gray-700 focus:outline-none">
                        <i class="fas fa-bars text-2xl"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Menu -->
        <div id="mobile-menu" class="md:hidden hidden bg-white shadow-inner">
            <a href="index.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Dashboard</a>
            <a href="hall_ticket.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Hall Ticket</a>
            <a href="attendance.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Attendance</a>
            <a href="marksheet.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Marksheet</a>
            <a href="electives.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Electives</a>
            <a href="grade_appeal.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Grade Appeals</a>
            <a href="seating.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Seating</a>
            <a href="fee_slip.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Fee Slip</a>
        </div>
    </nav>

    <!-- Dashboard Cards -->
    <main class="max-w-6xl mx-auto p-6">
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            
            <!-- Hall Ticket -->
            <div class="bg-white rounded-xl shadow-lg p-6 flex flex-col items-center transition transform hover:-translate-y-2 hover:shadow-2xl">
                <i class="fas fa-id-card text-4xl text-indigo-500"></i>
                <div class="mt-4 text-lg font-semibold text-gray-700 text-center">Hall Ticket Generator</div>
                <a href="hall_ticket.php" class="mt-4 px-4 py-2 bg-indigo-500 text-white rounded-full font-semibold hover:bg-indigo-600 transition">Go</a>
            </div>

            <!-- Attendance -->
            <div class="bg-white rounded-xl shadow-lg p-6 flex flex-col items-center transition transform hover:-translate-y-2 hover:shadow-2xl">
                <i class="fas fa-calendar-check text-4xl text-green-500"></i>
                <div class="mt-4 text-lg font-semibold text-gray-700 text-center">Attendance Checker / Pattern</div>
                <a href="attendance.php" class="mt-4 px-4 py-2 bg-green-500 text-white rounded-full font-semibold hover:bg-green-600 transition">Go</a>
            </div>

            <!-- Marksheet -->
            <div class="bg-white rounded-xl shadow-lg p-6 flex flex-col items-center transition transform hover:-translate-y-2 hover:shadow-2xl">
                <i class="fas fa-graduation-cap text-4xl text-yellow-500"></i>
                <div class="mt-4 text-lg font-semibold text-gray-700 text-center">Marksheet / Result Analysis</div>
                <a href="marksheet.php" class="mt-4 px-4 py-2 bg-yellow-500 text-white rounded-full font-semibold hover:bg-yellow-600 transition">Go</a>
            </div>

            <!-- Electives -->
            <div class="bg-white rounded-xl shadow-lg p-6 flex flex-col items-center transition transform hover:-translate-y-2 hover:shadow-2xl">
                <i class="fas fa-book-open text-4xl text-pink-500"></i>
                <div class="mt-4 text-lg font-semibold text-gray-700 text-center">Elective Selection</div>
                <a href="electives.php" class="mt-4 px-4 py-2 bg-pink-500 text-white rounded-full font-semibold hover:bg-pink-600 transition">Go</a>
            </div>

            <!-- Grade Appeal -->
            <div class="bg-white rounded-xl shadow-lg p-6 flex flex-col items-center transition transform hover:-translate-y-2 hover:shadow-2xl">
                <i class="fas fa-file-alt text-4xl text-red-500"></i>
                <div class="mt-4 text-lg font-semibold text-gray-700 text-center">Grade Appeal Requests</div>
                <a href="grade_appeal.php" class="mt-4 px-4 py-2 bg-red-500 text-white rounded-full font-semibold hover:bg-red-600 transition">Go</a>
            </div>

            <!-- Seating -->
            <div class="bg-white rounded-xl shadow-lg p-6 flex flex-col items-center transition transform hover:-translate-y-2 hover:shadow-2xl">
                <i class="fas fa-chair text-4xl text-teal-500"></i>
                <div class="mt-4 text-lg font-semibold text-gray-700 text-center">Seating Arrangement</div>
                <a href="seating.php" class="mt-4 px-4 py-2 bg-teal-500 text-white rounded-full font-semibold hover:bg-teal-600 transition">Go</a>
            </div>

            <!-- Fee Slip -->
            <div class="bg-white rounded-xl shadow-lg p-6 flex flex-col items-center transition transform hover:-translate-y-2 hover:shadow-2xl">
                <i class="fas fa-money-bill-wave text-4xl text-blue-500"></i>
                <div class="mt-4 text-lg font-semibold text-gray-700 text-center">Fee Slip Generator</div>
                <a href="fee_slip.php" class="mt-4 px-4 py-2 bg-blue-500 text-white rounded-full font-semibold hover:bg-blue-600 transition">Go</a>
            </div>

        </div>
    </main>

    <script>
        // Mobile Menu Toggle
        $('#mobile-menu-btn').click(function(){
            $('#mobile-menu').slideToggle();
        });
    </script>

</body>
</html>
