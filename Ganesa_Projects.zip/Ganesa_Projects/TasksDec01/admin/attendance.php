<?php
require_once '../config/db.php';
$eligibility_result = null;
$pattern = null;
$student_attendance = [];
$student = null;
$reg_no = null;
$students = $conn->query("SELECT reg_no, name FROM students ORDER BY name ASC");
$subjects = $conn->query("SELECT id, subject_name FROM subjects ORDER BY subject_name ASC")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['total_days'], $_POST['present_days'])) {
        $total_days = (int)$_POST['total_days'];
        $present_days = (int)$_POST['present_days'];
        if ($total_days > 0) {
            $percentage = ($present_days / $total_days) * 100;
            $status = ($percentage >= 75) ? 'Eligible' : 'Not Eligible';
            $eligibility_result = ['percentage' => round($percentage, 2), 'status' => $status];
        }
    }
    
    if (isset($_POST['subject_ids'])) {
        $pattern = [];
        foreach ($_POST['subject_ids'] as $i => $sid) {
            $pattern[] = ['name' => $_POST['subject_names'][$i], 'attendance' => (float)$_POST['subject_attendance'][$i]];
        }
    }
    
    if (isset($_POST['student_attendance'], $_POST['search_regno'])) {
        $reg_no = $conn->real_escape_string($_POST['search_regno']);
        $student = $conn->query("SELECT name, department_id, program_id FROM students WHERE reg_no='$reg_no'")->fetch_assoc();
        
        if ($student) {
            $student_attendance = $conn->query(
                "SELECT s.subject_name, a.total_days, a.present_days, a.attendance_percentage 
                 FROM attendance a JOIN subjects s ON a.subject_id=s.id 
                 WHERE a.reg_no='$reg_no' ORDER BY s.subject_name"
            )->fetch_all(MYSQLI_ASSOC);
            
            if (empty($student_attendance)) {
                $dept_id = (int)$student['department_id'];
                $prog_id = (int)$student['program_id'];
                $student_attendance = $conn->query(
                    "SELECT subject_name, 0 AS total_days, 0 AS present_days, 0 AS attendance_percentage 
                     FROM subjects 
                     WHERE department_id = $dept_id AND program_id = $prog_id
                     ORDER BY subject_name"
                )->fetch_all(MYSQLI_ASSOC);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Attendance Checker & Pattern</title>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
body{font-family:Arial;margin:20px;background:#f4f4f4}
h1{text-align:center}
form,.results{max-width:700px;margin:20px auto;background:#fff;padding:20px;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,0.1)}
label{display:block;margin-top:10px}
input,select{width:100%;padding:8px;margin-top:5px}
button{margin-top:15px;padding:10px 20px;cursor:pointer}
.eligible{color:green;font-weight:bold}
.not-eligible{color:red;font-weight:bold}
table{width:100%;border-collapse:collapse;margin-top:15px}
th,td{border:1px solid #333;padding:8px;text-align:left}
.low-attendance{background-color:#f8d7da}
.high-attendance{background-color:#d4edda}
.no-attendance{background-color:#fff3cd;color:#856404}
</style>
</head>
<body>
<h1>Attendance Checker & Pattern Visualizer</h1>

<form method="POST">
<h2>Exam Eligibility Checker</h2>
<label>Total Working Days</label>
<input type="number" name="total_days" id="total_days" min="1" required>
<label>Present Days</label>
<input type="number" name="present_days" id="present_days" min="0" required>
<label>Attendance %</label>
<input type="text" id="attendance_percent" readonly style="background:#eee;">
<button type="submit">Check Eligibility</button>
</form>
<?php if($eligibility_result): ?>
<div class="results">
<h3>Result:</h3>
<p>Attendance: <?= $eligibility_result['percentage'] ?>%</p>
<p>Status: <span class="<?= strtolower(str_replace(' ','-',$eligibility_result['status'])) ?>">
<?= $eligibility_result['status'] ?></span></p>
</div>
<?php endif; ?>

<form method="POST">
<h2>Student Attendance Report</h2>
<label>Select Student</label>
<select name="search_regno" required>
<option value="">Select Student</option>
<?php $students->data_seek(0); while($row=$students->fetch_assoc()): ?>
<option value="<?= $row['reg_no'] ?>" <?= $reg_no==$row['reg_no']?'selected':'' ?>><?= htmlspecialchars($row['reg_no']) ?> - <?= htmlspecialchars($row['name']) ?></option>
<?php endwhile; ?>
</select>
<button type="submit" name="student_attendance">View Attendance</button>
</form>

<?php if(!empty($student_attendance)): ?>
<div class="results">
<h3><?= htmlspecialchars($student['name']) ?> (<?= htmlspecialchars($reg_no) ?>)</h3>
<table>
<tr><th>Subject</th><th>Total Days</th><th>Present</th><th>%</th></tr>
<?php foreach($student_attendance as $att):
$class = ($att['attendance_percentage'] == 0) ? 'no-attendance' : (($att['attendance_percentage'] < 75) ? 'low-attendance' : 'high-attendance'); ?>
<tr class="<?= $class ?>">
<td><?= htmlspecialchars($att['subject_name']) ?></td>
<td><?= $att['total_days'] ?></td>
<td><?= $att['present_days'] ?></td>
<td><?= round($att['attendance_percentage'],1) ?>% <?= $att['attendance_percentage']==0 ? '(No Records)' : '' ?></td>
</tr>
<?php endforeach; ?>
</table>
</div>
<?php endif; ?>

<script>
$('#total_days,#present_days').on('input',function(){
    let t=parseFloat($('#total_days').val())||0,
        p=parseFloat($('#present_days').val())||0,
        per=(t>0)?(p/t*100).toFixed(2):0;
    $('#attendance_percent').val(per+'%');
});
</script>
</body>
</html>
