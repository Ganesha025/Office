<?php
// admin/fee_slip.php
require_once '../config/db.php';

$students = $conn->query("SELECT reg_no, name, program_id FROM students ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
$categories = ['Day Scholar', 'Hosteller'];

$fee_slip = null;
$message = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $reg_no = $_POST['student'] ?? '';
    $category = $_POST['category'] ?? '';

    if(!$reg_no || !$category){
        $message = "Please select student and category.";
    } else {
        $student = $conn->query("SELECT * FROM students WHERE reg_no='$reg_no'")->fetch_assoc();
        $program_id = $student['program_id'];

        // Fetch program fee structure
        $fees = $conn->query("SELECT * FROM fee_structure WHERE program_id=$program_id")->fetch_assoc();
        if(!$fees){
            $message = "Fee structure not found for this student.";
        } else {
            $tuition_fee = $fees['tuition_fee'];
            $exam_fee = $fees['exam_fee'];
            $lab_fee = $fees['lab_fee'];
            $mess_fee = ($category=='Hosteller') ? $fees['mess_fee'] : 0;
            $hostel_fee = ($category=='Hosteller') ? $fees['hostel_fee'] : 0;
            $total = $tuition_fee + $exam_fee + $lab_fee + $mess_fee + $hostel_fee;

            // Save to fee_slips table
            // First, get category_id from fee_categories table
            $cat_row = $conn->query("SELECT id FROM fee_categories WHERE category='$category'")->fetch_assoc();
            $category_id = $cat_row['id'] ?? null;
            if($category_id){
                $stmt = $conn->prepare("INSERT INTO fee_slips (reg_no, category_id, tuition_fee, exam_fee, lab_fee, mess_fee, hostel_fee, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("siiiiiii", $reg_no, $category_id, $tuition_fee, $exam_fee, $lab_fee, $mess_fee, $hostel_fee, $total);
                $stmt->execute();

                $fee_slip = [
                    'student'=>$student,
                    'category'=>$category,
                    'tuition_fee'=>$tuition_fee,
                    'exam_fee'=>$exam_fee,
                    'lab_fee'=>$lab_fee,
                    'mess_fee'=>$mess_fee,
                    'hostel_fee'=>$hostel_fee,
                    'total'=>$total
                ];
                $message = "Fee slip generated successfully!";
            } else {
                $message = "Fee category not found!";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Fee Slip Generator</title>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
body { font-family: Arial; margin: 20px; background: #f4f4f4; }
h1 { text-align: center; }
form, .slip { max-width: 600px; margin: 20px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
label { display: block; margin-top: 10px; }
select, input { width: 100%; padding: 8px; margin-top: 5px; }
button { margin-top: 15px; padding: 10px 20px; cursor: pointer; }
.message { text-align: center; margin: 10px 0; color: green; }
.error { color: red; }
.slip table { width: 100%; border-collapse: collapse; margin-top: 15px; }
.slip th, .slip td { border: 1px solid #333; padding: 8px; text-align: left; }
</style>
</head>
<body>
<h1>Fee Slip Generator</h1>

<form method="POST">
    <label>Select Student</label>
    <select name="student" id="student" required>
        <option value="">Select Student</option>
        <?php foreach($students as $s): ?>
            <option value="<?= $s['reg_no'] ?>" <?= (isset($reg_no) && $reg_no==$s['reg_no'])?'selected':'' ?>><?= $s['name'] ?> (<?= $s['reg_no'] ?>)</option>
        <?php endforeach; ?>
    </select>

    <label>Category</label>
    <select name="category" id="category" required>
        <option value="">Select Category</option>
        <?php foreach($categories as $c): ?>
            <option value="<?= $c ?>" <?= (isset($category) && $category==$c)?'selected':'' ?>><?= $c ?></option>
        <?php endforeach; ?>
    </select>

    <div id="hostel_fees" style="display:none;">
        <p>Mess and Hostel fees will be applied for Hostellers</p>
    </div>

    <button type="submit">Generate Fee Slip</button>
</form>

<?php if($message): ?>
<p class="<?= (strpos($message,'success')!==false)?'message':'error' ?>"><?= $message ?></p>
<?php endif; ?>

<?php if($fee_slip): ?>
<div class="slip">
    <h2>Fee Slip for <?= $fee_slip['student']['name'] ?> (<?= $fee_slip['student']['reg_no'] ?>)</h2>
    <table>
        <tr><th>Category</th><td><?= $fee_slip['category'] ?></td></tr>
        <tr><th>Tuition Fee</th><td><?= $fee_slip['tuition_fee'] ?></td></tr>
        <tr><th>Exam Fee</th><td><?= $fee_slip['exam_fee'] ?></td></tr>
        <tr><th>Lab Fee</th><td><?= $fee_slip['lab_fee'] ?></td></tr>
        <?php if($fee_slip['category']=='Hosteller'): ?>
        <tr><th>Mess Fee</th><td><?= $fee_slip['mess_fee'] ?></td></tr>
        <tr><th>Hostel Fee</th><td><?= $fee_slip['hostel_fee'] ?></td></tr>
        <?php endif; ?>
        <tr><th>Total</th><td><?= $fee_slip['total'] ?></td></tr>
    </table>
</div>
<?php endif; ?>

<script>
$(document).ready(function(){
    function toggleHostelFees(){
        if($('#category').val()=='Hosteller'){
            $('#hostel_fees').show();
        } else {
            $('#hostel_fees').hide();
        }
    }
    $('#category').change(toggleHostelFees);
    toggleHostelFees();
});
</script>
</body>
</html>
