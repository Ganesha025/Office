<?php
// admin/electives.php
require_once '../config/db.php';

$students = $conn->query("SELECT reg_no, name FROM students ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
$electives = $conn->query("SELECT * FROM electives ORDER BY elective_name ASC LIMIT 10")->fetch_all(MYSQLI_ASSOC);

$message = '';
$selected_electives = [];

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $reg_no = $_POST['student'] ?? '';
    $selected = $_POST['electives'] ?? [];

    if(!$reg_no){
        $message = "Please select a student.";
    } elseif(count($selected) > 3){
        $message = "You can select a maximum of 3 electives.";
    } else {
        // Validate electives exist in DB
        $valid_ids = array_column($electives,'id');
        foreach($selected as $eid){
            if(!in_array($eid, $valid_ids)){
                $message = "Invalid elective selected.";
                break;
            }
        }

        if(!$message){
            // Delete previous selections
            $conn->query("DELETE FROM student_electives WHERE reg_no='$reg_no'");

            // Insert new selections
            $stmt = $conn->prepare("INSERT INTO student_electives (reg_no, elective_id) VALUES (?, ?)");
            foreach($selected as $eid){
                $stmt->bind_param("si", $reg_no, $eid);
                $stmt->execute();
            }

            $selected_electives = $selected;
            $message = "Electives saved successfully!";
        }
    }
}

// Fetch already selected electives for a student if available
$pre_selected = [];
if(isset($_POST['student']) && $_POST['student']){
    $reg_no = $_POST['student'];
    $res = $conn->query("SELECT elective_id FROM student_electives WHERE reg_no='$reg_no'");
    $pre_selected = $res->fetch_all(MYSQLI_ASSOC);
    $pre_selected = array_column($pre_selected,'elective_id');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Elective Selection</title>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
body { font-family: Arial; margin: 20px; background: #f4f4f4; }
h1 { text-align: center; }
form { max-width: 600px; margin: 20px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
label { display: block; margin-top: 10px; }
input[type="checkbox"] { margin-right: 5px; }
button { margin-top: 15px; padding: 10px 20px; cursor: pointer; }
.message { text-align: center; margin: 10px 0; color: green; }
.error { color: red; }
.selected-list { margin-top: 15px; background: #eee; padding: 10px; border-radius: 5px; }
</style>
</head>
<body>
<h1>Elective Subject Selection</h1>

<form method="POST">
    <label>Select Student</label>
    <select name="student" id="student" required>
        <option value="">Select Student</option>
        <?php foreach($students as $s): ?>
            <option value="<?= $s['reg_no'] ?>" <?= (isset($reg_no) && $reg_no==$s['reg_no'])?'selected':'' ?>><?= $s['name'] ?> (<?= $s['reg_no'] ?>)</option>
        <?php endforeach; ?>
    </select>

    <label>Select Electives (Max 3)</label>
    <?php foreach($electives as $e): ?>
        <div>
            <input type="checkbox" name="electives[]" value="<?= $e['id'] ?>" 
            <?= in_array($e['id'],$pre_selected)?'checked':'' ?>>
            <?= $e['elective_name'] ?> (<?= $e['credit'] ?> Credits)
        </div>
    <?php endforeach; ?>

    <button type="submit">Save Electives</button>
</form>

<?php if($message): ?>
    <p class="<?= (strpos($message,'success')!==false)?'message':'error' ?>"><?= $message ?></p>
<?php endif; ?>

<?php if($selected_electives): ?>
    <div class="selected-list">
        <strong>Selected Electives:</strong>
        <ul>
        <?php
        $ids = implode(',', $selected_electives);
        $res = $conn->query("SELECT elective_name FROM electives WHERE id IN ($ids)");
        while($row = $res->fetch_assoc()){
            echo "<li>".$row['elective_name']."</li>";
        }
        ?>
        </ul>
    </div>
<?php endif; ?>

<script>
$(document).ready(function(){
    $('input[type="checkbox"]').change(function(){
        if($('input[type="checkbox"]:checked').length > 3){
            alert("You can select a maximum of 3 electives!");
            $(this).prop('checked', false);
        }
    });
});
</script>
</body>
</html>
