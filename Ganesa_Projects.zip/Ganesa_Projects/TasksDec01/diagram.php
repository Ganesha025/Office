/college_management_project
│
├─ config/
│   └─ db.php                  # Your DB setup & connection
│
├─ admin/
│   ├─ index.php               # Admin dashboard
│   ├─ hall_ticket.php         # Task 1 (generate hall ticket)
│   ├─ attendance.php          # Task 2 & Task 6 (eligibility & attendance pattern)
│   ├─ marksheet.php           # Task 3 & Task 8 (marks + result dashboard)
│   ├─ electives.php           # Task 4 (elective selection)
│   ├─ grade_appeal.php        # Task 5 (appeal requests)
│   ├─ seating.php             # Task 7 (seating arrangement)
│   └─ fee_slip.php            # Task 10 (fee slip generator)
│
├─ student/
│   ├─ login.php               # Student login
│   ├─ dashboard.php           # Student dashboard
│   ├─ hall_ticket.php         # View generated hall ticket
│   ├─ attendance.php          # Check eligibility / attendance
│   ├─ marksheet.php           # View marks & credits
│   ├─ electives.php           # Select electives
│   └─ fee_slip.php            # View fee slip
│
└─ assets/
    ├─ js/
    │   └─ main.js             # jQuery scripts (dynamic forms)
    └─ css/
        └─ style.css           # Styles, highlighting eligibility
