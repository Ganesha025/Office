<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Call JS from PHP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>

<?php
// This PHP code outputs JavaScript that calls the function
echo '<script type="text/javascript">',
     'window.onload = function() {',
     'spawnUniquePopup("Hello from PHP", "This popup is triggered by PHP.");',
     '};',
     '</script>';
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="sms.js"></script> <!-- Your external JS -->

</body>
</html>
