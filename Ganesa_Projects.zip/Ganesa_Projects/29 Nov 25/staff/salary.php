<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'staff'){
    header("Location: ../index.php");
    exit;
}

$staff_id = $_SESSION['staff_id'];
$salary = $conn->query("SELECT month, year, basic, hra, bonus, deductions FROM staff_salary WHERE staff_id=$staff_id ORDER BY year DESC, month DESC LIMIT 1")->fetch_assoc();
$staff = $conn->query("SELECT name, department FROM staff WHERE id=$staff_id")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
<title>Salary Slip</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4 p-4 bg-white shadow rounded">
<h3>Salary Slip</h3>
<p><b>Name:</b> <?= $staff['name'] ?></p>
<p><b>Department:</b> <?= $staff['department'] ?></p>
<p><b>Month:</b> <?= $salary['month'] ?> <?= $salary['year'] ?></p>
<table class="table table-bordered mt-3">
<tr><th>Earnings</th><th>Amount</th></tr>
<tr><td>Basic</td><td><?= $salary['basic'] ?></td></tr>
<tr><td>HRA</td><td><?= $salary['hra'] ?></td></tr>
<tr><td>Bonus</td><td><?= $salary['bonus'] ?></td></tr>
<tr><th>Deductions</th><th><?= $salary['deductions'] ?></th></tr>
<tr><th>Net Pay</th><th><?= ($salary['basic'] + $salary['hra'] + $salary['bonus']) - $salary['deductions'] ?></th></tr>
</table>
<a href="dashboard.php" class="btn btn-secondary">Back</a>
</div>
</body>
</html>
