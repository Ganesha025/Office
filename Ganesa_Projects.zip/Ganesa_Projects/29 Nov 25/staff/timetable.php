<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'staff'){
    header("Location: ../index.php");
    exit;
}

$staff_id = $_SESSION['staff_id'];
$res = $conn->query("SELECT day, time, subject, class FROM staff_timetable WHERE staff_id=$staff_id ORDER BY FIELD(day,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')");
?>
<!DOCTYPE html>
<html>
<head>
<title>Staff Timetable</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4 p-4 bg-white shadow rounded">
<h3>Your Timetable</h3>
<table class="table table-bordered mt-3">
<tr><th>Day</th><th>Time</th><th>Subject</th><th>Class</th></tr>
<?php while($r = $res->fetch_assoc()): ?>
<tr>
<td><?= htmlspecialchars($r['day']) ?></td>
<td><?= htmlspecialchars($r['time']) ?></td>
<td><?= htmlspecialchars($r['subject']) ?></td>
<td><?= htmlspecialchars($r['class']) ?></td>
</tr>
<?php endwhile; ?>
</table>
<a href="dashboard.php" class="btn btn-secondary">Back</a>
</div>
</body>
</html>
