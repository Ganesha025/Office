<?php
session_start();
require "../config/db.php";

// Check if user is logged in and is staff
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../index.php");
    exit;
}

$staff_id = $_SESSION['staff_id'];

// Prepare the SQL statement with error handling
$stmt = $conn->prepare("SELECT name, email, department FROM staff WHERE id = ?");
if (!$stmt) {
    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
}

// Bind the staff ID parameter and execute
$stmt->bind_param("i", $staff_id);
$stmt->execute();
$res = $stmt->get_result();

// Fetch the staff details if found
if ($res->num_rows === 1) {
    $staff = $res->fetch_assoc();
} else {
    $staff = [
        "name" => $_SESSION['username'],
        "email" => "Not Available",
        "department" => "Not Assigned"
    ];
}
$stmt->close();
?>
<!DOCTYPE html>
<html>
<head>
<title>Staff Dashboard</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4 p-4 bg-white shadow rounded">

<h2>Welcome, <?= htmlspecialchars($staff['name']) ?></h2>
<p>Email: <?= htmlspecialchars($staff['email']) ?></p>
<p>Department: <?= htmlspecialchars($staff['department']) ?></p>

<div class="row mt-4">
    <div class="col-md-3">
        <a href="attendance.php" class="btn btn-primary w-100">Attendance</a>
    </div>
    <div class="col-md-3">
        <a href="timetable.php" class="btn btn-primary w-100">Timetable</a>
    </div>
    <div class="col-md-3">
        <a href="salary.php" class="btn btn-primary w-100">Salary Slip</a>
    </div>
    <div class="col-md-3">
        <a href="../logout.php" class="btn btn-danger w-100">Logout</a>
    </div>
</div>

</div>
</body>
</html>
