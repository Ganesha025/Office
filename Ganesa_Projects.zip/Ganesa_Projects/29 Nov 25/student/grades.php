<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'student'){
    header("Location: ../index.php");
    exit;
}
require "../config/db.php";

$student_id = $_SESSION['student_id'];

$res = $conn->query("SELECT g.id, s.name AS subject, g.marks, g.grade
                     FROM grades g
                     JOIN subjects s ON g.subject_id = s.id
                     WHERE g.student_id=$student_id
                     ORDER BY s.name ASC");

$grades = [];
$total_marks = 0;
$num_subjects = 0;

if($res){
    while($row = $res->fetch_assoc()){
        $grades[] = $row;
        $total_marks += $row['marks'];
        $num_subjects++;
    }
}

$average = $num_subjects > 0 ? round($total_marks / $num_subjects, 2) : 0;

if($average > 90) $overall_grade = 'A';
elseif($average >= 80) $overall_grade = 'B';
elseif($average >= 70) $overall_grade = 'C';
elseif($average >= 60) $overall_grade = 'D';
else $overall_grade = 'F';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Grades</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<script src="https://cdn.tailwindcss.com"></script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
body { font-family: 'Inter', sans-serif; }
.material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
</style>
</head>
<body class="bg-slate-50 min-h-screen">
<?php include "../templates/header1.php"?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
<div class="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
<div class="bg-white rounded-lg shadow-sm border border-slate-200 p-5 sm:p-6 hover:shadow-md transition-shadow">
<div class="flex items-center justify-between mb-3">
<div class="bg-emerald-50 rounded-lg p-3">
<span class="material-symbols-outlined text-emerald-600 text-2xl">auto_stories</span>
</div>
<span class="text-3xl sm:text-4xl font-bold text-slate-800"><?= $num_subjects ?></span>
</div>
<h3 class="text-slate-600 text-sm font-medium">Total Subjects</h3>
</div>

<div class="bg-white rounded-lg shadow-sm border border-slate-200 p-5 sm:p-6 hover:shadow-md transition-shadow">
<div class="flex items-center justify-between mb-3">
<div class="bg-emerald-50 rounded-lg p-3">
<span class="material-symbols-outlined text-emerald-600 text-2xl">bar_chart</span>
</div>
<span class="text-3xl sm:text-4xl font-bold text-emerald-600"><?= $average ?></span>
</div>
<h3 class="text-slate-600 text-sm font-medium">Average Marks</h3>
<div class="mt-3 bg-slate-100 rounded-full h-2 overflow-hidden">
<div class="bg-emerald-600 h-full transition-all duration-500" style="width: <?= $average ?>%"></div>
</div>
</div>

<div class="bg-white rounded-lg shadow-sm border border-slate-200 p-5 sm:p-6 hover:shadow-md transition-shadow">
<div class="flex items-center justify-between mb-3">
<div class="bg-emerald-50 rounded-lg p-3">
<span class="material-symbols-outlined text-emerald-600 text-2xl">workspace_premium</span>
</div>
<span class="text-3xl sm:text-4xl font-bold text-slate-800"><?= $overall_grade ?></span>
</div>
<h3 class="text-slate-600 text-sm font-medium">Overall Grade</h3>
<p class="text-xs text-slate-500 mt-2">Based on average performance</p>
</div>
</div>

<div class="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
<div class="px-4 sm:px-6 py-4 border-b border-slate-200 bg-slate-50">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-emerald-600">assessment</span>
<h2 class="text-lg sm:text-xl font-semibold text-slate-800">Subject-wise Performance</h2>
</div>
</div>

<div class="overflow-x-auto">
<table class="w-full">
<thead class="bg-slate-50 border-b border-slate-200">
<tr>
<th class="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">#</th>
<th class="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Subject</th>
<th class="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Marks</th>
<th class="px-4 sm:px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Grade</th>
</tr>
</thead>
<tbody class="divide-y divide-slate-200">
<?php if(empty($grades)): ?>
<tr>
<td colspan="4" class="px-4 sm:px-6 py-8 text-center text-slate-500">
<span class="material-symbols-outlined text-5xl text-slate-300 mb-2">inbox</span>
<p class="text-sm">No grades available</p>
</td>
</tr>
<?php else: ?>
<?php $counter=1; foreach($grades as $g): ?>
<tr class="hover:bg-slate-50 transition-colors">
<td class="px-4 sm:px-6 py-4 text-sm text-slate-600 font-medium"><?= $counter++ ?></td>
<td class="px-4 sm:px-6 py-4 text-sm text-slate-800 font-medium">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-emerald-600 text-lg">book</span>
<?= htmlspecialchars($g['subject']) ?>
</div>
</td>
<td class="px-4 sm:px-6 py-4 text-sm">
<div class="flex items-center gap-3">
<span class="text-slate-800 font-semibold"><?= $g['marks'] ?></span>
<div class="flex-1 max-w-[100px] bg-slate-100 rounded-full h-1.5 overflow-hidden">
<div class="bg-emerald-600 h-full" style="width: <?= $g['marks'] ?>%"></div>
</div>
</div>
</td>
<td class="px-4 sm:px-6 py-4 text-sm">
<span class="inline-flex items-center justify-center w-10 h-10 rounded-lg font-bold <?= $g['grade'] === 'A' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : ($g['grade'] === 'B' ? 'bg-emerald-50 text-emerald-600 border border-emerald-200' : ($g['grade'] === 'C' ? 'bg-slate-100 text-slate-700 border border-slate-200' : 'bg-slate-100 text-slate-600 border border-slate-200')) ?>">
<?= $g['grade'] ?>
</span>
</td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

</div>

<?php include "../templates/footer1.php"?>
<script src="./valid.js"></script>
</body>
</html>