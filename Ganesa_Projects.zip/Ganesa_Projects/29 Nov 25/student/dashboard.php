<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'student'){
    header("Location: ../index.php");
    exit;
}
require "../config/db.php";

$student_id = $_SESSION['student_id'];
$student = $conn->query("SELECT * FROM students WHERE id=$student_id")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Dashboard</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<script src="https://cdn.tailwindcss.com"></script>
<style>
.material-symbols-outlined {
  font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
}
</style>
</head>
<body class="bg-slate-50">
<?php include "../templates/header1.php"?>

<div class="min-h-screen p-4 md:p-6 lg:p-8">
    <div class="max-w-7xl mx-auto">
        
        <div class="bg-white border border-slate-200 rounded-lg shadow-sm mb-6">
            <div class="border-b border-slate-200 bg-emerald-600 px-6 py-4">
                <h1 class="text-2xl font-semibold text-white">Student Dashboard</h1>
            </div>
            <div class="p-6">
                <div class="flex items-start space-x-4 mb-6">
                    <div class="bg-emerald-600 text-white rounded-lg w-16 h-16 flex items-center justify-center flex-shrink-0">
                        <span class="material-symbols-outlined text-3xl">person</span>
                    </div>
                    <div class="flex-1">
                        <h2 class="text-xl font-semibold text-slate-800 mb-1">Welcome, <?= htmlspecialchars($student['name']) ?></h2>
                        <p class="text-sm text-slate-600">Student Portal</p>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <div class="border border-slate-200 rounded-lg p-4 bg-emerald-50">
                        <div class="text-xs font-medium text-emerald-700 uppercase mb-1">Student ID</div>
                        <div class="text-base font-semibold text-slate-800"><?= htmlspecialchars($student['student_id']) ?></div>
                    </div>
                    <div class="border border-slate-200 rounded-lg p-4 bg-emerald-50">
                        <div class="text-xs font-medium text-emerald-700 uppercase mb-1">Class & Section</div>
                        <div class="text-base font-semibold text-slate-800"><?= htmlspecialchars($student['class'].'-'.$student['section']) ?></div>
                    </div>
                    <div class="border border-slate-200 rounded-lg p-4 bg-emerald-50">
                        <div class="text-xs font-medium text-emerald-700 uppercase mb-1">Email</div>
                        <div class="text-base font-semibold text-slate-800 truncate"><?= htmlspecialchars($student['email']) ?></div>
                    </div>
                    <div class="border border-slate-200 rounded-lg p-4 bg-emerald-50">
                        <div class="text-xs font-medium text-emerald-700 uppercase mb-1">Mobile</div>
                        <div class="text-base font-semibold text-slate-800"><?= htmlspecialchars($student['mobile']) ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-lg shadow-sm">
            <div class="border-b border-slate-200 bg-slate-700 px-6 py-4">
                <h3 class="text-lg font-semibold text-white">Quick Access</h3>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                    
                    <a href="profile.php" class="group border border-slate-200 rounded-lg p-5 hover:border-emerald-500 hover:bg-emerald-50 transition-all duration-200 flex flex-col items-center text-center">
                        <span class="material-symbols-outlined text-4xl text-slate-600 group-hover:text-emerald-600 mb-3">account_circle</span>
                        <span class="text-sm font-medium text-slate-700 group-hover:text-emerald-700">Profile</span>
                    </a>
                    
                    <a href="attendance.php" class="group border border-slate-200 rounded-lg p-5 hover:border-emerald-500 hover:bg-emerald-50 transition-all duration-200 flex flex-col items-center text-center">
                        <span class="material-symbols-outlined text-4xl text-slate-600 group-hover:text-emerald-600 mb-3">calendar_today</span>
                        <span class="text-sm font-medium text-slate-700 group-hover:text-emerald-700">Attendance</span>
                    </a>
                    
                    <a href="grades.php" class="group border border-slate-200 rounded-lg p-5 hover:border-emerald-500 hover:bg-emerald-50 transition-all duration-200 flex flex-col items-center text-center">
                        <span class="material-symbols-outlined text-4xl text-slate-600 group-hover:text-emerald-600 mb-3">grade</span>
                        <span class="text-sm font-medium text-slate-700 group-hover:text-emerald-700">Grades</span>
                    </a>
                    
                    <a href="timetable.php" class="group border border-slate-200 rounded-lg p-5 hover:border-emerald-500 hover:bg-emerald-50 transition-all duration-200 flex flex-col items-center text-center">
                        <span class="material-symbols-outlined text-4xl text-slate-600 group-hover:text-emerald-600 mb-3">schedule</span>
                        <span class="text-sm font-medium text-slate-700 group-hover:text-emerald-700">Timetable</span>
                    </a>
                    
                    <a href="feedback.php" class="group border border-slate-200 rounded-lg p-5 hover:border-emerald-500 hover:bg-emerald-50 transition-all duration-200 flex flex-col items-center text-center">
                        <span class="material-symbols-outlined text-4xl text-slate-600 group-hover:text-emerald-600 mb-3">feedback</span>
                        <span class="text-sm font-medium text-slate-700 group-hover:text-emerald-700">Feedback</span>
                    </a>
                    <a href="holiday.php" class="group border border-slate-200 rounded-lg p-5 hover:border-emerald-500 hover:bg-emerald-50 transition-all duration-200 flex flex-col items-center text-center">
    <span class="material-symbols-outlined text-4xl text-slate-600 group-hover:text-emerald-600 mb-3">event</span>
    <span class="text-sm font-medium text-slate-700 group-hover:text-emerald-700">School Holidays</span>
</a>
                    <a href="fine.php" class="group border border-slate-200 rounded-lg p-5 hover:border-emerald-500 hover:bg-emerald-50 transition-all duration-200 flex flex-col items-center text-center">
                        <span class="material-symbols-outlined text-4xl text-slate-600 group-hover:text-emerald-600 mb-3">local_library</span>
                        <span class="text-sm font-medium text-slate-700 group-hover:text-emerald-700">Library Fines</span>
                    </a>
                </div>
            </div>
        </div>

    </div>
</div>

<?php include "../templates/footer1.php"?>
<script src="./valid.js"></script>
</body>
</html>