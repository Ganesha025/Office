<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'student'){
    header("Location: ../index.php");
    exit;
}
require "../config/db.php";

$student_id = $_SESSION['student_id'];

$res = $conn->query("SELECT ib.id, lb.title, ib.due_day, ib.return_day, ib.fine
                     FROM issued_books ib
                     JOIN library_books lb ON ib.book_id = lb.id
                     WHERE ib.student_id=$student_id
                     ORDER BY ib.id DESC");

$issued_books = [];
if($res){
    while($row = $res->fetch_assoc()){
        $row['calculated_fine'] = 0;
        if($row['return_day'] > $row['due_day']){
            $row['calculated_fine'] = ($row['return_day'] - $row['due_day']) * 2;
        }
        $issued_books[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library Fines</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<style>
.material-symbols-outlined {
  font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
}
body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}
</style>
</head>
<body class="bg-slate-50">
<?php include "../templates/header1.php"?>

<div class="min-h-screen px-4 py-8 sm:px-6 lg:px-8">
  <div class="max-w-7xl mx-auto">
    
    <div class="mb-8">
      <div class="flex items-center gap-3 mb-2">
        <span class="material-symbols-outlined text-emerald-600 text-3xl">account_balance</span>
        <h1 class="text-2xl sm:text-3xl font-bold text-slate-800">Library Fines</h1>
      </div>
      <p class="text-slate-600 text-sm sm:text-base ml-0 sm:ml-11">View and manage your library fine records</p>
    </div>

    <div class="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
      
      <div class="overflow-x-auto">
        <table class="w-full">
          <thead>
            <tr class="bg-slate-50 border-b border-slate-200">
              <th class="px-4 sm:px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">#</th>
              <th class="px-4 sm:px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Book Title</th>
              <th class="px-4 sm:px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider whitespace-nowrap">Due Day</th>
              <th class="px-4 sm:px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider whitespace-nowrap">Return Day</th>
              <th class="px-4 sm:px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider whitespace-nowrap">Fine (₹2/day)</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-200">
            <?php if(empty($issued_books)): ?>
              <tr>
                <td colspan="5" class="px-4 sm:px-6 py-12 text-center">
                  <span class="material-symbols-outlined text-slate-300 text-5xl mb-3 block">receipt_long</span>
                  <p class="text-slate-500 text-sm">No fine records found</p>
                </td>
              </tr>
            <?php else: ?>
              <?php $counter=1; foreach($issued_books as $book): ?>
                <tr class="hover:bg-emerald-50 transition-colors duration-150">
                  <td class="px-4 sm:px-6 py-4 text-sm font-medium text-slate-800"><?= $counter++ ?></td>
                  <td class="px-4 sm:px-6 py-4 text-sm text-slate-800 font-medium"><?= htmlspecialchars($book['title']) ?></td>
                  <td class="px-4 sm:px-6 py-4 text-sm text-slate-600"><?= $book['due_day'] ?></td>
                  <td class="px-4 sm:px-6 py-4 text-sm text-slate-600"><?= $book['return_day'] ?></td>
                  <td class="px-4 sm:px-6 py-4 text-sm">
                    <?php if($book['calculated_fine'] > 0): ?>
                      <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-700">
                        ₹<?= $book['calculated_fine'] ?>
                      </span>
                    <?php else: ?>
                      <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700">
                        ₹0
                      </span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      
    </div>

    <?php if(!empty($issued_books)): ?>
      <div class="mt-6 bg-emerald-50 border border-emerald-200 rounded-lg p-4 flex items-start gap-3">
        <span class="material-symbols-outlined text-emerald-600 text-xl flex-shrink-0 mt-0.5">info</span>
        <div>
          <p class="text-sm text-emerald-800 font-medium">Fine Calculation</p>
          <p class="text-xs text-emerald-700 mt-1">Fines are calculated at ₹2 per day for late returns beyond the due date.</p>
        </div>
      </div>
    <?php endif; ?>

  </div>
</div>

<?php include "../templates/footer1.php"?>
<script src="./valid.js"></script>
</body>
</html>