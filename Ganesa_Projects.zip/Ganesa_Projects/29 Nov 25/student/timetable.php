<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'student'){
    header("Location: ../index.php");
    exit;
}
require "../config/db.php";

$student_id = $_SESSION['student_id'];
$student = $conn->query("SELECT class, section FROM students WHERE id=$student_id")->fetch_assoc();

$class = $student['class'];
$section = $student['section'];

$res = $conn->query("SELECT day, period, subject FROM timetable WHERE class=$class AND section='$section' ORDER BY FIELD(day,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'), period ASC");

$timetable = [];
if($res){
    while($row = $res->fetch_assoc()){
        $timetable[$row['day']][] = $row;
    }
}

$days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Timetable</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<style>
.material-symbols-outlined {
  font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
}
</style>
</head>
<body class="bg-slate-50 min-h-screen">

<?php include "../templates/header1.php"?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">

<div class="mb-6">
<div class="flex items-center gap-3 mb-2">
<span class="material-symbols-outlined text-emerald-600 text-3xl">schedule</span>
<h1 class="text-2xl sm:text-3xl font-bold text-slate-800">Class Timetable</h1>
</div>
<div class="flex items-center gap-2 text-slate-600">
<span class="material-symbols-outlined text-lg">school</span>
<p class="text-sm sm:text-base">Class <?= $class ?> - Section <?= $section ?></p>
</div>
</div>

<div class="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
<div class="overflow-x-auto">
<table class="w-full min-w-max">
<thead>
<tr class="bg-emerald-600 text-white">
<th class="px-4 py-4 text-left text-sm font-semibold whitespace-nowrap sticky left-0 bg-emerald-600 z-10">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-lg">calendar_today</span>
<span>Day</span>
</div>
</th>
<th class="px-4 py-4 text-center text-sm font-semibold whitespace-nowrap">Period 1</th>
<th class="px-4 py-4 text-center text-sm font-semibold whitespace-nowrap">Period 2</th>
<th class="px-4 py-4 text-center text-sm font-semibold whitespace-nowrap">Period 3</th>
<th class="px-4 py-4 text-center text-sm font-semibold whitespace-nowrap">Period 4</th>
<th class="px-4 py-4 text-center text-sm font-semibold whitespace-nowrap">Period 5</th>
<th class="px-4 py-4 text-center text-sm font-semibold whitespace-nowrap">Period 6</th>
</tr>
</thead>
<tbody class="divide-y divide-slate-200">
<?php foreach($days as $day): ?>
<tr class="hover:bg-emerald-50 transition-colors">
<td class="px-4 py-4 font-semibold text-slate-800 text-sm whitespace-nowrap sticky left-0 bg-white z-10 border-r border-slate-200">
<?= $day ?>
</td>
<?php
$periods = $timetable[$day] ?? [];
$period_map = [];
foreach($periods as $p){
$period_map[$p['period']] = $p['subject'];
}
for($i=1; $i<=6; $i++){
$subject = $period_map[$i] ?? '-';
$isEmpty = $subject === '-';
echo '<td class="px-4 py-4 text-center text-sm text-slate-700 whitespace-nowrap">';
if(!$isEmpty){
echo '<div class="inline-flex items-center gap-2 px-3 py-2 bg-emerald-50 rounded-md border border-emerald-200">';
echo '<span class="material-symbols-outlined text-emerald-600 text-lg">book</span>';
echo '<span class="font-medium">'.$subject.'</span>';
echo '</div>';
} else {
echo '<span class="text-slate-400 font-medium">'.$subject.'</span>';
}
echo '</td>';
}
?>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</div>

</div>

<?php include "../templates/footer1.php"?>
<script src="./valid.js"></script>
</body>
</html>