<?php
session_start();
require "config/db.php";

$error = "";

// Handle login
if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role     = $_POST['role'] ?? '';

    /* ------------------------ ADMIN LOGIN ------------------------ */
    if ($role === 'admin') {

        if ($username === "ModernAdmin@gmail.com" && $password === "S@vage#123") {
            $_SESSION['role'] = 'admin';
            $_SESSION['username'] = $username;
            header("Location: admin/dashboard.php");
            exit;
        } else {
            $error = "Invalid Admin credentials!";
        }

    /* ----------------------- STUDENT LOGIN ----------------------- */
    } elseif ($role === 'student') {

        $stmt = $conn->prepare("SELECT id, name, email, email_password FROM students WHERE email = ? OR name = ?");
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();

            if (password_verify($password, $row['email_password'])) {
                $_SESSION['role'] = 'student';
                $_SESSION['student_id'] = $row['id'];
                $_SESSION['username'] = $row['name'];
                header("Location: student/dashboard.php");
                exit;
            } else {
                $error = "Invalid password!";
            }
        } else {
            $error = "Student not found!";
        }
        $stmt->close();

    /* ------------------------- STAFF LOGIN ------------------------ */
    } elseif ($role === 'staff') {

        $stmt = $conn->prepare("SELECT id, name, email FROM staff WHERE email = ? OR name = ?");
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {

            // Static staff password
            if ($password === "Modern@123") {
                $row = $result->fetch_assoc();

                $_SESSION['role'] = 'staff';
                $_SESSION['staff_id'] = $row['id'];
                $_SESSION['username'] = $row['name'];

                header("Location: staff/dashboard.php");
                exit;

            } else {
                $error = "Invalid Staff password!";
            }

        } else {
            $error = "Staff not found!";
        }
        $stmt->close();

    } else {
        $error = "Please select a valid role!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School ERP Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        * {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="min-h-screen flex flex-col lg:flex-row">
        <div class="hidden lg:flex lg:w-1/2 bg-slate-900 items-center justify-center p-12">
            <div class="max-w-md text-white">
                <div class="flex items-center gap-3 mb-8">
                    <span class="material-symbols-outlined text-5xl">school</span>
                    <h1 class="text-4xl font-bold">Modern School </h1>
                </div>
                <p class="text-slate-300 text-lg leading-relaxed mb-6">Enterprise Resource Planning system designed for modern educational institutions. Manage students, staff, academics, and operations efficiently.</p>
                <div class="space-y-4">
                    <div class="flex items-start gap-3">
                        <span class="material-symbols-outlined text-emerald-400">check_circle</span>
                        <p class="text-slate-300">Comprehensive student management</p>
                    </div>
                    <div class="flex items-start gap-3">
                        <span class="material-symbols-outlined text-emerald-400">check_circle</span>
                        <p class="text-slate-300">Real-time attendance tracking</p>
                    </div>
                    <div class="flex items-start gap-3">
                        <span class="material-symbols-outlined text-emerald-400">check_circle</span>
                        <p class="text-slate-300">Secure role-based access control</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="flex-1 flex items-center justify-center p-6 lg:p-12">
            <div class="w-full max-w-md">
                <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
                    <div class="mb-8" id="loginTitle">
                        <div class="flex items-center gap-2 mb-2 lg:hidden">
                            <span class="material-symbols-outlined text-3xl text-slate-900">school</span>
                            <h2 class="text-2xl font-bold text-slate-900">Modern School ERP</h2>
                        </div>
                        <h2 class="text-2xl font-bold text-slate-900 mb-2 hidden lg:block">Welcome Back</h2>
                        <p class="text-gray-600">Sign in to access your account</p>
                    </div>

                    <div class="mb-8 hidden" id="resetTitle">
                        <div class="flex items-center gap-2 mb-2 lg:hidden">
                            <span class="material-symbols-outlined text-3xl text-slate-900">school</span>
                            <h2 class="text-2xl font-bold text-slate-900">Modern School ERP</h2>
                        </div>
                        <h2 class="text-2xl font-bold text-slate-900 mb-2 hidden lg:block">Reset Password</h2>
                        <p class="text-gray-600">Enter your details to reset your password</p>
                    </div>

                    <?php if($error): ?>
                    <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                        <span class="material-symbols-outlined text-red-600 text-xl">error</span>
                        <p class="text-red-700 text-sm flex-1"><?php echo $error; ?></p>
                    </div>
                    <?php endif; ?>

                    <form method="POST" class="space-y-5" id="loginForm">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Role</label>
                            <div class="relative">
                                <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xl">badge</span>
                                <select name="role" required class="w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent outline-none transition appearance-none bg-white">
                                    <option value="">Select Role</option>
                                    <option value="admin">Admin</option>
                                    <!-- <option value="staff">Staff/Teacher</option> -->
                                    <option value="student">Student</option>
                                </select>
                                <span class="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-xl pointer-events-none">expand_more</span>
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Username</label>
                            <div class="relative">
                                <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xl">person</span>
                                <input type="text" name="username" placeholder="Enter your username" id="FocusInput" required class="val-email w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent outline-none transition">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                            <div class="relative">
                                <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xl">lock</span>
                                <input type="password" id="password" name="password" placeholder="Enter your password" required class="val-password w-full pl-11 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent outline-none transition">
                                <button type="button" onclick="togglePassword()" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition">
                                    <span class="material-symbols-outlined text-xl" id="toggleIcon">visibility</span>
                                </button>
                            </div>
                        </div>

                        <div class="flex items-center justify-between text-sm">
                            <label class="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" class="w-4 h-4 border-gray-300 rounded text-slate-900 focus:ring-2 focus:ring-slate-900">
                                <span class="text-gray-600">Remember me</span>
                            </label>
                            <button type="button" onclick="toggleResetPassword()" class="text-slate-900 hover:text-slate-700 font-medium transition">Reset Password</button>
                        </div>

                        <button type="submit" name="login" class="w-full bg-slate-900 text-white py-3 rounded-lg font-medium hover:bg-slate-800 transition flex items-center justify-center gap-2">
                            <span>Sign In</span>
                            <span class="material-symbols-outlined text-xl">arrow_forward</span>
                        </button>
                    </form>

                    <form method="POST" class="space-y-5 hidden" id="resetForm">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Username</label>
                            <div class="relative">
                                <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xl">person</span>
                                <input type="text" name="reset_username" placeholder="Enter your username" required class="w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent outline-none transition">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">New Password</label>
                            <div class="relative">
                                <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xl">lock</span>
                                <input type="password" id="newPassword" name="new_password" placeholder="Enter new password" required class="w-full pl-11 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent outline-none transition">
                                <button type="button" onclick="toggleNewPassword()" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition">
                                    <span class="material-symbols-outlined text-xl" id="toggleNewIcon">visibility</span>
                                </button>
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Confirm Password</label>
                            <div class="relative">
                                <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xl">lock</span>
                                <input type="password" id="confirmPassword" name="confirm_password" placeholder="Confirm new password" required class="w-full pl-11 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent outline-none transition">
                                <button type="button" onclick="toggleConfirmPassword()" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition">
                                    <span class="material-symbols-outlined text-xl" id="toggleConfirmIcon">visibility</span>
                                </button>
                            </div>
                        </div>

                        <button type="submit" name="reset" class="w-full bg-slate-900 text-white py-3 rounded-lg font-medium hover:bg-slate-800 transition flex items-center justify-center gap-2">
                            <span>Reset Password</span>
                            <span class="material-symbols-outlined text-xl">lock_reset</span>
                        </button>

                        <button type="button" onclick="toggleResetPassword()" class="w-full border border-gray-300 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-50 transition flex items-center justify-center gap-2">
                            <span class="material-symbols-outlined text-xl">arrow_back</span>
                            <span>Back to Login</span>
                        </button>
                    </form>

                    <div class="mt-6 pt-6 border-t border-gray-200 text-center text-sm text-gray-600" id="supportSection">
                        <p>Need help? <a href="mailto:support@schoolerp.com" class="text-slate-900 hover:text-slate-700 font-medium transition">Contact Support</a></p>
                    </div>
                </div>

                <p class="text-center text-sm text-gray-500 mt-6">© 2025 Modern School ERP. All rights reserved.</p>
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.getElementById('toggleIcon');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.textContent = 'visibility_off';
            } else {
                passwordInput.type = 'password';
                toggleIcon.textContent = 'visibility';
            }
        }

        function toggleNewPassword() {
            const passwordInput = document.getElementById('newPassword');
            const toggleIcon = document.getElementById('toggleNewIcon');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.textContent = 'visibility_off';
            } else {
                passwordInput.type = 'password';
                toggleIcon.textContent = 'visibility';
            }
        }

        function toggleConfirmPassword() {
            const passwordInput = document.getElementById('confirmPassword');
            const toggleIcon = document.getElementById('toggleConfirmIcon');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.textContent = 'visibility_off';
            } else {
                passwordInput.type = 'password';
                toggleIcon.textContent = 'visibility';
            }
        }

        function toggleResetPassword() {
            const loginForm = document.getElementById('loginForm');
            const resetForm = document.getElementById('resetForm');
            const loginTitle = document.getElementById('loginTitle');
            const resetTitle = document.getElementById('resetTitle');
            const supportSection = document.getElementById('supportSection');
            
            loginForm.classList.toggle('hidden');
            resetForm.classList.toggle('hidden');
            loginTitle.classList.toggle('hidden');
            resetTitle.classList.toggle('hidden');
            
            if (resetForm.classList.contains('hidden')) {
                supportSection.innerHTML = '<p>Need help? <a href="mailto:support@schoolerp.com" class="text-slate-900 hover:text-slate-700 font-medium transition">Contact Support</a></p>';
            } else {
                supportSection.innerHTML = '';
            }
        }
    </script>
    <script>
        $(document).ready(function(){
            $("#FocusInput").focus();
        })
    </script>
    <script src="./sms.js"></script>
</body>
</html>