<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}

$message = "";

if(isset($_POST['assign_password'])){
    $student_id = $_POST['student_id'];
    $password = trim($_POST['password']);

    if($student_id && $password){
        $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE students SET email_password = ? WHERE id = ?");
        if(!$stmt) die("Prepare failed: ".$conn->error);
        $stmt->bind_param("si", $hashed_pass, $student_id);
        if($stmt->execute()){
            $message = "Password assigned successfully!";
        } else {
            $message = "Error: ".$conn->error;
        }
        $stmt->close();
    } else {
        $message = "Please select a student and enter a password.";
    }
}

$students = [];
$res = $conn->query("SELECT id, name, email, email_password FROM students WHERE email IS NOT NULL ORDER BY name ASC");
if($res){
    while($row = $res->fetch_assoc()){
        $students[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Assign Student Email Password</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
body {
    font-family: 'Inter', sans-serif;
    background: #f5f7fa;
}*{
    user-select:text;
}
</style>
</head>
<body>
<?php include "../templates/header.php"?>

<div class="min-h-screen" style="padding-top: 2rem; padding-bottom: 2rem;">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="mb-6">
            <div class="flex items-center gap-3 mb-2">
                <span class="material-icons text-3xl" style="color: #2563eb;">lock_person</span>
                <h1 class="text-2xl font-semibold" style="color: #1e293b;">Student Email Password Management</h1>
            </div>
            <p class="text-sm" style="color: #64748b;">Assign and manage email credentials for students</p>
        </div>

        <?php if($message): ?>
        <div class="mb-6 p-4 rounded-lg border-l-4" style="background: #eff6ff; border-color: #2563eb;">
            <div class="flex items-center gap-3">
                <span class="material-icons" style="color: #2563eb;">info</span>
                <span style="color: #1e40af;"><?= htmlspecialchars($message) ?></span>
            </div>
        </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <div class="lg:col-span-1">
                <div class="bg-white rounded-lg border" style="border-color: #e2e8f0;">
                    <div class="p-6 border-b" style="border-color: #e2e8f0;">
                        <div class="flex items-center gap-2 mb-1">
                            <span class="material-icons text-xl" style="color: #2563eb;">person_add</span>
                            <h2 class="text-lg font-semibold" style="color: #1e293b;">Assign Password</h2>
                        </div>
                        <p class="text-xs mt-1" style="color: #64748b;">Set email credentials for student</p>
                    </div>
                    
                    <form method="POST" class="p-6">
                        <div class="mb-4">
                            <label for="student_id" class="block text-sm font-medium mb-2" style="color: #475569;">
                                <span class="flex items-center gap-2">
                                    <span class="material-icons text-sm">person</span>
                                    Student
                                </span>
                            </label>
                            <select name="student_id" id="student_id" class="w-full px-3 py-2.5 border rounded-lg focus:outline-none focus:ring-2 text-sm" style="border-color: #cbd5e1; color: #334155;" required>
                                <option value="">Select student...</option>
                                <?php foreach($students as $stu): ?>
                                    <?php if(empty($stu['email_password'])): ?>
                                    <option value="<?= $stu['id'] ?>"><?= htmlspecialchars($stu['name'].' - '.$stu['email']) ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-6">
                            <label for="password" class="block text-sm font-medium mb-2" style="color: #475569;">
                                <span class="flex items-center gap-2">
                                    <span class="material-icons text-sm">vpn_key</span>
                                    Password
                                </span>
                            </label>
                            <input type="text" name="password" id="password" class="val-password w-full px-3 py-2.5 border rounded-lg focus:outline-none focus:ring-2 text-sm" style="border-color: #cbd5e1; color: #334155;" required>
                        </div>

                        <button type="submit" name="assign_password" class="w-full py-2.5 rounded-lg font-medium text-sm flex items-center justify-center gap-2 hover:opacity-90 transition" style="background: #2563eb; color: white;">
                            <span class="material-icons text-lg">save</span>
                            Assign Password
                        </button>
                    </form>
                </div>

                <div class="mt-6 p-4 rounded-lg border" style="background: #fefce8; border-color: #fde047;">
                    <div class="flex gap-3">
                        <span class="material-icons text-xl" style="color: #ca8a04;">info</span>
                        <div>
                            <h3 class="text-sm font-medium mb-1" style="color: #854d0e;">Important</h3>
                            <p class="text-xs" style="color: #a16207;">Only students without assigned passwords are shown in the dropdown. Ensure password security guidelines are followed.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="lg:col-span-2">
                <div class="bg-white rounded-lg border" style="border-color: #e2e8f0;">
                    <div class="p-6 border-b" style="border-color: #e2e8f0;">
                        <div class="flex items-center justify-between flex-wrap gap-4">
                            <div>
                                <div class="flex items-center gap-2 mb-1">
                                    <span class="material-icons text-xl" style="color: #2563eb;">group</span>
                                    <h2 class="text-lg font-semibold" style="color: #1e293b;">Student Directory</h2>
                                </div>
                                <p class="text-xs" style="color: #64748b;">Overview of all students with email accounts</p>
                            </div>
                            <div class="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium" style="background: #eff6ff; color: #1e40af;">
                                <span class="material-icons text-sm">badge</span>
                                <?= count($students) ?> Total
                            </div>
                        </div>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead>
                                <tr style="background: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                                    <th class="px-6 py-3 text-left text-xs font-semibold" style="color: #475569;">#</th>
                                    <th class="px-6 py-3 text-left text-xs font-semibold" style="color: #475569;">
                                        <div class="flex items-center gap-1">
                                            <span class="material-icons text-sm">person</span>
                                            Name
                                        </div>
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-semibold" style="color: #475569;">
                                        <div class="flex items-center gap-1">
                                            <span class="material-icons text-sm">email</span>
                                            Email
                                        </div>
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-semibold" style="color: #475569;">
                                        <div class="flex items-center gap-1">
                                            <span class="material-icons text-sm">security</span>
                                            Status
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $counter=1; foreach($students as $stu): ?>
                                <tr class="border-b hover:bg-gray-50 transition" style="border-color: #e2e8f0;">
                                    <td class="px-6 py-4 text-sm" style="color: #64748b;"><?= $counter++ ?></td>
                                    <td class="px-6 py-4 text-sm font-medium" style="color: #334155;"><?= htmlspecialchars($stu['name']) ?></td>
                                    <td class="px-6 py-4 text-sm" style="color: #64748b;"><?= htmlspecialchars($stu['email']) ?></td>
                                    <td class="px-6 py-4">
                                        <?php if(empty($stu['email_password'])): ?>
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium" style="background: #fee2e2; color: #991b1b;">
                                            <span class="material-icons" style="font-size: 14px;">cancel</span>
                                            Not Assigned
                                        </span>
                                        <?php else: ?>
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium" style="background: #dcfce7; color: #166534;">
                                            <span class="material-icons" style="font-size: 14px;">check_circle</span>
                                            Assigned
                                        </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php include "../templates/footer.php"?>
<script src="./valid.js"></script>
</body>
</html>