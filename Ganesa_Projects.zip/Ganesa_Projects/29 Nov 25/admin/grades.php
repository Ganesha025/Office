<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}

require "../config/db.php";

function calculateGrade($marks){
    if($marks > 90) return 'A';
    elseif($marks >= 80) return 'B';
    elseif($marks >= 70) return 'C';
    elseif($marks >= 60) return 'D';
    else return 'F';
}

$classes = [];
$result = $conn->query("SELECT DISTINCT class FROM students ORDER BY class ASC");
while($row = $result->fetch_assoc()){
    $classes[] = $row['class'];
}

$sections = ['A','B','C','D'];

$subjects = [];
$res = $conn->query("SELECT * FROM subjects ORDER BY id ASC");
while($row = $res->fetch_assoc()){
    $subjects[] = $row;
}

if(isset($_POST['submit_marks'])){
    $marks_data = $_POST['marks'];
    foreach($marks_data as $student_id => $subject_marks){
        foreach($subject_marks as $subject_id => $mark){
            $mark = intval($mark);
            $grade = calculateGrade($mark);
            $stmt = $conn->prepare("SELECT id FROM grades WHERE student_id=? AND subject_id=?");
            $stmt->bind_param("ii", $student_id, $subject_id);
            $stmt->execute();
            $stmt->store_result();
            if($stmt->num_rows > 0){
                $update = $conn->prepare("UPDATE grades SET marks=?, grade=? WHERE student_id=? AND subject_id=?");
                $update->bind_param("isii", $mark, $grade, $student_id, $subject_id);
                $update->execute();
            } else {
                $insert = $conn->prepare("INSERT INTO grades (student_id, subject_id, marks, grade) VALUES (?, ?, ?, ?)");
                $insert->bind_param("iiis", $student_id, $subject_id, $mark, $grade);
                $insert->execute();
            }
        }
    }
    echo "<script>alert('Grades saved successfully'); window.location.href='grades.php';</script>";
}

$students = [];
$selected_class = $_POST['class'] ?? '';
$selected_section = $_POST['section'] ?? '';

if($selected_class && $selected_section){
    $stmt = $conn->prepare("SELECT * FROM students WHERE class=? AND section=? ORDER BY roll_no ASC");
    $stmt->bind_param("is", $selected_class, $selected_section);
    $stmt->execute();
    $students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grades Management - Admin Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    
<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
        * { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; }
        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        input[type="number"] { -moz-appearance: textfield; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <?php include"../templates/header.php"?>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
            <div class="flex items-center space-x-2 mb-6">
                <span class="material-symbols-outlined text-gray-700">filter_alt</span>
                <h2 class="text-lg font-semibold text-gray-900">Filter Students</h2>
            </div>
            
            <form method="POST" class="space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Class</label>
                        <div class="relative">
                            <span class="material-symbols-outlined absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-xl">class</span>
                            <select name="class" required class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900">
                                <option value="">Select Class</option>
                                <?php foreach($classes as $c): ?>
                                <option value="<?php echo $c; ?>" <?php if($selected_class==$c) echo 'selected'; ?>>Class <?php echo $c; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Section</label>
                        <div class="relative">
                            <span class="material-symbols-outlined absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-xl">group</span>
                            <select name="section" required class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900">
                                <option value="">Select Section</option>
                                <?php foreach($sections as $s): ?>
                                <option value="<?php echo $s; ?>" <?php if($selected_section==$s) echo 'selected'; ?>>Section <?php echo $s; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end">
                    <button type="submit" name="filter_students" class="flex items-center space-x-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors duration-200 shadow-sm">
                        <span class="material-symbols-outlined text-xl">search</span>
                        <span>Show Students</span>
                    </button>
                </div>
            </form>
        </div>

        <?php if($students): ?>
        <div class="bg-white rounded-lg shadow-sm border border-gray-200">
            <div class="px-6 py-4 border-b border-gray-200">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-2">
                        <span class="material-symbols-outlined text-gray-700">grading</span>
                        <h2 class="text-lg font-semibold text-gray-900">Grade Entry</h2>
                        <span class="px-3 py-1 bg-blue-50 text-blue-700 text-sm font-medium rounded-full">Class <?php echo $selected_class; ?> - Section <?php echo $selected_section; ?></span>
                    </div>
                    <div class="text-sm text-gray-500">
                        <span class="font-medium text-gray-700"><?php echo count($students); ?></span> Students
                    </div>
                </div>
            </div>

            <form method="POST">
                <input type="hidden" name="class" value="<?php echo $selected_class; ?>">
                <input type="hidden" name="section" value="<?php echo $selected_section; ?>">
                
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 border-b border-gray-200">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider sticky left-0 bg-gray-50 z-10">Roll No</th>
                                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider min-w-[200px]">Student Name</th>
                                <?php foreach($subjects as $sub): ?>
                                <th class="px-6 py-3 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider min-w-[120px]">
                                    <div class="flex items-center justify-center space-x-1">
                                        <span class="material-symbols-outlined text-sm">book</span>
                                        <span><?php echo htmlspecialchars($sub['name']); ?></span>
                                    </div>
                                </th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach($students as $stu): 
                                $grade_row = [];
                                $res = $conn->prepare("SELECT subject_id, marks FROM grades WHERE student_id=?");
                                $res->bind_param("i", $stu['id']);
                                $res->execute();
                                $result = $res->get_result();
                                while($r = $result->fetch_assoc()){
                                    $grade_row[$r['subject_id']] = $r['marks'];
                                }
                            ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 sticky left-0 bg-white">
                                    <div class="flex items-center justify-center w-10 h-10 bg-blue-100 text-blue-700 rounded-lg font-semibold">
                                        <?php echo $stu['roll_no']; ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium"><?php echo htmlspecialchars($stu['name']); ?></td>
                                <?php foreach($subjects as $sub): ?>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <input type="number" name="marks[<?php echo $stu['id']; ?>][<?php echo $sub['id']; ?>]" value="<?php echo $grade_row[$sub['id']] ?? 0; ?>" min="0" max="100" required class="val-mark w-full px-3 py-2 text-center border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm font-medium text-gray-900">
                                </td>
                                <?php endforeach; ?>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
                    <div class="flex items-center space-x-2 text-sm text-gray-600">
                        <span class="material-symbols-outlined text-lg">info</span>
                        <span>Enter marks (0-100) for each subject</span>
                    </div>
                    <button type="submit" name="submit_marks" class="flex items-center space-x-2 px-6 py-2.5 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-colors duration-200 shadow-sm">
                        <span class="material-symbols-outlined text-xl">save</span>
                        <span>Save Grades</span>
                    </button>
                </div>
            </form>
        </div>
        <?php endif; ?>

    </div>

<?php include "../templates/footer.php"?>
<script src='./valid.js'></script>
</body>
</html>