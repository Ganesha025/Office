<?php
function x7q9zModal($u9kId, $v2mTitle, $w4pContent, $r8tAuto=false) {
    echo <<<MODAL
<style>
#{$u9kId}.x7q9zModal {
  display: none;
  position: fixed;
  z-index: 9999;
  left: 0; top: 0;
  width: 100%; height: 100%;
  overflow: auto;
  background-color: rgba(0,0,0,0.5);
  font-family: Arial, sans-serif;
}

#{$u9kId} .y3n5bContent {
  background-color: #fff;
  margin: 10% auto;
  padding: 20px;
  border-radius: 8px;
  width: 90%;
  max-width: 500px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.3);
  position: relative;
  box-sizing: border-box;
}

#{$u9kId} .z1h6eHeader {
  font-size: 1.25em;
  font-weight: bold;
  margin-bottom: 10px;
}

#{$u9kId} .a4c8vClose {
  position: absolute;
  top: 10px; right: 15px;
  font-size: 1.5em;
  font-weight: normal;
  color: #999;
  cursor: pointer;
  transition: color 0.2s ease;
}

#{$u9kId} .a4c8vClose:hover {
  color: #333;
}
</style>

<div id="{$u9kId}" class="x7q9zModal">
  <div class="y3n5bContent">
    <span class="a4c8vClose" onclick="document.getElementById('{$u9kId}').style.display='none'">&times;</span>
    <div class="z1h6eHeader">{$v2mTitle}</div>
    <div class="b9d3fBody">{$w4pContent}</div>
  </div>
</div>

<script>
function m6k2xOpen(n8vId) {
    document.getElementById(n8vId).style.display = 'block';
}

window.onclick = function(event) {
    if (event.target.classList.contains('x7q9zModal')) {
        event.target.style.display = 'none';
    }
}
</script>
MODAL;

    if ($r8tAuto) {
        echo "<script>m6k2xOpen('{$u9kId}');</script>";
    }
}
?>
