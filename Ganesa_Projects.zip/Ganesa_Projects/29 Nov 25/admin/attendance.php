<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}


require "../config/db.php";


$today = date('Y-m-d');


// --- Fetch Classes and Sections for dropdown ---
$classes = [];
$result = $conn->query("SELECT DISTINCT class FROM students ORDER BY class ASC");
while($row = $result->fetch_assoc()){
    $classes[] = $row['class'];
}
$sections = ['A','B','C','D'];


// --- Attendance Submission ---
if(isset($_POST['submit_attendance'])){
    $class = $_POST['class'];
    $section = $_POST['section'];
    $statuses = $_POST['status']; // array: student_id => P/A


    foreach($statuses as $student_id => $status){
        // Check if attendance already exists for this student today
        $check = $conn->query("SELECT id FROM attendance WHERE student_id=$student_id AND date='$today'");
        if($check->num_rows > 0){
            // Update existing record
            $conn->query("UPDATE attendance SET status='$status' WHERE student_id=$student_id AND date='$today'");
        } else {
            // Insert new record
            $conn->query("INSERT INTO attendance (student_id,class,section,date,status) VALUES ($student_id,$class,'$section','$today','$status')");
        }
    }
    echo "<script>alert('Attendance saved successfully'); window.location.href='attendance.php';</script>";
}


// --- Fetch students if class/section selected ---
$students = [];
$selected_class = $_POST['class'] ?? '';
$selected_section = $_POST['section'] ?? '';


if($selected_class && $selected_section){
    $stmt = $conn->prepare("SELECT * FROM students WHERE class=? AND section=? ORDER BY roll_no ASC");
    $stmt->bind_param("is", $selected_class, $selected_section);
    $stmt->execute();
    $students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}


// --- Calculate attendance percentage for a student ---
function getAttendancePercentage($conn, $student_id){
    $total = $conn->query("SELECT COUNT(*) as total FROM attendance WHERE student_id=$student_id")->fetch_assoc()['total'];
    $present = $conn->query("SELECT COUNT(*) as present FROM attendance WHERE student_id=$student_id AND status='P'")->fetch_assoc()['present'];
    if($total == 0) return 0;
    return round(($present / $total) * 100, 2);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Management - ERP</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'sans': ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50 font-sans antialiased">
    <div class="min-h-screen flex flex-col">
<?php include '../templates/header.php'?>
        <main class="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
                    <h2 class="text-lg font-semibold text-gray-900 mb-6 flex items-center">
                        <i class="material-icons text-blue-600 mr-3 text-lg">filter_list</i>
                        Select Class & Section
                    </h2>
                    <form method="POST" class="space-y-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Class</label>
                            <select name="class" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm">
                                <option value="">Select Class</option>
                                <?php foreach($classes as $c): ?>
                                <option value="<?php echo $c; ?>" <?php if($selected_class==$c) echo 'selected'; ?>><?php echo $c; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Section</label>
                            <select name="section" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white shadow-sm">
                                <option value="">Select Section</option>
                                <?php foreach($sections as $s): ?>
                                <option value="<?php echo $s; ?>" <?php if($selected_section==$s) echo 'selected'; ?>><?php echo $s; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" name="filter_students" class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 shadow-sm">
                            <i class="material-icons inline text-sm mr-2 align-middle">visibility</i>
                            Show Students
                        </button>
                    </form>
                </div>

                <?php if($students): ?>
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
                    <div class="flex items-center justify-between mb-6">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900">Class <?php echo $selected_class ?> - Section <?php echo $selected_section ?></h3>
                            <p class="text-sm text-gray-500"><?php echo count($students); ?> Students</p>
                        </div>
                        <div class="text-right">
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                <i class="material-icons text-xs mr-1">check_circle</i>
                                Marking Attendance
                            </span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <?php if($students): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <form method="POST">
                    <input type="hidden" name="class" value="<?php echo $selected_class; ?>">
                    <input type="hidden" name="section" value="<?php echo $selected_section; ?>">
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Roll No</th>
                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Student Name</th>
                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Status</th>
                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Attendance %</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach($students as $stu): 
                                    $att = $conn->query("SELECT status FROM attendance WHERE student_id=".$stu['id']." AND date='$today'")->fetch_assoc()['status'] ?? '';
                                ?>
                                <tr class="hover:bg-gray-50 transition-colors duration-150">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo $stu['roll_no']; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 max-w-xs">
                                        <?php echo htmlspecialchars($stu['name']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <select name="status[<?php echo $stu['id']; ?>]" required class="w-24 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white shadow-sm text-sm font-medium">
                                            <option value="P" <?php if($att=='P') echo 'selected'; ?> class="text-green-800 bg-green-50">Present</option>
                                            <option value="A" <?php if($att=='A') echo 'selected'; ?> class="text-red-800 bg-red-50">Absent</option>
                                        </select>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                            <?php echo getAttendancePercentage($conn, $stu['id']); ?>%
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="px-6 py-4 bg-gray-50 border-t border-gray-200">
                        <button type="submit" name="submit_attendance" class="inline-flex items-center px-6 py-3 bg-green-600 text-white text-sm font-semibold rounded-lg hover:bg-green-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 shadow-sm">
                            <i class="material-icons text-sm mr-2">save</i>
                            Save Attendance
                        </button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </main>
        <?php include "../templates/footer.php"?>
    </div>
</body>
</html>
