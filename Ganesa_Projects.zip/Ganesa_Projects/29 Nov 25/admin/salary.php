<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role']!=='admin'){
    header("Location: ../index.php");
    exit;
}
require "../config/db.php";

function calculateSalary($base,$allowance,$deduction){
    return $base+$allowance-$deduction;
}

if(isset($_POST['save_salary'])){
    $staff_id = intval($_POST['staff_id']);
    $month_year = $_POST['month_year'];
    $base = floatval($_POST['base_salary']);
    $allowance = floatval($_POST['allowance']);
    $deduction = floatval($_POST['deduction']);
    $paid_date = $_POST['paid_date'];
    $final_salary = calculateSalary($base,$allowance,$deduction);

    $stmt = $conn->prepare("INSERT INTO staff_salary (staff_id, month_year, base_salary, allowance, deduction, final_salary, paid_date) 
                            VALUES (?,?,?,?,?,?,?)
                            ON DUPLICATE KEY UPDATE base_salary=?, allowance=?, deduction=?, final_salary=?, paid_date=?");

    if($stmt){
        $stmt->bind_param(
            "isddddsdddds",
            $staff_id, $month_year, $base, $allowance, $deduction, $final_salary, $paid_date,
            $base, $allowance, $deduction, $final_salary, $paid_date
        );
        
        if($stmt->execute()){
            echo json_encode(['success' => true, 'message' => 'Salary saved successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $stmt->error]);
        }
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Prepare failed: ' . $conn->error]);
    }
    exit;
}

$staffs = $conn->query("SELECT * FROM staff ORDER BY id ASC");
$month_now = date('Y-m');
$paid_staff = $conn->query("SELECT ss.*, s.name, s.role, s.email FROM staff_salary ss JOIN staff s ON ss.staff_id=s.id WHERE ss.month_year='$month_now' ORDER BY ss.paid_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Monthly Salary - Admin</title>
<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<style>
* { font-family: 'Inter', sans-serif; margin: 0; padding: 0; box-sizing: border-box; }
body { background: #f8f9fa; }
.material-icons { vertical-align: middle; }
.final-salary { font-weight: 600; }
</style>
</head>
<body class="bg-gray-50">
<?php include "../templates/header.php"?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

<div class="bg-white rounded-xl shadow-sm border border-gray-200 mb-8 overflow-hidden">
<div class="bg-gray-50 px-6 py-4 border-b border-gray-200">
<h2 class="text-xl font-semibold text-gray-900 flex items-center gap-2">
<span class="material-icons text-gray-700">group</span>
Process Salary Payments
</h2>
</div>
<div class="overflow-x-auto">
<table class="w-full">
<thead class="bg-gray-50 border-b border-gray-200">
<tr>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">ID</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Name</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Role</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Month</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Base Salary</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Allowance</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Deduction</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Final Salary</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Paid Date</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Action</th>
</tr>
</thead>
<tbody class="bg-white divide-y divide-gray-200">
<?php if($staffs && $staffs->num_rows > 0): ?>
<?php while($row = $staffs->fetch_assoc()): ?>
<tr class="hover:bg-gray-50 transition-colors salary-row">
<td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
<?php echo $row['id']; ?>
</td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($row['name']); ?></td>
<td class="px-6 py-4 whitespace-nowrap">
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
<?php echo htmlspecialchars($row['role']); ?>
</span>
</td>
<td class="px-6 py-4 whitespace-nowrap">
<input type="month" name="month_year" required class="val-dobed month-input px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" value="<?php echo date('Y-m'); ?>">
</td>
<td class="px-6 py-4 whitespace-nowrap">
<input type="number" step="0.01" name="base_salary" value="<?php echo isset($row['base_salary']) ? $row['base_salary'] : 0; ?>" class="val-salary base-salary w-28 px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
</td>
<td class="px-6 py-4 whitespace-nowrap">
<input type="number" step="0.01" name="allowance" value="<?php echo isset($row['allowance']) ? $row['allowance'] : 0; ?>" class="val-salary allowance w-28 px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
</td>
<td class="px-6 py-4 whitespace-nowrap">
<input type="number" step="0.01" name="deduction" value="<?php echo isset($row['deduction']) ? $row['deduction'] : 0; ?>" class="val-salary deduction w-28 px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
</td>
<td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900 final-salary">
₹<?php echo number_format(calculateSalary(isset($row['base_salary']) ? $row['base_salary'] : 0, isset($row['allowance']) ? $row['allowance'] : 0, isset($row['deduction']) ? $row['deduction'] : 0), 2); ?>
</td>
<td class="px-6 py-4 whitespace-nowrap">
<input type="date" name="paid_date" required value="<?php echo date('Y-m-d'); ?>" class="val-dobed px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
</td>
<td class="px-6 py-4 whitespace-nowrap">
<button type="button" class="save-salary-btn inline-flex items-center gap-1 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
    data-staff-id="<?php echo $row['id']; ?>"
    data-name="<?php echo htmlspecialchars($row['name']); ?>"
    data-email="<?php echo htmlspecialchars($row['email']); ?>"
    data-role="<?php echo htmlspecialchars($row['role']); ?>">
<span class="material-icons text-lg">save</span>
Save
</button>
</td>
</tr>
<?php endwhile; ?>
<?php else: ?>
<tr>
<td colspan="10" class="px-6 py-8 text-center text-gray-500">No staff members found</td>
</tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
<div class="bg-gray-50 px-6 py-4 border-b border-gray-200">
<h2 class="text-xl font-semibold text-gray-900 flex items-center gap-2">
<span class="material-icons text-gray-700">receipt_long</span>
This Month Paid Staff (<?php echo date('F Y'); ?>)
</h2>
</div>
<div class="overflow-x-auto">
<table class="w-full">
<thead class="bg-gray-50 border-b border-gray-200">
<tr>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">ID</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Name</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Role</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Email</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Month</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Base Salary</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Allowance</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Deduction</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Final Salary</th>
<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Paid Date</th>
</tr>
</thead>
<tbody class="bg-white divide-y divide-gray-200">
<?php if($paid_staff && $paid_staff->num_rows > 0): ?>
<?php while($p = $paid_staff->fetch_assoc()): ?>
<tr class="hover:bg-gray-50 transition-colors">
<td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo $p['staff_id']; ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($p['name']); ?></td>
<td class="px-6 py-4 whitespace-nowrap">
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
<?php echo htmlspecialchars($p['role']); ?>
</span>
</td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($p['email']); ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $p['month_year']; ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">₹<?php echo number_format($p['base_salary'], 2); ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">₹<?php echo number_format($p['allowance'], 2); ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-red-600">-₹<?php echo number_format($p['deduction'], 2); ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">₹<?php echo number_format($p['final_salary'], 2); ?></td>
<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
<span class="material-icons text-sm text-gray-500 align-middle">event</span>
<?php echo $p['paid_date']; ?>
</td>
</tr>
<?php endwhile; ?>
<?php else: ?>
<tr>
<td colspan="10" class="px-6 py-8 text-center text-gray-500">No salary payments recorded for this month</td>
</tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>
</div>

<?php include "../templates/footer.php"?>
<script src="./valid.js"></script>
<script>
(function(){
    emailjs.init("PMWiXTG8JeA_JBELJ");
})();

$(document).ready(function() {
    // Auto-calculate final salary on input change
    $('.salary-row').each(function() {
        var row = $(this);
        row.find('.val-salary').on('input', function() {
            var baseSalary = parseFloat(row.find('.base-salary').val()) || 0;
            var allowance = parseFloat(row.find('.allowance').val()) || 0;
            var deduction = parseFloat(row.find('.deduction').val()) || 0;
            var finalSalary = baseSalary + allowance - deduction;
            row.find('.final-salary').text('₹' + finalSalary.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'));
        });
    });

    // Handle save button click
    $('.save-salary-btn').on("click", function(e) {
        e.preventDefault();
        
        var btn = $(this);
        var row = btn.closest('.salary-row');
        
        var employeeName = btn.data('name');
        var email = btn.data('email');
        var role = btn.data('role');
        var staffId = btn.data('staff-id');
        
        var monthYear = row.find('.month-input').val();
        var baseSalary = parseFloat(row.find('.base-salary').val()) || 0;
        var allowance = parseFloat(row.find('.allowance').val()) || 0;
        var deduction = parseFloat(row.find('.deduction').val()) || 0;
        var paidDate = row.find('input[name="paid_date"]').val();
        var netSalary = baseSalary + allowance - deduction;
        
        // Validation
        if(!monthYear || !paidDate) {
            alert('Please fill in all required fields');
            return;
        }
        
        // Disable button during processing
        btn.prop('disabled', true).html('<span class="material-icons text-lg animate-spin">refresh</span> Saving...');
        
        var formData = {
            save_salary: true,
            staff_id: staffId,
            month_year: monthYear,
            base_salary: baseSalary,
            allowance: allowance,
            deduction: deduction,
            paid_date: paidDate
        };
        
        $.ajax({
            url: '',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if(response.success) {
                    var templateParams = {
                        employee_name: employeeName,
                        email: email,
                        designation: role,
                        salary_month: monthYear,
                        basic_salary: baseSalary.toFixed(2),
                        allowances: allowance.toFixed(2),
                        deductions: deduction.toFixed(2),
                        net_salary: netSalary.toFixed(2),
                        salary_ref: staffId
                    };
                    
                    emailjs.send("service_1qu35rb", "template_bcwj85q", templateParams)
                    .then(function() {
                        alert("Salary saved successfully and email sent to " + employeeName);
                        location.reload();
                    })
                    .catch(function(err) {
                        alert("Salary saved successfully but email failed to send. Error: " + JSON.stringify(err));
                        location.reload();
                    });
                } else {
                    alert("Error: " + response.message);
                    btn.prop('disabled', false).html('<span class="material-icons text-lg">save</span> Save');
                }
            },
            error: function(xhr, status, error) {
                alert("Error saving salary: " + error);
                btn.prop('disabled', false).html('<span class="material-icons text-lg">save</span> Save');
            }
        });
    });
});
</script>
</body>
</html>