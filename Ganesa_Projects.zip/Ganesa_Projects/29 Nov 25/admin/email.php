<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}

require "../config/db.php";

function generateStudentEmail($name, $roll_no, $conn){
    $base = strtolower(preg_replace('/\s+/', '', $name)) . $roll_no;
    $email = $base . "@modernschool.com";
    $i = 1;
    while($conn->query("SELECT id FROM students WHERE email='$email'")->num_rows > 0){
        $email = $base . $i . "@modernschool.com";
        $i++;
    }
    return $email;
}

function generateStaffEmail($name, $id, $conn){
    $parts = explode(" ", strtolower($name));
    $first = $parts[0];
    $last = $parts[1] ?? "";
    $base = $first . "." . $last . $id;
    $email = $base . "@modernschool.com";
    $i = 1;
    while($conn->query("SELECT id FROM staff WHERE email='$email'")->num_rows > 0){
        $email = $base . $i . "@modernschool.com";
        $i++;
    }
    return $email;
}

$generated_email = "";

if(isset($_POST['generate_student'])){
    $student_id = intval($_POST['student_id']);
    $res = $conn->query("SELECT * FROM students WHERE id='$student_id'");
    if($res->num_rows > 0){
        $row = $res->fetch_assoc();
        $email = generateStudentEmail($row['name'], $row['roll_no'], $conn);
        $conn->query("UPDATE students SET email='$email' WHERE id='$student_id'");
        $generated_email = "Student Email Generated: $email";
    }
}

if(isset($_POST['generate_staff'])){
    $staff_id = intval($_POST['staff_id']);
    $res = $conn->query("SELECT * FROM staff WHERE id='$staff_id'");
    if($res->num_rows > 0){
        $row = $res->fetch_assoc();
        $email = generateStaffEmail($row['name'], $row['id'], $conn);
        $conn->query("UPDATE staff SET email='$email' WHERE id='$staff_id'");
        $generated_email = "Staff Email Generated: $email";
    }
}

$students = $conn->query("SELECT * FROM students ORDER BY class, roll_no");
$staffs = $conn->query("SELECT * FROM staff ORDER BY name");

$all_students = $conn->query("SELECT * FROM students WHERE email IS NOT NULL AND email!='' ORDER BY class, roll_no");
$all_staffs = $conn->query("SELECT * FROM staff WHERE email IS NOT NULL AND email!='' ORDER BY name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Email Management - Admin Panel</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
*{font-family:'Inter',sans-serif;}
body{background:#f8f9fa;margin:0;padding:0;}
.material-icons{vertical-align:middle;}
</style>
</head>
<body class="bg-gray-50">
<?php include "../templates/header.php"?>

<div class="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto">
       

        <?php if($generated_email!=""): ?>
        <div class="mb-6 p-4 bg-green-50 border-l-4 border-green-500 rounded-lg shadow-sm">
            <div class="flex items-center gap-3">
                <span class="material-icons text-green-600">check_circle</span>
                <p class="text-green-800 font-medium"><?php echo $generated_email; ?></p>
            </div>
        </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="bg-blue-600 px-6 py-4">
                    <h2 class="text-xl font-semibold text-white flex items-center gap-2">
                        <span class="material-icons">school</span>
                        Student Email Generator
                    </h2>
                </div>
                <form method="POST" class="p-6">
                    <div class="mb-4">
                        <label class="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-1">
                            <span class="material-icons text-sm">person</span>
                            Select Student
                        </label>
                        <select name="student_id" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200 bg-gray-50">
                            <option value="">-- Choose a student --</option>
                            <?php while($stu = $students->fetch_assoc()): ?>
                            <option value="<?php echo $stu['id']; ?>">Class <?php echo $stu['class']."-".$stu['section']." | ".$stu['name']." (Roll ".$stu['roll_no'].")"; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" name="generate_student" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-200 shadow-sm flex items-center justify-center gap-2">
                        <span class="material-icons">send</span>
                        Generate Student Email
                    </button>
                </form>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="bg-indigo-600 px-6 py-4">
                    <h2 class="text-xl font-semibold text-white flex items-center gap-2">
                        <span class="material-icons">badge</span>
                        Staff Email Generator
                    </h2>
                </div>
                <form method="POST" class="p-6">
                    <div class="mb-4">
                        <label class="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-1">
                            <span class="material-icons text-sm">person</span>
                            Select Staff Member
                        </label>
                        <select name="staff_id" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all duration-200 bg-gray-50">
                            <option value="">-- Choose a staff member --</option>
                            <?php while($stf = $staffs->fetch_assoc()): ?>
                            <option value="<?php echo $stf['id']; ?>"><?php echo $stf['name']." | ".$stf['role']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" name="generate_staff" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-200 shadow-sm flex items-center justify-center gap-2">
                        <span class="material-icons">send</span>
                        Generate Staff Email
                    </button>
                </form>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="bg-gray-800 px-6 py-4 flex items-center justify-between">
                <h2 class="text-xl font-semibold text-white flex items-center gap-2">
                    <span class="material-icons">list</span>
                    Generated Email Directory
                </h2>
                <span class="bg-white text-gray-800 px-3 py-1 rounded-full text-sm font-semibold">
                    <?php 
                    $total = $all_students->num_rows + $all_staffs->num_rows;
                    echo $total . " Total";
                    $all_students->data_seek(0);
                    $all_staffs->data_seek(0);
                    ?>
                </span>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-100 border-b border-gray-200">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                <div class="flex items-center gap-1">
                                    <span class="material-icons text-sm">tag</span>
                                    ID
                                </div>
                            </th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                <div class="flex items-center gap-1">
                                    <span class="material-icons text-sm">person</span>
                                    Name
                                </div>
                            </th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                <div class="flex items-center gap-1">
                                    <span class="material-icons text-sm">category</span>
                                    Type
                                </div>
                            </th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                <div class="flex items-center gap-1">
                                    <span class="material-icons text-sm">email</span>
                                    Email Address
                                </div>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php
                        $counter = 1;
                        while($stu = $all_students->fetch_assoc()){
                            echo "<tr class='hover:bg-gray-50 transition-colors duration-150'>
                            <td class='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'>".$counter++."</td>
                            <td class='px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium'>".$stu['name']."</td>
                            <td class='px-6 py-4 whitespace-nowrap'>
                                <span class='inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800'>
                                    <span class='material-icons text-xs'>school</span>
                                    Student
                                </span>
                            </td>
                            <td class='px-6 py-4 whitespace-nowrap text-sm text-gray-700 font-mono'>".$stu['email']."</td>
                            </tr>";
                        }
                        while($stf = $all_staffs->fetch_assoc()){
                            echo "<tr class='hover:bg-gray-50 transition-colors duration-150'>
                            <td class='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'>".$counter++."</td>
                            <td class='px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium'>".$stf['name']."</td>
                            <td class='px-6 py-4 whitespace-nowrap'>
                                <span class='inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-800'>
                                    <span class='material-icons text-xs'>badge</span>
                                    Staff
                                </span>
                            </td>
                            <td class='px-6 py-4 whitespace-nowrap text-sm text-gray-700 font-mono'>".$stf['email']."</td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<?php include "../templates/footer.php"?>
<script src="./valid.js"></script>
</body>
</html>