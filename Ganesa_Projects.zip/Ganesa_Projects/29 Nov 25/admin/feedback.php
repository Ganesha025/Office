<?php
session_start();
require "../config/db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}

$all_feedback = [];
$res = $conn->query("SELECT f.id, s.name AS student_name, f.feedback, f.submitted_at 
                     FROM feedback f 
                     JOIN students s ON f.student_id = s.id 
                     ORDER BY f.submitted_at DESC");
if($res){
    while($row = $res->fetch_assoc()){
        $all_feedback[] = $row;
    }
} else {
    die("DB Error: ".$conn->error);
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>All Student Feedback</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
<script src="https://cdn.tailwindcss.com"></script>
<style>
  body {
    font-family: 'Inter', sans-serif;
  }
</style>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col">

<?php include "../templates/header.php"?>

<main class="flex-grow container mx-auto px-4 py-6">
  <div class="bg-white shadow-md rounded-lg p-6">
    <h1 class="text-2xl font-semibold text-gray-900 mb-6">All Student Feedback</h1>

    <div class="overflow-x-auto">
      <table class="min-w-full border-collapse border border-gray-200">
        <thead class="bg-gray-100">
          <tr>
            <th class="border border-gray-300 text-left px-4 py-3 text-sm font-semibold text-gray-700 w-12">#</th>
            <th class="border border-gray-300 text-left px-4 py-3 text-sm font-semibold text-gray-700">Student Name</th>
            <th class="border border-gray-300 text-left px-4 py-3 text-sm font-semibold text-gray-700">Feedback</th>
            <th class="border border-gray-300 text-left px-4 py-3 text-sm font-semibold text-gray-700">Submitted At</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
        <?php $counter = 1; foreach($all_feedback as $fb): ?>
          <tr class="hover:bg-gray-50">
            <td class="border border-gray-300 px-4 py-2 text-sm text-gray-700 align-top"><?= $counter++ ?></td>
            <td class="border border-gray-300 px-4 py-2 text-sm text-gray-800 font-medium align-top"><?= htmlspecialchars($fb['student_name']) ?></td>
            <td class="border border-gray-300 px-4 py-2 text-sm text-gray-700 align-top whitespace-pre-line"><?= htmlspecialchars($fb['feedback']) ?></td>
            <td class="border border-gray-300 px-4 py-2 text-sm text-gray-600 align-top"><?= $fb['submitted_at'] ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>

<?php include "../templates/footer.php"?>

<script src="./valid.js"></script>
</body>
</html>
