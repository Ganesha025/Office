<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}

require "../config/db.php";

function calculateSalary($base, $allowance, $deduction){
    return $base + $allowance - $deduction;
}

$emailSent = false;
$emailTo = "";
$staffName = "";

if(isset($_POST['add_staff'])){
    $name = trim($_POST['name']);
    $role = trim($_POST['role']);
    $email = trim($_POST['email']);
    $mobile = trim($_POST['mobile']);
    $base_salary = floatval($_POST['base_salary']);
    $allowance = floatval($_POST['allowance']);
    $deduction = floatval($_POST['deduction']);

    $stmt = $conn->prepare("INSERT INTO staff (name, role, email, mobile, base_salary, allowance, deduction) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("ssssddd", $name, $role, $email, $mobile, $base_salary, $allowance, $deduction);
    
    if($stmt->execute()){
        $emailSent = true;
        $emailTo = $email;
        $staffName = $name;
    }
}

if(isset($_POST['edit_staff'])){
    $id = intval($_POST['edit_id']);
    $name = trim($_POST['edit_name']);
    $role = trim($_POST['edit_role']);
    $email = trim($_POST['edit_email']);
    $mobile = trim($_POST['edit_mobile']);
    $base_salary = floatval($_POST['edit_base_salary']);
    $allowance = floatval($_POST['edit_allowance']);
    $deduction = floatval($_POST['edit_deduction']);

    $stmt = $conn->prepare("UPDATE staff SET name=?, role=?, email=?, mobile=?, base_salary=?, allowance=?, deduction=? WHERE id=?");
    $stmt->bind_param("ssssdddi", $name, $role, $email, $mobile, $base_salary, $allowance, $deduction, $id);
    $stmt->execute();
    header("Location: manage_staff.php");
    exit;
}

if(isset($_GET['delete_id'])){
    $id = intval($_GET['delete_id']);
    $conn->query("DELETE FROM staff WHERE id=$id");
    header("Location: manage_staff.php");
    exit;
}

$staffs = $conn->query("SELECT * FROM staff ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Staff</title>
<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<style>
*{font-family:'Inter',sans-serif;}
body{background:#f8f9fa;margin:0;padding:0;}
.material-icons{vertical-align:middle;}
</style>

<script>
tailwind.config = {
  theme: {
    extend: {
      colors: {
        primary: '#1e40af',
        secondary: '#64748b',
        accent: '#0ea5e9',
      }
    }
  }
}
</script>

<script>
(function(){ emailjs.init("JOI7aiTqIdULejz3K"); })();

function sendMail(email, name) {
    emailjs.send("service_btk93pf", "template_u9vblac", {
        name: name,
        title: "Staff Added",
        email: email,
        message: "Your staff record has been added successfully."
    }).then(function() {
        showSuccessModal("Staff added and email sent successfully!");
    }, function() {
        showErrorModal("Staff added but email sending failed.");
    });
}

function showSuccessModal(message) {
    document.getElementById('statusModalLabel').textContent = 'Success';
    document.getElementById('statusModalBody').innerHTML = '<div class="text-center"><span class="material-icons text-success" style="font-size: 48px;">check_circle</span><p class="mt-3">' + message + '</p></div>';
    var modal = new bootstrap.Modal(document.getElementById('statusModal'));
    modal.show();
    setTimeout(function() {
        window.location.href = 'manage_staff.php';
    }, 2000);
}

function showErrorModal(message) {
    document.getElementById('statusModalLabel').textContent = 'Warning';
    document.getElementById('statusModalBody').innerHTML = '<div class="text-center"><span class="material-icons text-warning" style="font-size: 48px;">warning</span><p class="mt-3">' + message + '</p></div>';
    var modal = new bootstrap.Modal(document.getElementById('statusModal'));
    modal.show();
    setTimeout(function() {
        window.location.href = 'manage_staff.php';
    }, 2000);
}

<?php if($emailSent): ?>
window.onload = function() {
    sendMail('<?php echo addslashes($emailTo); ?>', '<?php echo addslashes($staffName); ?>');
};
<?php endif; ?>
</script>

</head>
<body class="bg-gray-50">

<?php include "../templates/header.php"?>

<!-- Status Modal -->
<div class="modal fade" id="statusModal" tabindex="-1" aria-labelledby="statusModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow-lg">
      <div class="modal-header bg-gray-50 border-b border-gray-200">
        <h5 class="modal-title font-semibold text-gray-900" id="statusModalLabel">Status</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4" id="statusModalBody">
        <!-- Dynamic content will be inserted here -->
      </div>
    </div>
  </div>
</div>

<div class="min-h-screen px-4 py-6 sm:px-6 lg:px-8">
  <div class="max-w-7xl mx-auto">
    
    <div class="mb-6 flex items-center justify-between flex-wrap gap-4">
      <div>
        <h1 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <span class="material-icons text-blue-600">groups</span>
          Staff Management
        </h1>
        <p class="text-sm text-gray-500 mt-1">Manage your staff members and their salary information</p>
      </div>
      <a href="dashboard.php" class="inline-flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
        <span class="material-icons text-lg">arrow_back</span>
        Dashboard
      </a>
    </div>

    <div class="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
      <div class="px-6 py-4 border-b border-gray-200">
        <h2 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
          <span class="material-icons text-blue-600">person_add</span>
          Add New Staff Member
        </h2>
      </div>
      <div class="p-6">
        <form method="POST" class="space-y-4">
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1.5">Full Name <span class="text-red-500">*</span></label>
              <input type="text" name="name" class="val-new-name w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm" placeholder="Enter full name" required>
              <span class="error-name text-xs text-red-600 mt-1 block"></span>
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1.5">Role <span class="text-red-500">*</span></label>
              <select name="role" class="val-gender w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm" required>
                <option value="">Select Role</option>
                <option value="Teacher">Teacher</option>
                <option value="Staff">Staff</option>
              </select>
              <span class="error-role text-xs text-red-600 mt-1 block"></span>
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
              <input type="text" name="email" class="val-alt-email w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm" placeholder="Enter email address">
              <span class="error-email text-xs text-red-600 mt-1 block"></span>
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1.5">Mobile Number</label>
              <input type="text" name="mobile" class="val-mobile w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm" placeholder="Enter mobile number">
              <span class="error-mobile text-xs text-red-600 mt-1 block"></span>
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1.5">Base Salary <span class="text-red-500">*</span></label>
              <input type="text" name="base_salary" class="val-salary w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm" placeholder="0.00" required>
              <span class="error-base-salary text-xs text-red-600 mt-1 block"></span>
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1.5">Allowance</label>
              <input type="text" name="allowance" class="val-salary w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm" placeholder="0.00">
              <span class="error-allowance text-xs text-red-600 mt-1 block"></span>
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1.5">Deduction</label>
              <input type="text" name="deduction" class="val-salary w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm" placeholder="0.00">
              <span class="error-deduction text-xs text-red-600 mt-1 block"></span>
            </div>

          </div>
          
          <div class="flex justify-end pt-2">
            <button type="submit" name="add_staff" class="inline-flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
              <span class="material-icons text-lg">add</span>
              Add Staff Member
            </button>
          </div>
        </form>
      </div>
    </div>

    <div class="bg-white rounded-lg shadow-sm border border-gray-200">
      <div class="px-6 py-4 border-b border-gray-200">
        <h2 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
          <span class="material-icons text-blue-600">list</span>
          Staff Directory
        </h2>
      </div>
      <div class="overflow-x-auto">
        <table class="w-full">
          <thead class="bg-gray-50 border-b border-gray-200">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">ID</th>
              <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Name</th>
              <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Role</th>
              <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Email</th>
              <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Mobile</th>
              <th class="px-6 py-3 text-right text-xs font-semibold text-gray-700 uppercase tracking-wider">Base Salary</th>
              <th class="px-6 py-3 text-right text-xs font-semibold text-gray-700 uppercase tracking-wider">Allowance</th>
              <th class="px-6 py-3 text-right text-xs font-semibold text-gray-700 uppercase tracking-wider">Deduction</th>
              <th class="px-6 py-3 text-right text-xs font-semibold text-gray-700 uppercase tracking-wider">Final Salary</th>
              <th class="px-6 py-3 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-200">
            <?php while($row = $staffs->fetch_assoc()): ?>
            <tr class="hover:bg-gray-50 transition-colors">
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $row['id']; ?></td>
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($row['name']); ?></td>
              <td class="px-6 py-4 whitespace-nowrap">
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo $row['role']=='Teacher' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'; ?>">
                  <?php echo htmlspecialchars($row['role']); ?>
                </span>
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?php echo $row['email']; ?></td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?php echo $row['mobile']; ?></td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-medium"><?php echo number_format($row['base_salary'],2); ?></td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-green-600 text-right font-medium">+<?php echo number_format($row['allowance'],2); ?></td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-red-600 text-right font-medium">-<?php echo number_format($row['deduction'],2); ?></td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-bold"><?php echo number_format(calculateSalary($row['base_salary'], $row['allowance'], $row['deduction']),2); ?></td>
              <td class="px-6 py-4 whitespace-nowrap text-center text-sm">
                <div class="flex items-center justify-center gap-2">
                  <button data-bs-toggle="modal" data-bs-target="#editModal<?php echo $row['id']; ?>" class="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-50 text-blue-700 rounded-md hover:bg-blue-100 transition-colors text-xs font-medium">
                    <span class="material-icons text-base">edit</span>
                    Edit
                  </button>
                  <a href="manage_staff.php?delete_id=<?php echo $row['id']; ?>" onclick="return confirm('Delete this staff member?')" class="inline-flex items-center gap-1 px-3 py-1.5 bg-red-50 text-red-700 rounded-md hover:bg-red-100 transition-colors text-xs font-medium">
                    <span class="material-icons text-base">delete</span>
                    Delete
                  </a>
                </div>
              </td>
            </tr>

            <div class="modal fade" id="editModal<?php echo $row['id']; ?>">
              <div class="modal-dialog modal-lg">
                <div class="modal-content border-0 shadow-lg">
                  <div class="modal-header bg-gray-50 border-b border-gray-200">
                    <h5 class="modal-title font-semibold text-gray-900 flex items-center gap-2">
                      <span class="material-icons text-blue-600">edit</span>
                      Edit Staff Member
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body p-6">
                    <form method="POST">
                      <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">
                      
                      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label class="block text-sm font-medium text-gray-700 mb-1.5">Full Name <span class="text-red-500">*</span></label>
                          <input type="text" name="edit_name" value="<?php echo $row['name']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm" required>
                        </div>

                        <div>
                          <label class="block text-sm font-medium text-gray-700 mb-1.5">Role <span class="text-red-500">*</span></label>
                          <select name="edit_role" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm" required>
                            <option value="Teacher" <?php if($row['role']=='Teacher') echo 'selected'; ?>>Teacher</option>
                            <option value="Staff" <?php if($row['role']=='Staff') echo 'selected'; ?>>Staff</option>
                          </select>
                        </div>

                        <div>
                          <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                          <input type="text" name="edit_email" value="<?php echo $row['email']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm">
                        </div>

                        <div>
                          <label class="block text-sm font-medium text-gray-700 mb-1.5">Mobile Number</label>
                          <input type="text" name="edit_mobile" value="<?php echo $row['mobile']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm">
                        </div>

                        <div>
                          <label class="block text-sm font-medium text-gray-700 mb-1.5">Base Salary <span class="text-red-500">*</span></label>
                          <input type="text" name="edit_base_salary" value="<?php echo $row['base_salary']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm" required>
                        </div>

                        <div>
                          <label class="block text-sm font-medium text-gray-700 mb-1.5">Allowance</label>
                          <input type="text" name="edit_allowance" value="<?php echo $row['allowance']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm">
                        </div>

                        <div class="md:col-span-2">
                          <label class="block text-sm font-medium text-gray-700 mb-1.5">Deduction</label>
                          <input type="text" name="edit_deduction" value="<?php echo $row['deduction']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm">
                        </div>
                      </div>

                      <div class="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-200">
                        <button type="button" data-bs-dismiss="modal" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium">Cancel</button>
                        <button type="submit" name="edit_staff" class="inline-flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
                          <span class="material-icons text-lg">save</span>
                          Update Staff
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>

            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</div>

<?php include "../templates/footer.php"?>
<script src='./valid.js'></script>
</body>
</html>