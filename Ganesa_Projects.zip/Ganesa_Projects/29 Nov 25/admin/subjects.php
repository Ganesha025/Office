<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../index.php");
    exit;
}

require "../config/db.php";

$available_subjects = [];
$result = $conn->query("SELECT * FROM subjects ORDER BY name ASC");
while($row = $result->fetch_assoc()){
    $available_subjects[] = $row['name'];
}

if(isset($_POST['add_subject'])){
    $subject_name = trim($_POST['subject_name']);
    if(!in_array($subject_name, $available_subjects)){
        $stmt = $conn->prepare("INSERT INTO subjects (name) VALUES (?)");
        $stmt->bind_param("s", $subject_name);
        $stmt->execute();
        header("Location: subjects.php");
        exit;
    } else {
        echo "<script>alert('Subject already exists');</script>";
    }
}

if(isset($_POST['assign_class_subjects'])){
    $class = intval($_POST['class']);
    $section = $_POST['section'];
    $subjects = $_POST['subjects'];

    if(count($subjects) !== count(array_unique($subjects))){
        echo "<script>alert('Duplicate subjects selected!');</script>";
    } else {
        $invalid = array_diff($subjects, $available_subjects);
        if(!empty($invalid)){
            echo "<script>alert('Invalid subjects selected!');</script>";
        } else {
            $stu_res = $conn->query("SELECT id FROM students WHERE class=$class AND section='$section'");
            while($st = $stu_res->fetch_assoc()){
                $sid = $st['id'];
                $conn->query("DELETE FROM student_subjects WHERE student_id=$sid");
                foreach($subjects as $sub){
                    $stmt = $conn->prepare("INSERT INTO student_subjects (student_id, subject_name) VALUES (?,?)");
                    $stmt->bind_param("is", $sid, $sub);
                    $stmt->execute();
                }
            }
            echo "<script>alert('Subjects assigned to whole class');</script>";
        }
    }
}

$classes = [];
$r = $conn->query("SELECT DISTINCT class FROM students ORDER BY class ASC");
while($row = $r->fetch_assoc()){
    $classes[] = $row['class'];
}
$sections = ['A','B','C','D'];

$class_subjects = [];
$res = $conn->query("
    SELECT s.class, s.section, GROUP_CONCAT(DISTINCT ss.subject_name ORDER BY ss.subject_name ASC) AS subjects
    FROM students s
    LEFT JOIN student_subjects ss ON s.id = ss.student_id
    GROUP BY s.class, s.section
    ORDER BY s.class, s.section
");
while($row = $res->fetch_assoc()){
    $class_subjects[$row['class'].'-'.$row['section']] = $row['subjects'] ? explode(',', $row['subjects']) : [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Subjects - Admin</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
.material-symbols-outlined {
  font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
}
body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}
</style>
</head>
<body class="bg-gray-50 min-h-screen">
<?php include"../templates/header.php"?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
  
  <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
    
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div class="bg-blue-50 border-b border-blue-100 px-6 py-4">
        <div class="flex items-center space-x-2">
          <span class="material-symbols-outlined text-blue-600">add_circle</span>
          <h2 class="text-lg font-semibold text-gray-800">Add New Subject</h2>
        </div>
      </div>
      <form method="POST" class="p-6 space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Subject Name</label>
          <div class="relative">
            <span class="material-symbols-outlined absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">book</span>
            <input type="text" name="subject_name" id="FocusInput" placeholder="Enter subject name" required class="val-com-name w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition">
          </div>
        </div>
        <button type="submit" name="add_subject" class="w-full flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-medium transition duration-150">
          <span class="material-symbols-outlined">add</span>
          <span>Add Subject</span>
        </button>
      </form>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div class="bg-green-50 border-b border-green-100 px-6 py-4">
        <div class="flex items-center space-x-2">
          <span class="material-symbols-outlined text-green-600">assignment</span>
          <h2 class="text-lg font-semibold text-gray-800">Assign Subjects to Class</h2>
        </div>
      </div>
      <form method="POST" class="p-6 space-y-4">
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Class</label>
            <div class="relative">
              <span class="material-symbols-outlined absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">grade</span>
              <select name="class" required class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition appearance-none bg-white">
                <option value="">Select Class</option>
                <?php foreach($classes as $c): ?>
                <option value="<?php echo $c; ?>">Class <?php echo $c; ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Section</label>
            <div class="relative">
              <span class="material-symbols-outlined absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">group</span>
              <select name="section" required class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition appearance-none bg-white">
                <option value="">Select Section</option>
                <?php foreach($sections as $s): ?>
                <option value="<?php echo $s; ?>">Section <?php echo $s; ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Select Subjects (Hold Ctrl/Cmd for multiple)</label>
          <select name="subjects[]" multiple size="5" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition">
            <?php foreach($available_subjects as $sub): ?>
            <option value="<?php echo $sub; ?>" class="py-1"><?php echo $sub; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" name="assign_class_subjects" class="w-full flex items-center justify-center space-x-2 bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-lg font-medium transition duration-150">
          <span class="material-symbols-outlined">done_all</span>
          <span>Assign to Class</span>
        </button>
      </form>
    </div>

  </div>

  <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
    <div class="bg-purple-50 border-b border-purple-100 px-6 py-4">
      <div class="flex items-center space-x-2">
        <span class="material-symbols-outlined text-purple-600">list_alt</span>
        <h2 class="text-lg font-semibold text-gray-800">Assigned Subjects Overview</h2>
      </div>
    </div>
    <div class="overflow-x-auto">
      <table class="w-full">
        <thead class="bg-gray-50 border-b border-gray-200">
          <tr>
            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Class-Section</th>
            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Assigned Subjects</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
          <?php if(empty($class_subjects)): ?>
          <tr>
            <td colspan="2" class="px-6 py-8 text-center text-gray-500">
              <span class="material-symbols-outlined text-4xl text-gray-300 block mb-2">inbox</span>
              No class data available
            </td>
          </tr>
          <?php else: ?>
          <?php foreach($class_subjects as $cls => $subs): ?>
          <tr class="hover:bg-gray-50 transition">
            <td class="px-6 py-4">
              <div class="flex items-center space-x-2">
                <span class="material-symbols-outlined text-gray-400 text-xl">class</span>
                <span class="font-medium text-gray-900"><?php echo $cls; ?></span>
              </div>
            </td>
            <td class="px-6 py-4">
              <?php if(!empty($subs)): ?>
              <div class="flex flex-wrap gap-2">
                <?php foreach(array_unique($subs) as $sub): ?>
                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700">
                  <?php echo $sub; ?>
                </span>
                <?php endforeach; ?>
              </div>
              <?php else: ?>
              <span class="text-gray-400 text-sm italic">No subjects assigned</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>
<?php include "../templates/footer.php"?>
<script src="./valid.js"></script>
<script>
    $(document).ready(function(){
    $("#FocusInput").focus();

    })
</script>
</body>
</html>