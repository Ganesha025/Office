<?php
session_start();
require_once '../../config/db.php';

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../../public/index.php");
    exit;
}

// Get all students for dropdown
$students_result = $conn->query("SELECT reg_no, name FROM students ORDER BY name ASC");
$students = $students_result ? $students_result->fetch_all(MYSQLI_ASSOC) : [];

// Selected student
$selected_student = $_GET['student'] ?? '';

// Fetch student details and marks
$student_data = null;
$marks_data = [];
$total_credits = 0;
$total_weighted_score = 0;
$weighted_average = 0;
$overall_grade = '';

if($selected_student) {
    // Get student info - using query instead of prepare to avoid bool error
    $safe_reg = $conn->real_escape_string($selected_student);
    $student_result = $conn->query("SELECT reg_no, name, email, phone FROM students WHERE reg_no = '$safe_reg'");
    
    if($student_result && $student_result->num_rows > 0) {
        $student_data = $student_result->fetch_assoc();
        
        // Get marks with subject details
        $marks_query = "SELECT 
                s.subject_name,
                s.credit,
                i.internal1,
                i.internal2,
                i.assignment,
                i.total as internal_total,
                e.marks as external_marks,
                e.result as grade,
                (i.total + e.marks) as total_marks,
                ((i.total + e.marks) * s.credit) as weighted_score
            FROM internal_marks i
            JOIN subjects s ON i.subject_id = s.id
            JOIN external_marks e ON i.reg_no = e.reg_no AND i.subject_id = e.subject_id
            WHERE i.reg_no = '$safe_reg'
            ORDER BY s.subject_name ASC";
        
        $marks_result = $conn->query($marks_query);
        
        if($marks_result) {
            $marks_data = $marks_result->fetch_all(MYSQLI_ASSOC);
            
            // Calculate totals
            foreach($marks_data as $mark) {
                $total_credits += $mark['credit'];
                $total_weighted_score += $mark['weighted_score'];
            }
            
            // Calculate weighted average
            if($total_credits > 0) {
                $weighted_average = $total_weighted_score / $total_credits;
                
                // Determine overall grade
                if($weighted_average >= 90) $overall_grade = 'A';
                else if($weighted_average >= 75) $overall_grade = 'B';
                else if($weighted_average >= 50) $overall_grade = 'C';
                else $overall_grade = 'Fail';
            }
        } else {
            // Debug: show SQL error
            // echo "SQL Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Marksheet Generator</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    @media print {
        .no-print { display: none; }
        body { background: white; }
        .marksheet-container { box-shadow: none; margin: 0; padding: 20px; }
    }
</style>
</head>
<body class="bg-gray-100">

<div class="min-h-screen p-6">
    <!-- Header Controls -->
    <div class="no-print max-w-5xl mx-auto mb-6 bg-white p-4 rounded-lg shadow">
        <div class="flex justify-between items-center">
            <h1 class="text-2xl font-bold text-gray-800">Marksheet Generator</h1>
            <div class="flex gap-3">
                <select id="studentSelect" class="p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" onchange="loadMarksheet()">
                    <option value="">Select Student</option>
                    <?php foreach($students as $s): ?>
                    <option value="<?= $s['reg_no'] ?>" <?= $selected_student == $s['reg_no'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($s['name']) ?> (<?= $s['reg_no'] ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
                <?php if($student_data): ?>
                <button onclick="window.print()" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                    🖨️ Print Marksheet
                </button>
                <?php endif; ?>
                <a href="marks.php" class="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition">
                    ← Back to Marks
                </a>
            </div>
        </div>
    </div>

    <!-- Marksheet -->
    <?php if($student_data && !empty($marks_data)): ?>
    <div class="marksheet-container max-w-5xl mx-auto bg-white rounded-lg shadow-lg p-8">
        <!-- Header -->
        <div class="text-center border-b-4 border-blue-600 pb-6 mb-6">
            <h1 class="text-4xl font-bold text-blue-900 mb-2">ACADEMIC MARKSHEET</h1>
            <p class="text-gray-600">With Credit Weightage Calculation</p>
            <p class="text-sm text-gray-500 mt-2">Academic Year 2024-25</p>
        </div>

        <!-- Student Information -->
        <div class="grid grid-cols-2 gap-6 mb-8 bg-blue-50 p-6 rounded-lg">
            <div>
                <p class="text-sm text-gray-600">Student Name</p>
                <p class="text-lg font-bold text-gray-800"><?= htmlspecialchars($student_data['name']) ?></p>
            </div>
            <div>
                <p class="text-sm text-gray-600">Registration Number</p>
                <p class="text-lg font-bold text-gray-800"><?= htmlspecialchars($student_data['reg_no']) ?></p>
            </div>
            <div>
                <p class="text-sm text-gray-600">Email</p>
                <p class="text-lg text-gray-800"><?= htmlspecialchars($student_data['email']) ?></p>
            </div>
            <div>
                <p class="text-sm text-gray-600">Phone</p>
                <p class="text-lg text-gray-800"><?= htmlspecialchars($student_data['phone']) ?></p>
            </div>
        </div>

        <!-- Marks Table -->
        <div class="mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Subject-wise Performance</h2>
            <table class="w-full border-collapse border-2 border-gray-300">
                <thead>
                    <tr class="bg-blue-600 text-white">
                        <th class="border border-gray-300 px-4 py-3 text-left">Subject</th>
                        <th class="border border-gray-300 px-4 py-3 text-center">Credit</th>
                        <th class="border border-gray-300 px-4 py-3 text-center">Internal-1<br><span class="text-xs">(25)</span></th>
                        <th class="border border-gray-300 px-4 py-3 text-center">Internal-2<br><span class="text-xs">(25)</span></th>
                        <th class="border border-gray-300 px-4 py-3 text-center">Assignment<br><span class="text-xs">(25)</span></th>
                        <th class="border border-gray-300 px-4 py-3 text-center">Internal Total<br><span class="text-xs">(75)</span></th>
                        <th class="border border-gray-300 px-4 py-3 text-center">External<br><span class="text-xs">(75)</span></th>
                        <th class="border border-gray-300 px-4 py-3 text-center">Total Marks<br><span class="text-xs">(150)</span></th>
                        <th class="border border-gray-300 px-4 py-3 text-center">Weighted Score<br><span class="text-xs">(Total × Credit)</span></th>
                        <th class="border border-gray-300 px-4 py-3 text-center">Grade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($marks_data as $mark): ?>
                    <tr class="hover:bg-gray-50">
                        <td class="border border-gray-300 px-4 py-3 font-medium"><?= htmlspecialchars($mark['subject_name']) ?></td>
                        <td class="border border-gray-300 px-4 py-3 text-center font-semibold"><?= $mark['credit'] ?></td>
                        <td class="border border-gray-300 px-4 py-3 text-center"><?= $mark['internal1'] ?></td>
                        <td class="border border-gray-300 px-4 py-3 text-center"><?= $mark['internal2'] ?></td>
                        <td class="border border-gray-300 px-4 py-3 text-center"><?= $mark['assignment'] ?></td>
                        <td class="border border-gray-300 px-4 py-3 text-center font-semibold text-green-700"><?= $mark['internal_total'] ?></td>
                        <td class="border border-gray-300 px-4 py-3 text-center"><?= $mark['external_marks'] ?></td>
                        <td class="border border-gray-300 px-4 py-3 text-center font-bold text-blue-700"><?= $mark['total_marks'] ?></td>
                        <td class="border border-gray-300 px-4 py-3 text-center font-bold text-purple-700"><?= number_format($mark['weighted_score'], 2) ?></td>
                        <td class="border border-gray-300 px-4 py-3 text-center">
                            <span class="px-3 py-1 rounded-full font-bold
                                <?= $mark['grade'] == 'A' ? 'bg-green-200 text-green-800' : '' ?>
                                <?= $mark['grade'] == 'B' ? 'bg-blue-200 text-blue-800' : '' ?>
                                <?= $mark['grade'] == 'C' ? 'bg-yellow-200 text-yellow-800' : '' ?>
                                <?= $mark['grade'] == 'Fail' ? 'bg-red-200 text-red-800' : '' ?>">
                                <?= $mark['grade'] ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <!-- Totals Row -->
                    <tr class="bg-gray-200 font-bold">
                        <td class="border border-gray-300 px-4 py-3 text-right" colspan="1">TOTALS</td>
                        <td class="border border-gray-300 px-4 py-3 text-center text-lg"><?= $total_credits ?></td>
                        <td class="border border-gray-300 px-4 py-3" colspan="6"></td>
                        <td class="border border-gray-300 px-4 py-3 text-center text-lg text-purple-700"><?= number_format($total_weighted_score, 2) ?></td>
                        <td class="border border-gray-300 px-4 py-3"></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Credit Weightage Breakdown -->
        <div class="mb-8 bg-purple-50 p-6 rounded-lg">
            <h2 class="text-xl font-bold text-gray-800 mb-4">📊 Credit Weightage Breakdown</h2>
            <div class="space-y-3">
                <?php foreach($marks_data as $mark): ?>
                <div class="flex items-center justify-between bg-white p-3 rounded border">
                    <span class="font-medium"><?= htmlspecialchars($mark['subject_name']) ?></span>
                    <span class="text-sm text-gray-600">
                        <?= $mark['total_marks'] ?> × <?= $mark['credit'] ?> = 
                        <span class="font-bold text-purple-700"><?= number_format($mark['weighted_score'], 2) ?></span>
                    </span>
                    <div class="w-48 bg-gray-200 rounded-full h-3">
                        <div class="bg-purple-600 h-3 rounded-full" style="width: <?= ($mark['weighted_score'] / $total_weighted_score) * 100 ?>%"></div>
                    </div>
                    <span class="text-sm text-gray-500"><?= number_format(($mark['weighted_score'] / $total_weighted_score) * 100, 1) ?>%</span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Final Result -->
        <div class="grid grid-cols-3 gap-6 mb-8">
            <div class="bg-blue-100 p-6 rounded-lg text-center">
                <p class="text-sm text-gray-600 mb-2">Total Credits</p>
                <p class="text-4xl font-bold text-blue-700"><?= $total_credits ?></p>
            </div>
            <div class="bg-purple-100 p-6 rounded-lg text-center">
                <p class="text-sm text-gray-600 mb-2">Weighted Average</p>
                <p class="text-4xl font-bold text-purple-700"><?= number_format($weighted_average, 2) ?></p>
                <p class="text-xs text-gray-500 mt-1">Out of 150</p>
            </div>
            <div class="bg-gradient-to-br from-green-400 to-blue-500 p-6 rounded-lg text-center">
                <p class="text-sm text-white mb-2">Overall Grade</p>
                <p class="text-5xl font-bold text-white"><?= $overall_grade ?></p>
            </div>
        </div>

        <!-- Grading Scale -->
        <div class="mb-8 bg-gray-50 p-6 rounded-lg">
            <h3 class="text-lg font-bold text-gray-800 mb-3">Grading Scale</h3>
            <div class="grid grid-cols-4 gap-4">
                <div class="text-center p-3 bg-green-100 rounded">
                    <p class="font-bold text-green-800">A Grade</p>
                    <p class="text-sm text-gray-600">90 - 150</p>
                </div>
                <div class="text-center p-3 bg-blue-100 rounded">
                    <p class="font-bold text-blue-800">B Grade</p>
                    <p class="text-sm text-gray-600">75 - 89</p>
                </div>
                <div class="text-center p-3 bg-yellow-100 rounded">
                    <p class="font-bold text-yellow-800">C Grade</p>
                    <p class="text-sm text-gray-600">50 - 74</p>
                </div>
                <div class="text-center p-3 bg-red-100 rounded">
                    <p class="font-bold text-red-800">Fail</p>
                    <p class="text-sm text-gray-600">Below 50</p>
                </div>
            </div>
        </div>

        <!-- Formula Explanation -->
        <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 mb-8">
            <h3 class="font-bold text-gray-800 mb-2">📐 Calculation Formula</h3>
            <p class="text-sm text-gray-700 mb-2">
                <strong>Weighted Score per Subject:</strong> Total Marks × Credit Hours
            </p>
            <p class="text-sm text-gray-700 mb-2">
                <strong>Weighted Average:</strong> (Sum of All Weighted Scores) ÷ (Total Credit Hours)
            </p>
            <p class="text-sm text-gray-600 italic">
                Example: <?= number_format($total_weighted_score, 2) ?> ÷ <?= $total_credits ?> = <?= number_format($weighted_average, 2) ?>
            </p>
        </div>

        <!-- Footer -->
        <div class="flex justify-between items-end border-t-2 border-gray-300 pt-6 mt-8">
            <div>
                <p class="text-sm text-gray-600">Date of Issue</p>
                <p class="font-semibold"><?= date('d-M-Y') ?></p>
            </div>
            <div class="text-center">
                <div class="border-t-2 border-gray-800 w-48 mb-2 mt-8"></div>
                <p class="font-semibold">Principal's Signature</p>
            </div>
            <div class="text-center">
                <div class="border-t-2 border-gray-800 w-48 mb-2 mt-8"></div>
                <p class="font-semibold">Registrar's Signature</p>
            </div>
        </div>
    </div>
    
    <?php elseif($selected_student && empty($marks_data)): ?>
    <div class="max-w-5xl mx-auto bg-white rounded-lg shadow-lg p-8 text-center">
        <div class="text-6xl mb-4">📋</div>
        <h2 class="text-2xl font-bold text-gray-800 mb-2">No Marks Found</h2>
        <p class="text-gray-600 mb-6">This student doesn't have any marks recorded yet.</p>
        <a href="marks.php?student=<?= urlencode($selected_student) ?>" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
            Add Marks for This Student
        </a>
    </div>
    
    <?php else: ?>
    <div class="max-w-5xl mx-auto bg-white rounded-lg shadow-lg p-8 text-center">
        <div class="text-6xl mb-4">👆</div>
        <h2 class="text-2xl font-bold text-gray-800 mb-2">Select a Student</h2>
        <p class="text-gray-600">Choose a student from the dropdown above to generate their marksheet.</p>
    </div>
    <?php endif; ?>
</div>

<script>
function loadMarksheet() {
    const student = document.getElementById('studentSelect').value;
    if(student) {
        window.location.href = `?student=${encodeURIComponent(student)}`;
    } else {
        window.location.href = 'marksheet.php';
    }
}
</script>

</body>
</html>