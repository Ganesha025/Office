<?php
session_start();
require_once '../../config/db.php';

// Admin access only
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../../public/index.php");
    exit;
}

$action = $_GET['action'] ?? 'list';

// Fetch students and subjects for forms
$students = $conn->query("SELECT reg_no, name FROM students ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
$subjects = $conn->query("SELECT id, subject_name, credit FROM subjects ORDER BY subject_name ASC")->fetch_all(MYSQLI_ASSOC);

// Handle POST for add/edit
if($_SERVER['REQUEST_METHOD']==='POST'){
    $reg_no = $_POST['reg_no'];
    $subject_id = $_POST['subject_id'];
    $internal1 = intval($_POST['internal1']);
    $internal2 = intval($_POST['internal2']);
    $assignment = intval($_POST['assignment']);
    $external = intval($_POST['external']);
    
    $total = $internal1 + $internal2 + $assignment + $external;

    // Weighted score
    $credit = intval($_POST['credit']);
    $weighted_score = ($total * $credit);

    // Determine grade
    if($total>=90) $grade='A';
    else if($total>=75) $grade='B';
    else if($total>=50) $grade='C';
    else $grade='Fail';

    if($action==='add'){
        // Check for duplicate entry
        $check = $conn->prepare("SELECT id FROM internal_marks WHERE reg_no=? AND subject_id=?");
        $check->bind_param("si", $reg_no, $subject_id);
        $check->execute();
        $result = $check->get_result();
        
        if($result->num_rows > 0){
            $_SESSION['error'] = "Marks already exist for this student and subject!";
            header("Location: marks.php?action=add");
            exit;
        }
        
        // Internal Marks
        $stmt = $conn->prepare("INSERT INTO internal_marks (reg_no, subject_id, internal1, internal2, assignment, total) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("siiiii",$reg_no,$subject_id,$internal1,$internal2,$assignment,$total);
        $stmt->execute();

        // External Marks
        $stmt = $conn->prepare("INSERT INTO external_marks (reg_no, subject_id, marks, result) VALUES (?,?,?,?)");
        $stmt->bind_param("siis",$reg_no,$subject_id,$external,$grade);
        $stmt->execute();

        // Weighted Scores
        $stmt = $conn->prepare("INSERT INTO weighted_scores (reg_no, subject_id, credit, marks, weighted_score) VALUES (?,?,?,?,?)");
        $stmt->bind_param("siiid",$reg_no,$subject_id,$credit,$total,$weighted_score);
        $stmt->execute();

        $_SESSION['success'] = "Marks added successfully!";
        header("Location: marks.php");
        exit;
    }

    if($action==='inline_edit'){
        $id_internal = intval($_POST['id_internal']);
        $id_external = intval($_POST['id_external']);
        $id_weighted = intval($_POST['id_weighted']);

        // Update internal
        $stmt = $conn->prepare("UPDATE internal_marks SET internal1=?, internal2=?, assignment=?, total=? WHERE id=?");
        $stmt->bind_param("iiiii",$internal1,$internal2,$assignment,$total,$id_internal);
        $stmt->execute();

        // Update external
        $stmt = $conn->prepare("UPDATE external_marks SET marks=?, result=? WHERE id=?");
        $stmt->bind_param("isi",$external,$grade,$id_external);
        $stmt->execute();

        // Update weighted
        $stmt = $conn->prepare("UPDATE weighted_scores SET credit=?, marks=?, weighted_score=? WHERE id=?");
        $stmt->bind_param("iidi",$credit,$total,$weighted_score,$id_weighted);
        $stmt->execute();

        $_SESSION['success'] = "Marks updated successfully!";
        header("Location: marks.php");
        exit;
    }
}

// Handle Delete
if($action==='delete'){
    $reg_no = $_GET['reg_no'];
    $subject_id = intval($_GET['subject_id']);

    $stmt = $conn->prepare("DELETE FROM internal_marks WHERE reg_no=? AND subject_id=?");
    $stmt->bind_param("si", $reg_no, $subject_id);
    $stmt->execute();
    
    $stmt = $conn->prepare("DELETE FROM external_marks WHERE reg_no=? AND subject_id=?");
    $stmt->bind_param("si", $reg_no, $subject_id);
    $stmt->execute();
    
    $stmt = $conn->prepare("DELETE FROM weighted_scores WHERE reg_no=? AND subject_id=?");
    $stmt->bind_param("si", $reg_no, $subject_id);
    $stmt->execute();
    
    $_SESSION['success'] = "Marks deleted successfully!";
    header("Location: marks.php");
    exit;
}

// Fetch all marks for listing with IDs
$marks = [];
if($action==='list'){
    $res = $conn->query("SELECT i.id as id_internal, e.id as id_external, w.id as id_weighted,
                                i.reg_no, s.name as student_name, sub.subject_name, sub.id as subject_id,
                                i.internal1, i.internal2, i.assignment, i.total as internal_total, 
                                e.marks as external_marks, e.result as grade, w.credit
                         FROM internal_marks i
                         JOIN students s ON i.reg_no=s.reg_no
                         JOIN subjects sub ON i.subject_id=sub.id
                         JOIN external_marks e ON i.reg_no=e.reg_no AND i.subject_id=e.subject_id
                         JOIN weighted_scores w ON i.reg_no=w.reg_no AND i.subject_id=w.subject_id
                         ORDER BY i.reg_no DESC");
    $marks = $res->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Marks Management</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<div class="flex min-h-screen">
    <!-- <?php include '../includes/sidebar_admin.php'; ?> -->
    <div class="flex-1 p-6">

    <?php if(isset($_SESSION['success'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            <?= $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>

    <?php if(isset($_SESSION['error'])): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <?= $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>

    <?php if($action==='list'): ?>
        <h1 class="text-3xl font-bold mb-6">Marks List</h1>
        <a href="?action=add" class="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 mb-4 inline-block">Add Marks</a>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white shadow rounded-lg overflow-hidden">
                <thead class="bg-blue-100 text-left">
                    <tr>
                        <th class="px-4 py-2">Reg No</th>
                        <th class="px-4 py-2">Student</th>
                        <th class="px-4 py-2">Subject</th>
                        <th class="px-4 py-2">Internal 1</th>
                        <th class="px-4 py-2">Internal 2</th>
                        <th class="px-4 py-2">Assignment</th>
                        <th class="px-4 py-2">External</th>
                        <th class="px-4 py-2">Credit</th>
                        <th class="px-4 py-2">Total</th>
                        <th class="px-4 py-2">Grade</th>
                        <th class="px-4 py-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($marks as $m): ?>
                        
                    <tr class="border-b hover:bg-gray-50" id="row-<?= $m['id_internal'] ?>" data-editing="false">
                        <!-- Display Mode -->
                        <td class="px-4 py-2 view-mode"><?= htmlspecialchars($m['reg_no']) ?></td>
                        <td class="px-4 py-2 view-mode"><?= htmlspecialchars($m['student_name']) ?></td>
                        <td class="px-4 py-2 view-mode"><?= htmlspecialchars($m['subject_name']) ?></td>
                        <td class="px-4 py-2 view-mode"><?= $m['internal1'] ?></td>
                        <td class="px-4 py-2 view-mode"><?= $m['internal2'] ?></td>
                        <td class="px-4 py-2 view-mode"><?= $m['assignment'] ?></td>
                        <td class="px-4 py-2 view-mode">
    <?= min(50, intval($m['external_marks'])) ?>
</td>
                        <td class="px-4 py-2 view-mode"><?= $m['credit'] ?></td>
                        <td class="px-4 py-2 view-mode"><?= min(50, intval($m['external_marks']))+($m['internal1'] ?? 0) + ($m['internal2'] ?? 0) + ($m['assignment'] ?? 0) ?></td>    
                        <td class="px-4 py-2 view-mode"><?= htmlspecialchars($m['grade']) ?></td>
                        
                        <!-- Edit Mode (Hidden by default) -->
                        <td class="px-4 py-2 edit-mode" style="display:none;"><?= htmlspecialchars($m['reg_no']) ?></td>
                        <td class="px-4 py-2 edit-mode" style="display:none;"><?= htmlspecialchars($m['student_name']) ?></td>
                        <td class="px-4 py-2 edit-mode" style="display:none;"><?= htmlspecialchars($m['subject_name']) ?></td>
                        <td class="px-4 py-2 edit-mode" style="display:none;">
                            <input type="number" id="internal1-<?= $m['id_internal'] ?>" value="<?= $m['internal1'] ?>" class="w-20 p-1 border rounded" min="0" max="100">
                        </td>
                        <td class="px-4 py-2 edit-mode" style="display:none;">
                            <input type="number" id="internal2-<?= $m['id_internal'] ?>" value="<?= $m['internal2'] ?>" class="w-20 p-1 border rounded" min="0" max="100">
                        </td>
                        <td class="px-4 py-2 edit-mode" style="display:none;">
                            <input type="number" id="assignment-<?= $m['id_internal'] ?>" value="<?= $m['assignment'] ?>" class="w-20 p-1 border rounded" min="0" max="100">
                        </td>
                        <td class="px-4 py-2 edit-mode" style="display:none;">
                            <input type="number" id="external-<?= $m['id_internal'] ?>" value="<?= $m['external_marks'] ?>" class="w-20 p-1 border rounded" min="0" max="100">
                        </td>
                        <td class="px-4 py-2 edit-mode" style="display:none;">
                            <input type="number" id="credit-<?= $m['id_internal'] ?>" value="<?= $m['credit'] ?>" class="w-20 p-1 border rounded" min="0" max="10">
                        </td>
                        <td class="px-4 py-2 edit-mode" style="display:none;"></td>
                        <td class="px-4 py-2 edit-mode" style="display:none;"></td>
                        
                        <td class="px-4 py-2">
                            <div class="view-mode">
                                <button onclick="editRow(<?= $m['id_internal'] ?>)" class="px-2 py-1 bg-yellow-500 text-white rounded hover:bg-yellow-600">Edit</button>
                                <a href="?action=delete&reg_no=<?= urlencode($m['reg_no']) ?>&subject_id=<?= $m['subject_id'] ?>" onclick="return confirm('Are you sure you want to delete these marks?');" class="px-2 py-1 bg-red-500 text-white rounded hover:bg-red-600">Delete</a>
                            </div>
                            <div class="edit-mode" style="display:none;">
                                <button onclick="saveRow(<?= $m['id_internal'] ?>, <?= $m['id_external'] ?>, <?= $m['id_weighted'] ?>, '<?= htmlspecialchars($m['reg_no']) ?>', <?= $m['subject_id'] ?>)" class="px-2 py-1 bg-green-500 text-white rounded hover:bg-green-600">Save</button>
                                <button type="button" onclick="cancelEdit(<?= $m['id_internal'] ?>)" class="px-2 py-1 bg-gray-500 text-white rounded hover:bg-gray-600">Cancel</button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(count($marks)==0): ?>
                    <tr><td colspan="11" class="text-center py-4">No marks found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    <?php elseif($action==='add'): ?>
        <h1 class="text-3xl font-bold mb-6">Add Marks</h1>
        <form method="POST" id="addMarksForm" class="bg-white p-6 rounded shadow max-w-xl">
            <label class="block mb-2">Student:</label>
            <select name="reg_no" required class="w-full p-2 border rounded mb-4">
                <option value="">Select Student</option>
                <?php foreach($students as $s): ?>
                    <option value="<?= htmlspecialchars($s['reg_no']) ?>"><?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['reg_no']) ?>)</option>
                <?php endforeach; ?>
            </select>

            <label class="block mb-2">Subject:</label>
            <select name="subject_id" required class="w-full p-2 border rounded mb-4">
                <option value="">Select Subject</option>
                <?php foreach($subjects as $sub): ?>
                    <option value="<?= $sub['id'] ?>"><?= htmlspecialchars($sub['subject_name']) ?></option>
                <?php endforeach; ?>
            </select>

            <label class="block mb-2">Internal 1 (Max 20):</label>
            <input type="number" name="internal1" value="0" class="w-full p-2 border rounded mb-4" min="0" max="20" required>

            <label class="block mb-2">Internal 2 (Max 20):</label>
            <input type="number" name="internal2" value="0" class="w-full p-2 border rounded mb-4" min="0" max="20" required>

            <label class="block mb-2">Assignment (Max 10):</label>
            <input type="number" name="assignment" value="0" class="w-full p-2 border rounded mb-4" min="0" max="10" required>

            <label class="block mb-2">External Marks (Max 50):</label>
            <input type="number" name="external" value="0" class="w-full p-2 border rounded mb-4" min="0" max="50" required>

            <label class="block mb-2">Credit:</label>
            <input type="number" name="credit" value="0" class="w-full p-2 border rounded mb-4" min="0" max="10" required>

            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Add Marks</button>
            <a href="marks.php" class="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 ml-2">Cancel</a>
        </form>
    <?php endif; ?>

    </div>
</div>

<!-- Hidden form for inline editing -->
<form id="inlineEditForm" method="POST" action="?action=inline_edit" style="display:none;">
    <input type="hidden" name="id_internal" id="form_id_internal">
    <input type="hidden" name="id_external" id="form_id_external">
    <input type="hidden" name="id_weighted" id="form_id_weighted">
    <input type="hidden" name="reg_no" id="form_reg_no">
    <input type="hidden" name="subject_id" id="form_subject_id">
    <input type="hidden" name="internal1" id="form_internal1">
    <input type="hidden" name="internal2" id="form_internal2">
    <input type="hidden" name="assignment" id="form_assignment">
    <input type="hidden" name="external" id="form_external">
    <input type="hidden" name="credit" id="form_credit">
</form>

<script>
// Prevent double submission for add form
document.getElementById('addMarksForm')?.addEventListener('submit', function(e) {
    const submitBtn = this.querySelector('button[type="submit"]');
    if (submitBtn.disabled) {
        e.preventDefault();
        return false;
    }
    submitBtn.disabled = true;
    submitBtn.textContent = 'Adding...';
});

function editRow(id) {
    // Check if any other row is being edited
    const editingRow = document.querySelector('tr[data-editing="true"]');
    if (editingRow) {
        alert('Please save or cancel the current edit first.');
        return;
    }
    
    const row = document.getElementById('row-' + id);
    row.setAttribute('data-editing', 'true');
    
    const viewElements = row.querySelectorAll('.view-mode');
    const editElements = row.querySelectorAll('.edit-mode');
    
    viewElements.forEach(el => el.style.display = 'none');
    editElements.forEach(el => el.style.display = 'table-cell');
}

function cancelEdit(id) {
    const row = document.getElementById('row-' + id);
    row.setAttribute('data-editing', 'false');
    
    const viewElements = row.querySelectorAll('.view-mode');
    const editElements = row.querySelectorAll('.edit-mode');
    
    viewElements.forEach(el => el.style.display = '');
    editElements.forEach(el => el.style.display = 'none');
}

function saveRow(id_internal, id_external, id_weighted, reg_no, subject_id) {
    // Get values from input fields
    const internal1 = document.getElementById('internal1-' + id_internal).value;
    const internal2 = document.getElementById('internal2-' + id_internal).value;
    const assignment = document.getElementById('assignment-' + id_internal).value;
    const external = document.getElementById('external-' + id_internal).value;
    const credit = document.getElementById('credit-' + id_internal).value;
    
    // Validate values
    if (internal1 < 0 || internal1 > 100 || internal2 < 0 || internal2 > 100 || 
        assignment < 0 || assignment > 100 || external < 0 || external > 100) {
        alert('Marks must be between 0 and 100');
        return;
    }
    
    if (credit < 0 || credit > 10) {
        alert('Credit must be between 0 and 10');
        return;
    }
    
    // Populate hidden form
    document.getElementById('form_id_internal').value = id_internal;
    document.getElementById('form_id_external').value = id_external;
    document.getElementById('form_id_weighted').value = id_weighted;
    document.getElementById('form_reg_no').value = reg_no;
    document.getElementById('form_subject_id').value = subject_id;
    document.getElementById('form_internal1').value = internal1;
    document.getElementById('form_internal2').value = internal2;
    document.getElementById('form_assignment').value = assignment;
    document.getElementById('form_external').value = external;
    document.getElementById('form_credit').value = credit;
    
    // Submit form
    document.getElementById('inlineEditForm').submit();
}
</script>

</body>
</html>