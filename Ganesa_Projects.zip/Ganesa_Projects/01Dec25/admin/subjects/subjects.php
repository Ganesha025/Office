<?php
session_start();
require_once '../../config/db.php';

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../../public/index.php");
    exit;
}

$action = $_GET['action'] ?? 'list';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    if(isset($_POST['ajax_update'])){
        header('Content-Type: application/json');
        $id = $_POST['id'];
        $subject_code = $_POST['subject_code'];
        $subject_name = $_POST['subject_name'];
        $department_id = $_POST['department_id'];
        $program_id = $_POST['program_id'];
        $semester_id = $_POST['semester_id'];
        $credit = $_POST['credit'];
        $type = $_POST['type'];
        
        $check = $conn->prepare("SELECT id FROM subjects WHERE subject_code=? AND id!=?");
        $check->bind_param("si", $subject_code, $id);
        $check->execute();
        if($check->get_result()->num_rows > 0){
            echo json_encode(['success' => false, 'message' => 'Duplicate subject code: This subject code already exists']);
            exit;
        }
        
        $stmt = $conn->prepare("UPDATE subjects SET subject_code=?, subject_name=?, department_id=?, program_id=?, semester_id=?, credit=?, type=? WHERE id=?");
        $stmt->bind_param("ssiiissi", $subject_code, $subject_name, $department_id, $program_id, $semester_id, $credit, $type, $id);
        if($stmt->execute()){
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update subject']);
        }
        exit;
    }
    
    $subject_code = $_POST['subject_code'];
    $subject_name = $_POST['subject_name'];
    $department_id = $_POST['department_id'];
    $program_id = $_POST['program_id'];
    $semester_id = $_POST['semester_id'];
    $credit = $_POST['credit'];
    $type = $_POST['type'];

    if($action === 'add'){
        $check = $conn->prepare("SELECT id FROM subjects WHERE subject_code=?");
        $check->bind_param("s", $subject_code);
        $check->execute();
        if($check->get_result()->num_rows === 0){
            $stmt = $conn->prepare("INSERT INTO subjects (subject_code, subject_name, department_id, program_id, semester_id, credit, type) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssiiiss", $subject_code, $subject_name, $department_id, $program_id, $semester_id, $credit, $type);
            $stmt->execute();
            header("Location: subjects.php");
            exit;
        } else {
            $_SESSION['error'] = 'Duplicate subject code: This subject code already exists';
            header("Location: subjects.php?action=add");
            exit;
        }
    }

    if($action === 'edit'){
        $id = $_POST['id'];
        $check = $conn->prepare("SELECT id FROM subjects WHERE subject_code=? AND id!=?");
        $check->bind_param("si", $subject_code, $id);
        $check->execute();
        if($check->get_result()->num_rows === 0){
            $stmt = $conn->prepare("UPDATE subjects SET subject_code=?, subject_name=?, department_id=?, program_id=?, semester_id=?, credit=?, type=? WHERE id=?");
            $stmt->bind_param("ssiiissi", $subject_code, $subject_name, $department_id, $program_id, $semester_id, $credit, $type, $id);
            $stmt->execute();
            header("Location: subjects.php");
            exit;
        } else {
            $_SESSION['error'] = 'Duplicate subject code: This subject code already exists';
            header("Location: subjects.php?action=edit&id=".$id);
            exit;
        }
    }
}

if($action === 'delete'){
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM subjects WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: subjects.php");
    exit;
}

$subject = null;
if(in_array($action, ['view','edit'])){
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM subjects WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $subject = $stmt->get_result()->fetch_assoc();
}

$subjects = [];
if($action === 'list'){
    $res = $conn->query("SELECT s.id, s.subject_code, s.subject_name, s.department_id, s.program_id, s.semester_id, s.credit, s.type, d.name as department, p.program_name, sem.sem_number 
                         FROM subjects s 
                         LEFT JOIN departments d ON s.department_id = d.id
                         LEFT JOIN programs p ON s.program_id = p.id
                         LEFT JOIN semesters sem ON s.semester_id = sem.id
                         ORDER BY FIELD(s.id, (SELECT MAX(id) FROM subjects)) DESC, s.id DESC");
    $subjects = $res->fetch_all(MYSQLI_ASSOC);
}

$departments = $conn->query("SELECT * FROM departments ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
$programs = $conn->query("SELECT * FROM programs ORDER BY program_name ASC")->fetch_all(MYSQLI_ASSOC);
$semesters = $conn->query("SELECT * FROM semesters ORDER BY sem_number ASC")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Subjects</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
  <style>
  :root {
    --radius: 25px;
  }
  .rounded-custom {
    border-radius: var(--radius);
  }
  table {
    border-collapse: separate;
    border-spacing: 0 12px;
  }
  thead tr th {
    background-color: #bfdbfe;
    padding: 12px 16px;
    border-radius: var(--radius);
    font-weight: 600;
  }
  tbody tr {
    background-color: #ffffff;
    box-shadow: 0 2px 6px rgb(191 219 254 / 0.5);
    transition: background-color 0.3s ease;
  }
  tbody tr:hover {
    background-color: #e0e7ff;
  }
  tbody tr td {
    padding: 12px 16px;
    vertical-align: middle;
  }
  input[type="text"], input[type="number"], select {
    outline: none;
    border-radius: var(--radius);
    border: 2px solid #3b82f6;
    padding: 8px 12px;
    transition: border-color 0.3s ease;
  }
  input[type="text"]:focus, input[type="number"]:focus, select:focus {
    border-color: #1e40af;
  }
  button {
    border-radius: var(--radius);
  }
  .material-icons {
    vertical-align: middle;
    cursor: pointer;
  }
  </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-6">
  <div class="w-full max-w-7xl bg-white p-8 rounded-custom shadow-lg">
    <?php if(isset($_SESSION['error'])): ?>
      <div class="bg-red-100 border border-red-400 text-red-700 px-6 py-3 rounded-custom mb-6">
          <?= $_SESSION['error'] ?>
      </div>
      <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <?php if($action === 'list'): ?>
      <div class="flex items-center justify-between mb-8">
        <h1 class="text-4xl font-extrabold text-blue-700 tracking-tight">Subjects List</h1>
        <a href="?action=add" class="flex items-center gap-2 px-6 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-custom shadow-md transition">
          <span class="material-icons">add_circle</span> Add New Subject
        </a>
      </div>
      <div class="overflow-x-auto">
        <table class="min-w-full">
          <thead>
            <tr>
              <th>ID</th>
              <th>Code</th>
              <th>Name</th>
              <th>Department</th>
              <th>Program</th>
              <th>Semester</th>
              <th>Credit</th>
              <th>Type</th>
              <th class="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($subjects as $s): ?>
            <tr data-id="<?= $s['id'] ?>">
              <td><?= $s['id'] ?></td>
              <td class="code-cell">
                <span class="display-mode"><?= $s['subject_code'] ?></span>
                <input type="text" class="edit-mode hidden w-full p-2 border rounded-custom code-input" value="<?= $s['subject_code'] ?>" />
              </td>
              <td class="name-cell">
                <span class="display-mode"><?= $s['subject_name'] ?></span>
                <input type="text" class="edit-mode hidden w-full p-2 border rounded-custom name-input" value="<?= $s['subject_name'] ?>" />
              </td>
              <td class="dept-cell">
                <span class="display-mode"><?= $s['department'] ?></span>
                <select class="edit-mode hidden w-full p-2 border rounded-custom dept-select">
                  <?php foreach($departments as $d): ?>
                    <option value="<?= $d['id'] ?>" <?= $s['department_id']==$d['id'] ? 'selected' : '' ?>><?= $d['name'] ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td class="prog-cell">
                <span class="display-mode"><?= $s['program_name'] ?></span>
                <select class="edit-mode hidden w-full p-2 border rounded-custom prog-select">
                  <?php foreach($programs as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= $s['program_id']==$p['id'] ? 'selected' : '' ?>><?= $p['program_name'] ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td class="sem-cell">
                <span class="display-mode"><?= $s['sem_number'] ?></span>
                <select class="edit-mode hidden w-full p-2 border rounded-custom sem-select">
                  <?php foreach($semesters as $sem): ?>
                    <option value="<?= $sem['id'] ?>" <?= $s['semester_id']==$sem['id'] ? 'selected' : '' ?>><?= $sem['sem_number'] ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td class="credit-cell">
                <span class="display-mode"><?= $s['credit'] ?></span>
                <input type="number" class="edit-mode hidden w-24 p-2 border rounded-custom credit-input" value="<?= $s['credit'] ?>" min="0" />
              </td>
              <td class="type-cell">
                <span class="display-mode"><?= $s['type'] ?></span>
                <select class="edit-mode hidden w-full p-2 border rounded-custom type-select">
                  <option value="Core" <?= $s['type']=='Core' ? 'selected' : '' ?>>Core</option>
                  <option value="Elective" <?= $s['type']=='Elective' ? 'selected' : '' ?>>Elective</option>
                </select>
              </td>
              <td class="text-center space-x-1">
                <button title="Edit" class="edit-btn p-2 bg-yellow-400 hover:bg-yellow-500 rounded-custom text-white transition">
                  <span class="material-icons">edit</span>
                </button>
                <button title="Save" class="save-btn p-2 bg-green-600 hover:bg-green-700 rounded-custom text-white transition hidden">
                  <span class="material-icons">save</span>
                </button>
                <button title="Cancel" class="cancel-btn p-2 bg-gray-500 hover:bg-gray-600 rounded-custom text-white transition hidden">
                  <span class="material-icons">cancel</span>
                </button>
                <a href="?action=delete&id=<?= $s['id'] ?>" onclick="return confirm('Are you sure?');" title="Delete" class="delete-btn p-2 bg-red-600 hover:bg-red-700 rounded-custom text-white inline-flex items-center justify-center transition">
                  <span class="material-icons">delete</span>
                </a>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if(count($subjects) === 0): ?>
              <tr><td colspan="9" class="text-center py-6 text-gray-600">No subjects found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <script>
        $(function(){
          $('.edit-btn').on('click', function(){
            var row = $(this).closest('tr');
            row.find('.display-mode').addClass('hidden');
            row.find('.edit-mode').removeClass('hidden');
            $(this).addClass('hidden');
            row.find('.save-btn, .cancel-btn').removeClass('hidden');
            row.find('.delete-btn').addClass('hidden');
          });

          $('.cancel-btn').on('click', function(){
            var row = $(this).closest('tr');
            row.find('.edit-mode').addClass('hidden');
            row.find('.display-mode').removeClass('hidden');
            row.find('.edit-btn, .delete-btn').removeClass('hidden');
            row.find('.save-btn, .cancel-btn').addClass('hidden');
          });

          $('.save-btn').on('click', function(){
            var row = $(this).closest('tr');
            var id = row.data('id');

            var subject_code = row.find('.code-input').val().trim();
            var subject_name = row.find('.name-input').val().trim();
            var department_id = row.find('.dept-select').val();
            var program_id = row.find('.prog-select').val();
            var semester_id = row.find('.sem-select').val();
            var credit = row.find('.credit-input').val();
            var type = row.find('.type-select').val();

            $.post('subjects.php', {
              ajax_update: true,
              id: id,
              subject_code: subject_code,
              subject_name: subject_name,
              department_id: department_id,
              program_id: program_id,
              semester_id: semester_id,
              credit: credit,
              type: type
            }, function(response){
              if(response.success){
                location.reload();
              } else {
                alert(response.message);
              }
            }, 'json');
          });
        });
      </script>

    <?php elseif($action === 'add' || $action === 'edit'): ?>
      <h1 class="text-4xl font-extrabold mb-8 text-blue-700"><?= ucfirst($action) ?> Subject</h1>
      <form method="POST" class="max-w-xl mx-auto p-8 bg-white rounded-custom shadow-lg">
        <?php if($action === 'edit'): ?>
          <input type="hidden" name="id" value="<?= $subject['id'] ?>">
        <?php endif; ?>

        <label class="block mb-3 font-semibold text-gray-700">Subject Code:</label>
        <input type="text" name="subject_code" required value="<?= $subject['subject_code'] ?? '' ?>" class="w-full p-3 border-2 border-blue-500 rounded-custom mb-6 text-lg" />

        <label class="block mb-3 font-semibold text-gray-700">Subject Name:</label>
        <input type="text" name="subject_name" required value="<?= $subject['subject_name'] ?? '' ?>" class="w-full p-3 border-2 border-blue-500 rounded-custom mb-6 text-lg" />

        <label class="block mb-3 font-semibold text-gray-700">Department:</label>
        <select name="department_id" required class="w-full p-3 border-2 border-blue-500 rounded-custom mb-6 text-lg">
          <option value="" disabled <?= empty($subject['department_id']) ? 'selected' : '' ?>>Select Department</option>
          <?php foreach($departments as $d): ?>
            <option value="<?= $d['id'] ?>" <?= ($subject['department_id'] ?? '') == $d['id'] ? 'selected' : '' ?>><?= $d['name'] ?></option>
          <?php endforeach; ?>
        </select>

        <label class="block mb-3 font-semibold text-gray-700">Program:</label>
        <select name="program_id" required class="w-full p-3 border-2 border-blue-500 rounded-custom mb-6 text-lg">
          <option value="" disabled <?= empty($subject['program_id']) ? 'selected' : '' ?>>Select Program</option>
          <?php foreach($programs as $p): ?>
            <option value="<?= $p['id'] ?>" <?= ($subject['program_id'] ?? '') == $p['id'] ? 'selected' : '' ?>><?= $p['program_name'] ?></option>
          <?php endforeach; ?>
        </select>

        <label class="block mb-3 font-semibold text-gray-700">Semester:</label>
        <select name="semester_id" required class="w-full p-3 border-2 border-blue-500 rounded-custom mb-6 text-lg">
          <option value="" disabled <?= empty($subject['semester_id']) ? 'selected' : '' ?>>Select Semester</option>
          <?php foreach($semesters as $sem): ?>
            <option value="<?= $sem['id'] ?>" <?= ($subject['semester_id'] ?? '') == $sem['id'] ? 'selected' : '' ?>><?= $sem['sem_number'] ?></option>
          <?php endforeach; ?>
        </select>

        <label class="block mb-3 font-semibold text-gray-700">Credit:</label>
        <input type="number" name="credit" required value="<?= $subject['credit'] ?? 0 ?>" min="0" class="w-full p-3 border-2 border-blue-500 rounded-custom mb-6 text-lg" />

        <label class="block mb-3 font-semibold text-gray-700">Type:</label>
        <select name="type" required class="w-full p-3 border-2 border-blue-500 rounded-custom mb-6 text-lg">
          <option value="" disabled <?= empty($subject['type']) ? 'selected' : '' ?>>Select Type</option>
          <option value="Core" <?= ($subject['type'] ?? '') === 'Core' ? 'selected' : '' ?>>Core</option>
          <option value="Elective" <?= ($subject['type'] ?? '') === 'Elective' ? 'selected' : '' ?>>Elective</option>
        </select>

        <div class="flex gap-4 justify-center">
          <button type="submit" class="bg-blue-700 hover:bg-blue-800 text-white font-bold px-8 py-3 rounded-custom transition"> <?= ucfirst($action) ?> Subject </button>
          <a href="subjects.php" class="bg-gray-600 hover:bg-gray-700 text-white font-bold px-8 py-3 rounded-custom transition flex items-center justify-center">Cancel</a>
        </div>
      </form>

    <?php elseif($action === 'view'): ?>
      <h1 class="text-4xl font-extrabold mb-8 text-blue-700">View Subject</h1>
      <div class="max-w-xl mx-auto bg-white p-8 rounded-custom shadow-lg space-y-4 text-gray-800 text-lg">
        <p><strong>ID:</strong> <?= $subject['id'] ?></p>
        <p><strong>Code:</strong> <?= $subject['subject_code'] ?></p>
        <p><strong>Name:</strong> <?= $subject['subject_name'] ?></p>
        <p><strong>Department:</strong> 
            <?= $conn->query("SELECT name FROM departments WHERE id=".$subject['department_id'])->fetch_assoc()['name'] ?>
        </p>
        <p><strong>Program:</strong> 
            <?= $conn->query("SELECT program_name FROM programs WHERE id=".$subject['program_id'])->fetch_assoc()['program_name'] ?>
        </p>
        <p><strong>Semester:</strong> 
            <?= $conn->query("SELECT sem_number FROM semesters WHERE id=".$subject['semester_id'])->fetch_assoc()['sem_number'] ?>
        </p>
        <p><strong>Credit:</strong> <?= $subject['credit'] ?></p>
        <p><strong>Type:</strong> <?= $subject['type'] ?></p>
      </div>
      <a href="subjects.php" class="block mt-8 w-max bg-gray-600 hover:bg-gray-700 text-white rounded-custom px-6 py-3 transition">Back</a>
    <?php endif; ?>
  </div>
</body>
</html>
