<?php
session_start();
require_once '../../config/db.php';

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../../public/index.php");
    exit;
}

$action = $_GET['action'] ?? 'list';

if($action === 'ajax_update'){
    $id = $_POST['id'];
    $program_name = $_POST['program_name'];
    $duration_years = $_POST['duration_years'];
    $stmt = $conn->prepare("UPDATE programs SET program_name=?, duration_years=? WHERE id=?");
    $stmt->bind_param("sii", $program_name, $duration_years, $id);
    $stmt->execute();
    echo "success";
    exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add'){
    $program_name = $_POST['program_name'];
    $duration_years = $_POST['duration_years'];
    $stmt = $conn->prepare("INSERT INTO programs (program_name, duration_years) VALUES (?, ?)");
    $stmt->bind_param("si", $program_name, $duration_years);
    $stmt->execute();
    header("Location: programs.php");
    exit;
}

if($action === 'delete'){
    $id = $_GET['id'];
    $conn->query("DELETE FROM programs WHERE id='$id'");
    header("Location: programs.php");
    exit;
}

$programs = [];
if($action === 'list'){
    $res = $conn->query("SELECT * FROM programs ORDER BY updated_at DESC");
    $programs = $res->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Programs</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>*{border-radius:25px; font-family: 'Inter', sans-serif;}</style>
</head>
<body class="bg-gray-50">

<div class="flex min-h-screen">
    <div class="flex-1 p-10">

        <div class="flex justify-between items-center mb-8">
            <h1 class="text-5xl font-bold text-gray-900">Programs</h1>
            <button id="openModal" class="bg-blue-600 text-white px-6 py-3 flex items-center gap-3 rounded-full hover:bg-blue-700 shadow-md">
                <span class="material-icons">add</span> Add Program
            </button>
        </div>

        <div class="bg-white p-8 shadow-xl rounded-3xl">
            <table class="w-full text-left border-collapse">
                <thead class="bg-gray-100">
                    <tr class="text-gray-700 text-lg">
                        <th class="px-6 py-4">ID</th>
                        <th class="px-6 py-4">Program Name</th>
                        <th class="px-6 py-4">Duration (Years)</th>
                        <th class="px-6 py-4">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($programs as $p): ?>
                    <tr class="border-b border-gray-200 hover:bg-gray-50 transition duration-200" data-id="<?= $p['id'] ?>">
                        <td class="px-6 py-4 font-medium text-gray-800"><?= $p['id'] ?></td>

                        <td class="px-6 py-4">
                            <span class="text-display"><?= $p['program_name'] ?></span>
                            <input class="hidden p-2 border border-gray-300 w-full edit-field" value="<?= $p['program_name'] ?>">
                        </td>

                        <td class="px-6 py-4">
                            <span class="text-display"><?= $p['duration_years'] ?></span>
                            <input type="number" class="hidden p-2 border border-gray-300 w-full edit-field" value="<?= $p['duration_years'] ?>">
                        </td>

                        <td class="px-6 py-4 flex gap-2">
                            <button class="bg-yellow-500 text-white px-5 py-2 flex gap-2 items-center edit-btn hover:bg-yellow-600 transition">
                                <span class="material-icons text-sm">edit</span> Edit
                            </button>
                            <button class="bg-green-600 text-white px-5 py-2 flex gap-2 items-center hidden save-btn hover:bg-green-700 transition">
                                <span class="material-icons text-sm">save</span> Save
                            </button>
                            <a href="?action=delete&id=<?= $p['id'] ?>" onclick="return confirm('Are you sure?');" class="bg-red-600 text-white px-5 py-2 flex gap-2 items-center hover:bg-red-700 transition">
                                <span class="material-icons text-sm">delete</span> Delete
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(count($programs)==0): ?>
                    <tr><td colspan="4" class="text-center py-6 text-gray-400 text-lg">No programs found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<div id="programModal" class="fixed inset-0 bg-black bg-opacity-40 hidden items-center justify-center">
    <div class="bg-white p-8 shadow-2xl rounded-3xl w-96 relative">
        <h2 class="text-3xl font-bold mb-5 text-gray-900">Add Program</h2>
        <form method="POST" action="programs.php?action=add" class="flex flex-col gap-4">
            <input type="text" name="program_name" placeholder="Program Name" required class="p-3 border border-gray-300 rounded-3xl focus:outline-none focus:ring-2 focus:ring-blue-500">
            <input type="number" name="duration_years" placeholder="Duration (Years)" required class="p-3 border border-gray-300 rounded-3xl focus:outline-none focus:ring-2 focus:ring-blue-500">
            <div class="flex justify-end gap-3 mt-4">
                <button type="submit" class="bg-blue-600 text-white px-6 py-3 rounded-full hover:bg-blue-700 shadow-md">Save</button>
                <button type="button" id="closeModal" class="bg-gray-500 text-white px-6 py-3 rounded-full hover:bg-gray-600 shadow-md">Cancel</button>
            </div>
        </form>
        <button id="closeModalX" class="absolute top-4 right-4 text-gray-500 hover:text-gray-900 material-icons text-3xl">close</button>
    </div>
</div>

<script>
document.querySelectorAll(".edit-btn").forEach(btn=>{
    btn.addEventListener("click",function(){
        const row = this.closest("tr");
        row.querySelectorAll(".text-display").forEach(e=>e.classList.add("hidden"));
        row.querySelectorAll(".edit-field").forEach(e=>e.classList.remove("hidden"));
        row.querySelector(".save-btn").classList.remove("hidden");
        this.classList.add("hidden");
    });
});

document.querySelectorAll(".save-btn").forEach(btn=>{
    btn.addEventListener("click",function(){
        const row = this.closest("tr");
        const id = row.dataset.id;
        const fields = row.querySelectorAll(".edit-field");
        const name = fields[0].value;
        const duration = fields[1].value;

        const formData = new FormData();
        formData.append("id", id);
        formData.append("program_name", name);
        formData.append("duration_years", duration);

        fetch("programs.php?action=ajax_update",{
            method:"POST",
            body:formData
        }).then(r=>r.text()).then(res=>{
            if(res==="success"){
                row.querySelectorAll(".text-display")[0].innerText = name;
                row.querySelectorAll(".text-display")[1].innerText = duration;
                row.querySelectorAll(".text-display").forEach(e=>e.classList.remove("hidden"));
                row.querySelectorAll(".edit-field").forEach(e=>e.classList.add("hidden"));
                row.querySelector(".edit-btn").classList.remove("hidden");
                this.classList.add("hidden");
                location.reload();
            }
        });
    });
});

const modal = document.getElementById("programModal");
document.getElementById("openModal").onclick = ()=>{modal.classList.remove("hidden"); modal.classList.add("flex")};
document.getElementById("closeModal").onclick = ()=>{modal.classList.add("hidden"); modal.classList.remove("flex")};
document.getElementById("closeModalX").onclick = ()=>{modal.classList.add("hidden"); modal.classList.remove("flex")};
</script>

</body>
</html>
