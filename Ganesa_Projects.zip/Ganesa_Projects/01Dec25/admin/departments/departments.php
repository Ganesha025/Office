<?php
session_start();
require_once '../../config/db.php';
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
header("Location: ../../public/index.php");
exit;
}
$action = $_GET['action'] ?? 'list';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
$code = $_POST['code'];
$name = $_POST['name'];
$hod = $_POST['hod'] ?? '';
if($action === 'add'){
$stmt = $conn->prepare("INSERT INTO departments (code, name, hod, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
$stmt->bind_param("sss", $code, $name, $hod);
$stmt->execute();
header("Location: departments.php?added=1");
exit;
}
if($action === 'edit'){
$id = $_POST['id'];
$stmt = $conn->prepare("UPDATE departments SET code=?, name=?, hod=?, updated_at=NOW() WHERE id=?");
$stmt->bind_param("sssi", $code, $name, $hod, $id);
$stmt->execute();
header("Location: departments.php?edited=1");
exit;
}
}
if($action === 'delete'){
$id = $_GET['id'];
$conn->query("DELETE FROM departments WHERE id='$id'");
header("Location: departments.php?deleted=1");
exit;
}
$departments = [];
$res = $conn->query("SELECT *, 
    CASE 
        WHEN updated_at > created_at THEN updated_at 
        ELSE created_at 
    END as sort_date
    FROM departments 
    ORDER BY sort_date DESC");
$departments = $res->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Departments</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<script src="../valid.js"></script>
<link rel="stylesheet" href="../style.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<style>
body { font-family: 'Roboto', sans-serif; }
</style>
</head>
<body class="bg-white">

<div class="flex min-h-screen">
    <div class="flex-1">

        <?php if(isset($_GET['edited'])): ?>
            <div class="mx-4 sm:mx-6 mt-6 bg-green-50 border-l-4 border-green-500 text-green-800 px-4 py-3 rounded flex items-center gap-2">
                <span class="material-icons text-green-600">check_circle</span>
                <span>Department updated successfully!</span>
            </div>
        <?php endif; ?>
        
        <?php if(isset($_GET['added'])): ?>
            <div class="mx-4 sm:mx-6 mt-6 bg-blue-50 border-l-4 border-blue-500 text-blue-800 px-4 py-3 rounded flex items-center gap-2">
                <span class="material-icons text-blue-600">check_circle</span>
                <span>Department added successfully!</span>
            </div>
        <?php endif; ?>
        
        <?php if(isset($_GET['deleted'])): ?>
            <div class="mx-4 sm:mx-6 mt-6 bg-red-50 border-l-4 border-red-500 text-red-800 px-4 py-3 rounded flex items-center gap-2">
                <span class="material-icons text-red-600">check_circle</span>
                <span>Department deleted successfully!</span>
            </div>
        <?php endif; ?>

        <div class="p-4 sm:p-6">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
                <h1 class="text-xl sm:text-2xl font-normal text-gray-800">Departments</h1>
                <button onclick="openModal('add')" class="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 shadow-sm w-full sm:w-auto justify-center">
                    <span class="material-icons text-xl">add</span>
                    <span>Add Department</span>
                </button>
            </div>

            <div class="mb-6 relative">
                <div class="relative">
                    <span class="material-icons absolute left-4 top-3 text-gray-400">search</span>
                    <input type="text" id="searchInput" placeholder="Search by code, name, or HOD..." class="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                <div id="suggestions" class="absolute w-full bg-white border border-gray-200 rounded-lg shadow-lg mt-1 hidden max-h-96 overflow-y-auto z-10"></div>
            </div>
            
            <div class="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-gray-50 border-b border-gray-200">
                            <tr>
                                <th class="px-4 sm:px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">ID</th>
                                <th class="px-4 sm:px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Code</th>
                                <th class="px-4 sm:px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Name</th>
                                <th class="px-4 sm:px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider hidden sm:table-cell">HOD</th>
                                <th class="px-4 sm:px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200" id="tableBody">
                            <?php foreach($departments as $d): ?>
                            <?php 
                            $isNew = (strtotime($d['created_at']) > strtotime('-24 hours'));
                            $isEdited = ($d['updated_at'] > $d['created_at']);
                            ?>
                            <tr class="hover:bg-gray-50 transition department-row" id="row-<?= $d['id'] ?>">
                                <td class="px-4 sm:px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <div class="flex items-center gap-2">
                                        <?= $d['id'] ?>
                                        <?php if($isNew && !$isEdited): ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                                            <span class="material-icons text-xs mr-1">fiber_new</span>
                                            New
                                        </span>
                                        <?php endif; ?>
                                        <?php if($isEdited): ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                                            <span class="material-icons text-xs mr-1">edit</span>
                                            Updated
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="px-4 sm:px-6 py-4 whitespace-nowrap">
                                    <span class="inline-flex items-center px-2 py-1 rounded text-sm font-medium bg-purple-100 text-purple-800"><?= $d['code'] ?></span>
                                </td>
                                <td class="px-4 sm:px-6 py-4">
                                    <div class="text-sm font-medium text-gray-900"><?= $d['name'] ?></div>
                                    <?php if($isEdited): ?>
                                    <div class="text-xs text-gray-500 mt-1">Updated: <?= date('M d, Y H:i', strtotime($d['updated_at'])) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 sm:px-6 py-4 whitespace-nowrap text-sm text-gray-600 hidden sm:table-cell"><?= $d['hod'] ?: 'Not Assigned' ?></td>
                                <td class="px-4 sm:px-6 py-4 whitespace-nowrap text-sm">
                                    <button onclick='editDepartment(<?= json_encode($d) ?>)' class="inline-flex items-center gap-1 text-blue-600 hover:text-blue-800 mr-2 sm:mr-3">
                                        <span class="material-icons text-lg">edit</span>
                                    </button>
                                    <a href="?action=delete&id=<?= $d['id'] ?>" onclick="return confirm('Are you sure?');" class="inline-flex items-center gap-1 text-red-600 hover:text-red-800">
                                        <span class="material-icons text-lg">delete</span>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(count($departments)==0): ?>
                            <tr id="emptyRow">
                                <td colspan="5" class="px-4 sm:px-6 py-12 text-center text-gray-500">
                                    <span class="material-icons text-5xl text-gray-300 mb-2">domain</span>
                                    <div>No departments found.</div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<div id="modal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div class="flex items-center justify-between px-4 sm:px-6 py-4 border-b border-gray-200">
            <h2 id="modalTitle" class="text-lg sm:text-xl font-medium text-gray-800">Add Department</h2>
            <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                <span class="material-icons">close</span>
            </button>
        </div>
        
        <form method="POST" id="departmentForm" class="p-4 sm:p-6">
            <input type="hidden" name="id" id="dept_id">
            
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Department Code *</label>
                    <input type="text" name="code" id="code" required class="val-dept-code w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Department Name *</label>
                    <input type="text" name="name" id="dept_name" required class="val-dept-name w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Head of Department</label>
                    <input type="text" name="hod" id="hod" class="val-username w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
            </div>

            <div class="mt-6 flex gap-3 justify-end">
                <button type="button" onclick="closeModal()" class="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded font-medium">Cancel</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
const departmentsData = <?= json_encode($departments) ?>;

function openModal(action, dept = null) {
    document.getElementById('modal').classList.remove('hidden');
    document.getElementById('modal').classList.add('flex');
    document.getElementById('modalTitle').textContent = action === 'add' ? 'Add Department' : 'Edit Department';
    document.getElementById('departmentForm').action = '?action=' + action;
    
    if(action === 'add') {
        document.getElementById('departmentForm').reset();
        document.getElementById('dept_id').value = '';
    } else if(dept) {
        document.getElementById('dept_id').value = dept.id;
        document.getElementById('code').value = dept.code;
        document.getElementById('dept_name').value = dept.name;
        document.getElementById('hod').value = dept.hod || '';
    }
}

function closeModal() {
    document.getElementById('modal').classList.add('hidden');
    document.getElementById('modal').classList.remove('flex');
}

function editDepartment(dept) {
    openModal('edit', dept);
}

window.onclick = function(event) {
    const modal = document.getElementById('modal');
    if (event.target === modal) {
        closeModal();
    }
}

const searchInput = document.getElementById('searchInput');
const suggestions = document.getElementById('suggestions');
const tableBody = document.getElementById('tableBody');

searchInput.addEventListener('input', function() {
    const query = this.value.toLowerCase().trim();
    
    if(query === '') {
        suggestions.classList.add('hidden');
        showAllRows();
        return;
    }
    
    const filtered = departmentsData.filter(d => 
        d.code.toLowerCase().includes(query) ||
        d.name.toLowerCase().includes(query) ||
        (d.hod && d.hod.toLowerCase().includes(query))
    );
    
    if(filtered.length > 0) {
        suggestions.innerHTML = filtered.map(d => `
            <div class="px-4 py-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 flex items-center gap-3" onclick='selectDepartment(${d.id})'>
                <span class="material-icons text-gray-400">domain</span>
                <div class="flex-1">
                    <div class="font-medium text-gray-900">${d.name}</div>
                    <div class="text-sm text-gray-500">${d.code} ${d.hod ? '• ' + d.hod : ''}</div>
                </div>
            </div>
        `).join('');
        suggestions.classList.remove('hidden');
    } else {
        suggestions.innerHTML = '<div class="px-4 py-3 text-gray-500 text-center">No results found</div>';
        suggestions.classList.remove('hidden');
    }
    
    filterTable(query);
});

function selectDepartment(id) {
    const row = document.getElementById('row-' + id);
    if(row) {
        row.scrollIntoView({ behavior: 'smooth', block: 'center' });
        row.classList.add('bg-blue-50');
        setTimeout(() => {
            row.classList.remove('bg-blue-50');
        }, 2000);
    }
    suggestions.classList.add('hidden');
    searchInput.value = '';
    showAllRows();
}

function filterTable(query) {
    const rows = document.querySelectorAll('.department-row');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        if(text.includes(query)) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });
    
    const emptyRow = document.getElementById('emptyRow');
    if(emptyRow) {
        emptyRow.style.display = visibleCount === 0 ? '' : 'none';
    }
}

function showAllRows() {
    const rows = document.querySelectorAll('.department-row');
    rows.forEach(row => row.style.display = '');
    const emptyRow = document.getElementById('emptyRow');
    if(emptyRow) {
        emptyRow.style.display = rows.length === 0 ? '' : 'none';
    }
}

document.addEventListener('click', function(e) {
    if(!searchInput.contains(e.target) && !suggestions.contains(e.target)) {
        suggestions.classList.add('hidden');
    }
});
</script>
<script>
    $(document).ready(function(){
$("#searchInput").focus();
    });
</script>
</body>
</html>