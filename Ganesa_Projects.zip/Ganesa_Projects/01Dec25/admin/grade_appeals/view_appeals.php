<?php
session_start();
require_once '../../config/db.php';

// Admin access only
if(!isset($_SESSION['role']) || $_SESSION['role']!=='admin'){
    header("Location: ../../public/index.php");
    exit;
}

// Handle status update
if(isset($_GET['action'], $_GET['id'])){
    $id = (int)$_GET['id'];
    if($_GET['action'] === 'approve'){
        $conn->query("UPDATE grade_appeals SET status='Approved' WHERE id=$id");
    } elseif($_GET['action'] === 'reject'){
        $conn->query("UPDATE grade_appeals SET status='Rejected' WHERE id=$id");
    }
}

// Fetch all appeals
$appeals = $conn->query("SELECT ga.*, s.name as student_name, sub.subject_name 
                        FROM grade_appeals ga
                        JOIN students s ON ga.reg_no=s.reg_no
                        JOIN subjects sub ON ga.subject_id=sub.id
                        ORDER BY ga.submitted_at DESC")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Grade Appeals</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<div class="flex min-h-screen">
<!-- <?php include '../includes/sidebar_admin.php'; ?> -->
<div class="flex-1 p-6">

<h1 class="text-3xl font-bold mb-6">Grade Appeal Requests</h1>

<div class="bg-white p-6 rounded shadow overflow-x-auto">
    <table class="w-full border border-gray-300">
        <thead>
            <tr class="bg-gray-200">
                <th class="border px-2 py-1">ID</th>
                <th class="border px-2 py-1">Student Name</th>
                <th class="border px-2 py-1">Reg No</th>
                <th class="border px-2 py-1">Subject</th>
                <th class="border px-2 py-1">Current Grade</th>
                <th class="border px-2 py-1">Reason</th>
                <th class="border px-2 py-1">Status</th>
                <th class="border px-2 py-1">Submitted At</th>
                <th class="border px-2 py-1">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($appeals as $app): ?>
            <tr>
                <td class="border px-2 py-1"><?= $app['id'] ?></td>
                <td class="border px-2 py-1"><?= $app['student_name'] ?></td>
                <td class="border px-2 py-1"><?= $app['reg_no'] ?></td>
                <td class="border px-2 py-1"><?= $app['subject_name'] ?></td>
                <td class="border px-2 py-1"><?= $app['current_grade'] ?></td>
                <td class="border px-2 py-1"><?= $app['reason'] ?></td>
                <td class="border px-2 py-1">
                    <?php if($app['status']=='Pending'): ?>
                        <span class="px-2 py-1 bg-yellow-200 text-yellow-800 rounded">Pending</span>
                    <?php elseif($app['status']=='Approved'): ?>
                        <span class="px-2 py-1 bg-green-200 text-green-800 rounded">Approved</span>
                    <?php else: ?>
                        <span class="px-2 py-1 bg-red-200 text-red-800 rounded">Rejected</span>
                    <?php endif; ?>
                </td>
                <td class="border px-2 py-1"><?= $app['submitted_at'] ?></td>
                <td class="border px-2 py-1">
                    <?php if($app['status']=='Pending'): ?>
                        <a href="?action=approve&id=<?= $app['id'] ?>" class="px-2 py-1 bg-green-600 text-white rounded hover:bg-green-700">Approve</a>
                        <a href="?action=reject&id=<?= $app['id'] ?>" class="px-2 py-1 bg-red-600 text-white rounded hover:bg-red-700">Reject</a>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</div>
</div>
</body>
</html>
