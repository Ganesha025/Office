<?php
session_start();
require_once '../../config/db.php';
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
header("Location: ../../public/index.php");
exit;
}
$action = $_GET['action'] ?? 'list';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
if(isset($_POST['ajax_update'])){
header('Content-Type: application/json');
$id = $_POST['id'];
$reg_no = $_POST['reg_no'];
$subject_id = $_POST['subject_id'];
$total_days = $_POST['total_days'];
$present_days = $_POST['present_days'];
$attendance_percentage = ($total_days>0) ? ($present_days/$total_days)*100 : 0;
$check = $conn->prepare("SELECT id FROM attendance WHERE reg_no=? AND subject_id=? AND id!=?");
$check->bind_param("sii", $reg_no, $subject_id, $id);
$check->execute();
if($check->get_result()->num_rows > 0){
echo json_encode(['success' => false, 'message' => 'Duplicate record: This student already has attendance for this subject']);
exit;
}
$stmt = $conn->prepare("UPDATE attendance SET reg_no=?, subject_id=?, total_days=?, present_days=?, attendance_percentage=? WHERE id=?");
$stmt->bind_param("siiidi", $reg_no, $subject_id, $total_days, $present_days, $attendance_percentage, $id);
if($stmt->execute()){
echo json_encode(['success' => true]);
} else {
echo json_encode(['success' => false, 'message' => 'Failed to update record']);
}
exit;
}
$reg_no = $_POST['reg_no'];
$subject_id = $_POST['subject_id'];
$total_days = $_POST['total_days'];
$present_days = $_POST['present_days'];
$attendance_percentage = ($total_days>0) ? ($present_days/$total_days)*100 : 0;
if($action === 'add'){
$check = $conn->prepare("SELECT id FROM attendance WHERE reg_no=? AND subject_id=?");
$check->bind_param("si", $reg_no, $subject_id);
$check->execute();
if($check->get_result()->num_rows === 0){
$stmt = $conn->prepare("INSERT INTO attendance (reg_no, subject_id, total_days, present_days, attendance_percentage) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("siiid", $reg_no, $subject_id, $total_days, $present_days, $attendance_percentage);
$stmt->execute();
header("Location: attendance.php");
exit;
} else {
$_SESSION['error'] = 'Duplicate record: This student already has attendance for this subject';
header("Location: attendance.php?action=add");
exit;
}
}
if($action === 'edit'){
$id = $_POST['id'];
$check = $conn->prepare("SELECT id FROM attendance WHERE reg_no=? AND subject_id=? AND id!=?");
$check->bind_param("sii", $reg_no, $subject_id, $id);
$check->execute();
if($check->get_result()->num_rows === 0){
$stmt = $conn->prepare("UPDATE attendance SET reg_no=?, subject_id=?, total_days=?, present_days=?, attendance_percentage=? WHERE id=?");
$stmt->bind_param("siiidi", $reg_no, $subject_id, $total_days, $present_days, $attendance_percentage, $id);
$stmt->execute();
header("Location: attendance.php");
exit;
} else {
$_SESSION['error'] = 'Duplicate record: This student already has attendance for this subject';
header("Location: attendance.php?action=edit&id=".$id);
exit;
}
}
}
if($action === 'delete'){
$id = $_GET['id'];
$stmt = $conn->prepare("DELETE FROM attendance WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
header("Location: attendance.php");
exit;
}
$record = null;
if(in_array($action, ['view','edit'])){
$id = $_GET['id'];
$stmt = $conn->prepare("SELECT a.*, s.name AS student_name, sub.subject_name FROM attendance a
JOIN students s ON a.reg_no=s.reg_no
JOIN subjects sub ON a.subject_id=sub.id
WHERE a.id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$record = $stmt->get_result()->fetch_assoc();
}
$records = [];
if($action === 'list'){
$res = $conn->query("SELECT a.*, s.name AS student_name, sub.subject_name FROM attendance a
JOIN students s ON a.reg_no=s.reg_no
JOIN subjects sub ON a.subject_id=sub.id
ORDER BY a.id DESC");
$records = $res->fetch_all(MYSQLI_ASSOC);
}
$students = $conn->query("SELECT reg_no, name FROM students ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
$subjects = $conn->query("SELECT id, subject_name FROM subjects ORDER BY subject_name ASC")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Attendance Management</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
* {
  font-family: 'Inter', sans-serif;
}
.material-symbols-outlined {
  font-variation-settings:
  'FILL' 0,
  'wght' 400,
  'GRAD' 0,
  'opsz' 24
}
.custom-rounded {
  border-radius: 25px;
}
.custom-shadow {
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
}
.hover-scale {
  transition: all 0.3s ease;
}
.hover-scale:hover {
  transform: translateY(-2px);
  box-shadow: 0 15px 40px rgba(0, 0, 0, 0.12);
}
</style>
</head>
<body class="bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
<div class="flex min-h-screen">
<div class="flex-1 p-8">
<?php if(isset($_SESSION['error'])): ?>
<div class="bg-red-50 border-2 border-red-200 text-red-700 px-6 py-4 custom-rounded mb-6 flex items-center custom-shadow">
<span class="material-symbols-outlined mr-3 text-red-500">error</span>
<div><?= $_SESSION['error'] ?></div>
</div>
<?php unset($_SESSION['error']); ?>
<?php endif; ?>

<?php if($action === 'list'): ?>
<div class="bg-white custom-rounded custom-shadow p-8 mb-6">
<div class="flex items-center justify-between mb-8">
<div class="flex items-center">
<span class="material-symbols-outlined text-4xl text-blue-600 mr-4">fact_check</span>
<h1 class="text-4xl font-bold text-gray-800">Attendance Records</h1>
</div>
<a href="?action=add" class="flex items-center px-6 py-3 bg-blue-600 text-white custom-rounded hover:bg-blue-700 hover-scale transition-all duration-300 font-medium">
<span class="material-symbols-outlined mr-2">add_circle</span>
Add New Record
</a>
</div>

<div class="overflow-hidden custom-rounded custom-shadow bg-white">
<table class="min-w-full">
<thead class="bg-slate-50">
<tr>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">tag</span>
ID
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">person</span>
Student
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">book</span>
Subject
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">calendar_month</span>
Total Days
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">check_circle</span>
Present Days
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">percent</span>
Attendance %
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">verified</span>
Status
</div>
</th>
<th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">
<div class="flex items-center">
<span class="material-symbols-outlined mr-2 text-slate-500">settings</span>
Actions
</div>
</th>
</tr>
</thead>
<tbody class="divide-y divide-gray-100">
<?php foreach($records as $r): ?>
<tr class="hover:bg-slate-50 transition-colors duration-200" data-id="<?= $r['id'] ?>">
<td class="px-6 py-4 whitespace-nowrap">
<div class="flex items-center">
<span class="inline-flex items-center justify-center w-8 h-8 bg-blue-100 text-blue-800 custom-rounded text-sm font-medium">
<?= $r['id'] ?>
</span>
</div>
</td>
<td class="px-6 py-4 student-cell" data-reg="<?= $r['reg_no'] ?>">
<span class="display-mode flex items-center">
<span class="material-symbols-outlined mr-3 text-blue-500">account_circle</span>
<div>
<div class="font-medium text-gray-900"><?= $r['student_name'] ?></div>
<div class="text-sm text-gray-500"><?= $r['reg_no'] ?></div>
</div>
</span>
<select class="edit-mode hidden w-full p-3 border-2 border-gray-200 custom-rounded student-select focus:border-blue-500 focus:outline-none">
<?php foreach($students as $s): ?>
<option value="<?= $s['reg_no'] ?>" <?= $r['reg_no']==$s['reg_no']?'selected':'' ?>><?= $s['name'] ?> (<?= $s['reg_no'] ?>)</option>
<?php endforeach; ?>
</select>
</td>
<td class="px-6 py-4 subject-cell" data-subject="<?= $r['subject_id'] ?>">
<span class="display-mode flex items-center">
<span class="material-symbols-outlined mr-3 text-green-500">menu_book</span>
<span class="font-medium text-gray-900"><?= $r['subject_name'] ?></span>
</span>
<select class="edit-mode hidden w-full p-3 border-2 border-gray-200 custom-rounded subject-select focus:border-blue-500 focus:outline-none">
<?php foreach($subjects as $sub): ?>
<option value="<?= $sub['id'] ?>" <?= $r['subject_id']==$sub['id']?'selected':'' ?>><?= $sub['subject_name'] ?></option>
<?php endforeach; ?>
</select>
</td>
<td class="px-6 py-4 total-cell">
<span class="display-mode flex items-center">
<span class="inline-flex items-center justify-center w-10 h-10 bg-purple-100 text-purple-800 custom-rounded font-semibold">
<?= $r['total_days'] ?>
</span>
</span>
<input type="number" class="edit-mode hidden w-24 p-3 border-2 border-gray-200 custom-rounded total-input focus:border-blue-500 focus:outline-none" value="<?= $r['total_days'] ?>" min="0">
</td>
<td class="px-6 py-4 present-cell">
<span class="display-mode flex items-center">
<span class="inline-flex items-center justify-center w-10 h-10 bg-green-100 text-green-800 custom-rounded font-semibold">
<?= $r['present_days'] ?>
</span>
</span>
<input type="number" class="edit-mode hidden w-24 p-3 border-2 border-gray-200 custom-rounded present-input focus:border-blue-500 focus:outline-none" value="<?= $r['present_days'] ?>" min="0">
</td>
<td class="px-6 py-4 percentage-display">
<span class="inline-flex items-center px-4 py-2 custom-rounded text-sm font-semibold <?= $r['attendance_percentage']<75?'bg-red-100 text-red-800':'bg-green-100 text-green-800' ?>">
<?= number_format($r['attendance_percentage'],1) ?>%
</span>
</td>
<td class="px-6 py-4 status-display">
<span class="inline-flex items-center px-4 py-2 custom-rounded text-sm font-semibold <?= $r['attendance_percentage']<75?'bg-red-100 text-red-800':'bg-green-100 text-green-800' ?>">
<span class="material-symbols-outlined mr-1 text-sm"><?= $r['attendance_percentage']<75?'cancel':'check_circle' ?></span>
<?= $r['attendance_percentage']<75?'Not Eligible':'Eligible' ?>
</span>
</td>
<td class="px-6 py-4">
<div class="flex items-center space-x-2">
<button class="edit-btn flex items-center px-4 py-2 bg-amber-500 text-white custom-rounded hover:bg-amber-600 hover-scale transition-all duration-200">
<span class="material-symbols-outlined mr-1 text-sm">edit</span>
Edit
</button>
<button class="save-btn hidden flex items-center px-4 py-2 bg-green-500 text-white custom-rounded hover:bg-green-600 hover-scale transition-all duration-200">
<span class="material-symbols-outlined mr-1 text-sm">save</span>
Save
</button>
<button class="cancel-btn hidden flex items-center px-4 py-2 bg-gray-500 text-white custom-rounded hover:bg-gray-600 hover-scale transition-all duration-200">
<span class="material-symbols-outlined mr-1 text-sm">cancel</span>
Cancel
</button>
<a href="?action=delete&id=<?= $r['id'] ?>" onclick="return confirm('Are you sure you want to delete this record?');" class="delete-btn flex items-center px-4 py-2 bg-red-500 text-white custom-rounded hover:bg-red-600 hover-scale transition-all duration-200">
<span class="material-symbols-outlined mr-1 text-sm">delete</span>
Delete
</a>
</div>
</td>
</tr>
<?php endforeach; ?>
<?php if(count($records)==0): ?>
<tr>
<td colspan="8" class="px-6 py-12 text-center">
<div class="flex flex-col items-center">
<span class="material-symbols-outlined text-6xl text-gray-300 mb-4">inbox</span>
<p class="text-gray-500 text-lg">No attendance records found.</p>
<p class="text-gray-400 text-sm mt-2">Start by adding your first attendance record.</p>
</div>
</td>
</tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

<script>
$(document).ready(function(){
$('.edit-btn').click(function(){
var row = $(this).closest('tr');
row.find('.display-mode').addClass('hidden');
row.find('.edit-mode').removeClass('hidden');
$(this).addClass('hidden');
row.find('.save-btn, .cancel-btn').removeClass('hidden');
row.find('.delete-btn').addClass('hidden');
});
$('.cancel-btn').click(function(){
var row = $(this).closest('tr');
row.find('.edit-mode').addClass('hidden');
row.find('.display-mode').removeClass('hidden');
row.find('.edit-btn, .delete-btn').removeClass('hidden');
row.find('.save-btn, .cancel-btn').addClass('hidden');
});
$('.total-input, .present-input').on('input', function(){
var row = $(this).closest('tr');
var total = parseInt(row.find('.total-input').val()) || 0;
var present = parseInt(row.find('.present-input').val()) || 0;
if(present > total) {
row.find('.present-input').val(total);
present = total;
}
});
$('.save-btn').click(function(){
var row = $(this).closest('tr');
var id = row.data('id');
var reg_no = row.find('.student-select').val();
var subject_id = row.find('.subject-select').val();
var total_days = row.find('.total-input').val();
var present_days = row.find('.present-input').val();
$.post('attendance.php', {
ajax_update: true,
id: id,
reg_no: reg_no,
subject_id: subject_id,
total_days: total_days,
present_days: present_days
}, function(response){
if(response.success){
location.reload();
} else {
alert(response.message);
}
}, 'json');
});
});
</script>

<?php elseif($action === 'add' || $action === 'edit'): ?>
<div class="max-w-2xl mx-auto">
<div class="bg-white custom-rounded custom-shadow p-8">
<div class="flex items-center mb-8">
<span class="material-symbols-outlined text-4xl text-blue-600 mr-4"><?= $action === 'add' ? 'add_circle' : 'edit' ?></span>
<h1 class="text-4xl font-bold text-gray-800"><?= ucfirst($action) ?> Attendance Record</h1>
</div>

<form method="POST" class="space-y-6">
<?php if($action==='edit'): ?>
<input type="hidden" name="id" value="<?= $record['id'] ?>">
<?php endif; ?>

<div>
<label class="flex items-center text-lg font-semibold text-gray-700 mb-3">
<span class="material-symbols-outlined mr-2 text-blue-500">person</span>
Student
</label>
<select name="reg_no" required class="w-full p-4 border-2 border-gray-200 custom-rounded focus:border-blue-500 focus:outline-none transition-colors duration-200">
<option value="">Select a student...</option>
<?php foreach($students as $s): ?>
<option value="<?= $s['reg_no'] ?>" <?= ($record['reg_no'] ?? '')==$s['reg_no']?'selected':'' ?>><?= $s['name'] ?> (<?= $s['reg_no'] ?>)</option>
<?php endforeach; ?>
</select>
</div>

<div>
<label class="flex items-center text-lg font-semibold text-gray-700 mb-3">
<span class="material-symbols-outlined mr-2 text-green-500">book</span>
Subject
</label>
<select name="subject_id" required class="w-full p-4 border-2 border-gray-200 custom-rounded focus:border-blue-500 focus:outline-none transition-colors duration-200">
<option value="">Select a subject...</option>
<?php foreach($subjects as $sub): ?>
<option value="<?= $sub['id'] ?>" <?= ($record['subject_id'] ?? '')==$sub['id']?'selected':'' ?>><?= $sub['subject_name'] ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
<div>
<label class="flex items-center text-lg font-semibold text-gray-700 mb-3">
<span class="material-symbols-outlined mr-2 text-purple-500">calendar_month</span>
Total Days
</label>
<input type="number" name="total_days" id="total_days" required value="<?= $record['total_days'] ?? 0 ?>" min="0" class="w-full p-4 border-2 border-gray-200 custom-rounded focus:border-blue-500 focus:outline-none transition-colors duration-200">
</div>

<div>
<label class="flex items-center text-lg font-semibold text-gray-700 mb-3">
<span class="material-symbols-outlined mr-2 text-green-500">check_circle</span>
Present Days
</label>
<input type="number" name="present_days" id="present_days" required value="<?= $record['present_days'] ?? 0 ?>" min="0" class="w-full p-4 border-2 border-gray-200 custom-rounded focus:border-blue-500 focus:outline-none transition-colors duration-200">
</div>
</div>

<div class="bg-slate-50 p-6 custom-rounded">
<div class="flex items-center justify-between">
<span class="flex items-center text-lg font-semibold text-gray-700">
<span class="material-symbols-outlined mr-2 text-blue-500">percent</span>
Attendance Percentage
</span>
<span class="text-3xl font-bold text-blue-600" id="attendance_pct"><?= number_format($record['attendance_percentage'] ?? 0, 1) ?></span>%
</div>
</div>

<div class="flex items-center space-x-4 pt-6">
<button type="submit" class="flex items-center px-8 py-4 bg-blue-600 text-white custom-rounded hover:bg-blue-700 hover-scale transition-all duration-300 font-semibold text-lg">
<span class="material-symbols-outlined mr-2"><?= $action === 'add' ? 'add_circle' : 'save' ?></span>
<?= $action === 'add' ? 'Add Record' : 'Update Record' ?>
</button>
<a href="attendance.php" class="flex items-center px-8 py-4 bg-gray-500 text-white custom-rounded hover:bg-gray-600 hover-scale transition-all duration-300 font-semibold text-lg">
<span class="material-symbols-outlined mr-2">arrow_back</span>
Cancel
</a>
</div>
</form>
</div>
</div>

<script>
function updatePercentage(){
let total = parseInt($('#total_days').val()) || 0;
let present = parseInt($('#present_days').val()) || 0;
if(present > total) {
$('#present_days').val(total);
present = total;
}
let pct = total>0 ? ((present/total)*100).toFixed(1) : 0;
$('#attendance_pct').text(pct);
}
$('#total_days, #present_days').on('input', updatePercentage);
</script>

<?php elseif($action === 'view'): ?>
<div class="max-w-2xl mx-auto">
<div class="bg-white custom-rounded custom-shadow p-8">
<div class="flex items-center mb-8">
<span class="material-symbols-outlined text-4xl text-blue-600 mr-4">visibility</span>
<h1 class="text-4xl font-bold text-gray-800">View Attendance Record</h1>
</div>

<div class="space-y-6">
<div class="flex items-center p-4 bg-slate-50 custom-rounded">
<span class="material-symbols-outlined mr-4 text-blue-500">tag</span>
<div>
<span class="text-sm text-gray-500 uppercase tracking-wide">Record ID</span>
<div class="text-xl font-semibold text-gray-800"><?= $record['id'] ?></div>
</div>
</div>

<div class="flex items-center p-4 bg-slate-50 custom-rounded">
<span class="material-symbols-outlined mr-4 text-blue-500">account_circle</span>
<div>
<span class="text-sm text-gray-500 uppercase tracking-wide">Student</span>
<div class="text-xl font-semibold text-gray-800"><?= $record['student_name'] ?></div>
<div class="text-sm text-gray-600"><?= $record['reg_no'] ?></div>
</div>
</div>

<div class="flex items-center p-4 bg-slate-50 custom-rounded">
<span class="material-symbols-outlined mr-4 text-green-500">menu_book</span>
<div>
<span class="text-sm text-gray-500 uppercase tracking-wide">Subject</span>
<div class="text-xl font-semibold text-gray-800"><?= $record['subject_name'] ?></div>
</div>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
<div class="flex items-center p-4 bg-slate-50 custom-rounded">
<span class="material-symbols-outlined mr-4 text-purple-500">calendar_month</span>
<div>
<span class="text-sm text-gray-500 uppercase tracking-wide">Total Days</span>
<div class="text-2xl font-bold text-gray-800"><?= $record['total_days'] ?></div>
</div>
</div>

<div class="flex items-center p-4 bg-slate-50 custom-rounded">
<span class="material-symbols-outlined mr-4 text-green-500">check_circle</span>
<div>
<span class="text-sm text-gray-500 uppercase tracking-wide">Present Days</span>
<div class="text-2xl font-bold text-gray-800"><?= $record['present_days'] ?></div>
</div>
</div>
</div>

<div class="p-6 bg-blue-50 custom-rounded">
<div class="flex items-center justify-between">
<div class="flex items-center">
<span class="material-symbols-outlined mr-4 text-blue-600 text-2xl">percent</span>
<div>
<span class="text-sm text-blue-600 uppercase tracking-wide font-medium">Attendance Percentage</span>
<div class="text-4xl font-bold text-blue-700"><?= number_format($record['attendance_percentage'],1) ?>%</div>
</div>
</div>
</div>
</div>

<div class="p-6 <?= $record['attendance_percentage']<75?'bg-red-50':'bg-green-50' ?> custom-rounded">
<div class="flex items-center">
<span class="material-symbols-outlined mr-4 <?= $record['attendance_percentage']<75?'text-red-600':'text-green-600' ?> text-2xl"><?= $record['attendance_percentage']<75?'cancel':'verified' ?></span>
<div>
<span class="text-sm <?= $record['attendance_percentage']<75?'text-red-600':'text-green-600' ?> uppercase tracking-wide font-medium">Eligibility Status</span>
<div class="text-2xl font-bold <?= $record['attendance_percentage']<75?'text-red-700':'text-green-700' ?>"><?= $record['attendance_percentage']<75?'Not Eligible':'Eligible' ?></div>
</div>
</div>
</div>
</div>

<div class="mt-8">
<a href="attendance.php" class="flex items-center px-8 py-4 bg-gray-500 text-white custom-rounded hover:bg-gray-600 hover-scale transition-all duration-300 font-semibold text-lg w-fit">
<span class="material-symbols-outlined mr-2">arrow_back</span>
Back to Records
</a>
</div>
</div>
</div>
<?php endif; ?>
</div>
</div>
</body>
</html>