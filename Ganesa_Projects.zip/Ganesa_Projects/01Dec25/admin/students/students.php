<?php
session_start();
require_once '../../config/db.php';

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../../public/index.php");
    exit;
}

$action = $_GET['action'] ?? 'list';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $reg_no = $_POST['reg_no'];
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $department_id = $_POST['department_id'];
    $program_id = $_POST['program_id'];
    $semester_id = $_POST['semester_id'];
    $admission_year = $_POST['admission_year'];

    if($action === 'add'){
        $stmt = $conn->prepare("INSERT INTO students 
            (reg_no, name, dob, gender, department_id, program_id, semester_id, admission_year) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssiiii", $reg_no, $name, $dob, $gender, $department_id, $program_id, $semester_id, $admission_year);
        $stmt->execute();
        header("Location: students.php?added=1");
        exit;
    }

    if($action === 'edit'){
        $stmt = $conn->prepare("UPDATE students SET 
            name=?, dob=?, gender=?, department_id=?, program_id=?, semester_id=?, admission_year=? 
            WHERE reg_no=?");
        $stmt->bind_param("sssiiiis", $name, $dob, $gender, $department_id, $program_id, $semester_id, $admission_year, $reg_no);
        $stmt->execute();
        header("Location: students.php?edited=1");
        exit;
    }
}

if($action === 'delete'){
    $reg_no = $_GET['reg_no'];
    $conn->query("DELETE FROM students WHERE reg_no='$reg_no'");
    header("Location: students.php?deleted=1");
    exit;
}

$students = [];
$res = $conn->query("SELECT s.*, d.name as dept_name, p.program_name, sem.sem_number
    FROM students s
    LEFT JOIN departments d ON s.department_id=d.id
    LEFT JOIN programs p ON s.program_id=p.id
    LEFT JOIN semesters sem ON s.semester_id=sem.id
    ORDER BY s.admission_year DESC");
$students = $res->fetch_all(MYSQLI_ASSOC);

$departments = $conn->query("SELECT * FROM departments")->fetch_all(MYSQLI_ASSOC);
$programs = $conn->query("SELECT * FROM programs")->fetch_all(MYSQLI_ASSOC);
$semesters = $conn->query("SELECT * FROM semesters")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Students</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<script src="../valid.js"></script>
<link rel="stylesheet" href="../style.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<style>
    body { font-family: 'Roboto', sans-serif; }
</style>
</head>
<body class="bg-white">

<div class="flex min-h-screen">
    <div class="flex-1">

        <?php if(isset($_GET['edited'])): ?>
            <div class="mx-6 mt-6 bg-green-50 border-l-4 border-green-500 text-green-800 px-4 py-3 rounded flex items-center gap-2">
                <span class="material-icons text-green-600">check_circle</span>
                <span>Student updated successfully!</span>
            </div>
        <?php endif; ?>
        
        <?php if(isset($_GET['added'])): ?>
            <div class="mx-6 mt-6 bg-blue-50 border-l-4 border-blue-500 text-blue-800 px-4 py-3 rounded flex items-center gap-2">
                <span class="material-icons text-blue-600">check_circle</span>
                <span>Student added successfully!</span>
            </div>
        <?php endif; ?>
        
        <?php if(isset($_GET['deleted'])): ?>
            <div class="mx-6 mt-6 bg-red-50 border-l-4 border-red-500 text-red-800 px-4 py-3 rounded flex items-center gap-2">
                <span class="material-icons text-red-600">check_circle</span>
                <span>Student deleted successfully!</span>
            </div>
        <?php endif; ?>

        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <h1 class="text-2xl font-normal text-gray-800">Students</h1>
                <button onclick="openModal('add')" class="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 shadow-sm">
                    <span class="material-icons text-xl">add</span>
                    <span>Add Student</span>
                </button>
            </div>

            <div class="mb-6 relative">
                <div class="relative">
                    <span class="material-icons absolute left-4 top-3 text-gray-400">search</span>
                    <input type="text" id="searchInput" placeholder="Search by name, reg no, department, or program..." class="val-com-name w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                <div id="suggestions" class="absolute w-full bg-white border border-gray-200 rounded-lg shadow-lg mt-1 hidden max-h-96 overflow-y-auto z-10"></div>
            </div>
            
            <div class="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-gray-50 border-b border-gray-200">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Reg No</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Name</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">DOB</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Gender</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Department</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Program</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Semester</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Year</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200" id="tableBody">
                            <?php foreach($students as $s): ?>
                            <tr class="hover:bg-gray-50 transition student-row" id="row-<?= $s['reg_no'] ?>">
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?= $s['reg_no'] ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?= $s['name'] ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?= $s['dob'] ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?= $s['gender'] ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?= $s['dept_name'] ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?= $s['program_name'] ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?= $s['sem_number'] ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?= $s['admission_year'] ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm">
                                    <button onclick='editStudent(<?= json_encode($s) ?>)' class="inline-flex items-center gap-1 text-blue-600 hover:text-blue-800 mr-3">
                                        <span class="material-icons text-lg">edit</span>
                                    </button>
                                    <a href="?action=delete&reg_no=<?= $s['reg_no'] ?>" onclick="return confirm('Are you sure?');" class="inline-flex items-center gap-1 text-red-600 hover:text-red-800">
                                        <span class="material-icons text-lg">delete</span>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(count($students)==0): ?>
                            <tr id="emptyRow">
                                <td colspan="9" class="px-6 py-12 text-center text-gray-500">
                                    <span class="material-icons text-5xl text-gray-300 mb-2">group</span>
                                    <div>No students found.</div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<div id="modal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto m-4">
        <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200">
            <h2 id="modalTitle" class="text-xl font-medium text-gray-800">Add Student</h2>
            <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                <span class="material-icons">close</span>
            </button>
        </div>
        
        <form method="POST" id="studentForm" class="p-6">
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Reg No *</label>
                    <input type="text" name="reg_no" id="reg_no" required class="val-com-name w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                    <input type="text" name="name" id="name" required class="val-username w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">DOB *</label>
                    <input type="date" name="dob" id="dob" class="val-dob w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Gender *</label>
                    <select name="gender" id="gender" class="val-gender w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Department *</label>
                    <select name="department_id" id="department_id" class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                        <?php foreach($departments as $d): ?>
                            <option value="<?= $d['id'] ?>"><?= $d['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Program *</label>
                    <select name="program_id" id="program_id" class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                        <?php foreach($programs as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= $p['program_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Semester</label>
                    <select name="semester_id" id="semester_id" class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                        <?php foreach($semesters as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= $s['sem_number'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Admission Year *</label>
                    <input type="number" name="admission_year" id="admission_year" required class="val-year w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
            </div>

            <div class="mt-6 flex gap-3 justify-end">
                <button type="button" onclick="closeModal()" class="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded font-medium">Cancel</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium">Save</button>
            </div>
        </form>
    </div>
</div>
<script>
    $(document).ready(function(){
$("#searchInput").focus();
    });
</script>
<script>
const studentsData = <?= json_encode($students) ?>;

function openModal(action) {
    document.getElementById('modal').classList.remove('hidden');
    document.getElementById('modal').classList.add('flex');
    document.getElementById('modalTitle').textContent = action === 'add' ? 'Add Student' : 'Edit Student';
    document.getElementById('studentForm').action = '?action=' + action;
    if(action === 'add') {
        document.getElementById('studentForm').reset();
        document.getElementById('reg_no').readOnly = false;
    }
}

function closeModal() {
    document.getElementById('modal').classList.add('hidden');
    document.getElementById('modal').classList.remove('flex');
}

function editStudent(student) {
    openModal('edit');
    document.getElementById('reg_no').value = student.reg_no;
    document.getElementById('reg_no').readOnly = true;
    document.getElementById('name').value = student.name;
    document.getElementById('dob').value = student.dob;
    document.getElementById('gender').value = student.gender;
    document.getElementById('department_id').value = student.department_id;
    document.getElementById('program_id').value = student.program_id;
    document.getElementById('semester_id').value = student.semester_id;
    document.getElementById('admission_year').value = student.admission_year;
}

window.onclick = function(event) {
    const modal = document.getElementById('modal');
    if (event.target === modal) {
        closeModal();
    }
}

const searchInput = document.getElementById('searchInput');
const suggestions = document.getElementById('suggestions');
const tableBody = document.getElementById('tableBody');

searchInput.addEventListener('input', function() {
    const query = this.value.toLowerCase().trim();
    
    if(query === '') {
        suggestions.classList.add('hidden');
        showAllRows();
        return;
    }
    
    const filtered = studentsData.filter(s => 
        s.name.toLowerCase().includes(query) ||
        s.reg_no.toLowerCase().includes(query) ||
        (s.dept_name && s.dept_name.toLowerCase().includes(query)) ||
        (s.program_name && s.program_name.toLowerCase().includes(query))
    );
    
    if(filtered.length > 0) {
        suggestions.innerHTML = filtered.map(s => `
            <div class="px-4 py-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 flex items-center gap-3" onclick='selectStudent("${s.reg_no}")'>
                <span class="material-icons text-gray-400">person</span>
                <div class="flex-1">
                    <div class="font-medium text-gray-900">${s.name}</div>
                    <div class="text-sm text-gray-500">${s.reg_no} • ${s.dept_name || ''} • ${s.program_name || ''}</div>
                </div>
            </div>
        `).join('');
        suggestions.classList.remove('hidden');
    } else {
        suggestions.innerHTML = '<div class="px-4 py-3 text-gray-500 text-center">No results found</div>';
        suggestions.classList.remove('hidden');
    }
    
    filterTable(query);
});

function selectStudent(regNo) {
    const row = document.getElementById('row-' + regNo);
    if(row) {
        row.scrollIntoView({ behavior: 'smooth', block: 'center' });
        row.classList.add('bg-blue-50');
        setTimeout(() => {
            row.classList.remove('bg-blue-50');
        }, 2000);
    }
    suggestions.classList.add('hidden');
    searchInput.value = '';
    showAllRows();
}

function filterTable(query) {
    const rows = document.querySelectorAll('.student-row');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        if(text.includes(query)) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });
    
    const emptyRow = document.getElementById('emptyRow');
    if(emptyRow) {
        emptyRow.style.display = visibleCount === 0 ? '' : 'none';
    }
}

function showAllRows() {
    const rows = document.querySelectorAll('.student-row');
    rows.forEach(row => row.style.display = '');
    const emptyRow = document.getElementById('emptyRow');
    if(emptyRow) {
        emptyRow.style.display = rows.length === 0 ? '' : 'none';
    }
}

document.addEventListener('click', function(e) {
    if(!searchInput.contains(e.target) && !suggestions.contains(e.target)) {
        suggestions.classList.add('hidden');
    }
});
</script>

</body>
</html>