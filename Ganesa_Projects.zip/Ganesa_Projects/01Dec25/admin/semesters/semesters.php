<?php
session_start();
require_once '../../config/db.php';

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../../public/index.php");
    exit;
}

$action = $_GET['action'] ?? 'list';

if($action === 'ajax_update'){
    $id = $_POST['id'];
    $program_id = $_POST['program_id'];
    $sem_number = $_POST['sem_number'];
    $stmt = $conn->prepare("UPDATE semesters SET program_id=?, sem_number=?, updated_at=NOW() WHERE id=?");
    $stmt->bind_param("iii", $program_id, $sem_number, $id);
    $stmt->execute();
    echo "success";
    exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add'){
    $program_id = $_POST['program_id'];
    $sem_number = $_POST['sem_number'];
    $stmt = $conn->prepare("INSERT INTO semesters (program_id, sem_number, updated_at) VALUES (?, ?, NOW())");
    $stmt->bind_param("ii", $program_id, $sem_number);
    $stmt->execute();
    header("Location: semesters.php?added=1");
    exit;
}

if($action === 'delete'){
    $id = $_GET['id'];
    $conn->query("DELETE FROM semesters WHERE id='$id'");
    header("Location: semesters.php?deleted=1");
    exit;
}

$semesters = [];
if($action === 'list'){
    $sql = "SELECT s.id, s.sem_number, s.program_id, p.program_name, s.updated_at,
            (SELECT MIN(updated_at) FROM semesters) as first_created
            FROM semesters s 
            JOIN programs p ON s.program_id = p.id 
            ORDER BY s.updated_at DESC, s.id DESC";
    $res = $conn->query($sql);
    if($res){
        $semesters = $res->fetch_all(MYSQLI_ASSOC);
    }
}

$programs = [];
$res_programs = $conn->query("SELECT * FROM programs ORDER BY program_name ASC");
$programs = $res_programs->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Semesters</title>
<script src="../valid.js"></script>
<link rel="stylesheet" href="../style.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<style>
body { font-family: 'Roboto', sans-serif; }
</style>
</head>
<body class="bg-white">

<div class="flex min-h-screen">
    <div class="flex-1">

        <?php if(isset($_GET['added'])): ?>
            <div class="mx-4 sm:mx-6 mt-6 bg-blue-50 border-l-4 border-blue-500 text-blue-800 px-4 py-3 rounded flex items-center gap-2">
                <span class="material-icons text-blue-600">check_circle</span>
                <span>Semester added successfully!</span>
            </div>
        <?php endif; ?>
        
        <?php if(isset($_GET['deleted'])): ?>
            <div class="mx-4 sm:mx-6 mt-6 bg-red-50 border-l-4 border-red-500 text-red-800 px-4 py-3 rounded flex items-center gap-2">
                <span class="material-icons text-red-600">check_circle</span>
                <span>Semester deleted successfully!</span>
            </div>
        <?php endif; ?>

        <div class="p-4 sm:p-6">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
                <h1 class="text-xl sm:text-2xl font-normal text-gray-800">Semesters</h1>
                <button id="openModal" class="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 shadow-sm w-full sm:w-auto justify-center">
                    <span class="material-icons text-xl">add</span>
                    <span>Add Semester</span>
                </button>
            </div>

            <div class="mb-6 relative">
                <div class="relative">
                    <span class="material-icons absolute left-4 top-3 text-gray-400">search</span>
                    <input type="text" id="searchInput" placeholder="Search by program name or semester number..." class="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                <div id="suggestions" class="absolute w-full bg-white border border-gray-200 rounded-lg shadow-lg mt-1 hidden max-h-96 overflow-y-auto z-10"></div>
            </div>
            
            <div class="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-gray-50 border-b border-gray-200">
                            <tr>
                                <th class="px-4 sm:px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">ID</th>
                                <th class="px-4 sm:px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Program</th>
                                <th class="px-4 sm:px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Semester</th>
                                <th class="px-4 sm:px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200" id="semesterTable">
                            <?php foreach($semesters as $index => $s): ?>
                            <?php 
                            $isNew = ($index === 0 && strtotime($s['updated_at']) > strtotime('-24 hours'));
                            ?>
                            <tr class="hover:bg-gray-50 transition semester-row" data-id="<?= $s['id'] ?>" id="row-<?= $s['id'] ?>">
                                <td class="px-4 sm:px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <div class="flex items-center gap-2">
                                        <?= $s['id'] ?>
                                        <?php if($isNew): ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                                            <span class="material-icons text-xs mr-1">fiber_new</span>
                                            New
                                        </span>
                                        <?php elseif($index === 0): ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                                            <span class="material-icons text-xs mr-1">update</span>
                                            Updated
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="px-4 sm:px-6 py-4">
                                    <span class="text-display text-sm font-medium text-gray-900"><?= $s['program_name'] ?></span>
                                    <select class="hidden px-3 py-2 border border-gray-300 rounded w-full focus:outline-none focus:ring-2 focus:ring-blue-500 edit-field" data-original="<?= $s['program_id'] ?>">
                                        <?php foreach($programs as $p): ?>
                                            <option value="<?= $p['id'] ?>" <?= $s['program_id']==$p['id']?'selected':'' ?>><?= $p['program_name'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td class="px-4 sm:px-6 py-4">
                                    <span class="text-display text-sm text-gray-600"><?= $s['sem_number'] ?></span>
                                    <input type="number" class="hidden px-3 py-2 border border-gray-300 rounded w-full focus:outline-none focus:ring-2 focus:ring-blue-500 edit-field" value="<?= $s['sem_number'] ?>">
                                </td>
                                <td class="px-4 sm:px-6 py-4 whitespace-nowrap text-sm">
                                    <div class="flex gap-2">
                                        <button class="inline-flex items-center gap-1 text-yellow-600 hover:text-yellow-800 edit-btn">
                                            <span class="material-icons text-lg">edit</span>
                                        </button>
                                        <button class="hidden inline-flex items-center gap-1 text-green-600 hover:text-green-800 save-btn">
                                            <span class="material-icons text-lg">save</span>
                                        </button>
                                        <button class="hidden inline-flex items-center gap-1 text-gray-600 hover:text-gray-800 cancel-btn">
                                            <span class="material-icons text-lg">close</span>
                                        </button>
                                        <a href="?action=delete&id=<?= $s['id'] ?>" onclick="return confirm('Are you sure?');" class="inline-flex items-center gap-1 text-red-600 hover:text-red-800 delete-btn">
                                            <span class="material-icons text-lg">delete</span>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(count($semesters)==0): ?>
                            <tr id="emptyRow">
                                <td colspan="4" class="px-4 sm:px-6 py-12 text-center text-gray-500">
                                    <span class="material-icons text-5xl text-gray-300 mb-2">school</span>
                                    <div>No semesters found.</div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<div id="semesterModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-lg shadow-2xl w-full max-w-md">
        <div class="flex items-center justify-between px-4 sm:px-6 py-4 border-b border-gray-200">
            <h2 class="text-lg sm:text-xl font-medium text-gray-800">Add Semester</h2>
            <button id="closeModalX" class="text-gray-400 hover:text-gray-600">
                <span class="material-icons">close</span>
            </button>
        </div>
        
        <form method="POST" action="semesters.php?action=add" class="p-4 sm:p-6">
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Program * </label>
                    <select name="program_id" required class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Select Program</option>
                        <?php foreach($programs as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= $p['program_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Semester Number *</label>
                    <input type="number" name="sem_number" required class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Enter semester number">
                </div>
            </div>

            <div class="mt-6 flex gap-3 justify-end">
                <button type="button" id="closeModal" class="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded font-medium">Cancel</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium">Save</button>
            </div>
        </form>
    </div>
</div>
<script>
    $(document).ready(function(){
$("#searchInput").focus();
    });
</script>
<script>
const semestersData = <?= json_encode($semesters) ?>;
const programsData = <?= json_encode($programs) ?>;

const modal = document.getElementById("semesterModal");
document.getElementById("openModal").onclick = () => { modal.classList.remove("hidden"); modal.classList.add("flex"); };
document.getElementById("closeModal").onclick = () => { modal.classList.add("hidden"); modal.classList.remove("flex"); };
document.getElementById("closeModalX").onclick = () => { modal.classList.add("hidden"); modal.classList.remove("flex"); };

window.onclick = function(event) {
    if (event.target === modal) {
        modal.classList.add("hidden");
        modal.classList.remove("flex");
    }
}

function attachRowEvents(row) {
    const editBtn = row.querySelector(".edit-btn");
    const saveBtn = row.querySelector(".save-btn");
    const cancelBtn = row.querySelector(".cancel-btn");
    const deleteBtn = row.querySelector(".delete-btn");

    editBtn.addEventListener("click", () => {
        row.querySelectorAll(".text-display").forEach(e => e.classList.add("hidden"));
        row.querySelectorAll(".edit-field").forEach(e => e.classList.remove("hidden"));
        saveBtn.classList.remove("hidden");
        cancelBtn.classList.remove("hidden");
        editBtn.classList.add("hidden");
        deleteBtn.classList.add("hidden");
    });

    cancelBtn.addEventListener("click", () => {
        row.querySelectorAll(".text-display").forEach(e => e.classList.remove("hidden"));
        row.querySelectorAll(".edit-field").forEach(e => e.classList.add("hidden"));
        editBtn.classList.remove("hidden");
        deleteBtn.classList.remove("hidden");
        saveBtn.classList.add("hidden");
        cancelBtn.classList.add("hidden");
        
        const fields = row.querySelectorAll(".edit-field");
        fields[0].value = fields[0].dataset.original;
    });

    saveBtn.addEventListener("click", () => {
        const id = row.dataset.id;
        const fields = row.querySelectorAll(".edit-field");
        const program_id = fields[0].value;
        const sem_number = fields[1].value;

        const formData = new FormData();
        formData.append("id", id);
        formData.append("program_id", program_id);
        formData.append("sem_number", sem_number);

        fetch("semesters.php?action=ajax_update", {
            method: "POST",
            body: formData
        }).then(r => r.text()).then(res => {
            if (res === "success") {
                const program_name = fields[0].options[fields[0].selectedIndex].text;
                row.querySelectorAll(".text-display")[0].innerText = program_name;
                row.querySelectorAll(".text-display")[1].innerText = sem_number;
                
                row.querySelectorAll(".text-display").forEach(e => e.classList.remove("hidden"));
                row.querySelectorAll(".edit-field").forEach(e => e.classList.add("hidden"));
                editBtn.classList.remove("hidden");
                deleteBtn.classList.remove("hidden");
                saveBtn.classList.add("hidden");
                cancelBtn.classList.add("hidden");
                
                const badges = row.querySelectorAll("span.inline-flex");
                badges.forEach(badge => badge.remove());
                
                const idCell = row.querySelector("td:first-child div");
                const newBadge = document.createElement("span");
                newBadge.className = "inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800";
                newBadge.innerHTML = '<span class="material-icons text-xs mr-1">update</span>Updated';
                idCell.appendChild(newBadge);
                
                const table = document.getElementById("semesterTable");
                table.prepend(row);
            }
        });
    });
}

document.querySelectorAll("#semesterTable tr[data-id]").forEach(tr => attachRowEvents(tr));

const searchInput = document.getElementById('searchInput');
const suggestions = document.getElementById('suggestions');

searchInput.addEventListener('input', function() {
    const query = this.value.toLowerCase().trim();
    
    if(query === '') {
        suggestions.classList.add('hidden');
        showAllRows();
        return;
    }
    
    const filtered = semestersData.filter(s => 
        s.program_name.toLowerCase().includes(query) ||
        s.sem_number.toString().includes(query)
    );
    
    if(filtered.length > 0) {
        suggestions.innerHTML = filtered.map(s => `
            <div class="px-4 py-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 flex items-center gap-3" onclick='selectSemester(${s.id})'>
                <span class="material-icons text-gray-400">school</span>
                <div class="flex-1">
                    <div class="font-medium text-gray-900">${s.program_name}</div>
                    <div class="text-sm text-gray-500">Semester ${s.sem_number}</div>
                </div>
            </div>
        `).join('');
        suggestions.classList.remove('hidden');
    } else {
        suggestions.innerHTML = '<div class="px-4 py-3 text-gray-500 text-center">No results found</div>';
        suggestions.classList.remove('hidden');
    }
    
    filterTable(query);
});

function selectSemester(id) {
    const row = document.getElementById('row-' + id);
    if(row) {
        row.scrollIntoView({ behavior: 'smooth', block: 'center' });
        row.classList.add('bg-blue-50');
        setTimeout(() => {
            row.classList.remove('bg-blue-50');
        }, 2000);
    }
    suggestions.classList.add('hidden');
    searchInput.value = '';
    showAllRows();
}

function filterTable(query) {
    const rows = document.querySelectorAll('.semester-row');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        if(text.includes(query)) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });
    
    const emptyRow = document.getElementById('emptyRow');
    if(emptyRow) {
        emptyRow.style.display = visibleCount === 0 ? '' : 'none';
    }
}

function showAllRows() {
    const rows = document.querySelectorAll('.semester-row');
    rows.forEach(row => row.style.display = '');
    const emptyRow = document.getElementById('emptyRow');
    if(emptyRow) {
        emptyRow.style.display = rows.length === 0 ? '' : 'none';
    }
}

document.addEventListener('click', function(e) {
    if(!searchInput.contains(e.target) && !suggestions.contains(e.target)) {
        suggestions.classList.add('hidden');
    }
});
</script>

</body>
</html>