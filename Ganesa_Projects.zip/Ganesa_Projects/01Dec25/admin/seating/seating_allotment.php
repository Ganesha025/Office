<?php
session_start();
require_once '../../config/db.php';

$rooms = $conn->query("SELECT * FROM rooms ORDER BY room_no ASC")->fetch_all(MYSQLI_ASSOC);
$students = $conn->query("SELECT reg_no FROM students ORDER BY reg_no ASC")->fetch_all(MYSQLI_ASSOC);

$allocation = [];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $exam_session = $_POST['exam_session'];

    $regNos = array_column($students, 'reg_no');
    shuffle($regNos);

    $i = 0;
    foreach ($rooms as $room) {
        for ($s = 1; $s <= $room['capacity'] && $i < count($regNos); $s++) {
            $allocation[] = [
                'room_id' => $room['id'],
                'room_no' => $room['room_no'],
                'reg_no' => $regNos[$i],
                'seat_no' => $s
            ];
            $i++;
        }
    }

    foreach ($allocation as $a) {
        $conn->query("INSERT INTO seating_allotment (room_id, reg_no, seat_no, exam_session)
            VALUES ('{$a['room_id']}', '{$a['reg_no']}', '{$a['seat_no']}', '$exam_session')");
    }

    $message = "Seating arrangement generated successfully.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Seating Allotment</title>
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- Clean font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>

<body class="bg-gray-100 min-h-screen p-6 ">
<div class="max-w-5xl mx-auto bg-white shadow-lg rounded-[40px] p-8 border border-gray-200">

    <!-- Header -->
    <div class="flex items-center gap-3 mb-8">
        <span class="material-icons text-blue-600 text-4xl">event_seat</span>
        <h1 class="text-3xl font-bold text-gray-800">Exam Seating Arrangement</h1>
    </div>

    <?php if ($message): ?>
        <div class="flex items-center gap-2 bg-green-50 text-green-700 border border-green-200 p-3 rounded-md mb-6">
            <span class="material-icons">check_circle</span>
            <p><?php echo $message; ?></p>
        </div>
    <?php endif; ?>

    <!-- FORM -->
    <form method="POST" class="mb-10">
        <label class="block mb-2 font-medium text-gray-700">Exam Session</label>
        <input type="text"
               name="exam_session"
               required
               class="border border-gray-300 p-3 rounded w-full focus:outline-none focus:border-blue-500 mb-4">

        <button class="flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-[40px] hover:bg-blue-700">
            <span class="material-icons">autorenew</span>
            Generate Seating
        </button>
    </form>

    <!-- Seating Chart -->
    <?php if (!empty($allocation)): ?>

        <div class="flex items-center gap-2 mb-6">
            <span class="material-icons text-gray-700">table_chart</span>
            <h2 class="text-2xl font-semibold text-gray-800">Seating Chart</h2>
        </div>

        <?php
        $grouped = [];
        foreach ($allocation as $a) {
            $grouped[$a['room_no']][] = $a;
        }
        ?>

        <?php foreach ($grouped as $room_no => $list): ?>
            <div class="bg-gray-50 rounded-lg p-5 shadow mb-8 border border-gray-200">

                <div class="flex items-center gap-2 mb-4">
                    <span class="material-icons text-indigo-600">meeting_room</span>
                    <h3 class="text-xl font-semibold text-indigo-700">Room: <?php echo $room_no; ?></h3>
                </div>

                <table class="w-full border border-gray-300 rounded-lg overflow-hidden">
                    <thead class="bg-gray-200 text-gray-700">
                    <tr>
                        <th class="border p-3">Seat No</th>
                        <th class="border p-3">Reg No</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($list as $row): ?>
                        <tr class="hover:bg-gray-100 transition">
                            <td class="border p-3 text-center"><?php echo $row['seat_no']; ?></td>
                            <td class="border p-3"><?php echo $row['reg_no']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

            </div>
        <?php endforeach; ?>

    <?php endif; ?>

</div>

</body>
</html>
