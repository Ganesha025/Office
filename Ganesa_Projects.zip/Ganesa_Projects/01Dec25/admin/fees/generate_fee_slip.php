<?php
session_start();
require_once '../../config/db.php';

// Admin access only
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../../public/index.php");
    exit;
}

// Session timeout & regeneration
if (!isset($_SESSION['last_activity']) || (time() - $_SESSION['last_activity'] > 900)) {
    session_regenerate_id(true);
}
$_SESSION['last_activity'] = time();

$students = $conn->query("SELECT reg_no, name FROM students ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
$categories = $conn->query("SELECT * FROM fee_categories ORDER BY category ASC")->fetch_all(MYSQLI_ASSOC);

$fee_slip = null;

// Handle form submission
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $reg_no = $_POST['reg_no'];
    $category_id = $_POST['category_id'];
    $tuition_fee = (int)$_POST['tuition_fee'];
    $exam_fee = (int)$_POST['exam_fee'];
    $lab_fee = (int)$_POST['lab_fee'];
    $mess_fee = isset($_POST['mess_fee']) ? (int)$_POST['mess_fee'] : 0;
    $hostel_fee = isset($_POST['hostel_fee']) ? (int)$_POST['hostel_fee'] : 0;

    $total = $tuition_fee + $exam_fee + $lab_fee + $mess_fee + $hostel_fee;

    $stmt = $conn->prepare("INSERT INTO fee_slips (reg_no, category_id, tuition_fee, exam_fee, lab_fee, mess_fee, hostel_fee, total) VALUES (?,?,?,?,?,?,?,?)");
    $stmt->bind_param("siiiiiii", $reg_no, $category_id, $tuition_fee, $exam_fee, $lab_fee, $mess_fee, $hostel_fee, $total);
    $stmt->execute();
    $fee_slip_id = $stmt->insert_id;

    // Fetch generated fee slip
    $fee_slip = $conn->query("
        SELECT fs.*, s.name as student_name, c.category 
        FROM fee_slips fs 
        JOIN students s ON fs.reg_no = s.reg_no 
        JOIN fee_categories c ON fs.category_id = c.id 
        WHERE fs.id = $fee_slip_id
    ")->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Generate Fee Slip</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
@media print {
    .no-print { display: none !important; }
    body { background: white !important; }
}
</style>
</head>
<body class="bg-gray-100">

<div class="flex min-h-screen">
<div class="flex-1 p-6">

<?php if($fee_slip): ?>
    <!-- Fee Slip Display -->
    <div class="bg-white p-8 rounded-lg shadow-xl max-w-2xl mx-auto">
        <div class="text-center mb-8">
            <h2 class="text-3xl font-bold text-gray-800">FEE SLIP</h2>
            <p class="text-sm text-gray-600 mt-2">Generated on <?= date('d M Y') ?></p>
        </div>
        
        <div class="grid grid-cols-2 gap-8 mb-8">
            <div>
                <p><strong class="text-lg">Student Name:</strong> <?= $fee_slip['student_name'] ?></p>
                <p><strong class="text-lg">Reg No:</strong> <?= $fee_slip['reg_no'] ?></p>
                <p><strong class="text-lg">Category:</strong> <?= $fee_slip['category'] ?></p>
            </div>
            <div class="text-right">
                <p><strong class="text-lg">Fee Slip ID:</strong> #<?= $fee_slip['id'] ?></p>
            </div>
        </div>
        
        <hr class="border-gray-300 mb-6">
        
        <div class="space-y-3 mb-8">
            <div class="flex justify-between py-2 border-b">
                <span>Tuition Fee</span>
                <span>₹<?= number_format($fee_slip['tuition_fee']) ?></span>
            </div>
            <div class="flex justify-between py-2 border-b">
                <span>Exam Fee</span>
                <span>₹<?= number_format($fee_slip['exam_fee']) ?></span>
            </div>
            <div class="flex justify-between py-2 border-b">
                <span>Lab Fee</span>
                <span>₹<?= number_format($fee_slip['lab_fee']) ?></span>
            </div>
            <?php if($fee_slip['mess_fee'] > 0): ?>
            <div class="flex justify-between py-2 border-b">
                <span>Mess Fee</span>
                <span>₹<?= number_format($fee_slip['mess_fee']) ?></span>
            </div>
            <div class="flex justify-between py-2 border-b">
                <span>Hostel Fee</span>
                <span>₹<?= number_format($fee_slip['hostel_fee']) ?></span>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="border-t-2 border-gray-800 pt-4">
            <div class="flex justify-between text-2xl font-bold">
                <span>Total Amount</span>
                <span>₹<?= number_format($fee_slip['total']) ?></span>
            </div>
        </div>
        
        <div class="no-print mt-8 text-center space-x-4">
            <button onclick="window.print()" class="px-8 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition duration-200 text-lg">🖨️ Print Fee Slip</button>
            <a href="" class="px-8 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition duration-200 text-lg">Generate New</a>
        </div>
    </div>
<?php else: ?>
    <!-- Fee Slip Form -->
    <h1 class="text-3xl font-bold mb-6">Generate Fee Slip</h1>
    <form method="POST" class="bg-white p-6 rounded shadow max-w-lg mx-auto">
        <label class="block mb-2 font-medium">Select Student:</label>
        <select name="reg_no" id="student_select" required class="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:ring-2 focus:ring-blue-500">
            <option value="">Select Student</option>
            <?php foreach($students as $s): ?>
                <option value="<?= $s['reg_no'] ?>"><?= $s['name'] ?> (<?= $s['reg_no'] ?>)</option>
            <?php endforeach; ?>
        </select>

        <label class="block mb-2 font-medium">Category:</label>
        <select name="category_id" id="category_select" required class="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:ring-2 focus:ring-blue-500">
            <option value="">Select Category</option>
            <?php foreach($categories as $c): ?>
                <option value="<?= $c['id'] ?>"><?= $c['category'] ?></option>
            <?php endforeach; ?>
        </select>

        <label class="block mb-2 font-medium">Tuition Fee:</label>
        <input type="number" name="tuition_fee" min="0" required class="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:ring-2 focus:ring-blue-500">

        <label class="block mb-2 font-medium">Exam Fee:</label>
        <input type="number" name="exam_fee" min="0" required class="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:ring-2 focus:ring-blue-500">

        <label class="block mb-2 font-medium">Lab Fee:</label>
        <input type="number" name="lab_fee" min="0" required class="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:ring-2 focus:ring-blue-500">

        <div id="hostel_fields" class="hidden">
            <label class="block mb-2 font-medium">Mess Fee:</label>
            <input type="number" name="mess_fee" min="0" class="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:ring-2 focus:ring-blue-500">

            <label class="block mb-2 font-medium">Hostel Fee:</label>
            <input type="number" name="hostel_fee" min="0" class="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:ring-2 focus:ring-blue-500">
        </div>

        <button type="submit" class="w-full px-4 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 transition duration-200">Generate Fee Slip</button>
    </form>
<?php endif; ?>

</div>
</div>

<script>
$(document).ready(function(){
    $("#category_select").change(function(){
        var selectedText = $(this).find("option:selected").text().toLowerCase();
        if(selectedText.includes("hostel") || selectedText.includes("hosteller")){
            $("#hostel_fields").slideDown();
        } else {
            $("#hostel_fields").slideUp();
            $('input[name="mess_fee"], input[name="hostel_fee"]').val(0);
        }
    });

    $('input[type="number"]').on('input', function(){
        $(this).val(Math.max(0, parseInt($(this).val()) || 0));
    });
});
</script>

</body>
</html>
