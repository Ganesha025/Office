<?php
session_start();
require_once '../config/db.php';

// Initialize messages
$login_error = '';
$signup_error = '';
$signup_success = '';

// Handle Login
if(isset($_POST['action']) && $_POST['action'] === 'login'){
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    $sql = "SELECT * FROM users WHERE username='$username' AND role='$role'";
    $result = $conn->query($sql);

    if($result->num_rows === 1){
        $user = $result->fetch_assoc();
        if(password_verify($password, $user['password'])){
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            // Redirect based on role
            if($role === 'admin'){
                header("Location: ../admin/dashboard.php");
            } else {
                header("Location: ../student/dashboard.php");
            }
            exit;
        } else {
            $login_error = "Invalid password!";
        }
    } else {
        $login_error = "User not found!";
    }
}

// Handle Signup
if(isset($_POST['action']) && $_POST['action'] === 'signup'){
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Check if user exists
    $check = $conn->query("SELECT * FROM users WHERE username='$username'");
    if($check->num_rows > 0){
        $signup_error = "Username already exists!";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $insert = $conn->query("INSERT INTO users (username, password, role) VALUES ('$username', '$hashed_password', '$role')");
        if($insert){
            $signup_success = "Signup successful! You can login now.";
        } else {
            $signup_error = "Signup failed: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>College Management - Login / Signup</title>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

<div class="w-full max-w-md bg-white rounded-lg shadow-lg p-8">
    <!-- Toggle Buttons -->
    <div class="flex justify-center mb-6">
        <button id="loginBtn" class="px-4 py-2 bg-blue-500 text-white rounded-l-lg focus:outline-none">Login</button>
        <button id="signupBtn" class="px-4 py-2 bg-gray-200 rounded-r-lg focus:outline-none">Signup</button>
    </div>

    <!-- Login Form -->
    <form id="loginForm" method="POST" class="space-y-4">
        <input type="hidden" name="action" value="login">
        <h2 class="text-2xl font-bold text-center">Login</h2>
        <?php if($login_error): ?>
            <p class="text-red-500 text-center"><?= $login_error ?></p>
        <?php endif; ?>
        <input type="text" name="username" placeholder="Username" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400">
        <input type="password" name="password" placeholder="Password" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400">
        <select name="role" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400">
            <option value="">Select Role</option>
            <option value="admin">Admin</option>
            <option value="student">Student</option>
        </select>
        <button type="submit" class="w-full bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">Login</button>
    </form>

    <!-- Signup Form -->
    <form id="signupForm" method="POST" class="space-y-4 hidden">
        <input type="hidden" name="action" value="signup">
        <h2 class="text-2xl font-bold text-center">Signup</h2>
        <?php if($signup_error): ?>
            <p class="text-red-500 text-center"><?= $signup_error ?></p>
        <?php endif; ?>
        <?php if($signup_success): ?>
            <p class="text-green-500 text-center"><?= $signup_success ?></p>
        <?php endif; ?>
        <input type="text" name="username" placeholder="Username" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-400">
        <input type="password" name="password" placeholder="Password" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-400">
        <select name="role" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-400">
            <option value="">Select Role</option>
            <option value="admin">Admin</option>
            <option value="student">Student</option>
        </select>
        <button type="submit" class="w-full bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600">Signup</button>
    </form>
</div>

<script>
$(document).ready(function(){
    $("#loginBtn").click(function(){
        $(this).addClass("bg-blue-500 text-white");
        $("#signupBtn").removeClass("bg-green-500 text-white").addClass("bg-gray-200 text-black");
        $("#loginForm").show();
        $("#signupForm").hide();
    });

    $("#signupBtn").click(function(){
        $(this).addClass("bg-green-500 text-white");
        $("#loginBtn").removeClass("bg-blue-500 text-white").addClass("bg-gray-200 text-black");
        $("#signupForm").show();
        $("#loginForm").hide();
    });

    // Show signup if signup was successful or has error
    <?php if($signup_error || $signup_success): ?>
        $("#signupBtn").click();
    <?php endif; ?>
    // Show login if login error
    <?php if($login_error): ?>
        $("#loginBtn").click();
    <?php endif; ?>
});
</script>

</body>
</html>
