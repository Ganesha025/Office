<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'college_management');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if not exists
$sql = "CREATE DATABASE IF NOT EXISTS " . DB_NAME;
if (!$conn->query($sql)) {
    die("Error creating database: " . $conn->error);
}

// Select database
$conn->select_db(DB_NAME);

// Function to create tables
function createTables($conn) {
    $tables = [
        // Users & Auth
        "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            role VARCHAR(20) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )",

        // Master Tables
        "CREATE TABLE IF NOT EXISTS departments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(20) UNIQUE NOT NULL,
            name VARCHAR(200) NOT NULL,
            hod VARCHAR(200)
        )",

        "CREATE TABLE IF NOT EXISTS programs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            program_name VARCHAR(100) NOT NULL,
            duration_years INT NOT NULL
        )",

        "CREATE TABLE IF NOT EXISTS semesters (
            id INT AUTO_INCREMENT PRIMARY KEY,
            program_id INT NOT NULL,
            sem_number INT NOT NULL,
            FOREIGN KEY (program_id) REFERENCES programs(id) ON DELETE CASCADE
        )",

        // Student Tables
        "CREATE TABLE IF NOT EXISTS students (
            reg_no VARCHAR(50) PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            dob DATE,
            gender VARCHAR(10),
            department_id INT,
            program_id INT,
            semester_id INT,
            admission_year INT,
            total_credits INT DEFAULT 0,
            status VARCHAR(20) DEFAULT 'active',
            FOREIGN KEY (department_id) REFERENCES departments(id),
            FOREIGN KEY (program_id) REFERENCES programs(id),
            FOREIGN KEY (semester_id) REFERENCES semesters(id)
        )",

        "CREATE TABLE IF NOT EXISTS parents (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reg_no VARCHAR(50) NOT NULL,
            father_name VARCHAR(200),
            mother_name VARCHAR(200),
            phone VARCHAR(20),
            address TEXT,
            FOREIGN KEY (reg_no) REFERENCES students(reg_no) ON DELETE CASCADE
        )",

        // Subjects & Electives
        "CREATE TABLE IF NOT EXISTS subjects (
            id INT AUTO_INCREMENT PRIMARY KEY,
            subject_code VARCHAR(20) UNIQUE NOT NULL,
            subject_name VARCHAR(200) NOT NULL,
            department_id INT,
            program_id INT,
            semester_id INT,
            credit INT DEFAULT 0,
            type VARCHAR(20),
            FOREIGN KEY (department_id) REFERENCES departments(id),
            FOREIGN KEY (program_id) REFERENCES programs(id),
            FOREIGN KEY (semester_id) REFERENCES semesters(id)
        )",

        "CREATE TABLE IF NOT EXISTS electives (
            id INT AUTO_INCREMENT PRIMARY KEY,
            elective_code VARCHAR(20) UNIQUE NOT NULL,
            elective_name VARCHAR(200) NOT NULL,
            credit INT DEFAULT 0
        )",

        "CREATE TABLE IF NOT EXISTS student_electives (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reg_no VARCHAR(50) NOT NULL,
            elective_id INT NOT NULL,
            FOREIGN KEY (reg_no) REFERENCES students(reg_no) ON DELETE CASCADE,
            FOREIGN KEY (elective_id) REFERENCES electives(id) ON DELETE CASCADE
        )",

        // Attendance System
        "CREATE TABLE IF NOT EXISTS attendance (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reg_no VARCHAR(50) NOT NULL,
            subject_id INT NOT NULL,
            total_days INT DEFAULT 0,
            present_days INT DEFAULT 0,
            attendance_percentage FLOAT DEFAULT 0,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (reg_no) REFERENCES students(reg_no) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
        )",

        // Internal & Exam Marks
        "CREATE TABLE IF NOT EXISTS internal_marks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reg_no VARCHAR(50) NOT NULL,
            subject_id INT NOT NULL,
            internal1 INT DEFAULT 0,
            internal2 INT DEFAULT 0,
            assignment INT DEFAULT 0,
            total INT DEFAULT 0,
            FOREIGN KEY (reg_no) REFERENCES students(reg_no) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
        )",

        "CREATE TABLE IF NOT EXISTS external_marks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reg_no VARCHAR(50) NOT NULL,
            subject_id INT NOT NULL,
            marks INT DEFAULT 0,
            result VARCHAR(20),
            FOREIGN KEY (reg_no) REFERENCES students(reg_no) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
        )",

        "CREATE TABLE IF NOT EXISTS weighted_scores (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reg_no VARCHAR(50) NOT NULL,
            subject_id INT NOT NULL,
            credit INT DEFAULT 0,
            marks INT DEFAULT 0,
            weighted_score FLOAT DEFAULT 0,
            FOREIGN KEY (reg_no) REFERENCES students(reg_no) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
        )",

        // Hall Ticket & Exam
        "CREATE TABLE IF NOT EXISTS hall_tickets (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reg_no VARCHAR(50) NOT NULL,
            semester_id INT NOT NULL,
            exam_session VARCHAR(50),
            generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (reg_no) REFERENCES students(reg_no) ON DELETE CASCADE,
            FOREIGN KEY (semester_id) REFERENCES semesters(id)
        )",

        "CREATE TABLE IF NOT EXISTS hall_ticket_subjects (
            id INT AUTO_INCREMENT PRIMARY KEY,
            hall_ticket_id INT NOT NULL,
            subject_id INT NOT NULL,
            FOREIGN KEY (hall_ticket_id) REFERENCES hall_tickets(id) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
        )",

        // Seating Arrangement
        "CREATE TABLE IF NOT EXISTS rooms (
            id INT AUTO_INCREMENT PRIMARY KEY,
            room_no VARCHAR(20) UNIQUE NOT NULL,
            capacity INT DEFAULT 0,
            building VARCHAR(100)
        )",

        "CREATE TABLE IF NOT EXISTS seating_allotment (
            id INT AUTO_INCREMENT PRIMARY KEY,
            room_id INT NOT NULL,
            reg_no VARCHAR(50) NOT NULL,
            seat_no INT,
            exam_session VARCHAR(50),
            FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
            FOREIGN KEY (reg_no) REFERENCES students(reg_no) ON DELETE CASCADE
        )",

        // Result & Grade Processing
        "CREATE TABLE IF NOT EXISTS results (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reg_no VARCHAR(50) NOT NULL,
            semester_id INT NOT NULL,
            total_marks INT DEFAULT 0,
            sgpa FLOAT DEFAULT 0,
            cgpa FLOAT DEFAULT 0,
            grade VARCHAR(5),
            FOREIGN KEY (reg_no) REFERENCES students(reg_no) ON DELETE CASCADE,
            FOREIGN KEY (semester_id) REFERENCES semesters(id)
        )",

        "CREATE TABLE IF NOT EXISTS grade_appeals (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reg_no VARCHAR(50) NOT NULL,
            subject_id INT NOT NULL,
            current_grade VARCHAR(5),
            reason TEXT,
            status VARCHAR(20) DEFAULT 'Pending',
            submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (reg_no) REFERENCES students(reg_no) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
        )",

        // Fees & Finance
        "CREATE TABLE IF NOT EXISTS fee_categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            category VARCHAR(50) UNIQUE NOT NULL
        )",

        "CREATE TABLE IF NOT EXISTS fee_structure (
            id INT AUTO_INCREMENT PRIMARY KEY,
            program_id INT NOT NULL,
            tuition_fee INT DEFAULT 0,
            exam_fee INT DEFAULT 0,
            lab_fee INT DEFAULT 0,
            mess_fee INT DEFAULT 0,
            hostel_fee INT DEFAULT 0,
            FOREIGN KEY (program_id) REFERENCES programs(id) ON DELETE CASCADE
        )",

        "CREATE TABLE IF NOT EXISTS fee_slips (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reg_no VARCHAR(50) NOT NULL,
            category_id INT NOT NULL,
            tuition_fee INT DEFAULT 0,
            exam_fee INT DEFAULT 0,
            lab_fee INT DEFAULT 0,
            mess_fee INT DEFAULT 0,
            hostel_fee INT DEFAULT 0,
            total INT DEFAULT 0,
            generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (reg_no) REFERENCES students(reg_no) ON DELETE CASCADE,
            FOREIGN KEY (category_id) REFERENCES fee_categories(id)
        )"
    ];

    foreach ($tables as $sql) {
        if (!$conn->query($sql)) {
            echo "Error creating table: " . $conn->error . "<br>";
        }
    }
    
    // echo "Database and tables created successfully!<br>";
}

// Create all tables
createTables($conn);

// Insert default admin user if not exists
$check_admin = $conn->query("SELECT * FROM users WHERE username = 'admin'");
if ($check_admin->num_rows == 0) {
    $default_password = password_hash('admin123', PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (username, password, role) VALUES ('admin', '$default_password', 'admin')";
    if ($conn->query($sql)) {
        echo "Default admin user created (username: admin, password: admin123)<br>";
    }
}

// Set charset to UTF-8
$conn->set_charset("utf8mb4");
?>