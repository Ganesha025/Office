<?php
session_start();
require_once './config/db.php';

// Fetch all students for dropdown
$students_list = $conn->query("SELECT reg_no, name FROM students ORDER BY name ASC");

// Check if student is selected
$reg_no = $_GET['reg_no'] ?? null;

// Fetch student details
$student = null;
if ($reg_no) {
    $stmt = $conn->prepare("SELECT s.reg_no, s.name, p.program_name 
                            FROM students s
                            LEFT JOIN programs p ON s.program_id = p.id
                            WHERE s.reg_no = ?");
    $stmt->bind_param("s", $reg_no);
    $stmt->execute();
    $student = $stmt->get_result()->fetch_assoc();
}

// Fetch subjects and marks for the student
$subjects = [];
if ($student) {
    $stmt = $conn->prepare("
        SELECT sub.id, sub.subject_name, sub.credit, im.total AS internal_total, em.marks AS external_marks
        FROM subjects sub
        LEFT JOIN internal_marks im ON im.subject_id = sub.id AND im.reg_no = ?
        LEFT JOIN external_marks em ON em.subject_id = sub.id AND em.reg_no = ?
        LEFT JOIN students s ON s.program_id = sub.program_id
        WHERE s.reg_no = ?");
    $stmt->bind_param("sss", $reg_no, $reg_no, $reg_no);
    $stmt->execute();
    $subjects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Calculate weighted scores and final grade
$total_weighted = 0;
$total_credits = 0;
$grades = [];
$final_grade = '';

if (!empty($subjects)) {
    foreach ($subjects as $sub) {
        $credit = $sub['credit'];
        // Calculate final marks as sum of internal + external (adjust as per your scheme)
        $internal = $sub['internal_total'] ?? 0;
        $external = $sub['external_marks'] ?? 0;
        $total_marks = $internal + $external; // assuming out of 100

        // Weighted score = (marks / 100) * credit * 10 (scale)
        $weighted = ($total_marks / 100) * $credit * 10;
        $grades[$sub['id']] = [
            'subject_name' => $sub['subject_name'],
            'credit' => $credit,
            'total_marks' => $total_marks,
            'weighted_score' => round($weighted, 2)
        ];

        $total_weighted += $weighted;
        $total_credits += $credit;
    }

    // Calculate weighted average
    if ($total_credits > 0) {
        $weighted_avg = $total_weighted / $total_credits;
    } else {
        $weighted_avg = 0;
    }

    // Assign grade
    if ($weighted_avg >= 8.5) {
        $final_grade = 'A';
    } elseif ($weighted_avg >= 7) {
        $final_grade = 'B';
    } elseif ($weighted_avg >= 5) {
        $final_grade = 'C';
    } else {
        $final_grade = 'Fail';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Weighted Marksheet</title>
<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    table { border-collapse: collapse; width: 70%; margin-bottom: 20px; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
    th { background-color: #f4f4f4; }
    .grade { font-size: 20px; font-weight: bold; }
</style>
</head>
<body>

<h2>Weighted Marksheet (Calculated from Credits Earned)</h2>

<!-- Student Selection Dropdown -->
<form method="get">
    Select Student:
    <select name="reg_no" onchange="this.form.submit()" required>
        <option value="">--Select--</option>
        <?php while ($row = $students_list->fetch_assoc()): ?>
            <option value="<?= $row['reg_no'] ?>" <?= ($reg_no == $row['reg_no']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($row['name'] . ' (' . $row['reg_no'] . ')') ?>
            </option>
        <?php endwhile; ?>
    </select>
</form>

<?php if ($student && !empty($subjects)): ?>
    <h3>Student: <?= htmlspecialchars($student['name']) ?> (<?= $student['reg_no'] ?>)</h3>
    <h4>Program: <?= htmlspecialchars($student['program_name']) ?></h4>

    <table>
        <tr>
            <th>Subject</th>
            <th>Credit</th>
            <th>Weighted Score</th>
        </tr>
        <?php foreach ($grades as $g): ?>
        <tr>
            <td><?= htmlspecialchars($g['subject_name']) ?></td>
            <td><?= $g['credit'] ?></td>
            <td><?= $g['weighted_score'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <h3>Result Breakdown</h3>
    <table>
        <tr>
            <th>Total Credits</th>
            <td><?= $total_credits ?></td>
        </tr>
      
        <tr>
            <th>Final Grade</th>
            <td class="grade"><?= $final_grade ?></td>
        </tr>
    </table>
<?php elseif ($student): ?>
    <p>No marks found for this student yet.</p>
<?php endif; ?>

</body>
</html>
