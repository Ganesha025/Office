<?php
session_start();

$result = null;
$inputString = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['userString'])) {
    $inputString = htmlspecialchars($_POST['userString']);
    $cleanStr = strtolower(str_replace(' ', '', $inputString));
    $result = $cleanStr === strrev($cleanStr);

    // Save result to session
    $_SESSION['result'] = $result;
    $_SESSION['inputString'] = $inputString;

    // Redirect to avoid resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Retrieve result from session if exists
if (isset($_SESSION['result'])) {
    $result = $_SESSION['result'];
    $inputString = $_SESSION['inputString'];
    // Clear session so it doesn't show again on next reload
    unset($_SESSION['result'], $_SESSION['inputString']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Palindrome Checker</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-gradient-to-r from-purple-200 to-pink-200 min-h-screen flex items-center justify-center">

    <div class="bg-white rounded-3xl shadow-2xl p-8 max-w-lg w-full transform hover:scale-105 transition-transform duration-300">
        <h1 class="text-3xl font-bold text-center text-purple-700 mb-6">Palindrome Checker</h1>

        <form method="POST" class="space-y-4">
            <label class="block font-medium text-gray-700">Enter a String:</label>
            <input type="text" name="userString" placeholder="madam" required id="focus"
                class="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-purple-400">
            <button type="submit"
                class="w-full bg-purple-500 text-white py-2 rounded hover:bg-purple-600 transition-colors font-semibold">
                Check Palindrome
            </button>
        </form>

        <?php if ($result !== null): ?>
            <div class="mt-6 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl shadow-inner space-y-3 text-center">
                <p class="text-lg"><span class="font-semibold text-purple-700">Input String:</span> "<?php echo $inputString; ?>"</p>
                <p class="text-xl font-bold <?php echo $result ? 'text-green-600' : 'text-red-600'; ?>">
                    <?php echo $result ? "✅ It's a palindrome!" : "❌ Not a palindrome." ?>
                </p>
            </div>
        <?php endif; ?>

    </div>

<script>
$(document).ready(function(){
    $("#focus").focus();
});
</script>

</body>
</html>
