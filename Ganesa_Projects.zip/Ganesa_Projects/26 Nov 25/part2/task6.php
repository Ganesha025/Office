<?php
session_start();
$subjects = ["Tamil","English","Math","Science","Social"];
$marks = [];
$total = $average = 0;
$pass = true;
$grade = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $marks = isset($_POST['marks']) ? array_map('intval', $_POST['marks']) : [];
    if (count($marks) === 5) {
        $total = array_sum($marks);
        $average = round($total / 5, 2);
        foreach ($marks as $m) if ($m <= 35) $pass = false;
        if (!$pass) $grade = "Fail";
        else if ($average >= 90) $grade = "A+";
        else if ($average >= 80) $grade = "A";
        else if ($average >= 70) $grade = "B";
        else if ($average >= 60) $grade = "C";
        else $grade = "Fail";
        $_SESSION['result'] = [
            'marks' => $marks,
            'total' => $total,
            'average' => $average,
            'pass' => $pass,
            'grade' => $grade
        ];
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

if (isset($_SESSION['result'])) {
    $result = $_SESSION['result'];
    $marks = $result['marks'];
    $total = $result['total'];
    $average = $result['average'];
    $pass = $result['pass'];
    $grade = $result['grade'];
    unset($_SESSION['result']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Grade Assignment</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="styles.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>
<body class="bg-purple-50 min-h-screen flex items-center justify-center p-6">
<div class="w-full max-w-md bg-white rounded-2xl shadow-2xl p-6">
<h1 class="text-3xl font-bold text-center text-purple-700 mb-6">Grade Assignment</h1>
<form method="POST" class="space-y-4">
<?php foreach($subjects as $i=>$sub): ?>
<div class="flex justify-between items-center">
<label class="font-semibold text-purple-800"><?php echo $sub; ?>:</label>
<input type="number" name="marks[]" value="<?php echo $marks[$i]??''; ?>" min="0" max="100" class="val-mark w-20 border <?php echo isset($marks[$i]) && $marks[$i]<=35 ? 'border-red-500' : 'border-gray-300'; ?> p-2 rounded text-center" required>
</div>
<?php endforeach; ?>
<button type="submit" class="w-full bg-purple-600 text-white py-2 rounded font-semibold mt-4">Calculate</button>
</form>
<?php if($marks && count($marks)==5): ?>
<div class="mt-6 p-4 bg-purple-100 rounded-xl text-center space-y-2">
<p class="text-lg font-semibold text-purple-700">Total Marks: <?php echo $total; ?></p>
<p class="text-lg font-semibold text-purple-700">Average: <?php echo $average; ?></p>
<p class="text-lg font-semibold <?php echo $pass?'text-green-600':'text-red-600'; ?>">Result: <?php echo $pass?'Pass':'Fail'; ?></p>
<p class="text-lg font-semibold text-purple-800">Grade: <?php echo $grade; ?></p>
</div>
<?php endif; ?>
</div>
<script src="./valid.js"></script>
</body>
</html>
