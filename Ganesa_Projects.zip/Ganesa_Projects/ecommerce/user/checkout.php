<?php
session_start();
require "../config/db.php";

if (empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}

$cart_items = [];
$total = 0;

if (!empty($_SESSION['cart'])) {
    $ids = implode(',', array_keys($_SESSION['cart']));
    $sql = "SELECT * FROM products WHERE id IN ($ids)";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $quantity = $_SESSION['cart'][$row['id']];
        $subtotal = $row['price'] * $quantity;
        $total += $subtotal;
        
        $cart_items[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'price' => $row['price'],
            'image_url' => $row['image_url'],
            'quantity' => $quantity,
            'subtotal' => $subtotal
        ];
    }
}

$subtotal = $total;
$tax = $total * 0.1;
$shipping = 0;
$grand_total = $subtotal + $tax + $shipping;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $pincode = $_POST['pincode'];
    $payment_method = $_POST['payment_method'];
    
    $_SESSION['cart'] = [];
    header('Location: order_success.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Checkout - Zencom</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Inter',sans-serif;}
:root{--bg-primary:#ffffff;--bg-secondary:#f8fafc;--text-primary:#0f172a;--text-secondary:#64748b;--accent:#2563eb;--border:#e2e8f0;}
.dark{--bg-primary:#0f172a;--bg-secondary:#1e293b;--text-primary:#f1f5f9;--text-secondary:#94a3b8;--accent:#3b82f6;--border:#334155;}
body{background:var(--bg-primary);color:var(--text-primary);transition:all 0.3s ease;}
input:focus,select:focus,textarea:focus{outline:none;ring:2px;ring-color:var(--accent);border-color:transparent;}
</style>
</head>
<body class="min-h-screen bg-[var(--bg-primary)]">

<header class="bg-white/80 backdrop-blur-md border-b border-[var(--border)] sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-6 py-4">
        <div class="flex items-center justify-between">
            <a href="view.php" class="flex items-center gap-3">
                <div class="w-10 h-10 bg-[var(--accent)] rounded-xl flex items-center justify-center">
                    <span class="material-icons text-white">shopping_bag</span>
                </div>
                <span class="text-xl font-bold text-[var(--text-primary)]">Zencom</span>
            </a>
            <div class="flex items-center gap-6">
                <a href="cart.php" class="text-[var(--text-secondary)] hover:text-[var(--accent)] font-medium transition-colors flex items-center gap-2">
                    <span class="material-icons text-xl">arrow_back</span>
                    <span>Back to Cart</span>
                </a>
            </div>
        </div>
    </div>
</header>

<main class="py-12">
    <div class="max-w-7xl mx-auto px-6">
        <div class="flex items-center gap-2 text-sm text-[var(--text-secondary)] mb-8">
            <a href="view.php" class="hover:text-[var(--accent)] transition-colors">Products</a>
            <span class="material-icons text-xs">chevron_right</span>
            <a href="cart.php" class="hover:text-[var(--accent)] transition-colors">Cart</a>
            <span class="material-icons text-xs">chevron_right</span>
            <span class="text-[var(--text-primary)]">Checkout</span>
        </div>

        <h1 class="text-4xl font-bold text-[var(--text-primary)] mb-12">Checkout</h1>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="lg:col-span-2">
                <form method="POST" id="checkoutForm">
                    <div class="bg-white rounded-2xl border border-[var(--border)] shadow-sm overflow-hidden mb-6">
                        <div class="px-8 py-6 border-b border-[var(--border)] bg-[var(--bg-secondary)]">
                            <h2 class="text-xl font-bold text-[var(--text-primary)] flex items-center gap-3">
                                <span class="material-icons">local_shipping</span>
                                Shipping Information
                            </h2>
                        </div>
                        
                        <div class="px-8 py-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">Full Name *</label>
                                <input type="text" name="full_name" required class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="John Doe">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">Email Address *</label>
                                <input type="email" name="email" required class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="john@example.com">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">Phone Number *</label>
                                <input type="tel" name="phone" required class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="+91 98765 43210">
                            </div>
                            
                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">Address *</label>
                                <textarea name="address" required rows="3" class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent resize-none" placeholder="Street address, apartment, suite, etc."></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">City *</label>
                                <input type="text" name="city" required class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="Mumbai">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">State *</label>
                                <input type="text" name="state" required class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="Maharashtra">
                            </div>
                            
                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">PIN Code *</label>
                                <input type="text" name="pincode" required pattern="[0-9]{6}" class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="400001">
                            </div>
                        </div>
                    </div>

                    <div class="bg-white rounded-2xl border border-[var(--border)] shadow-sm overflow-hidden">
                        <div class="px-8 py-6 border-b border-[var(--border)] bg-[var(--bg-secondary)]">
                            <h2 class="text-xl font-bold text-[var(--text-primary)] flex items-center gap-3">
                                <span class="material-icons">payment</span>
                                Payment Method
                            </h2>
                        </div>
                        
                        <div class="px-8 py-6 space-y-4">
                            <label class="flex items-center p-4 border-2 border-[var(--border)] rounded-xl cursor-pointer hover:border-[var(--accent)] transition-all">
                                <input type="radio" name="payment_method" value="cod" required class="w-5 h-5 text-[var(--accent)]">
                                <div class="ml-4 flex-1">
                                    <div class="flex items-center gap-3">
                                        <span class="material-icons text-[var(--accent)]">money</span>
                                        <span class="font-semibold text-[var(--text-primary)]">Cash on Delivery</span>
                                    </div>
                                    <p class="text-sm text-[var(--text-secondary)] mt-1">Pay when you receive your order</p>
                                </div>
                            </label>
                            
                            <label class="flex items-center p-4 border-2 border-[var(--border)] rounded-xl cursor-pointer hover:border-[var(--accent)] transition-all">
                                <input type="radio" name="payment_method" value="upi" class="w-5 h-5 text-[var(--accent)]">
                                <div class="ml-4 flex-1">
                                    <div class="flex items-center gap-3">
                                        <span class="material-icons text-[var(--accent)]">qr_code_2</span>
                                        <span class="font-semibold text-[var(--text-primary)]">UPI Payment</span>
                                    </div>
                                    <p class="text-sm text-[var(--text-secondary)] mt-1">Pay using Google Pay, PhonePe, Paytm</p>
                                </div>
                            </label>
                            
                            <label class="flex items-center p-4 border-2 border-[var(--border)] rounded-xl cursor-pointer hover:border-[var(--accent)] transition-all">
                                <input type="radio" name="payment_method" value="card" class="w-5 h-5 text-[var(--accent)]">
                                <div class="ml-4 flex-1">
                                    <div class="flex items-center gap-3">
                                        <span class="material-icons text-[var(--accent)]">credit_card</span>
                                        <span class="font-semibold text-[var(--text-primary)]">Credit/Debit Card</span>
                                    </div>
                                    <p class="text-sm text-[var(--text-secondary)] mt-1">Visa, Mastercard, Rupay accepted</p>
                                </div>
                            </label>
                            
                            <label class="flex items-center p-4 border-2 border-[var(--border)] rounded-xl cursor-pointer hover:border-[var(--accent)] transition-all">
                                <input type="radio" name="payment_method" value="netbanking" class="w-5 h-5 text-[var(--accent)]">
                                <div class="ml-4 flex-1">
                                    <div class="flex items-center gap-3">
                                        <span class="material-icons text-[var(--accent)]">account_balance</span>
                                        <span class="font-semibold text-[var(--text-primary)]">Net Banking</span>
                                    </div>
                                    <p class="text-sm text-[var(--text-secondary)] mt-1">Pay directly from your bank account</p>
                                </div>
                            </label>
                        </div>
                    </div>
                </form>
            </div>
            
            <div class="lg:col-span-1">
                <div class="bg-white rounded-2xl border border-[var(--border)] shadow-sm overflow-hidden sticky top-24">
                    <div class="px-8 py-6 border-b border-[var(--border)] bg-[var(--bg-secondary)]">
                        <h2 class="text-xl font-bold text-[var(--text-primary)]">Order Summary</h2>
                    </div>
                    
                    <div class="px-8 py-6">
                        <div class="space-y-4 mb-6 max-h-64 overflow-y-auto">
                            <?php foreach ($cart_items as $item): ?>
                            <div class="flex items-center gap-4">
                                <img src="<?php echo htmlspecialchars($item['image_url']); ?>" 
                                     alt="<?php echo htmlspecialchars($item['name']); ?>"
                                     class="w-16 h-16 object-cover rounded-lg border border-[var(--border)]"
                                     onerror="this.src='https://via.placeholder.com/64x64/e2e8f0/64748b?text=Product'">
                                <div class="flex-1 min-w-0">
                                    <h3 class="font-semibold text-[var(--text-primary)] text-sm truncate"><?php echo htmlspecialchars($item['name']); ?></h3>
                                    <p class="text-sm text-[var(--text-secondary)]">Qty: <?php echo $item['quantity']; ?></p>
                                </div>
                                <div class="text-right">
                                    <p class="font-bold text-[var(--accent)]">₹<?php echo number_format($item['subtotal'], 2); ?></p>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="border-t border-[var(--border)] pt-4 space-y-3 mb-6">
                            <div class="flex justify-between items-center text-[var(--text-secondary)]">
                                <span class="font-medium">Subtotal</span>
                                <span class="font-semibold">₹<?php echo number_format($subtotal, 2); ?></span>
                            </div>
                            <div class="flex justify-between items-center text-[var(--text-secondary)]">
                                <span class="font-medium">Shipping</span>
                                <span class="font-semibold text-green-600">Free</span>
                            </div>
                            <div class="flex justify-between items-center text-[var(--text-secondary)]">
                                <span class="font-medium">Tax (10%)</span>
                                <span class="font-semibold">₹<?php echo number_format($tax, 2); ?></span>
                            </div>
                            <div class="border-t border-[var(--border)] pt-3 flex justify-between items-center">
                                <span class="text-lg font-bold text-[var(--text-primary)]">Total</span>
                                <span class="text-2xl font-bold text-[var(--accent)]">₹<?php echo number_format($grand_total, 2); ?></span>
                            </div>
                        </div>
                        
                        <button type="submit" form="checkoutForm" name="place_order" class="w-full bg-green-600 text-white py-4 px-6 rounded-xl font-bold hover:bg-green-700 transition-all flex items-center justify-center gap-3 shadow-lg hover:shadow-xl">
                            <span class="material-icons">lock</span>
                            <span>Place Order</span>
                        </button>
                        
                        <p class="text-xs text-center text-[var(--text-secondary)] mt-4">
                            <span class="material-icons text-green-600" style="font-size:14px;vertical-align:middle;">verified_user</span>
                            Secure checkout - Your data is protected
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<footer class="bg-[var(--bg-secondary)] border-t border-[var(--border)] mt-24">
    <div class="max-w-7xl mx-auto px-6 py-16">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div>
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 bg-[var(--accent)] rounded-xl flex items-center justify-center">
                        <span class="material-icons text-white">shopping_bag</span>
                    </div>
                    <span class="text-xl font-bold text-[var(--text-primary)]">Zencom</span>
                </div>
                <p class="text-[var(--text-secondary)] leading-relaxed">Quality products, exceptional service</p>
            </div>
            <div>
                <h4 class="font-bold text-[var(--text-primary)] mb-4">Shop</h4>
                <ul class="space-y-3 text-[var(--text-secondary)]">
                    <li><a href="view.php" class="hover:text-[var(--accent)] transition-colors">All Products</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">New Arrivals</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Best Sellers</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-bold text-[var(--text-primary)] mb-4">Support</h4>
                <ul class="space-y-3 text-[var(--text-secondary)]">
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Contact Us</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Shipping</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Returns</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-bold text-[var(--text-primary)] mb-4">Company</h4>
                <ul class="space-y-3 text-[var(--text-secondary)]">
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">About</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Careers</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Privacy</a></li>
                </ul>
            </div>
        </div>
        <div class="border-t border-[var(--border)] mt-12 pt-8 text-center">
            <p class="text-[var(--text-secondary)]">© 2025 Zencom. All rights reserved.</p>
        </div>
    </div>
</footer>

<button class="fixed bottom-8 right-8 w-14 h-14 bg-[var(--accent)] text-white rounded-full shadow-xl hover:shadow-2xl transition-all flex items-center justify-center z-50 hover:scale-110" onclick="toggleTheme()">
    <span class="material-icons" id="themeIcon">dark_mode</span>
</button>

<script>
const currentTheme = localStorage.getItem('theme') || 'light';
document.documentElement.className = currentTheme;
updateThemeIcon();

function toggleTheme() {
    const newTheme = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
    document.documentElement.className = newTheme;
    localStorage.setItem('theme', newTheme);
    updateThemeIcon();
}

function updateThemeIcon() {
    const icon = document.getElementById('themeIcon');
    icon.textContent = document.documentElement.classList.contains('dark') ? 'light_mode' : 'dark_mode';
}
</script>

</body>
</html>