<?php
session_start();
require "../config/db.php";

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'] ?? 1;
    
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = $quantity;
    }
}

if (isset($_POST['update_cart'])) {
    foreach ($_POST['quantities'] as $product_id => $quantity) {
        if ($quantity <= 0) {
            unset($_SESSION['cart'][$product_id]);
        } else {
            $_SESSION['cart'][$product_id] = $quantity;
        }
    }
}

if (isset($_POST['remove_item'])) {
    $product_id = $_POST['product_id'];
    unset($_SESSION['cart'][$product_id]);
}

$cart_items = [];
$total = 0;

if (!empty($_SESSION['cart'])) {
    $ids = implode(',', array_keys($_SESSION['cart']));
    $sql = "SELECT * FROM products WHERE id IN ($ids)";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $quantity = $_SESSION['cart'][$row['id']];
        $subtotal = $row['price'] * $quantity;
        $total += $subtotal;
        
        $cart_items[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'price' => $row['price'],
            'image_url' => $row['image_url'],
            'quantity' => $quantity,
            'subtotal' => $subtotal
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Shopping Cart - Zencom</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="../styles/styles.css">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Inter',sans-serif;}
:root{--bg-primary:#ffffff;--bg-secondary:#f8fafc;--text-primary:#0f172a;--text-secondary:#64748b;--accent:#2563eb;--border:#e2e8f0;}
.dark{--bg-primary:#0f172a;--bg-secondary:#1e293b;--text-primary:#f1f5f9;--text-secondary:#94a3b8;--accent:#3b82f6;--border:#334155;}
body{background:var(--bg-primary);color:var(--text-primary);transition:all 0.3s ease;}
</style>
</head>
<body class="min-h-screen bg-[var(--bg-primary)]">

<header class="bg-white/80 backdrop-blur-md border-b border-[var(--border)] sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-6 py-4">
        <div class="flex items-center justify-between">
            <a href="view.php" class="flex items-center gap-3">
                <div class="w-10 h-10 bg-[var(--accent)] rounded-xl flex items-center justify-center">
                    <span class="material-icons text-white">shopping_bag</span>
                </div>
                <span class="text-xl font-bold text-[var(--text-primary)]">Zencom</span>
            </a>
            <div class="flex items-center gap-6">
                <a href="view.php" class="text-[var(--text-secondary)] hover:text-[var(--accent)] font-medium transition-colors">Continue Shopping</a>
                <a href="cart.php" class="bg-[var(--accent)] text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-blue-600 transition-all flex items-center gap-2 shadow-sm">
                    <span class="material-icons text-xl">shopping_cart</span>
                    <span><?php echo array_sum($_SESSION['cart']); ?></span>
                </a>
            </div>
        </div>
    </div>
</header>

<main class="py-12">
    <div class="max-w-7xl mx-auto px-6">
        <div class="flex items-center gap-2 text-sm text-[var(--text-secondary)] mb-8">
            <a href="view.php" class="hover:text-[var(--accent)] transition-colors">Products</a>
            <span class="material-icons text-xs">chevron_right</span>
            <span class="text-[var(--text-primary)]">Shopping Cart</span>
        </div>

        <h1 class="text-4xl font-bold text-[var(--text-primary)] mb-12">Shopping Cart</h1>

        <?php if (empty($cart_items)): ?>
        <div class="text-center py-24">
            <div class="inline-flex items-center justify-center w-24 h-24 bg-[var(--bg-secondary)] rounded-full mb-6">
                <span class="material-icons text-5xl text-[var(--text-secondary)]">shopping_cart</span>
            </div>
            <h2 class="text-2xl font-bold text-[var(--text-primary)] mb-3">Your cart is empty</h2>
            <p class="text-[var(--text-secondary)] mb-8 text-lg">Browse our products and add items to your cart</p>
            <a href="view.php" class="inline-flex items-center gap-3 bg-[var(--accent)] text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-600 transition-all shadow-lg hover:shadow-xl">
                <span class="material-icons">shopping_bag</span>
                <span>Start Shopping</span>
            </a>
        </div>
        <?php else: ?>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="lg:col-span-2">
                <form method="POST">
                    <div class="bg-white rounded-2xl border border-[var(--border)] shadow-sm overflow-hidden">
                        <div class="px-8 py-6 border-b border-[var(--border)] bg-[var(--bg-secondary)]">
                            <h2 class="text-xl font-bold text-[var(--text-primary)]">Cart Items (<?php echo count($cart_items); ?>)</h2>
                        </div>
                        
                        <div class="divide-y divide-[var(--border)]">
                            <?php foreach ($cart_items as $item): ?>
                            <div class="px-8 py-6 flex items-center gap-6">
                                <img src="<?php echo htmlspecialchars($item['image_url']); ?>" 
                                     alt="<?php echo htmlspecialchars($item['name']); ?>"
                                     class="w-24 h-24 object-cover rounded-xl border border-[var(--border)]"
                                     onerror="this.src='https://via.placeholder.com/96x96/e2e8f0/64748b?text=Product'">
                                
                                <div class="flex-1 min-w-0">
                                    <h3 class="font-semibold text-black mb-2 text-lg"><?php echo htmlspecialchars($item['name']); ?></h3>
                                    <p class="text-xl font-bold text-[var(--accent)]">₹<?php echo number_format($item['price'], 2); ?></p>
                                </div>
                                
                                <div class="flex items-center gap-4">
                                    <input type="number" 
                                           name="quantities[<?php echo $item['id']; ?>]" 
                                           value="<?php echo $item['quantity']; ?>" 
                                           min="0"
                                           class="w-20 px-4 py-3 border border-[var(--border)] rounded-xl text-black text-center font-semibold focus:outline-none focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent">
                                    
                                    <form method="POST" class="inline">
                                        <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                        <button type="submit" name="remove_item" class="w-10 h-10 flex items-center justify-center text-red-500 hover:bg-red-50 rounded-xl transition-all">
                                            <span class="material-icons">delete</span>
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="px-8 py-6 bg-[var(--bg-secondary)] flex justify-between items-center">
                            <a href="view.php" class="text-[var(--accent)] hover:text-blue-600 font-semibold flex items-center gap-2 transition-colors">
                                <span class="material-icons">arrow_back</span>
                                <span>Continue Shopping</span>
                            </a>
                            
                            <button type="submit" name="update_cart" class="bg-[var(--accent)] text-white px-8 py-3 rounded-xl font-semibold hover:bg-blue-600 transition-all shadow-sm hover:shadow-md">
                                Update Cart
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            
            <div class="lg:col-span-1">
                <div class="bg-white rounded-2xl border border-[var(--border)] shadow-sm overflow-hidden sticky top-24">
                    <div class="px-8 py-6 border-b border-[var(--border)] bg-[var(--bg-secondary)]">
                        <h2 class="text-xl font-bold text-[var(--text-primary)]">Order Summary</h2>
                    </div>
                    
                    <div class="px-8 py-6 space-y-4">
                        <div class="flex justify-between items-center text-[var(--text-secondary)]">
                            <span class="font-medium">Subtotal</span>
                            <span class="font-semibold">₹<?php echo number_format($total, 2); ?></span>
                        </div>
                        <div class="flex justify-between items-center text-[var(--text-secondary)]">
                            <span class="font-medium">Shipping</span>
                            <span class="font-semibold text-green-600">Free</span>
                        </div>
                        <div class="flex justify-between items-center text-[var(--text-secondary)]">
                            <span class="font-medium">Tax (10%)</span>
                            <span class="font-semibold">₹<?php echo number_format($total * 0.1, 2); ?></span>
                        </div>
                        <div class="border-t border-[var(--border)] pt-4 flex justify-between items-center">
                            <span class="text-lg font-bold text-[var(--text-primary)]">Total</span>
                            <span class="text-2xl font-bold text-[var(--accent)]">₹<?php echo number_format($total * 1.1, 2); ?></span>
                        </div>
                    </div>
                    
                    <div class="px-8 pb-8">
                        <a href="checkout.php" class="w-full bg-green-600 text-white py-4 px-6 rounded-xl font-bold hover:bg-green-700 transition-all flex items-center justify-center gap-3 shadow-lg hover:shadow-xl mb-4">
                            <span class="material-icons">lock</span>
                            <span>Proceed to Checkout</span>
                            </a>
                                
                        <p class="text-sm text-center text-[var(--text-secondary)] font-medium">🚚 Free shipping and returns</p>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</main>

<footer class="bg-[var(--bg-secondary)] border-t border-[var(--border)] mt-24">
    <div class="max-w-7xl mx-auto px-6 py-16">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div>
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 bg-[var(--accent)] rounded-xl flex items-center justify-center">
                        <span class="material-icons text-white">shopping_bag</span>
                    </div>
                    <span class="text-xl font-bold text-[var(--text-primary)]">Zencom</span>
                </div>
                <p class="text-[var(--text-secondary)] leading-relaxed">Quality products, exceptional service</p>
            </div>
            <div>
                <h4 class="font-bold text-[var(--text-primary)] mb-4">Shop</h4>
                <ul class="space-y-3 text-[var(--text-secondary)]">
                    <li><a href="view.php" class="hover:text-[var(--accent)] transition-colors">All Products</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">New Arrivals</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Best Sellers</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-bold text-[var(--text-primary)] mb-4">Support</h4>
                <ul class="space-y-3 text-[var(--text-secondary)]">
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Contact Us</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Shipping</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Returns</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-bold text-[var(--text-primary)] mb-4">Company</h4>
                <ul class="space-y-3 text-[var(--text-secondary)]">
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">About</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Careers</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Privacy</a></li>
                </ul>
            </div>
        </div>
        <div class="border-t border-[var(--border)] mt-12 pt-8 text-center">
            <p class="text-[var(--text-secondary)]">© 2025 Zencom. All rights reserved.</p>
        </div>
    </div>
</footer>

<button class="fixed bottom-8 right-8 w-14 h-14 bg-[var(--accent)] text-white rounded-full shadow-xl hover:shadow-2xl transition-all flex items-center justify-center z-50 hover:scale-110" onclick="toggleTheme()">
    <span class="material-icons" id="themeIcon">dark_mode</span>
</button>

<script>
const currentTheme = localStorage.getItem('theme') || 'light';
document.documentElement.className = currentTheme;
updateThemeIcon();

function toggleTheme() {
    const newTheme = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
    document.documentElement.className = newTheme;
    localStorage.setItem('theme', newTheme);
    updateThemeIcon();
}

function updateThemeIcon() {
    const icon = document.getElementById('themeIcon');
    icon.textContent = document.documentElement.classList.contains('dark') ? 'light_mode' : 'dark_mode';
}
</script>

</body>
</html>