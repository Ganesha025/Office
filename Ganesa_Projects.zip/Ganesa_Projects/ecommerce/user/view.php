<?php
require "../config/db.php";

$sort = $_GET['sort'] ?? 'newest';
$seller_filter = $_GET['seller'] ?? '';

$sort_sql = "ORDER BY id DESC";
switch($sort) {
    case 'price_low': $sort_sql = "ORDER BY price ASC"; break;
    case 'price_high': $sort_sql = "ORDER BY price DESC"; break;
    case 'name': $sort_sql = "ORDER BY name ASC"; break;
    case 'newest': $sort_sql = "ORDER BY id DESC"; break;
    case 'oldest': $sort_sql = "ORDER BY id ASC"; break;
}

$where_sql = "";
if(!empty($seller_filter)) {
    $where_sql = "WHERE seller_name = '" . $conn->real_escape_string($seller_filter) . "'";
}

$sql = "SELECT * FROM products $where_sql $sort_sql";
$products = $conn->query($sql);
$all_products = [];
if($products) {
    while($row = $products->fetch_assoc()){
        $all_products[] = $row;
    }
}

$sellers_query = $conn->query("SELECT seller_name FROM sellers WHERE seller_name IS NOT NULL AND seller_name != ''");
$all_sellers = [];
if($sellers_query) {
    while($row = $sellers_query->fetch_assoc()){
        $all_sellers[] = $row['seller_name'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Products - Zencom</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Inter',sans-serif;}
:root{--bg-primary:#ffffff;--bg-secondary:#f8fafc;--text-primary:#0f172a;--text-secondary:#475569;--accent:#2563eb;--border:#e2e8f0;}
.dark{--bg-primary:#0f172a;--bg-secondary:#1e293b;--text-primary:#f1f5f9;--text-secondary:#94a3b8;--accent:#3b82f6;--border:#334155;}
body{background:var(--bg-primary);color:var(--text-primary);transition:all 0.3s ease;}
.line-clamp-2{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
.filter-btn{background:var(--bg-secondary);border:1px solid var(--border);padding:8px 16px;border-radius:8px;font-size:14px;cursor:pointer;display:flex;align-items:center;gap:6px;transition:all 0.2s;}
.filter-btn:hover{background:var(--accent);color:white;}
.filter-btn.active{background:var(--accent);color:white;}
</style>
</head>
<body class="flex flex-col min-h-screen bg-[var(--bg-primary)]">

<header class="w-full bg-white/80 backdrop-blur-sm border-b border-[var(--border)] sticky top-0 z-40">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
            <div class="flex items-center space-x-3">
                <div class="w-9 h-9 bg-[var(--accent)] rounded-lg flex items-center justify-center">
                    <span class="material-icons text-white text-lg">shopping_bag</span>
                </div>
                <span class="text-xl font-semibold text-[var(--text-primary)]">Zencom</span>
            </div>
            <a href="../seller/register.php" class="bg-[var(--accent)] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors flex items-center space-x-2">
                <span class="material-icons text-lg">store</span>
                <span>Seller Login</span>
            </a>
        </div>
    </div>
</header>

<main class="flex-1 py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-12">
            <h1 class="text-4xl font-bold text-[var(--text-primary)] mb-4">Our Collection</h1>
            <p class="text-lg text-[var(--text-secondary)] max-w-2xl mx-auto">Discover exceptional products from trusted sellers</p>
        </div>

        <div class="flex flex-wrap gap-3 mb-8 p-4 bg-[var(--bg-secondary)] rounded-xl border border-[var(--border)]">
            <div class="filter-btn <?php echo $sort === 'newest' ? 'active' : ''; ?>" onclick="setSort('newest')">
                <span class="material-icons text-sm">new_releases</span>
                <span>Newest</span>
            </div>
            <div class="filter-btn <?php echo $sort === 'oldest' ? 'active' : ''; ?>" onclick="setSort('oldest')">
                <span class="material-icons text-sm">schedule</span>
                <span>Oldest</span>
            </div>
            <div class="filter-btn <?php echo $sort === 'price_low' ? 'active' : ''; ?>" onclick="setSort('price_low')">
                <span class="material-icons text-sm">arrow_upward</span>
                <span>Price: Low to High</span>
            </div>
            <div class="filter-btn <?php echo $sort === 'price_high' ? 'active' : ''; ?>" onclick="setSort('price_high')">
                <span class="material-icons text-sm">arrow_downward</span>
                <span>Price: High to Low</span>
            </div>
            <div class="filter-btn <?php echo $sort === 'name' ? 'active' : ''; ?>" onclick="setSort('name')">
                <span class="material-icons text-sm">sort_by_alpha</span>
                <span>Name A-Z</span>
            </div>
            
            <div class="ml-2 pl-2 border-l border-[var(--border)]">
                <select onchange="setSeller(this.value)" class="p-2 border border-[var(--border)] rounded-lg bg-white text-[var(--text-primary)] text-sm focus:ring-2 focus:ring-[var(--accent)]">
                    <option value="">All Sellers</option>
                    <?php foreach($all_sellers as $seller): ?>
                    <option value="<?php echo htmlspecialchars($seller); ?>" <?php echo $seller_filter === $seller ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($seller); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="ml-auto">
                <button onclick="clearFilters()" class="px-4 py-2 border border-[var(--border)] text-[var(--text-secondary)] rounded-lg hover:bg-white transition-colors text-sm font-medium flex items-center gap-2">
                    <span class="material-icons text-sm">clear</span>
                    <span>Clear</span>
                </button>
            </div>
        </div>

        <?php if(count($all_products)>0): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <?php foreach($all_products as $product): ?>
            <a href="full_detail.php?id=<?php echo $product['id']; ?>" class="group block">
                <div class="bg-white rounded-2xl border border-[var(--border)] overflow-hidden hover:shadow-lg transition-all duration-300 h-full flex flex-col">
                    <div class="relative aspect-square overflow-hidden">
                        <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                             alt="<?php echo htmlspecialchars($product['name']); ?>"
                             class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                             onerror="this.src='https://via.placeholder.com/400x400/e2e8f0/64748b?text=Product+Image'">
                        <?php if($product['allowed_discount'] > 0): ?>
                        <div class="absolute top-3 right-3 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                            -<?php echo $product['allowed_discount']; ?>%
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="p-5 flex flex-col flex-grow">
                        <h3 class="font-semibold text-black mb-2 line-clamp-2 group-hover:text-[var(--accent)] transition-colors"><?php echo htmlspecialchars($product['name']); ?></h3>
                        <p class="text-sm text-[var(--text-secondary)] mb-4 line-clamp-2 flex-grow"><?php echo htmlspecialchars($product['mini_desc']); ?></p>
                        <div class="flex items-center justify-between mt-auto">
                            <div class="flex items-center space-x-2">
                                <span class="text-xl font-bold text-[var(--accent)]">$<?php echo number_format($product['price'], 2); ?></span>
                                <?php if($product['allowed_discount'] > 0): ?>
                                <span class="text-sm text-[var(--text-secondary)] line-through">$<?php echo number_format($product['price'] * (1 + $product['allowed_discount']/100), 2); ?></span>
                                <?php endif; ?>
                            </div>
                            <button class="bg-[var(--accent)] text-white p-2 rounded-lg hover:bg-blue-600 transition-colors">
                                <span class="material-icons text-lg">shopping_cart</span>
                            </button>
                        </div>
                    </div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="text-center py-16">
            <div class="max-w-md mx-auto">
                <span class="material-icons text-6xl text-[var(--accent)] mb-4 opacity-50">inventory_2</span>
                <h3 class="text-2xl font-semibold text-[var(--text-primary)] mb-3">No Products Found</h3>
                <p class="text-[var(--text-secondary)] mb-6">Try adjusting your filters or check back later</p>
                <button onclick="clearFilters()" class="bg-[var(--accent)] text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors font-medium">
                    Clear Filters
                </button>
            </div>
        </div>
        <?php endif; ?>
    </div>
</main>

<footer class="w-full bg-[var(--bg-secondary)] border-t border-[var(--border)] mt-16">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div class="md:col-span-1">
                <div class="flex items-center space-x-3 mb-4">
                    <div class="w-8 h-8 bg-[var(--accent)] rounded-lg flex items-center justify-center">
                        <span class="material-icons text-white text-sm">shopping_bag</span>
                    </div>
                    <span class="text-lg font-semibold text-[var(--text-primary)]">Zencom</span>
                </div>
                <p class="text-sm text-[var(--text-secondary)]">Quality products, exceptional service</p>
            </div>
            <div>
                <h4 class="font-semibold text-[var(--text-primary)] mb-4">Shop</h4>
                <ul class="space-y-2 text-sm text-[var(--text-secondary)]">
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">All Products</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">New Arrivals</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Best Sellers</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-semibold text-[var(--text-primary)] mb-4">Support</h4>
                <ul class="space-y-2 text-sm text-[var(--text-secondary)]">
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Contact Us</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Shipping</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Returns</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-semibold text-[var(--text-primary)] mb-4">Company</h4>
                <ul class="space-y-2 text-sm text-[var(--text-secondary)]">
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">About</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Careers</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Privacy</a></li>
                </ul>
            </div>
        </div>
        <div class="border-t border-[var(--border)] mt-8 pt-8 text-center">
            <p class="text-sm text-[var(--text-secondary)]">© 2025 Zencom. All rights reserved.</p>
        </div>
    </div>
</footer>

<button class="fixed bottom-6 right-6 w-12 h-12 bg-[var(--accent)] text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center z-50" onclick="toggleTheme()">
    <span class="material-icons" id="themeIcon">dark_mode</span>
</button>

<script>
const currentTheme = localStorage.getItem('theme') || 'light';
document.documentElement.className = currentTheme;
updateThemeIcon();

function toggleTheme() {
    const newTheme = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
    document.documentElement.className = newTheme;
    localStorage.setItem('theme', newTheme);
    updateThemeIcon();
}

function updateThemeIcon() {
    const icon = document.getElementById('themeIcon');
    icon.textContent = document.documentElement.classList.contains('dark') ? 'light_mode' : 'dark_mode';
}

function setSort(sortValue) {
    const seller = document.querySelector('select').value;
    updateURL({sort: sortValue, seller: seller});
}

function setSeller(sellerValue) {
    const sort = '<?php echo $sort; ?>';
    updateURL({sort: sort, seller: sellerValue});
}

function updateURL(params) {
    const urlParams = new URLSearchParams();
    if(params.sort && params.sort !== 'newest') urlParams.set('sort', params.sort);
    if(params.seller) urlParams.set('seller', params.seller);
    window.location.href = '?' + urlParams.toString();
}

function clearFilters() {
    window.location.href = window.location.pathname;
}
</script>

</body>
</html>