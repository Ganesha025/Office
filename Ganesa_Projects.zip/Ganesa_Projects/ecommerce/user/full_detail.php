<?php
session_start();
require "../config/db.php";

$id = $_GET['id'] ?? 0;
$sql = "SELECT p.*, s.seller_name 
        FROM products p 
        LEFT JOIN sellers s ON p.seller_id = s.id 
        WHERE p.id = " . intval($id);
$result = $conn->query($sql);
$product = $result->fetch_assoc();

if(!$product) {
    header("Location: view.php");
    exit();
}

if(isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'] ?? 1;
    
    if(!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    if(isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = $quantity;
    }
    
    header("Location: cart.php");
    exit();
}

$category = $product['category'] ?? 'General';
$related_sql = "SELECT p.*, s.seller_name 
               FROM products p 
               LEFT JOIN sellers s ON p.seller_id = s.id 
               WHERE p.category = '" . $conn->real_escape_string($category) . "' 
               AND p.id != " . intval($id) . " 
               LIMIT 4";
$related_result = $conn->query($related_sql);
$related_products = [];
if($related_result) {
    while($row = $related_result->fetch_assoc()) {
        $related_products[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($product['name']); ?> - Zencom</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Inter',sans-serif;}
:root{--bg-primary:#ffffff;--bg-secondary:#f8fafc;--text-primary:#0f172a;--text-secondary:#475569;--accent:#2563eb;--border:#e2e8f0;}
.dark{--bg-primary:#0f172a;--bg-secondary:#1e293b;--text-primary:#f1f5f9;--text-secondary:#94a3b8;--accent:#3b82f6;--border:#334155;}
body{background:var(--bg-primary);color:var(--text-primary);transition:all 0.3s ease;}
</style>
</head>
<body class="flex flex-col min-h-screen bg-[var(--bg-primary)]">

<header class="w-full bg-white/80 backdrop-blur-sm border-b border-[var(--border)] sticky top-0 z-40">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
            <div class="flex items-center space-x-3">
                <a href="view.php" class="flex items-center space-x-3">
                    <div class="w-9 h-9 bg-[var(--accent)] rounded-lg flex items-center justify-center">
                        <span class="material-icons text-white text-lg">shopping_bag</span>
                    </div>
                    <span class="text-xl font-semibold text-[var(--text-primary)]">Zencom</span>
                </a>
            </div>
            <a href="cart.php" class="bg-[var(--accent)] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors flex items-center space-x-2">
                <span class="material-icons">shopping_cart</span>
                <span>Cart (<?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>)</span>
            </a>
        </div>
    </div>
</header>

<main class="flex-1 py-8">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav class="flex items-center space-x-2 text-sm text-[var(--text-secondary)] mb-8">
            <a href="view.php" class="hover:text-[var(--accent)] transition-colors">Products</a>
            <span class="material-icons text-xs">chevron_right</span>
            <span><?php echo htmlspecialchars($product['name']); ?></span>
        </nav>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div class="space-y-4">
                <div class="bg-white rounded-2xl border border-[var(--border)] overflow-hidden">
                    <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                         alt="<?php echo htmlspecialchars($product['name']); ?>"
                         class="w-full h-auto object-cover"
                         onerror="this.src='https://via.placeholder.com/600x600/e2e8f0/64748b?text=Product+Image'">
                </div>
            </div>

            <div class="space-y-6">
                <div>
                    <h1 class="text-3xl font-bold text-[var(--text-primary)] mb-4"><?php echo htmlspecialchars($product['name']); ?></h1>
                    <div class="flex items-center space-x-4 mb-4">
                        <div class="flex items-center space-x-2">
                            <span class="material-icons text-yellow-400 text-lg">star</span>
                            <span class="font-medium">4.8</span>
                            <span class="text-[var(--text-secondary)]">(128 reviews)</span>
                        </div>
                        <span class="text-[var(--text-secondary)]">•</span>
                        <span class="text-green-600 font-medium">In Stock</span>
                    </div>

                    <div class="flex items-center space-x-3 mb-6">
                        <span class="text-3xl font-bold text-[var(--accent)]">$<?php echo number_format($product['price'], 2); ?></span>
                        <?php if(isset($product['allowed_discount']) && $product['allowed_discount'] > 0): ?>
                        <span class="text-xl text-[var(--text-secondary)] line-through">$<?php echo number_format($product['price'] * (1 + $product['allowed_discount']/100), 2); ?></span>
                        <span class="bg-red-500 text-white px-2 py-1 rounded-full text-sm font-bold">-<?php echo $product['allowed_discount']; ?>%</span>
                        <?php endif; ?>
                    </div>

                    <p class="text-lg text-[var(--text-primary)] leading-relaxed"><?php echo htmlspecialchars($product['mini_desc'] ?? ''); ?></p>
                </div>

                <form method="POST">
                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                    <div class="space-y-4">
                        <div class="flex items-center space-x-4">
                            <button type="submit" name="add_to_cart" class="flex-1 bg-[var(--accent)] text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-600 transition-colors flex items-center justify-center space-x-2">
                                <span class="material-icons">shopping_cart</span>
                                <span>Add to Cart</span>
                            </button>
                            <button type="button" class="w-12 h-12 border border-[var(--border)] rounded-lg flex items-center justify-center hover:bg-[var(--bg-secondary)] transition-colors">
                                <span class="material-icons text-[var(--text-primary)]">favorite_border</span>
                            </button>
                        </div>
                        
                        <button type="button" class="w-full bg-green-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-green-700 transition-colors flex items-center justify-center space-x-2">
                            <span class="material-icons">flash_on</span>
                            <span>Buy Now</span>
                        </button>
                    </div>
                </form>

                <div class="border-t border-[var(--border)] pt-6">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-[var(--accent)] rounded-full flex items-center justify-center">
                            <span class="material-icons text-white text-sm">store</span>
                        </div>
                        <div>
                            <p class="text-sm text-[var(--text-secondary)]">Sold by</p>
                            <p class="font-semibold text-[var(--text-primary)]"><?php echo htmlspecialchars($product['seller_name'] ?? 'Unknown Seller'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-16 border-t border-[var(--border)] pt-12">
            <div class="max-w-4xl">
                <h2 class="text-2xl font-bold text-[var(--text-primary)] mb-8">Product Details</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="space-y-4">
                        <div>
                            <h3 class="font-semibold text-[var(--text-primary)] mb-2">Description</h3>
                           <p class="text-[var(--text-secondary)] leading-relaxed whitespace-pre-wrap break-words">
    <?php echo nl2br(htmlspecialchars($product['description'] ?? 'No description available.')); ?>
</p>
                        </div>
                    </div>
                    
                    <div class="space-y-6">
                        <div>
                            <h3 class="font-semibold text-[var(--text-primary)] mb-4">Specifications</h3>
                            <div class="space-y-3">
                                <div class="flex justify-between border-b border-[var(--border)] pb-2">
                                    <span class="text-[var(--text-secondary)]">Seller</span>
                                    <span class="font-medium"><?php echo htmlspecialchars($product['seller_name'] ?? 'Unknown Seller'); ?></span>
                                </div>
                                <div class="flex justify-between border-b border-[var(--border)] pb-2">
                                    <span class="text-[var(--text-secondary)]">Category</span>
                                    <span class="font-medium"><?php echo htmlspecialchars($product['category'] ?? 'General'); ?></span>
                                </div>
                                <div class="flex justify-between border-b border-[var(--border)] pb-2">
                                    <span class="text-[var(--text-secondary)]">SKU</span>
                                    <span class="font-medium">#<?php echo $product['id']; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if(!empty($related_products)): ?>
        <div class="mt-16 border-t border-[var(--border)] pt-12">
            <div class="max-w-6xl">
                <h2 class="text-2xl font-bold text-[var(--text-primary)] mb-8">People Also Search For</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <?php foreach($related_products as $related): ?>
                    <div class="bg-white rounded-xl border border-[var(--border)] overflow-hidden hover:shadow-lg transition-shadow">
                        <a href="full_detail.php?id=<?php echo $related['id']; ?>" class="block">
                            <div class="aspect-square overflow-hidden">
                                <img src="<?php echo htmlspecialchars($related['image_url'] ?? ''); ?>" 
                                     alt="<?php echo htmlspecialchars($related['name']); ?>"
                                     class="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                                     onerror="this.src='https://via.placeholder.com/300x300/e2e8f0/64748b?text=Product+Image'">
                            </div>
                            <div class="p-4">
                                <h3 class="font-semibold text-[var(--text-primary)] mb-2 line-clamp-2"><?php echo htmlspecialchars($related['name']); ?></h3>
                                <p class="text-sm text-[var(--text-secondary)] mb-3 line-clamp-2"><?php echo htmlspecialchars($related['mini_desc'] ?? ''); ?></p>
                                <div class="flex items-center justify-between">
                                    <span class="text-lg font-bold text-[var(--accent)]">$<?php echo number_format($related['price'], 2); ?></span>
                                    <?php if(isset($related['allowed_discount']) && $related['allowed_discount'] > 0): ?>
                                    <span class="bg-red-500 text-white px-2 py-1 rounded text-xs font-bold">-<?php echo $related['allowed_discount']; ?>%</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</main>

<footer class="w-full bg-[var(--bg-secondary)] border-t border-[var(--border)] mt-16">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div class="md:col-span-1">
                <div class="flex items-center space-x-3 mb-4">
                    <div class="w-8 h-8 bg-[var(--accent)] rounded-lg flex items-center justify-center">
                        <span class="material-icons text-white text-sm">shopping_bag</span>
                    </div>
                    <span class="text-lg font-semibold text-[var(--text-primary)]">Zencom</span>
                </div>
                <p class="text-sm text-[var(--text-secondary)]">Quality products, exceptional service</p>
            </div>
            <div>
                <h4 class="font-semibold text-[var(--text-primary)] mb-4">Shop</h4>
                <ul class="space-y-2 text-sm text-[var(--text-secondary)]">
                    <li><a href="view.php" class="hover:text-[var(--accent)] transition-colors">All Products</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">New Arrivals</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Best Sellers</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-semibold text-[var(--text-primary)] mb-4">Support</h4>
                <ul class="space-y-2 text-sm text-[var(--text-secondary)]">
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Contact Us</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Shipping</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Returns</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-semibold text-[var(--text-primary)] mb-4">Company</h4>
                <ul class="space-y-2 text-sm text-[var(--text-secondary)]">
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">About</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Careers</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Privacy</a></li>
                </ul>
            </div>
        </div>
        <div class="border-t border-[var(--border)] mt-8 pt-8 text-center">
            <p class="text-sm text-[var(--text-secondary)]">© 2025 Zencom. All rights reserved.</p>
        </div>
    </div>
</footer>

<button class="fixed bottom-6 right-6 w-12 h-12 bg-[var(--accent)] text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center z-50" onclick="toggleTheme()">
    <span class="material-icons" id="themeIcon">dark_mode</span>
</button>

<script>
const currentTheme = localStorage.getItem('theme') || 'light';
document.documentElement.className = currentTheme;
updateThemeIcon();

function toggleTheme() {
    const newTheme = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
    document.documentElement.className = newTheme;
    localStorage.setItem('theme', newTheme);
    updateThemeIcon();
}

function updateThemeIcon() {
    const icon = document.getElementById('themeIcon');
    icon.textContent = document.documentElement.classList.contains('dark') ? 'light_mode' : 'dark_mode';
}
</script>

</body>
</html>