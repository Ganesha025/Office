<?php
session_start();
require "../config/db.php";

$error = '';
$success = '';
$isLogin = isset($_GET['login']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($isLogin) {
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        
        if (empty($email) || empty($password)) {
            $error = 'Email and password are required';
        } else {
            $sql = "SELECT id, name, email, password FROM users WHERE email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                if (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    $success = 'Login successful! Redirecting...';
                    header("refresh:2;url=view.php");
                } else {
                    $error = 'Invalid password';
                }
            } else {
                $error = 'No account found with this email';
            }
        }
    } else {
        $name = trim($_POST['name']);
        $mobile = trim($_POST['mobile']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        $door_no = trim($_POST['door_no']);
        $street_name = trim($_POST['street_name']);
        $city = trim($_POST['city']);
        $pincode = trim($_POST['pincode']);
        $district = trim($_POST['district']);
        
        if (empty($name) || empty($mobile) || empty($email) || empty($password)) {
            $error = 'All fields are required';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format';
        } elseif (!preg_match('/^[0-9]{10}$/', $mobile)) {
            $error = 'Mobile number must be 10 digits';
        } else {
            $check_sql = "SELECT id FROM users WHERE email = ? OR mobile = ?";
            $stmt = $conn->prepare($check_sql);
            $stmt->bind_param("ss", $email, $mobile);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $error = 'Email or mobile number already registered';
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $full_address = "$door_no, $street_name, $city, $district - $pincode";
                
                $insert_sql = "INSERT INTO users (name, mobile, email, password, door_no, street_name, city, pincode, district, full_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($insert_sql);
                $stmt->bind_param("ssssssssss", $name, $mobile, $email, $hashed_password, $door_no, $street_name, $city, $pincode, $district, $full_address);
                
                if ($stmt->execute()) {
                    $success = 'Registration successful! Redirecting to login...';
                    header("refresh:2;url=?login");
                } else {
                    $error = 'Registration failed. Please try again';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $isLogin ? 'Login' : 'Register'; ?> - Zencom</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Inter',sans-serif;}
:root{--bg-primary:#ffffff;--bg-secondary:#f8fafc;--text-primary:#0f172a;--text-secondary:#64748b;--accent:#2563eb;--border:#e2e8f0;}
.dark{--bg-primary:#0f172a;--bg-secondary:#1e293b;--text-primary:#0f172a;--text-secondary:#94a3b8;--accent:#3b82f6;--border:#334155;}
body{background:var(--bg-primary);color:var(--text-primary);transition:all 0.3s ease;}
input:focus{outline:none;ring:2px;ring-color:var(--accent);border-color:transparent;}
.password-container{position:relative;}
.toggle-password{position:absolute;right:12px;top:50%;transform:translateY(-50%);cursor:pointer;color:var(--text-secondary);}
</style>
</head>
<body class="min-h-screen bg-[var(--bg-primary)]">

<header class="bg-white/80 backdrop-blur-md border-b border-[var(--border)]">
    <div class="max-w-7xl mx-auto px-6 py-4">
        <div class="flex items-center justify-between">
            <a href="view.php" class="flex items-center gap-3">
                <div class="w-10 h-10 bg-[var(--accent)] rounded-xl flex items-center justify-center">
                    <span class="material-icons text-white">shopping_bag</span>
                </div>
                <span class="text-xl font-bold text-[var(--text-primary)]">Zencom</span>
            </a>
            <div class="flex items-center gap-4">
                <?php if($isLogin): ?>
                    <span class="text-[var(--text-secondary)]">Don't have an account?</span>
                    <a href="?" class="bg-[var(--accent)] text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-blue-600 transition-all shadow-sm">Register</a>
                <?php else: ?>
                    <span class="text-[var(--text-secondary)]">Already have an account?</span>
                    <a href="?login" class="bg-[var(--accent)] text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-blue-600 transition-all shadow-sm">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>

<main class="py-12">
    <div class="max-w-md mx-auto px-6">
        <div class="text-center mb-12">
            <h1 class="text-4xl font-bold text-[var(--text-primary)] mb-3">
                <?php echo $isLogin ? 'Welcome Back' : 'Create Your Account'; ?>
            </h1>
            <p class="text-lg text-[var(--text-secondary)]">
                <?php echo $isLogin ? 'Sign in to your account' : 'Join Zencom and start shopping today'; ?>
            </p>
        </div>

        <div class="bg-white rounded-2xl border border-[var(--border)] shadow-lg overflow-hidden">
            <?php if ($error): ?>
            <div class="px-8 py-4 bg-red-50 border-b border-red-200">
                <div class="flex items-center gap-3 text-red-700">
                    <span class="material-icons">error</span>
                    <span class="font-semibold"><?php echo htmlspecialchars($error); ?></span>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
            <div class="px-8 py-4 bg-green-50 border-b border-green-200">
                <div class="flex items-center gap-3 text-green-700">
                    <span class="material-icons">check_circle</span>
                    <span class="font-semibold"><?php echo htmlspecialchars($success); ?></span>
                </div>
            </div>
            <?php endif; ?>

            <form method="POST" class="px-8 py-8">
                <?php if (!$isLogin): ?>
                <div class="mb-6">
                    <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">Full Name *</label>
                    <input type="text" name="name" required value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="Enter your full name">
                </div>

                <div class="mb-6">
                    <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">Mobile Number *</label>
                    <input type="tel" name="mobile" required pattern="[0-9]{10}" value="<?php echo isset($_POST['mobile']) ? htmlspecialchars($_POST['mobile']) : ''; ?>" class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="10 digit mobile number">
                </div>
                <?php endif; ?>

                <div class="mb-6">
                    <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">Email Address *</label>
                    <input type="email" name="email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="your@email.com">
                </div>

                <?php if (!$isLogin): ?>
                <div class="mb-8">
                    <div class="flex items-center gap-3 mb-4">
                        <span class="material-icons text-[var(--accent)]">location_on</span>
                        <h2 class="text-lg font-bold text-[var(--text-primary)]">Address Details</h2>
                    </div>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">Door No. / Building *</label>
                            <input type="text" name="door_no" required value="<?php echo isset($_POST['door_no']) ? htmlspecialchars($_POST['door_no']) : ''; ?>" class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="123, Building Name">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">Street Name *</label>
                            <input type="text" name="street_name" required value="<?php echo isset($_POST['street_name']) ? htmlspecialchars($_POST['street_name']) : ''; ?>" class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="Street, Area, Locality">
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">City *</label>
                                <input type="text" name="city" required value="<?php echo isset($_POST['city']) ? htmlspecialchars($_POST['city']) : ''; ?>" class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="Mumbai">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">District *</label>
                                <input type="text" name="district" required value="<?php echo isset($_POST['district']) ? htmlspecialchars($_POST['district']) : ''; ?>" class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="Mumbai">
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">PIN Code *</label>
                            <input type="text" name="pincode" required pattern="[0-9]{6}" value="<?php echo isset($_POST['pincode']) ? htmlspecialchars($_POST['pincode']) : ''; ?>" class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="6 digit PIN code">
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="mb-6">
                    <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">Password *</label>
                    <div class="password-container">
                        <input type="password" name="password" required <?php if(!$isLogin) echo 'minlength="6"'; ?> class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="<?php echo $isLogin ? 'Enter your password' : 'At least 6 characters'; ?>">
                        <span class="toggle-password material-icons" onclick="togglePassword(this)">visibility</span>
                    </div>
                </div>

                <?php if (!$isLogin): ?>
                <div class="mb-6">
                    <label class="block text-sm font-semibold text-[var(--text-primary)] mb-2">Confirm Password *</label>
                    <div class="password-container">
                        <input type="password" name="confirm_password" required minlength="6" class="w-full px-4 py-3 border border-[var(--border)] rounded-xl text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent" placeholder="Re-enter password">
                        <span class="toggle-password material-icons" onclick="togglePassword(this)">visibility</span>
                    </div>
                </div>
                <?php endif; ?>

                <button type="submit" class="w-full bg-[var(--accent)] text-white py-4 px-6 rounded-xl font-bold hover:bg-blue-600 transition-all flex items-center justify-center gap-3 shadow-lg hover:shadow-xl">
                    <span class="material-icons"><?php echo $isLogin ? 'login' : 'person_add'; ?></span>
                    <span><?php echo $isLogin ? 'Sign In' : 'Create Account'; ?></span>
                </button>

                <p class="text-center text-[var(--text-secondary)] mt-6">
                    <?php if($isLogin): ?>
                    Don't have an account? 
                    <a href="?" class="text-[var(--accent)] font-semibold hover:underline">Register here</a>
                    <?php else: ?>
                    Already have an account? 
                    <a href="?login" class="text-[var(--accent)] font-semibold hover:underline">Login here</a>
                    <?php endif; ?>
                </p>
            </form>
        </div>
    </div>
</main>

<footer class="bg-[var(--bg-secondary)] border-t border-[var(--border)] mt-24">
    <div class="max-w-7xl mx-auto px-6 py-16">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div>
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 bg-[var(--accent)] rounded-xl flex items-center justify-center">
                        <span class="material-icons text-white">shopping_bag</span>
                    </div>
                    <span class="text-xl font-bold text-[var(--text-primary)]">Zencom</span>
                </div>
                <p class="text-[var(--text-secondary)] leading-relaxed">Quality products, exceptional service</p>
            </div>
            <div>
                <h4 class="font-bold text-[var(--text-primary)] mb-4">Shop</h4>
                <ul class="space-y-3 text-[var(--text-secondary)]">
                    <li><a href="view.php" class="hover:text-[var(--accent)] transition-colors">All Products</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">New Arrivals</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Best Sellers</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-bold text-[var(--text-primary)] mb-4">Support</h4>
                <ul class="space-y-3 text-[var(--text-secondary)]">
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Contact Us</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Shipping</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Returns</a></li>
                </ul>
            </div>
            <div>
                <h4 class="font-bold text-[var(--text-primary)] mb-4">Company</h4>
                <ul class="space-y-3 text-[var(--text-secondary)]">
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">About</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Careers</a></li>
                    <li><a href="#" class="hover:text-[var(--accent)] transition-colors">Privacy</a></li>
                </ul>
            </div>
        </div>
        <div class="border-t border-[var(--border)] mt-12 pt-8 text-center">
            <p class="text-[var(--text-secondary)]">© 2025 Zencom. All rights reserved.</p>
        </div>
    </div>
</footer>

<button class="fixed bottom-8 right-8 w-14 h-14 bg-[var(--accent)] text-white rounded-full shadow-xl hover:shadow-2xl transition-all flex items-center justify-center z-50 hover:scale-110" onclick="toggleTheme()">
    <span class="material-icons" id="themeIcon">dark_mode</span>
</button>

<script>
const currentTheme = localStorage.getItem('theme') || 'light';
document.documentElement.className = currentTheme;
updateThemeIcon();

function toggleTheme() {
    const newTheme = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
    document.documentElement.className = newTheme;
    localStorage.setItem('theme', newTheme);
    updateThemeIcon();
}

function updateThemeIcon() {
    const icon = document.getElementById('themeIcon');
    icon.textContent = document.documentElement.classList.contains('dark') ? 'light_mode' : 'dark_mode';
}

function togglePassword(element) {
    const passwordInput = element.previousElementSibling;
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        element.textContent = 'visibility_off';
    } else {
        passwordInput.type = 'password';
        element.textContent = 'visibility';
    }
}
</script>

</body>
</html>