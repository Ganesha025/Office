<?php
require "../config/db.php";
session_start();
if(!isset($_SESSION['seller_id'])){
    header("Location: register.php");
    exit;
}
if(isset($_GET['logout'])){
    session_destroy();
    header("Location: register.php");
    exit;
}

$seller_id = $_SESSION['seller_id'];

$total_orders = 0;
$total_products = 0;
$pending_shipments = 0;
$recent_orders = [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Seller Dashboard - Zencom</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
body{font-family:'Inter',sans-serif;background:#222831;min-height:100vh;}
.header, .footer{background:#31363F;color:#EEEEEE;}
.sidebar{background:#31363F;}
.main-content{background:#222831;color:#EEEEEE;}
.nav-link{transition:all 0.2s ease;}
.nav-link:hover{background:#76ABAE;color:#EEEEEE;}
.card{background:#31363F;box-shadow:0 4px 12px rgba(0,0,0,0.3);}
</style>
</head>
<body class="flex flex-col min-h-screen">
<header class="header w-full py-3 sm:py-4 px-4 sm:px-6 shadow-lg flex justify-between items-center">
<h1 class="text-lg sm:text-xl md:text-2xl font-bold">Zencom Seller Dashboard</h1>
<a href="?logout=1" class="btn-logout bg-[#76ABAE] text-[#EEEEEE] px-3 py-1 rounded hover:bg-[#689FA2]">Logout</a>
</header>
<div class="flex flex-1">
<aside class="sidebar w-64 hidden md:block flex-shrink-0 p-4 space-y-4">
<nav class="flex flex-col space-y-2">
<a href="#" class="nav-link text-white block px-3 py-2 rounded">Dashboard</a>
<a href="#" class="nav-link text-white block px-3 py-2 rounded">Orders</a>
<a href="product.php" class="nav-link text-white block px-3 py-2 rounded">Products</a>
<a href="#" class="nav-link text-white block px-3 py-2 rounded">Inventory</a>
<a href="#" class="nav-link text-white block px-3 py-2 rounded">Analytics</a>
<a href="#" class="nav-link text-white block px-3 py-2 rounded">Profile</a>
</nav>
</aside>
<main class="main-content flex-1 p-4 sm:p-6">
<h2 class="text-2xl sm:text-3xl font-bold mb-4">Welcome, <?php echo htmlspecialchars($_SESSION['seller_name']); ?>!</h2>
<p class="mb-6 text-sm sm:text-base opacity-80">Here’s a quick overview of your store performance.</p>
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
<div class="card p-4 rounded-lg">
<h3 class="font-semibold text-lg mb-2">Total Orders</h3>
<p class="text-xl font-bold"><?php echo $total_orders; ?></p>
</div>
<div class="card p-4 rounded-lg">
<h3 class="font-semibold text-lg mb-2">Products Listed</h3>
<p class="text-xl font-bold"><?php echo $total_products; ?></p>
</div>
<div class="card p-4 rounded-lg">
<h3 class="font-semibold text-lg mb-2">Pending Shipments</h3>
<p class="text-xl font-bold"><?php echo $pending_shipments; ?></p>
</div>
</div>
<div class="mt-6">
<h3 class="text-xl font-semibold mb-2">Recent Orders</h3>
<div class="overflow-x-auto">
<table class="min-w-full text-sm sm:text-base">
<thead class="bg-[#31363F] text-[#EEEEEE]">
<tr>
<th class="px-3 py-2 text-left">Order ID</th>
<th class="px-3 py-2 text-left">Customer</th>
<th class="px-3 py-2 text-left">Amount</th>
<th class="px-3 py-2 text-left">Status</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="4" class="px-3 py-2 text-center text-gray-400">No recent orders</td>
</tr>
</tbody>
</table>
</div>
</div>
</main>
</div>
<footer class="footer w-full py-3 sm:py-4 px-4 sm:px-6 shadow-lg mt-auto">
<div class="max-w-7xl mx-auto text-center text-xs sm:text-sm text-[#EEEEEE]">
© 2025 Zencom. All Rights Reserved.
</div>
</footer>
</body>
</html>
