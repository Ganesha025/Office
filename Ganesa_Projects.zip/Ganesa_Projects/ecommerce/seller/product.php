<!-- product.php -->
<?php
require "../config/db.php";
session_start();
if(!isset($_SESSION['seller_id'])){
    header("Location: register.php");
    exit;
}
$seller_id = $_SESSION['seller_id'];

$conn->query("CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    seller_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    mini_desc VARCHAR(255),
    description TEXT,
    image_url VARCHAR(500),
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    allowed_discount DECIMAL(5,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

if(isset($_POST['add_product'])){
    $name = $_POST['name'];
    $mini_desc = $_POST['mini_desc'];
    $desc = $_POST['description'];
    $image = $_POST['image_url'];
    $price = $_POST['price'];
    $discount = $_POST['allowed_discount'];
    $stmt = $conn->prepare("INSERT INTO products (seller_id,name,mini_desc,description,image_url,price,allowed_discount) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("issssdd",$seller_id,$name,$mini_desc,$desc,$image,$price,$discount);
    $stmt->execute();
    header("Location: product.php");
    exit;
}

if(isset($_POST['edit_product'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $mini_desc = $_POST['mini_desc'];
    $desc = $_POST['description'];
    $image = $_POST['image_url'];
    $price = $_POST['price'];
    $discount = $_POST['allowed_discount'];
    $stmt = $conn->prepare("UPDATE products SET name=?, mini_desc=?, description=?, image_url=?, price=?, allowed_discount=? WHERE id=? AND seller_id=?");
    $stmt->bind_param("ssssddii",$name,$mini_desc,$desc,$image,$price,$discount,$id,$seller_id);
    $stmt->execute();
    header("Location: product.php");
    exit;
}

if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM products WHERE id=? AND seller_id=?");
    $stmt->bind_param("ii",$id,$seller_id);
    $stmt->execute();
    header("Location: product.php");
    exit;
}

if(isset($_GET['logout'])){
    session_destroy();
    header("Location: register.php");
    exit;
}

$products = $conn->prepare("SELECT * FROM products WHERE seller_id=? ORDER BY id DESC");
$products->bind_param("i",$seller_id);
$products->execute();
$result = $products->get_result();
$all_products = [];
while($row = $result->fetch_assoc()){
    $all_products[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Products - Zencom</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
*{font-family:'Inter',sans-serif;margin:0;padding:0;box-sizing:border-box;}
:root {
    --bg-primary: #ffffff;
    --bg-secondary: #f8fafc;
    --bg-card: #ffffff;
    --text-primary: #1e293b;
    --text-secondary: #64748b;
    --accent: #76ABAE;
    --border: #e2e8f0;
    --shadow: 0 1px 3px rgba(0,0,0,0.1);
}
.dark {
    --bg-primary: #222831;
    --bg-secondary: #31363F;
    --bg-card: #31363F;
    --text-primary: #EEEEEE;
    --text-secondary: #94a3b8;
    --accent: #76ABAE;
    --border: #374151;
    --shadow: 0 1px 3px rgba(0,0,0,0.3);
}
body{background:var(--bg-primary);color:var(--text-primary);transition:all 0.3s ease;}
.glass{background:var(--bg-card);border:1px solid var(--border);box-shadow:var(--shadow);}
.input-field{transition:all 0.3s ease;border:1px solid var(--border);background:var(--bg-primary);color:var(--text-primary);}
.input-field:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(118,171,174,0.1);outline:none;}
.btn-primary{background:var(--accent);transition:all 0.3s ease;color:#ffffff;}
.btn-primary:hover{background:#689FA2;transform:translateY(-1px);box-shadow:0 4px 12px rgba(118,171,174,0.3);}
.btn-danger{background:#ef4444;transition:all 0.3s ease;color:#ffffff;}
.btn-danger:hover{background:#dc2626;transform:translateY(-1px);}
.btn-warning{background:#f59e0b;transition:all 0.3s ease;color:#ffffff;}
.btn-warning:hover{background:#d97706;transform:translateY(-1px);}
.btn-secondary{background:#6b7280;transition:all 0.3s ease;color:#ffffff;}
.btn-secondary:hover{background:#4b5563;transform:translateY(-1px);}
.modal-overlay{background:rgba(0,0,0,0.5);backdrop-filter:blur(4px);}
.modal-content{animation:slideUp 0.3s ease;}
@keyframes slideUp{from{opacity:0;transform:translateY(20px);}to{opacity:1;transform:translateY(0);}}
.product-card{transition:all 0.3s ease;border:1px solid var(--border);}
.product-card:hover{border-color:var(--accent);transform:translateY(-2px);}
.empty-state{opacity:0.6;}
table{border-collapse:separate;border-spacing:0;}
tbody tr{transition:all 0.2s ease;}
tbody tr:hover{background:rgba(118,171,174,0.05);}
.stat-card{background:linear-gradient(135deg,var(--accent) 0%,#689FA2 100%);color:#ffffff;}
.theme-toggle{position:fixed;bottom:2rem;right:2rem;z-index:50;width:3rem;height:3rem;border-radius:50%;background:var(--accent);color:#ffffff;border:none;box-shadow:0 4px 12px rgba(0,0,0,0.15);cursor:pointer;transition:all 0.3s ease;}
.theme-toggle:hover{transform:scale(1.1);}
</style>
</head>
<body class="flex flex-col min-h-screen">

<header class="w-full bg-[var(--bg-secondary)] py-4 px-6 border-b border-[var(--border)] sticky top-0 z-40">
<div class="max-w-7xl mx-auto flex items-center justify-between">
<div class="flex items-center space-x-3">
<div class="w-10 h-10 bg-[var(--accent)] rounded-lg flex items-center justify-center">
<svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
</svg>
</div>
<h1 class="text-xl font-bold text-[var(--text-primary)]">Zencom Seller Portal</h1>
</div>
<div class="flex items-center space-x-3">
<span class="text-sm text-[var(--text-secondary)]">Welcome, <?php echo htmlspecialchars($_SESSION['seller_name']); ?></span>
<a href="?logout=1" class="btn-primary px-4 py-2 rounded-lg text-sm font-medium flex items-center space-x-2">
<span class="material-icons text-lg">logout</span>
<span>Logout</span>
</a>
</div>
</div>
</header>

<main class="flex-1 p-6">
<div class="max-w-7xl mx-auto">
<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
<div>
<h2 class="text-2xl font-bold text-[var(--text-primary)]">Product Management</h2>
<p class="text-sm text-[var(--text-secondary)] mt-1">Manage your product inventory</p>
</div>
<button onclick="openModal('add')" class="btn-primary px-6 py-3 rounded-lg text-base font-medium flex items-center space-x-2 w-full sm:w-auto">
<span class="material-icons text-xl">add_circle</span>
<span>Add New Product</span>
</button>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
<div class="stat-card rounded-xl p-6">
<div class="flex items-center justify-between">
<div>
<p class="text-sm opacity-90">Total Products</p>
<p class="text-3xl font-bold mt-1"><?php echo count($all_products); ?></p>
</div>
<div class="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
<span class="material-icons text-2xl">inventory_2</span>
</div>
</div>
</div>
<div class="stat-card rounded-xl p-6">
<div class="flex items-center justify-between">
<div>
<p class="text-sm opacity-90">Avg Price</p>
<p class="text-3xl font-bold mt-1">$<?php 
$avg = count($all_products)>0 ? array_sum(array_column($all_products,'price'))/count($all_products) : 0;
echo number_format($avg,2); 
?></p>
</div>
<div class="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
<span class="material-icons text-2xl">attach_money</span>
</div>
</div>
</div>
<div class="stat-card rounded-xl p-6">
<div class="flex items-center justify-between">
<div>
<p class="text-sm opacity-90">Total Value</p>
<p class="text-3xl font-bold mt-1">$<?php 
echo number_format(array_sum(array_column($all_products,'price')),2); 
?></p>
</div>
<div class="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
<span class="material-icons text-2xl">trending_up</span>
</div>
</div>
</div>
</div>

<div class="glass rounded-xl overflow-hidden">
<div class="hidden md:block overflow-x-auto">
<table class="w-full">
<thead class="bg-[var(--accent)] text-white">
<tr>
<th class="px-6 py-4 text-left text-sm font-semibold">ID</th>
<th class="px-6 py-4 text-left text-sm font-semibold">Product</th>
<th class="px-6 py-4 text-left text-sm font-semibold">Description</th>
<th class="px-6 py-4 text-left text-sm font-semibold">Price</th>
<th class="px-6 py-4 text-left text-sm font-semibold">Discount</th>
<th class="px-6 py-4 text-center text-sm font-semibold">Actions</th>
</tr>
</thead>
<tbody class="text-[var(--text-primary)]">
<?php if(count($all_products)>0): ?>
<?php foreach($all_products as $row): ?>
<tr class="border-b border-[var(--border)]">
<td class="px-6 py-4 text-sm font-medium">#<?php echo $row['id']; ?></td>
<td class="px-6 py-4">
<div class="flex items-center space-x-3">
<img src="<?php echo htmlspecialchars($row['image_url']); ?>" class="w-16 h-16 object-cover rounded-lg" onerror="this.src='https://via.placeholder.com/100'">
<span class="text-sm font-medium"><?php echo htmlspecialchars($row['name']); ?></span>
</div>
</td>
<td class="px-6 py-4 text-sm text-[var(--text-secondary)] max-w-xs truncate"><?php echo htmlspecialchars($row['mini_desc']); ?></td>
<td class="px-6 py-4 text-sm font-semibold">$<?php echo number_format($row['price'],2); ?></td>
<td class="px-6 py-4 text-sm">
<span class="bg-[var(--accent)] px-2 py-1 rounded text-white"><?php echo $row['allowed_discount']; ?>%</span>
</td>
<td class="px-6 py-4">
<div class="flex items-center justify-center space-x-2">
<button onclick='openModal("edit",<?php echo json_encode($row); ?>)' class="btn-warning px-3 py-1.5 rounded-lg text-xs font-medium flex items-center space-x-1">
<span class="material-icons text-sm">edit</span>
<span>Edit</span>
</button>
<a href="?delete=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this product?');" class="btn-danger px-3 py-1.5 rounded-lg text-xs font-medium flex items-center space-x-1">
<span class="material-icons text-sm">delete</span>
<span>Delete</span>
</a>
</div>
</td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr>
<td colspan="6" class="px-4 py-12 text-center">
<div class="empty-state">
<span class="material-icons text-6xl text-[var(--accent)] mb-3">inventory_2</span>
<p class="text-lg font-medium text-[var(--text-primary)]">No products found</p>
<p class="text-sm text-[var(--text-secondary)] mt-1">Click "Add New Product" to get started</p>
</div>
</td>
</tr>
<?php endif; ?>
</tbody>
</table>
</div>

<div class="md:hidden divide-y divide-[var(--border)]">
<?php if(count($all_products)>0): ?>
<?php foreach($all_products as $row): ?>
<div class="product-card p-4 bg-[var(--bg-card)]">
<div class="flex items-start space-x-3 mb-3">
<img src="<?php echo htmlspecialchars($row['image_url']); ?>" class="w-16 h-16 object-cover rounded-lg flex-shrink-0" onerror="this.src='https://via.placeholder.com/100'">
<div class="flex-1 min-w-0">
<h3 class="text-sm font-semibold text-[var(--text-primary)] truncate"><?php echo htmlspecialchars($row['name']); ?></h3>
<p class="text-xs text-[var(--text-secondary)] truncate mt-1"><?php echo htmlspecialchars($row['mini_desc']); ?></p>
<div class="flex items-center space-x-2 mt-2">
<span class="text-sm font-bold text-[var(--accent)]">$<?php echo number_format($row['price'],2); ?></span>
<span class="text-xs bg-[var(--accent)] px-2 py-0.5 rounded text-white"><?php echo $row['allowed_discount']; ?>% OFF</span>
</div>
</div>
</div>
<div class="flex space-x-2">
<button onclick='openModal("edit",<?php echo json_encode($row); ?>)' class="btn-warning flex-1 px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-center space-x-1">
<span class="material-icons text-sm">edit</span>
<span>Edit</span>
</button>
<a href="?delete=<?php echo $row['id']; ?>" onclick="return confirm('Delete this product?');" class="btn-danger flex-1 px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-center space-x-1">
<span class="material-icons text-sm">delete</span>
<span>Delete</span>
</a>
</div>
</div>
<?php endforeach; ?>
<?php else: ?>
<div class="p-12 text-center empty-state">
<span class="material-icons text-6xl text-[var(--accent)] mb-3">inventory_2</span>
<p class="text-base font-medium text-[var(--text-primary)]">No products found</p>
<p class="text-sm text-[var(--text-secondary)] mt-1">Click "Add New Product" to get started</p>
</div>
<?php endif; ?>
</div>
</div>
</div>
</main>

<div id="modal" class="hidden fixed inset-0 flex items-center justify-center modal-overlay z-50 p-4">
<div class="glass modal-content rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
<div class="sticky top-0 bg-[var(--bg-card)] px-6 py-5 border-b border-[var(--border)] flex items-center justify-between">
<h2 id="modalTitle" class="text-xl font-bold text-[var(--text-primary)]">Add Product</h2>
<button onclick="closeModal()" class="text-[var(--text-secondary)] hover:text-[var(--accent)] transition-colors">
<span class="material-icons text-2xl">close</span>
</button>
</div>
<form method="POST" id="productForm" class="p-6">
<input type="hidden" name="id" id="productId">
<div class="space-y-4">
<div>
<label class="block text-sm font-medium text-[var(--text-primary)] mb-2">Product Name*</label>
<input type="text" name="name" id="name" required class="input-field w-full px-4 py-2.5 rounded-lg text-base" placeholder="Enter product name">
</div>
<div>
<label class="block text-sm font-medium text-[var(--text-primary)] mb-2">Mini Description</label>
<input type="text" name="mini_desc" id="mini_desc" class="input-field w-full px-4 py-2.5 rounded-lg text-base" placeholder="Short description">
</div>
<div>
<label class="block text-sm font-medium text-[var(--text-primary)] mb-2">Full Description</label>
<textarea name="description" id="description" rows="4" class="input-field w-full px-4 py-2.5 rounded-lg text-base resize-none" placeholder="Detailed product description"></textarea>
</div>
<div>
<label class="block text-sm font-medium text-[var(--text-primary)] mb-2">Image URL</label>
<input type="url" name="image_url" id="image_url" class="input-field w-full px-4 py-2.5 rounded-lg text-base" placeholder="https://example.com/image.jpg">
</div>
<div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
<div>
<label class="block text-sm font-medium text-[var(--text-primary)] mb-2">Price ($)*</label>
<input type="number" step="0.01" min="0" name="price" id="price" required class="input-field w-full px-4 py-2.5 rounded-lg text-base" placeholder="0.00">
</div>
<div>
<label class="block text-sm font-medium text-[var(--text-primary)] mb-2">Discount (%)</label>
<input type="number" step="0.01" min="0" max="100" name="allowed_discount" id="allowed_discount" class="input-field w-full px-4 py-2.5 rounded-lg text-base" placeholder="0">
</div>
</div>
</div>
<div class="flex flex-col sm:flex-row gap-3 mt-6">
<button type="submit" name="add_product" id="submitBtn" class="btn-primary flex-1 px-6 py-3 rounded-lg text-base font-medium flex items-center justify-center space-x-2">
<span class="material-icons text-xl">save</span>
<span id="submitText">Add Product</span>
</button>
<button type="button" onclick="closeModal()" class="btn-secondary px-6 py-3 rounded-lg text-base font-medium flex items-center justify-center space-x-2">
<span class="material-icons text-xl">cancel</span>
<span>Cancel</span>
</button>
</div>
</form>
</div>
</div>

<footer class="w-full bg-[var(--bg-secondary)] py-4 px-6 border-t border-[var(--border)]">
<div class="max-w-7xl mx-auto">
<div class="flex flex-col sm:flex-row items-center justify-between text-[var(--text-secondary)] text-sm">
<p class="mb-2 sm:mb-0">© 2025 Zencom. All Rights Reserved.</p>
<div class="flex items-center space-x-4">
<a href="#" class="hover:text-[var(--accent)] transition-colors">Privacy Policy</a>
<a href="#" class="hover:text-[var(--accent)] transition-colors">Terms of Service</a>
<a href="#" class="hover:text-[var(--accent)] transition-colors">Support</a>
</div>
</div>
</div>
</footer>

<button class="theme-toggle" onclick="toggleTheme()">
<span class="material-icons" id="themeIcon">dark_mode</span>
</button>

<script>
const currentTheme = localStorage.getItem('theme') || 'light';
document.documentElement.className = currentTheme;
updateThemeIcon();

function toggleTheme() {
    const newTheme = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
    document.documentElement.className = newTheme;
    localStorage.setItem('theme', newTheme);
    updateThemeIcon();
}

function updateThemeIcon() {
    const icon = document.getElementById('themeIcon');
    icon.textContent = document.documentElement.classList.contains('dark') ? 'light_mode' : 'dark_mode';
}

function openModal(mode,data=null){
    document.getElementById('modal').classList.remove('hidden');
    const form = document.getElementById('productForm');
    form.reset();
    
    if(mode==='add'){
        document.getElementById('modalTitle').textContent='Add New Product';
        document.getElementById('submitBtn').name='add_product';
        document.getElementById('submitText').textContent='Add Product';
        document.getElementById('productId').value='';
    }else{
        document.getElementById('modalTitle').textContent='Edit Product';
        document.getElementById('submitBtn').name='edit_product';
        document.getElementById('submitText').textContent='Update Product';
        document.getElementById('productId').value=data.id;
        document.getElementById('name').value=data.name;
        document.getElementById('mini_desc').value=data.mini_desc||'';
        document.getElementById('description').value=data.description||'';
        document.getElementById('image_url').value=data.image_url||'';
        document.getElementById('price').value=data.price;
        document.getElementById('allowed_discount').value=data.allowed_discount||0;
    }
}

function closeModal(){
    document.getElementById('modal').classList.add('hidden');
}

document.getElementById('modal').addEventListener('click',function(e){
    if(e.target===this) closeModal();
});
</script>

</body>
</html>