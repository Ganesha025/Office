<?php
require "../config/db.php";
session_start();
if(isset($_SESSION['seller_id'])) header("Location: dashboard.php");

$errors = [];
if(isset($_POST['register'])){
    // Account Information
    $name = $_POST['seller_name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile_number'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    // Business Details
    $business_type = $_POST['business_type'];
    $shop = $_POST['shop_name'];
    $flat_no = $_POST['flat_no'];
    $street = $_POST['street_name'];
    $city = $_POST['city_name'];
    $pincode = $_POST['pincode'];
    $address = $flat_no . ', ' . $street . ', ' . $city . ' - ' . $pincode;
    
    // Identity Proof
    $pan_card = $_POST['pan_card'];
    $aadhaar = $_POST['aadhaar_number'] ?? '';
    
    // Tax Information
    $gstin = $_POST['gstin'] ?? '';
    
    // Bank Account Details
    $bank_account = $_POST['bank_account_number'];
    $ifsc_code = $_POST['ifsc_code'];
    
    // Additional contact info (optional)
    $secondary_name = $_POST['secondary_contact_name'] ?? '';
    $alt_mobile = $_POST['alternative_number'] ?? '';
    $alt_email = $_POST['secondary_email'] ?? '';

    // Validation
    // PAN Card validation
    if(!preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', $pan_card)) {
        $errors[] = "Invalid PAN Card format";
    }
    
    // GSTIN validation (if provided)
    if(!empty($gstin) && !preg_match('/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/', $gstin)) {
        $errors[] = "Invalid GSTIN format";
    }
    
    // Mobile validation
    if(!preg_match('/^[6-9][0-9]{9}$/', $mobile)) {
        $errors[] = "Invalid mobile number format";
    }
    
    // Check for existing user
    $stmt = $conn->prepare("SELECT id FROM sellers WHERE mobile_number=? OR email=?");
    $stmt->bind_param("ss",$mobile,$email);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows>0) $errors[]="Mobile or Email already exists";
    
    if(empty($errors)){
        $stmt = $conn->prepare("INSERT INTO sellers (seller_name, secondary_contact_name, shop_name, business_type, shop_address, mobile_number, alternative_number, email, secondary_email, password, pan_card, aadhaar_number, gstin, bank_account_number, ifsc_code) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sssssssssssssss", $name, $secondary_name, $shop, $business_type, $address, $mobile, $alt_mobile, $email, $alt_email, $password, $pan_card, $aadhaar, $gstin, $bank_account, $ifsc_code);
        $stmt->execute();
        $_SESSION['seller_id'] = $stmt->insert_id;
        $_SESSION['seller_name'] = $name;
        header("Location: dashboard.php");
        exit;
    }
}

if(isset($_POST['login'])){
    $login_email = $_POST['login_email'];
    $login_pass = $_POST['login_password'];
    $stmt = $conn->prepare("SELECT id,seller_name,password FROM sellers WHERE email=?");
    $stmt->bind_param("s",$login_email);
    $stmt->execute();
    $res = $stmt->get_result();
    if($res->num_rows==1){
        $row = $res->fetch_assoc();
        if(password_verify($login_pass,$row['password'])){
            $_SESSION['seller_id']=$row['id'];
            $_SESSION['seller_name']=$row['seller_name'];
            header("Location: dashboard.php");
            exit;
        }else $errors[]="Incorrect password";
    }else $errors[]="Email not registered";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Zencom Seller Portal - Login & Register</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
*{font-family:'Inter',sans-serif;margin:0;padding:0;box-sizing:border-box;}
body{background:#222831;min-h:screen;}
.glass{background:#31363F;box-shadow:0 8px 32px 0 rgba(0,0,0,0.3);}
.input-field{transition:all 0.3s ease;border:2px solid #31363F;background:#EEEEEE;color:#222831;}
.input-field:focus{border-color:#76ABAE;transform:translateY(-2px);box-shadow:0 4px 12px rgba(118,171,174,0.3);}
.btn-primary{background:#76ABAE;transition:all 0.3s ease;color:#EEEEEE;}
.btn-primary:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(118,171,174,0.4);background:#689FA2;}
.error-message{animation:slideIn 0.3s ease;}
@keyframes slideIn{from{opacity:0;transform:translateY(-10px);}to{opacity:1;transform:translateY(0);}}
.forms-container{position:relative;overflow:hidden;width:100%;}
.form-wrapper{display:flex;transition:transform 0.6s cubic-bezier(0.68,-0.55,0.265,1.55);width:200%;}
.form-panel{width:50%;flex-shrink:0;padding:1.5rem;}
.slide-left .form-wrapper{transform:translateX(0);}
.slide-right .form-wrapper{transform:translateX(-50%);}
.password-toggle{position:absolute;right:12px;top:50%;transform:translateY(-50%);cursor:pointer;color:#222831;user-select:none;}
.password-toggle:hover{color:#76ABAE;}
.input-container{position:relative;}
.section-divider{border-top:2px solid #76ABAE;margin:1.5rem 0;padding-top:1rem;}
.section-title{color:#76ABAE;font-weight:600;margin-bottom:1rem;font-size:1.1rem;}
@media (min-width:640px){
.form-panel{padding:2rem;}
}
@media (min-width:768px){
.form-panel{padding:3rem;}
}
</style>
</head>
<body class="flex flex-col min-h-screen">

<header class="w-full bg-[#31363F] py-3 sm:py-4 px-4 sm:px-6 shadow-lg">
<div class="max-w-7xl mx-auto flex items-center justify-between">
<div class="flex items-center space-x-2 sm:space-x-3">
<div class="w-8 h-8 sm:w-10 sm:h-10 bg-[#76ABAE] rounded-lg flex items-center justify-center flex-shrink-0">
<svg class="w-4 h-4 sm:w-6 sm:h-6 text-[#EEEEEE]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
</svg>
</div>
<h1 class="text-lg sm:text-xl md:text-2xl font-bold text-[#EEEEEE]">Zencom Seller Portal</h1>
</div>
</div>
</header>

<div class="flex-1 flex items-center justify-center p-3 sm:p-4 md:p-6 lg:p-8">
<div class="w-full max-w-7xl">

<?php if($errors): ?>
<div class="glass rounded-lg p-3 sm:p-4 mb-4 sm:mb-6 max-w-md mx-auto error-message border-2 border-red-400">
<div class="flex items-center">
<svg class="w-4 h-4 sm:w-5 sm:h-5 text-red-400 mr-2 sm:mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
</svg>
<div class="text-xs sm:text-sm text-[#EEEEEE]">
<?php foreach($errors as $e) echo "<p class='font-medium'>$e</p>"; ?>
</div>
</div>
</div>
<?php endif; ?>

<div class="glass rounded-xl sm:rounded-2xl overflow-hidden max-w-6xl mx-auto">
<div class="grid lg:grid-cols-2">
<div class="hidden lg:flex flex-col justify-center p-6 xl:p-12 bg-[#76ABAE] text-[#EEEEEE]">
<div class="space-y-6">
<div class="w-14 h-14 xl:w-16 xl:h-16 bg-[#31363F] rounded-xl flex items-center justify-center mb-6 xl:mb-8">
<svg class="w-7 h-7 xl:w-8 xl:h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
</svg>
</div>
<h2 class="text-2xl xl:text-3xl font-bold">Welcome to Zencom</h2>
<p class="text-base xl:text-lg opacity-90">Manage your store, track orders, and grow your business with our comprehensive seller dashboard.</p>
<div class="space-y-3 xl:space-y-4 pt-4">
<div class="flex items-center space-x-3">
<div class="w-8 h-8 bg-[#31363F] rounded-full flex items-center justify-center flex-shrink-0">
<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
<path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
</svg>
</div>
<span class="text-sm xl:text-base">Real-time inventory management</span>
</div>
<div class="flex items-center space-x-3">
<div class="w-8 h-8 bg-[#31363F] rounded-full flex items-center justify-center flex-shrink-0">
<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
<path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
</svg>
</div>
<span class="text-sm xl:text-base">Advanced analytics & reports</span>
</div>
<div class="flex items-center space-x-3">
<div class="w-8 h-8 bg-[#31363F] rounded-full flex items-center justify-center flex-shrink-0">
<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
<path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
</svg>
</div>
<span class="text-sm xl:text-base">24/7 seller support</span>
</div>
</div>
</div>
</div>

<div class="forms-container slide-left" id="formsContainer">
<div class="form-wrapper">
<div class="form-panel">
<h2 class="text-xl sm:text-2xl lg:text-3xl font-bold text-[#EEEEEE] mb-2">Welcome Back</h2>
<p class="text-xs sm:text-sm lg:text-base text-[#EEEEEE] opacity-80 mb-4 sm:mb-6 lg:mb-8">Sign in to your seller account</p>
<form method="POST" class="space-y-3 sm:space-y-4 lg:space-y-5">
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Email Address</label>
<input type="email" name="login_email" required class="val-email input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 lg:py-3 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="you@example.com">
</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Password</label>
<div class="input-container">
<input type="password" id="loginPassword" name="login_password" required class="val-password input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 lg:py-3 rounded-lg outline-none text-xs sm:text-sm lg:text-base pr-10" placeholder="••••••••">
<span class="material-icons password-toggle text-lg sm:text-xl" onclick="togglePassword('loginPassword',this)">visibility_off</span>
</div>
</div>
<button type="submit" name="login" class="btn-primary w-full py-2 sm:py-2.5 lg:py-3 rounded-lg font-semibold text-xs sm:text-sm lg:text-base">Sign In</button>
<p class="text-center text-xs sm:text-sm text-[#EEEEEE] opacity-80 mt-3 sm:mt-4 lg:mt-6">
Don't have an account? 
<span id="toRegister" class="text-[#76ABAE] font-semibold cursor-pointer hover:underline">Create Account</span>
</p>
</form>
</div>

<div class="form-panel">
<h2 class="text-xl sm:text-2xl lg:text-3xl font-bold text-[#EEEEEE] mb-2">Create Account</h2>
<p class="text-xs sm:text-sm lg:text-base text-[#EEEEEE] opacity-80 mb-4 sm:mb-6 lg:mb-8">Join Zencom as a seller today</p>
<form method="POST" class="space-y-3 sm:space-y-4">
<!-- Account Information Section -->
<div class="section-divider">
<div class="section-title">Account Information</div>
<div class="grid sm:grid-cols-2 gap-3 sm:gap-4">
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Full Name / Business Name*</label>
<input type="text" name="seller_name" required class="val-username input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="John Doe or ABC Enterprises">
</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Business Type*</label>
<select name="business_type" required class="input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base">
<option value="">Select Business Type</option>
<option value="Individual">Individual</option>
<option value="Sole Proprietor">Sole Proprietor</option>
<option value="Private Limited">Private Limited</option>
<option value="LLP">LLP</option>
</select>
</div>
</div>
<div class="grid sm:grid-cols-2 gap-3 sm:gap-4">
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Email*</label>
<input type="email" name="email" required class="val-email input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="you@example.com">
</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Phone Number*</label>
<input type="text" name="mobile_number" required maxlength="10" class="val-mobile input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="9876543210">
<small class="text-[#76ABAE] text-xs mt-1">10-digit Indian mobile number only</small>
</div>
</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Password*</label>
<div class="input-container">
<input type="password" id="registerPassword" name="password" required class="val-password input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base pr-10" placeholder="••••••••">
<span class="material-icons password-toggle text-lg sm:text-xl" onclick="togglePassword('registerPassword',this)">visibility_off</span>
</div>
</div>
</div>

<!-- Business Details Section -->
<div class="section-divider">
<div class="section-title">Business Details</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Shop/Business Name*</label>
<input type="text" name="shop_name" required class="input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="My Store">
</div>
<div class="grid sm:grid-cols-2 gap-3 sm:gap-4">
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Flat/Door No*</label>
<input type="text" name="flat_no" required class="input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="123">
</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Street Name*</label>
<input type="text" name="street_name" required class="input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="Main Street">
</div>
</div>
<div class="grid sm:grid-cols-2 gap-3 sm:gap-4">
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Village/City*</label>
<input type="text" name="city_name" required class="input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="City Name">
</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Pincode*</label>
<input type="text" name="pincode" required maxlength="6" class="val-pincode input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="123456">
</div>
</div>
</div>

<!-- Identity Proof Section -->
<div class="section-divider">
<div class="section-title">Identity Proof</div>
<div class="grid sm:grid-cols-2 gap-3 sm:gap-4">
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">PAN Card*</label>
<input type="text" name="pan_card" required maxlength="10" class="val-pan input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="ABCDE1234F">
<small class="text-[#76ABAE] text-xs mt-1">Format: 5 letters + 4 digits + 1 letter</small>
</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Aadhaar Number (Optional)</label>
<input type="text" name="aadhaar_number" maxlength="12" class="val-aadhaar input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="123456789012">
</div>
</div>
</div>

<!-- Tax Information Section -->
<div class="section-divider">
<div class="section-title">Tax Information</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">GSTIN (Optional)</label>
<input type="text" name="gstin" maxlength="15" class="val-gstin input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="22ABCDE1234F1Z5">
<small class="text-[#76ABAE] text-xs mt-1">Only if registered for GST</small>
</div>
</div>

<!-- Bank Account Details Section -->
<div class="section-divider">
<div class="section-title">Bank Account Details</div>
<div class="grid sm:grid-cols-2 gap-3 sm:gap-4">
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Bank Account Number*</label>
<input type="text" name="bank_account_number" required class="val-account input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="123456789012">
</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">IFSC Code*</label>
<input type="text" name="ifsc_code" required class="val-ifsc input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="ABCD0123456">
</div>
</div>
</div>

<!-- Additional Contact Information -->
<div class="section-divider">
<div class="section-title">Additional Contact Information (Optional)</div>
<div class="grid sm:grid-cols-2 gap-3 sm:gap-4">
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Secondary Contact Name</label>
<input type="text" name="secondary_contact_name" class="val-username input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="Jane Doe">
</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Alternative Number</label>
<input type="text" name="alternative_number" maxlength="10" class="val-mobile input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="0987654321">
</div>
</div>
<div>
<label class="block text-xs sm:text-sm font-medium text-[#EEEEEE] mb-1.5 sm:mb-2">Secondary Email</label>
<input type="email" name="secondary_email" class="val-email input-field w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg outline-none text-xs sm:text-sm lg:text-base" placeholder="alt@example.com">
</div>
</div>

<!-- Phone Verification Note -->
<div class="bg-[#76ABAE] bg-opacity-20 rounded-lg p-3 sm:p-4 mt-4 border border-[#76ABAE]">
<div class="flex items-start">
<svg class="w-4 h-4 sm:w-5 sm:h-5 text-[#76ABAE] mr-2 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
<path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
</svg>
<div class="text-xs sm:text-sm text-[#EEEEEE]">
<strong class="text-[#76ABAE]">Phone Verification Required:</strong> An OTP will be sent to your mobile number to verify your account before you can start selling.
</div>
</div>
</div>

<button type="submit" name="register" class="btn-primary w-full py-2 sm:py-2.5 lg:py-3 rounded-lg font-semibold text-xs sm:text-sm lg:text-base mt-4">Create Account</button>
<p class="text-center text-xs sm:text-sm text-[#EEEEEE] opacity-80 mt-3 sm:mt-4">
Already have an account? 
<span id="toLogin" class="text-[#76ABAE] font-semibold cursor-pointer hover:underline">Sign In</span>
</p>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<footer class="w-full bg-[#31363F] py-3 sm:py-4 px-4 sm:px-6 shadow-lg mt-4 sm:mt-6 lg:mt-8">
<div class="max-w-7xl mx-auto">
<div class="flex flex-col sm:flex-row items-center justify-between text-[#EEEEEE] text-xs sm:text-sm">
<p class="mb-2 sm:mb-0">© 2025 Zencom. All Rights Reserved.</p>
<div class="flex items-center space-x-3 sm:space-x-4">
<a href="#" class="hover:text-[#76ABAE] transition-colors">Privacy Policy</a>
<a href="#" class="hover:text-[#76ABAE] transition-colors">Terms of Service</a>
<a href="#" class="hover:text-[#76ABAE] transition-colors">Support</a>
</div>
</div>
</div>
</footer>
<script src="../valid.js"></script>
<script>
const container=document.getElementById('formsContainer');
const toRegisterBtn=document.getElementById('toRegister');
const toLoginBtn=document.getElementById('toLogin');

toRegisterBtn.addEventListener('click',()=>{
container.classList.remove('slide-left');
container.classList.add('slide-right');
});

toLoginBtn.addEventListener('click',()=>{
container.classList.remove('slide-right');
container.classList.add('slide-left');
});

function togglePassword(fieldId,icon){
const field=document.getElementById(fieldId);
if(field.type==='password'){
field.type='text';
icon.textContent='visibility';
}else{
field.type='password';
icon.textContent='visibility_off';
}
}

// Real-time validation
document.addEventListener('DOMContentLoaded', function() {
    // PAN Card validation
    const panInput = document.querySelector('input[name="pan_card"]');
    if(panInput) {
        panInput.addEventListener('input', function(e) {
            this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
        });
    }

    // Mobile number validation
    const mobileInputs = document.querySelectorAll('input.val-mobile');
    mobileInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    });

    // Aadhaar validation
    const aadhaarInput = document.querySelector('input[name="aadhaar_number"]');
    if(aadhaarInput) {
        aadhaarInput.addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    }

    // IFSC code validation
    const ifscInput = document.querySelector('input[name="ifsc_code"]');
    if(ifscInput) {
        ifscInput.addEventListener('input', function(e) {
            this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
        });
    }
});
</script>
</body>
</html>