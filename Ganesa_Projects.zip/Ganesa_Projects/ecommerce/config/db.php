<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "zencoms";

$conn = new mysqli($host, $user, $pass);
$conn->query("CREATE DATABASE IF NOT EXISTS $dbname CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("DB Connection Failed: ".$conn->connect_error);
}

$conn->query("
CREATE TABLE IF NOT EXISTS sellers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    seller_name VARCHAR(150) NOT NULL,
    secondary_contact_name VARCHAR(150),
    shop_name VARCHAR(200) NOT NULL,
    shop_address TEXT NOT NULL,
    mobile_number VARCHAR(10) NOT NULL UNIQUE,
    alternative_number VARCHAR(10) UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    secondary_email VARCHAR(255) UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
");

function addColumnIfMissing($conn, $table, $column, $definition) {
    $check = $conn->query("SHOW COLUMNS FROM $table LIKE '$column'");
    if ($check->num_rows == 0) {
        $conn->query("ALTER TABLE $table ADD $column $definition");
    }
}

$columns = [
    "seller_name" => "VARCHAR(150) NOT NULL",
    "secondary_contact_name" => "VARCHAR(150)",
    "shop_name" => "VARCHAR(200) NOT NULL",
    "shop_address" => "TEXT NOT NULL",
    "mobile_number" => "VARCHAR(10) NOT NULL",
    "alternative_number" => "VARCHAR(10)",
    "email" => "VARCHAR(255) NOT NULL",
    "secondary_email" => "VARCHAR(255)",
    "password" => "VARCHAR(255) NOT NULL",
    "created_at" => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
];

foreach ($columns as $col => $def) {
    addColumnIfMissing($conn, "sellers", $col, $def);
}

$unique_constraints = ["mobile_number","alternative_number","email","secondary_email"];

foreach ($unique_constraints as $col) {
    $conn->query("
        DELETE t1 FROM sellers t1
        INNER JOIN sellers t2
        WHERE 
            t1.id > t2.id 
            AND t1.$col = t2.$col 
            AND t1.$col IS NOT NULL 
            AND t1.$col != '';
    ");
    $result = $conn->query("SHOW INDEX FROM sellers WHERE Column_name = '$col' AND Non_unique = 0");
    if ($result->num_rows == 0) {
        $conn->query("ALTER TABLE sellers ADD UNIQUE ($col)");
    }
}
?>
