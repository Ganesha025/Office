<?php
session_start();
include 'db.php';

$error_message = '';

if($_SERVER['REQUEST_METHOD']=='POST'){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM agents WHERE username=?");
    $stmt->bind_param("s",$username);
    $stmt->execute();
    $res = $stmt->get_result();

    if($res->num_rows==1){
        $row = $res->fetch_assoc();
        if(password_verify($password,$row['password'])){
            $_SESSION['agent'] = $row;
            header("Location: admin.php");
            exit;
        } else {
            $error_message = "Incorrect password";
        }
    } else {
        $error_message = "User not found";
    }
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agent Login</title>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    .divofcontainer{
       box-shadow: rgba(0, 0, 0, 0.07) 0px 1px 2px, rgba(0, 0, 0, 0.07) 0px 2px 4px, rgba(0, 0, 0, 0.07) 0px 4px 8px, rgba(0, 0, 0, 0.07) 0px 8px 16px, rgba(0, 0, 0, 0.07) 0px 16px 32px, rgba(0, 0, 0, 0.07) 0px 32px 64px;
    }
</style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
<div class="divofcontainer bg-white p-8 rounded w-full max-w-md">
    <h2 class="text-2xl font-bold mb-6 text-center">Agent Login</h2>

    <?php if(!empty($error_message)): ?>
        <p class="text-red-500 mb-4"><?= $error_message ?></p>
    <?php endif; ?>

    <form id="loginForm" method="post" novalidate>
        <!-- Username -->
        <label class="block font-semibold mb-1">Username <span class="text-red-500">*</span></label>
        <input type="text" id="username" name="username" class="border border-gray-300 rounded w-full p-2 mb-1 focus:outline-none focus:ring-2 focus:ring-blue-400">
        <span class="text-red-500 text-sm hidden" id="usernameError">Username is required</span>

        <!-- Password -->
        <label class="block font-semibold mt-4 mb-1">Password <span class="text-red-500">*</span></label>
        <div class="relative">
            <input type="password" id="password" name="password" class="border border-gray-300 rounded w-full p-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-400">
            <button type="button" id="togglePassword" class="absolute right-2 top-2 text-gray-500">Show</button>
        </div>
        <span class="text-red-500 text-sm hidden" id="passwordError">Password is required</span>

        <button type="submit" class="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 rounded mt-6">Login</button>
    </form>

    <p class="mt-4 text-center">Don't have an account? <a href="index.php" class="text-blue-500 font-semibold">Signup</a></p>
</div>

<script>
$(document).ready(function(){
    $('#username').focus();

    // Prevent typing numbers or special characters in username
    $('#username').on('keypress', function(e){
        let char = String.fromCharCode(e.which);
        if(!/^[A-Za-z ]$/.test(char)) e.preventDefault();
    });

    // Username validation: letters and spaces only, max 15
    function validateUsername(u){
        return /^[A-Za-z ]{1,15}$/.test(u);
    }

    $('#username').on('input', function(){
    if($(this).val().length > 15){
        $(this).val($(this).val().substring(0, 15));
    }
});


     $('#password').on('input', function(){
    if($(this).val().length > 6){
        $(this).val($(this).val().substring(0, 6));
    }
});

    // Password validation: exactly 6 chars, 1 uppercase, 1 lowercase, 1 number, 1 special
    function validatePassword(p){
        return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6}$/.test(p);
    }

    $('#loginForm').on('submit', function(e){
        let valid = true;

        if($('#username').val().trim() === ''){
            $('#usernameError').removeClass('hidden'); valid=false;
        } else $('#usernameError').addClass('hidden');

        if($('#password').val().trim() === ''){
            $('#passwordError').removeClass('hidden'); valid=false;
        } else $('#passwordError').addClass('hidden');

        if(!valid) e.preventDefault();
    });

    $('input').on('input', function(){ $(this).next('.text-red-500').addClass('hidden'); });

    // Show/Hide password
    $('#togglePassword').on('click', function(){
        let input = $('#password');
        if(input.attr('type') === 'password'){
            input.attr('type','text'); $(this).text('Hide');
        } else {
            input.attr('type','password'); $(this).text('Show');
        }
    });
});
</script>
</body>
</html>
