<?php
session_start();
if(!isset($_SESSION['agent'])){
    header("Location: signin.php");
    exit;
}
$agent = $_SESSION['agent'];

// Mission Authorization
$mission = $agent['agentLevel']==1?"Trainee: Limited":($agent['agentLevel']==2?"Field Agent: Standard":"Supervisor: Full");

// Target Status
$targetMsg = $agent['targetStatus']=='alive'?"Alive":"Eliminated";
$targetColor = $agent['targetStatus']=='alive' ? 'green' : 'red';

// Marks Positive/Negative/Zero
$marks = $agent['marks'];
$numStatus = $marks>0?"Positive":($marks<0?"Negative":"Zero");

// Grade
if($marks>=90) $grade="A";
elseif($marks>=80) $grade="B";
elseif($marks>=70) $grade="C";
elseif($marks>=60) $grade="D";
else $grade="F";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agent Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    .divofcontainer{
       box-shadow: rgba(0, 0, 0, 0.07) 0px 1px 2px, rgba(0, 0, 0, 0.07) 0px 2px 4px, rgba(0, 0, 0, 0.07) 0px 4px 8px, rgba(0, 0, 0, 0.07) 0px 8px 16px, rgba(0, 0, 0, 0.07) 0px 16px 32px, rgba(0, 0, 0, 0.07) 0px 32px 64px;
    }
</style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col items-center justify-center p-4">

<!-- Dashboard Card -->
<div class="w-full max-w-2xl">

    <div class="divofcontainer bg-white rounded-2xl p-8 space-y-8">

        <h2 class="text-3xl font-bold text-center text-blue-600">Agent Dashboard</h2>

        <!-- User Info -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">

            <!-- Username -->
            <div class="bg-blue-50 p-4 rounded-lg shadow hover:shadow-md transition-all">
                <p class="text-gray-700 font-semibold">Username</p>
                <p class="text-lg text-gray-900"><?= htmlspecialchars($agent['username']) ?></p>
            </div>

            <!-- Agent Level -->
            <div class="bg-blue-50 p-4 rounded-lg shadow hover:shadow-md transition-all">
                <p class="text-gray-700 font-semibold">Agent Level</p>
                <p class="text-lg text-gray-900"><?= $agent['agentLevel'] ?> 
                    <span class="text-gray-500 italic">(<?= $mission ?>)</span>
                </p>
            </div>

            <!-- Target Status -->
            <div class="bg-blue-50 p-4 rounded-lg shadow hover:shadow-md transition-all">
                <p class="text-gray-700 font-semibold">Target Status</p>
                <span class="inline-block px-3 py-1 rounded-full font-semibold text-white bg-<?= $targetColor ?>-500">
                    <?= $targetMsg ?>
                </span>
            </div>

            <!-- Marks -->
            <div class="bg-blue-50 p-4 rounded-lg shadow hover:shadow-md transition-all">
                <p class="text-gray-700 font-semibold">Marks</p>
                <p class="text-lg text-gray-900"><?= $marks ?> 
                    <span class="text-gray-500 italic">(<?= $numStatus ?>)</span>
                </p>
            </div>

            <!-- Grade -->
            <div class="bg-yellow-100 p-4 rounded-lg shadow hover:shadow-md transition-all sm:col-span-2">
                <p class="text-gray-700 font-semibold">Grade</p>
                <span class="inline-block px-4 py-2 rounded-full bg-yellow-300 text-yellow-900 font-bold text-xl">
                    <?= $grade ?>
                </span>
            </div>

        </div>

        <!-- Logout Button -->
        <form method="post" action="logout.php">
            <button type="submit" class="w-full bg-red-500 hover:bg-red-600 text-white font-bold py-3 rounded-xl text-lg transition-all duration-200">
                Logout
            </button>
        </form>

    </div>

</div>

</body>
</html>
