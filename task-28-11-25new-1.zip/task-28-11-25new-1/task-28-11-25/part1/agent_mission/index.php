<?php
session_start();
include 'db.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $agentLevel = $_POST['agentLevel'];
    $targetStatus = $_POST['targetStatus'];
    $marks = $_POST['marks'];

    // Insert into database
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO agents(username,password,agentLevel,targetStatus,marks) VALUES(?,?,?,?,?)");
    $stmt->bind_param("ssisd", $username, $hashed, $agentLevel, $targetStatus, $marks);

    if($stmt->execute()){
        $_SESSION['message'] = "Signup successful! Please login.";
        header("Location: login.php");
        exit;
    } else {
        $error_message = "Username already exists.";
    }
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agent Signup</title>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    .divofcontainer{
       box-shadow: rgba(0, 0, 0, 0.07) 0px 1px 2px, rgba(0, 0, 0, 0.07) 0px 2px 4px, rgba(0, 0, 0, 0.07) 0px 4px 8px, rgba(0, 0, 0, 0.07) 0px 8px 16px, rgba(0, 0, 0, 0.07) 0px 16px 32px, rgba(0, 0, 0, 0.07) 0px 32px 64px;
    }
    input[type=number]::-webkit-outer-spin-button,
    input[type=number]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
</style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
<div class="bg-white p-8 rounded divofcontainer w-full max-w-md">
    <h2 class="text-2xl font-bold mb-6 text-center">Agent Signup</h2>

    <?php if(isset($error_message)): ?>
        <p class="text-red-500 mb-4"><?= $error_message ?></p>
    <?php endif; ?>

    <form id="signupForm" method="post" novalidate>
        <!-- Username -->
        <label class="block font-semibold mb-1">Username <span class="text-red-500">*</span></label>
        <input type="text" id="username" name="username" maxlength="15" class="border border-gray-300 rounded w-full p-2 mb-1 focus:outline-none focus:ring-2 focus:ring-blue-400">
        <span class="text-red-500 text-sm hidden" id="usernameError">Letters & spaces only, max 15 characters</span>

        <!-- Password -->
        <label class="block font-semibold mt-4 mb-1">Password <span class="text-red-500">*</span></label>
        <div class="relative">
            <input type="password" id="password" name="password" maxlength="6" class="border border-gray-300 rounded w-full p-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-400">
            <button type="button" id="togglePassword" class="absolute right-2 top-2 text-gray-500">Show</button>
        </div>
        <span class="text-red-500 text-sm hidden" id="passwordError">Exactly 6 chars: 1 uppercase, 1 lowercase, 1 number, 1 special char</span>

        <!-- Agent Level -->
        <label class="block font-semibold mt-4 mb-1">Agent Level <span class="text-red-500">*</span></label>
        <select id="agentLevel" name="agentLevel" class="border border-gray-300 rounded w-full p-2 focus:outline-none focus:ring-2 focus:ring-blue-400">
            <option value="">Select Level</option>
            <option value="1">Trainee</option>
            <option value="2">Field Agent</option>
            <option value="3">Supervisor</option>
        </select>
        <span class="text-red-500 text-sm hidden" id="agentLevelError">Select agent level</span>

        <!-- Target Status -->
        <label class="block font-semibold mt-4 mb-1">Target Status <span class="text-red-500">*</span></label>
        <select id="targetStatus" name="targetStatus" class="border border-gray-300 rounded w-full p-2 focus:outline-none focus:ring-2 focus:ring-blue-400">
            <option value="">Select Status</option>
            <option value="alive">Alive</option>
            <option value="eliminated">Eliminated</option>
        </select>
        <span class="text-red-500 text-sm hidden" id="targetStatusError">Select target status</span>

        <!-- Marks -->
        <label class="block font-semibold mt-4 mb-1">Marks <span class="text-red-500">*</span></label>
        <input type="number" id="marks" name="marks" min="1" max="100" class="border border-gray-300 rounded w-full p-2 mb-1 focus:outline-none focus:ring-2 focus:ring-blue-400" oninput="this.value = Math.min(this.value, 100)">
        <span class="text-red-500 text-sm hidden" id="marksError">Marks must be 1-100</span>

        <button type="submit" class="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 rounded mt-6">Signup</button>
    </form>

    <p class="mt-4 text-center">Already have an account? <a href="login.php" class="text-blue-500 font-semibold">Login</a></p>
</div>

<script>
$(document).ready(function(){

    $('#username').focus();

    // Prevent typing numbers or special characters in username
    $('#username').on('keypress', function(e){
        let char = String.fromCharCode(e.which);
        if(!/^[A-Za-z ]$/.test(char)) e.preventDefault();
    });

    // Username validation: letters and spaces only, max 15
    function validateUsername(u){
        return /^[A-Za-z ]{1,15}$/.test(u);
    }

    // Password validation: exactly 6 chars, 1 uppercase, 1 lowercase, 1 number, 1 special
    function validatePassword(p){
        return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6}$/.test(p);
    }

    $('#signupForm').on('submit', function(e){
        let valid = true;

        // Username validation
        if(!validateUsername($('#username').val())){
            $('#usernameError').removeClass('hidden'); valid=false;
        } else $('#usernameError').addClass('hidden');

        // Password validation
        if(!validatePassword($('#password').val())){
            $('#passwordError').removeClass('hidden'); valid=false;
        } else $('#passwordError').addClass('hidden');

        // Agent Level validation
        if($('#agentLevel').val()===""){
            $('#agentLevelError').removeClass('hidden'); valid=false;
        } else $('#agentLevelError').addClass('hidden');

        // Target Status validation
        if($('#targetStatus').val()===""){
            $('#targetStatusError').removeClass('hidden'); valid=false;
        } else $('#targetStatusError').addClass('hidden');

        // Marks validation
        let marks = $('#marks').val();
        if(marks==="" || marks<1 || marks>100){
            $('#marksError').removeClass('hidden'); valid=false;
        } else $('#marksError').addClass('hidden');

        if(!valid) e.preventDefault();
    });

    // Clear errors when input becomes valid
    $('#username').on('input', function(){
        if(validateUsername($(this).val())){
            $('#usernameError').addClass('hidden');
        }
    });

    $('#marks').on('input', function(){
        let val = $(this).val();
        if(val>=1 && val<=100){
            $('#marksError').addClass('hidden');
        }
        if(val>100) $(this).val(100); // Prevent >100
    });

    // Hide number input arrows (spinner)
    $('#marks').css({'-moz-appearance':'textfield','appearance':'textfield'});
    $('#marks').on('wheel', function(e){ e.preventDefault(); }); // Disable scroll change

    // Hide error for other fields on input/change
    $('#password, #agentLevel, #targetStatus').on('input change', function(){
        $(this).next('.text-red-500').addClass('hidden');
    });

    // Show/Hide Password
    $('#togglePassword').on('click', function(){
        let input = $('#password');
        if(input.attr('type') === 'password'){
            input.attr('type','text'); $(this).text('Hide');
        } else {
            input.attr('type','password'); $(this).text('Show');
        }
    });

});
</script>



</body>
</html>
