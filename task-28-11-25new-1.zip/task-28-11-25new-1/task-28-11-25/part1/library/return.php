<?php
session_start();

$book_id = $_GET['id'] ?? null;
if (!$book_id) {
    header("Location: borrowed_books.php");
    exit;
}

// Find borrowed book
$borrowed_book = null;
foreach($_SESSION['borrowed_books'] as $key => $b) {
    if ($b['book_id'] == $book_id) {
        $borrowed_book = $b;
        $borrow_key = $key;
        break;
    }
}
if (!$borrowed_book) {
    header("Location: borrowed_books.php");
    exit;
}

$today = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $actual_return = $_POST['actual_return'];
    $expected_return = $borrowed_book['return_date'];

    $penalty = 0;
    if(strtotime($actual_return) > strtotime($expected_return)){
        $days_late = (strtotime($actual_return) - strtotime($expected_return))/86400;
        $penalty = $days_late * 5;
    }

    // Remove from borrowed books
    unset($_SESSION['borrowed_books'][$borrow_key]);
    $_SESSION['borrowed_books'] = array_values($_SESSION['borrowed_books']);

    header("Location: borrowed_books.php");
    exit;
}

// Navbar
function navbar() {
    echo '<nav class="navbar navbar-expand-lg shadow-sm mb-5" style="background: linear-gradient(90deg, #2c2c2c, #3d3d3d);">
            <div class="container">
              <a class="navbar-brand fw-bold fs-3 text-light" href="index.php">📚 My Library</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto fw-semibold">
                  <li class="nav-item"><a class="nav-link text-light" href="index.php">Books</a></li>
                  <li class="nav-item"><a class="nav-link text-light" href="borrowed_books.php">Borrowed Books</a></li>
                </ul>
              </div>
            </div>
          </nav>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Return Book</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background: #f5f5f5;
    font-family: 'Inter', sans-serif;
}
h2 {
    font-weight: 800;
    color: #1c1c1c;
    margin-bottom: 2rem;
    text-align: center;
}

/* Card layout */
.card {
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 12px 28px rgba(0,0,0,0.15);
    transition: transform 0.3s, box-shadow 0.3s;
}
.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 18px 35px rgba(0,0,0,0.2);
}
.card-img-left {
    height: 250px;
    width: 200px;
    object-fit: cover;
    border-radius: 20px 0 0 20px;
}
.card-body {
    padding: 1.5rem;
    display: flex;
    flex-direction: column;
}
.card-title {
    font-weight: 700;
    color: #0d3b66;
    margin-bottom: 1rem;
    font-size: 1.5rem;
}
.card-text {
    font-size: 1rem;
    color: #333;
    margin-bottom: 0.5rem;
}
.btn-return {
    background: linear-gradient(135deg, #ff6a00, #ee0979);
    color: #fff;
    font-weight: 600;
    border-radius: 12px;
    padding: 0.75rem;
    transition: all 0.3s;
    margin-top: 1rem;
}
.btn-return:hover {
    background: linear-gradient(135deg, #ee0979, #ff6a00);
    box-shadow: 0 8px 20px rgba(238,9,121,0.6);
}

@media(max-width: 768px){
    .d-flex-row {
        flex-direction: column;
        align-items: center;
    }
    .card-img-left {
        width: 100%;
        height: 250px;
        border-radius: 20px 20px 0 0;
    }
}
</style>
</head>
<body>
<?php navbar(); ?>

<div class="container">
    <h2>Return Book</h2>
    <div class="card d-flex d-flex-row">
        <img src="<?= htmlspecialchars($borrowed_book['image'] ?? 'images/bookr.png') ?>" class="card-img-left" alt="<?= htmlspecialchars($borrowed_book['title']) ?>" onerror="this.src='images/bookr.jpg'">
        <div class="card-body">
            <h5 class="card-title"><?= htmlspecialchars($borrowed_book['title']) ?></h5>
            <p class="card-text"><strong>User:</strong> <?= htmlspecialchars($borrowed_book['user']) ?></p>
            <p class="card-text"><strong>Department:</strong> <?= htmlspecialchars($borrowed_book['department']) ?></p>
            <p class="card-text"><strong>Borrow Date:</strong> <?= $borrowed_book['borrow_date'] ?></p>
            <p class="card-text"><strong>Expected Return:</strong> <?= $borrowed_book['return_date'] ?></p>
            
            <form method="POST" class="mt-3">
                <div class="mb-3">
                    <label class="form-label">Actual Return Date <span style="color:red">*</span></label>
                    <input type="date" class="form-control" id="actual_return" name="actual_return" autofocus>
                    <div id="dateError" class="text-danger mt-1" style="font-size:0.9rem;"></div>
                    <div id="fineMessage" class="text-danger mt-1 fw-bold"></div>
                </div>
                <button type="submit" class="btn btn-return w-100">Return Book</button>
            </form>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

<script>
$(document).ready(function () {

    let borrowedDate   = "<?= $borrowed_book['borrow_date'] ?>";
    let expectedReturn = "<?= $borrowed_book['return_date'] ?>";

    // Allowed range: Borrowed date → borrowed date + 30 days
    let maxDate = new Date(borrowedDate);
    maxDate.setDate(maxDate.getDate() + 30);
    maxDate = maxDate.toISOString().split("T")[0];

    $("#actual_return").attr("min", borrowedDate);
    $("#actual_return").attr("max", maxDate);

    // LIVE VALIDATION
    $("#actual_return").on("input", function () {
        let actual = $(this).val();
        $("#dateError").text("");
        $("#fineMessage").text("");

        // Required
        if (!actual) {
            $("#dateError").text("Please select a return date.");
            return;
        }

        // Range check
        if (actual < borrowedDate || actual > maxDate) {
            $("#dateError").text("Date must be between " + borrowedDate + " and " + maxDate + ".");
            return;
        }

        // Fine calculation
        if (actual > expectedReturn) {
            let diffDays = (new Date(actual) - new Date(expectedReturn)) / (1000 * 60 * 60 * 24);
            let fine = diffDays * 2; // 2 rupees per day late
            $("#fineMessage").text("Late Return Fine: ₹" + fine);
        }
    });

    // FORM SUBMIT VALIDATION
    $("form").on("submit", function (e) {
        let actual = $("#actual_return").val();

        $("#dateError").text("");

        if (!actual) {
            $("#dateError").text("Please select a return date.");
            e.preventDefault();
            return;
        }

        if (actual < borrowedDate || actual > maxDate) {
            $("#dateError").text("Date must be between " + borrowedDate + " and " + maxDate + ".");
            e.preventDefault();
            return;
        }
    });
});
</script>

</body>
</html>
