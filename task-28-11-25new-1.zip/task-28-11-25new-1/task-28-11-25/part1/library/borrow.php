<?php
session_start();

// Get book ID from query
$book_id = $_GET['id'] ?? null;
if (!$book_id) {
    header("Location: index.php");
    exit;
}

// Find book
$book = null;
foreach($_SESSION['books'] as $b) {
    if ($b['id'] == $book_id) $book = $b;
}
if (!$book) {
    header("Location: index.php");
    exit;
}

// Handle borrow form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_POST['user'];
    $department = $_POST['department'];
    $borrow_date = $_POST['borrow_date'];
    $return_date = $_POST['return_date'];

    $_SESSION['borrowed_books'][] = [
    'book_id'     => $book['id'],
    'title'       => $book['title'],
    'author'      => $book['author'],
    'year'        => $book['year'],
    'image'       => "https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png",
    'user'        => $user,
    'department'  => $department,
    'borrow_date' => $borrow_date,
    'return_date' => $return_date
];


    header("Location: borrowed_books.php");
    exit;
}

// Navigation bar
function navbar() {
    echo '<nav class="navbar navbar-expand-lg shadow-sm mb-5" style="background: linear-gradient(90deg, #2c2c2c, #3d3d3d);">
            <div class="container">
              <a class="navbar-brand fw-bold fs-3 text-light" href="index.php">📚 My Library</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto fw-semibold">
                  <li class="nav-item"><a class="nav-link text-light" href="index.php">Books</a></li>
                  <li class="nav-item"><a class="nav-link text-light" href="add_book.php">Add Book</a></li>
                  <li class="nav-item"><a class="nav-link text-light" href="borrowed_books.php">Borrowed Books</a></li>
                </ul>
              </div>
            </div>
          </nav>';
}

$today = date('Y-m-d');
$return_default = date('Y-m-d', strtotime('+10 days'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Borrow Book</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background: #f5f5f5;
    font-family: 'Inter', sans-serif;
}

h2 {
    font-weight: 800;
    color: #1c1c1c;
    margin-bottom: 2rem;
    text-align: center;
}

/* Form Card */
.form-card {
    max-width: 600px;
    background: #fff;
    margin: 0 auto 50px auto;
    padding: 2rem;
    border-radius: 20px;
    box-shadow: 0 12px 28px rgba(0,0,0,0.15);
    transition: transform 0.3s, box-shadow 0.3s;
}
.form-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 18px 35px rgba(0,0,0,0.2);
}

.form-label {
    font-weight: 600;
    color: #333;
}

input.form-control {
    border-radius: 12px;
    padding: 0.75rem 1.25rem;
    border: 1px solid #ccc;
    transition: border-color 0.3s, box-shadow 0.3s;
}

input.form-control:focus {
    border-color: #ee0979;
    box-shadow: 0 0 8px rgba(238,9,121,0.2);
    outline: none;
}

.btn-submit {
    background: linear-gradient(135deg, #ff6a00, #ee0979);
    color: #fff;
    font-weight: 600;
    border-radius: 12px;
    padding: 0.75rem;
    transition: all 0.3s;
    box-shadow: 0 5px 15px rgba(238,9,121,0.4);
}
.btn-submit:hover {
    background: linear-gradient(135deg, #ee0979, #ff6a00);
    box-shadow: 0 8px 20px rgba(238,9,121,0.6);
}

.error {
    font-size: 0.9rem;
    margin-top: 0.25rem;
    color: #d90429;
    min-height: 20px;
}

@media(max-width: 768px){
    .form-card {
        padding: 1.5rem;
        margin: 20px;
    }
}
</style>
</head>
<body>
<?php navbar(); ?>

<div class="container">
    <h2>Borrow Book</h2>
    <div class="form-card">
        <form id="borrowForm" method="POST">
            <div class="mb-3">
                <label class="form-label">Book Title</label>
                <input type="text" class="form-control" name="title" value="<?= htmlspecialchars($book['title']) ?>" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label">Author</label>
                <input type="text" class="form-control" name="author" value="<?= htmlspecialchars($book['author']) ?>" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label">Year</label>
                <input type="text" class="form-control" name="year" value="<?= htmlspecialchars($book['year']) ?>" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label">Your Name <span style="color:red">*</span></label>
                <input type="text" class="form-control" name="user" id="user">
                <div class="error" id="userError"></div>
            </div>
            <div class="mb-3">
                <label class="form-label">Department <span style="color:red">*</span></label>
                <input type="text" class="form-control" name="department" id="department">
                <div class="error" id="deptError"></div>
            </div>
            <div class="mb-3">
                <label class="form-label">Borrow Date</label>
                <input type="date" class="form-control" name="borrow_date" value="<?= $today ?>" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label">Return Date</label>
                <input type="date" class="form-control" name="return_date" value="<?= $return_default ?>" readonly>
            </div>
            <button type="submit" class="btn btn-submit w-100">Borrow</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

<script>
$(document).ready(function() {

    // Live validation for user field
    $("#user").on("input", function() {
        this.value = this.value.replace(/[^A-Za-z\s]/g, "").substring(0, 15);

        let user = $(this).val().trim();
        if (/^[A-Za-z\s]{1,15}$/.test(user)) {
            $("#userError").text(""); // Clear error if valid
        }
    });

    // Live validation for department field
    $("#department").on("input", function() {
        this.value = this.value.replace(/[^A-Za-z\s]/g, "").substring(0, 20);

        let dept = $(this).val().trim();
        if (/^[A-Za-z\s]{1,20}$/.test(dept)) {
            $("#deptError").text(""); // Clear error if valid
        }
    });

    // Final submit validation
    $("#borrowForm").on("submit", function(e) {
        let valid = true;

        $("#userError").text("");
        $("#deptError").text("");

        let user = $("#user").val().trim();
        let dept = $("#department").val().trim();

        // Name validation
        if (user.length === 0) {
            $("#userError").text("Name is required.");
            valid = false;
        } else if (!/^[A-Za-z\s]{1,15}$/.test(user)) {
            $("#userError").text("Only letters and spaces allowed (max 15 characters).");
            valid = false;
        }

        // Department validation
        if (dept.length === 0) {
            $("#deptError").text("Department is required.");
            valid = false;
        } else if (!/^[A-Za-z\s]{1,20}$/.test(dept)) {
            $("#deptError").text("Only letters and spaces allowed (max 20 characters).");
            valid = false;
        }

        if (!valid) e.preventDefault();
    });

});
</script>


</body>
</html>
