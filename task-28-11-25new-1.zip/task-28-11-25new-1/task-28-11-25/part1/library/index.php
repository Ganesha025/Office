<?php
session_start();
session_unset();

// Initialize default books with images
if (!isset($_SESSION['books'])) {
    $_SESSION['books'] = [
        ['id' => 1, 'title' => 'Moby-Dick', 'author' => 'Herman Melville', 'year' => 1851, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'],
        ['id' => 2, 'title' => 'The Chronicles of Narnia', 'author' => 'C.S. Lewis', 'year' => 1950, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'],
        ['id' => 3, 'title' => 'The Alchemist', 'author' => 'Paulo Coelho', 'year' => 1988, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'],
        ['id' => 4, 'title' => 'The Lord of the Rings', 'author' => 'J.R.R. Tolkien', 'year' => 1954, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'],
        ['id' => 5, 'title' => 'Fahrenheit 451', 'author' => 'Ray Bradbury', 'year' => 1953, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'],
        ['id' => 6, 'title' => '1984', 'author' => 'George Orwell', 'year' => 1949, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png']
    ];
}


if (!isset($_SESSION['borrowed_initialized'])) {

    $_SESSION['borrowed_books'] = [
        ['book_id'=>1,'title'=>'Moby-Dick','author'=>'Herman Melville','year'=>1851,'image'=>'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png','user'=>'John','department'=>'CS','borrow_date'=>'2025-11-20','return_date'=>'2025-11-30'],
        ['book_id'=>2,'title'=>'The Alchemist','author'=>'Paulo Coelho','year'=>1988,'image'=>'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png','user'=>'Jane','department'=>'EE','borrow_date'=>'2025-11-18','return_date'=>'2025-11-28'],
        ['book_id'=>3,'title'=>'The Lord of the Rings','author'=>'J.R.R. Tolkien','year'=>1954,'image'=>'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png','user'=>'Alex','department'=>'ME','borrow_date'=>'2025-11-22','return_date'=>'2025-12-02'],
        ['book_id'=>4,'title'=>'1984','author'=>'George Orwell','year'=>1949,'image'=>'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png','user'=>'Maria','department'=>'CE','borrow_date'=>'2025-11-21','return_date'=>'2025-12-01']
    ];

    $_SESSION['borrowed_initialized'] = true;
}


// Navigation bar HTML
function navbar() {
    echo '<nav class="navbar navbar-expand-lg shadow-sm mb-5" style="background: linear-gradient(90deg, #2c2c2c, #3d3d3d);">
            <div class="container">
              <a class="navbar-brand fw-bold fs-3 text-light" href="index.php">📚 My Library</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto fw-semibold">
                  <li class="nav-item"><a class="nav-link text-light" href="index.php">Books</a></li>
                  <li class="nav-item"><a class="nav-link text-light" href="borrowed_books.php">Borrowed Books</a></li>
                </ul>
              </div>
            </div>
          </nav>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Library Books</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background: #f5f5f5;
        font-family: 'Inter', sans-serif;
    }

    h2 {
        font-weight: 800;
        color: #1c1c1c;
        margin-bottom: 2rem;
    }

    /* Card Styles */
    .card {
        border-radius: 20px;
        overflow: hidden;
        transition: transform 0.3s, box-shadow 0.3s;
        background: #ffffff;
        border: none;
    }
    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.2);
    }
    .card-img-top {
        height: 200px;
        object-fit: cover;
        transition: transform 0.3s;
    }
    .card:hover .card-img-top {
        transform: scale(1.08);
    }
    .card-body {
        padding: 1.5rem;
        display: flex;
        flex-direction: column;
    }
    .card-title {
        font-size: 1.25rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
        color: #1b1b1b;
    }
    .card-text {
        font-size: 0.95rem;
        color: #555;
    }
    .btn-borrow {
        background: linear-gradient(135deg, #ff6a00, #ee0979);
        color: #fff;
        font-weight: 600;
        transition: all 0.3s;
        margin-top: auto;
        border-radius: 12px;
        box-shadow: 0 5px 15px rgba(238, 9, 121, 0.4);
    }
    .btn-borrow:hover {
        background: linear-gradient(135deg, #ee0979, #ff6a00);
        box-shadow: 0 8px 20px rgba(238, 9, 121, 0.6);
    }

    /* Responsive grid */
    @media (min-width: 1200px) { .col-lg-3 { flex: 0 0 23%; max-width: 23%; } }
    @media (min-width: 992px) { .col-md-4 { flex: 0 0 31%; max-width: 31%; } }
</style>
</head>
<body>
<?php navbar(); ?>

<div class="container">
    <h2 class="text-center">Available Books</h2>
    <div class="row g-4">
        <?php foreach($_SESSION['books'] as $book): ?>
            <div class="col-md-4 col-lg-3">
                <div class="card h-100 shadow-sm">
                   <img src="<?= htmlspecialchars($book['image'] ?? 'images/bookr.png') ?>" 
                        onerror="this.src='images/bookr.jpg'" 
                        class="card-img-top" 
                        alt="<?= htmlspecialchars($book['title']) ?>">
                   <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?= htmlspecialchars($book['title']) ?></h5>
                        <p class="card-text mb-1"><strong>Author:</strong> <?= htmlspecialchars($book['author']) ?></p>
                        <p class="card-text mb-3"><strong>Year:</strong> <?= htmlspecialchars($book['year']) ?></p>
                        <a href="borrow.php?id=<?= $book['id'] ?>" class="btn btn-borrow w-100" autofocus>Borrow</a>
                   </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
