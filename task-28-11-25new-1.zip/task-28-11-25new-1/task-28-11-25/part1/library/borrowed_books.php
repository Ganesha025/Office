<?php
session_start();

// Navbar
function navbar() {
    echo '<nav class="navbar navbar-expand-lg shadow-sm mb-5" style="background: linear-gradient(90deg, #2c2c2c, #3d3d3d);">
            <div class="container">
              <a class="navbar-brand fw-bold fs-3 text-light" href="index.php">📚 My Library</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto fw-semibold">
                  <li class="nav-item"><a class="nav-link text-light" href="index.php">Books</a></li>
                  <li class="nav-item"><a class="nav-link text-light" href="borrowed_books.php">Borrowed Books</a></li>
                </ul>
              </div>
            </div>
          </nav>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Borrowed Books</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background: #f5f5f5;
    font-family: 'Inter', sans-serif;
}

h2 {
    font-weight: 800;
    color: #1c1c1c;
    margin-bottom: 2rem;
    text-align: center;
}

/* Card style */
.card {
    border-radius: 20px;
    overflow: hidden;
    transition: transform 0.3s, box-shadow 0.3s;
    box-shadow: 0 12px 28px rgba(0,0,0,0.15);
}
.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 18px 35px rgba(0,0,0,0.2);
}
.card-img-top {
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s;
}
.card:hover .card-img-top {
    transform: scale(1.05);
}
.card-body {
    display: flex;
    flex-direction: column;
    padding: 1.5rem;
}
.card-title {
    font-weight: 700;
    color: #0d3b66;
    margin-bottom: 0.5rem;
    font-size: 1.25rem;
}
.card-text {
    font-size: 0.95rem;
    color: #333;
    margin-bottom: 0.25rem;
}
.btn-return {
    background: linear-gradient(135deg, #ff6a00, #ee0979);
    color: #fff;
    font-weight: 600;
    border-radius: 12px;
    padding: 0.75rem;
    transition: all 0.3s;
    margin-top: auto;
}
.btn-return:hover {
    background: linear-gradient(135deg, #ee0979, #ff6a00);
    box-shadow: 0 8px 20px rgba(238,9,121,0.6);
}

@media(max-width: 768px){
    .card-img-top {
        height: 180px;
    }
}
</style>
</head>
<body>
<?php navbar(); ?>

<div class="container">
    <h2>Borrowed Books</h2>
    <div class="row g-4">
        <?php if (empty($_SESSION['borrowed_books'])): ?>
            <p class="text-center">No borrowed books.</p>
        <?php else: ?>
            <?php foreach($_SESSION['borrowed_books'] as $borrow): ?>
                <div class="col-md-4 col-lg-3">
                    <div class="card h-100">
                        <img src="<?= htmlspecialchars($borrow['image'] ?? 'images/bookr.png') ?>" 
                             onerror="this.src='images/bookr.jpg'" 
                             class="card-img-top" 
                             alt="<?= htmlspecialchars($borrow['title']) ?>">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= htmlspecialchars($borrow['title']) ?></h5>
                            <p class="card-text"><strong>User:</strong> <?= htmlspecialchars($borrow['user']) ?></p>
                            <p class="card-text"><strong>Dept:</strong> <?= htmlspecialchars($borrow['department']) ?></p>
                            <p class="card-text"><strong>Borrowed:</strong> <?= $borrow['borrow_date'] ?></p>
                            <p class="card-text"><strong>Return by:</strong> <?= $borrow['return_date'] ?></p>
                            <a href="return.php?id=<?= $borrow['book_id'] ?>" class="btn btn-return w-100" autofocus>Return</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
