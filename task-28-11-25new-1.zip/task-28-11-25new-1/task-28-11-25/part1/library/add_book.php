<?php
session_start();

// Initialize books if not set
if (!isset($_SESSION['books'])) {
    $_SESSION['books'] = [
        ['id' => 1, 'title' => 'Moby-Dick', 'author' => 'Herman Melville', 'year' => 1851, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'],
        ['id' => 2, 'title' => 'The Chronicles of Narnia', 'author' => 'C.S. Lewis', 'year' => 1950, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png']
    ];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $year = $_POST['year'];

    $new_id = end($_SESSION['books'])['id'] + 1;
    $_SESSION['books'][] = [
        'id' => $new_id,
        'title' => $title,
        'author' => $author,
        'year' => $year,
        'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'
    ];
    header("Location: index.php");
    exit;
}

// Navbar
function navbar() {
    echo '<nav class="navbar navbar-expand-lg shadow-sm mb-5" style="background: linear-gradient(90deg, #2c2c2c, #3d3d3d);">
            <div class="container">
              <a class="navbar-brand fw-bold fs-3 text-light" href="index.php">📚 My Library</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto fw-semibold">
                  <li class="nav-item"><a class="nav-link text-light" href="index.php">Books</a></li>
                  <li class="nav-item"><a class="nav-link text-light" href="add_book.php">Add Book</a></li>
                  <li class="nav-item"><a class="nav-link text-light" href="borrowed_books.php">Borrowed Books</a></li>
                </ul>
              </div>
            </div>
          </nav>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Book</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body { background: #f5f5f5; font-family: 'Inter', sans-serif; }
    h2 { font-weight: 800; color: #1c1c1c; margin-bottom: 2rem; text-align: center; }
    .form-card { max-width: 600px; background: #fff; margin: 0 auto 50px auto; padding: 2rem; border-radius: 20px; box-shadow: 0 12px 28px rgba(0,0,0,0.15); transition: transform 0.3s, box-shadow 0.3s; }
    .form-card:hover { transform: translateY(-5px); box-shadow: 0 18px 35px rgba(0,0,0,0.2); }
    .form-label { font-weight: 600; color: #333; }
    input.form-control { border-radius: 12px; padding: 0.75rem 1.25rem; border: 1px solid #ccc; transition: border-color 0.3s, box-shadow 0.3s; }
    input.form-control:focus { border-color: #ee0979; box-shadow: 0 0 8px rgba(238,9,121,0.2); outline: none; }
    input::-webkit-outer-spin-button, input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
    input[type=number] { -moz-appearance: textfield; }
    .btn-submit { background: linear-gradient(135deg, #ff6a00, #ee0979); color: #fff; font-weight: 600; border-radius: 12px; padding: 0.75rem; transition: all 0.3s; box-shadow: 0 5px 15px rgba(238,9,121,0.4); }
    .btn-submit:hover { background: linear-gradient(135deg, #ee0979, #ff6a00); box-shadow: 0 8px 20px rgba(238,9,121,0.6); }
    .error { font-size: 0.9rem; margin-top: 0.25rem; color: #d90429; min-height: 20px; }
    .required { color: #d90429; }
    @media(max-width: 768px){ .form-card { padding: 1.5rem; margin: 20px; } }
</style>
</head>
<body>
<?php navbar(); ?>

<div class="container">
    <h2>Add New Book</h2>
    <div class="form-card">
        <form id="addBookForm" method="POST" novalidate>
            <div class="mb-3">
                <label class="form-label">Book Title <span class="required">*</span></label>
                <input type="text" class="form-control" name="title" id="title" maxlength="20" autocomplete="off">
                <div class="error" id="titleError"></div>
            </div>
            <div class="mb-3">
                <label class="form-label">Author <span class="required">*</span></label>
                <input type="text" class="form-control" name="author" id="author" maxlength="15" autocomplete="off">
                <div class="error" id="authorError"></div>
            </div>
            <div class="mb-3">
                <label class="form-label">Year <span class="required">*</span></label>
                <input type="number" class="form-control" name="year" id="year" max="2025" autocomplete="off">
                <div class="error" id="yearError"></div>
            </div>
            <button type="submit" class="btn btn-submit w-100">Add Book</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script>
$(document).ready(function(){

    // Restrict author input to letters & spaces only, max 15
    $('#author').on('input', function(){
        let val = $(this).val().replace(/[^a-zA-Z\s]/g, '').slice(0,15);
        $(this).val(val);
        $('#authorError').text('');
    });

    // Restrict title input to letters & spaces only, max 20
    $('#title').on('input', function(){
        let val = $(this).val().slice(0,20);
        $(this).val(val);
        // Show error only if all 20 chars are invalid
        if(val.length === 20 && !/^[a-zA-Z\s]{20}$/.test(val)){
            $('#titleError').text('Enter valid book title');
        } else {
            $('#titleError').text('');
        }
    });

    // Restrict year to 4 digits, max 2025
    $('#year').on('input', function(){
        let val = $(this).val().slice(0,4);
        if(val > 2025) val = 2025;
        $(this).val(val);
    });

    $('#addBookForm').submit(function(e){
        let title = $('#title').val().trim();
        let author = $('#author').val().trim();
        let year = $('#year').val().trim();
        let valid = true;

        if(title === '' || !/^[a-zA-Z\s]+$/.test(title)) {
            $('#titleError').text(title === '' ? 'Book title is required' : 'Enter valid book title');
            valid = false;
        } else { $('#titleError').text(''); }

        if(author === '' || !/^[a-zA-Z\s]+$/.test(author)) {
            $('#authorError').text(author === '' ? 'Author name is required' : 'Enter valid author name');
            valid = false;
        } else { $('#authorError').text(''); }

        if(year === '' || year.length !== 4 || parseInt(year) > 2025) {
            $('#yearError').text(year === '' ? 'Year is required' : 'Enter valid year (<=2025)');
            valid = false;
        } else { $('#yearError').text(''); }

        if(!valid) e.preventDefault();
    });

});
</script>
</body>
</html>
