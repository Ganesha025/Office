<?php
session_start();

// Handle order submission
if($_SERVER['REQUEST_METHOD']==='POST'){
    $customer_name = $_POST['customer_name'] ?? '';
    $order_date = $_POST['order_date'] ?? '';
    $item_names = $_POST['item_name'] ?? [];

    if($customer_name && $order_date && !empty($item_names)){
        $_SESSION['orders'][] = [
            'customer_name' => htmlspecialchars($customer_name),
            'order_date' => $order_date,
            'items' => array_map('htmlspecialchars', $item_names)
        ];

        header('Location: order_summary.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Place Order</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{
    font-family:'Roboto',sans-serif;
    background:linear-gradient(135deg,#C8F7DC,#A7E8E8);
    color:#333;
}
a{text-decoration:none;}
header,footer{width:100%;}

/* Header */
header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:20px 50px;
    background: linear-gradient(90deg,#C8F7DC,#A7E8E8);
    flex-wrap:wrap;
    box-shadow:0 5px 20px rgba(0,0,0,0.1);
}
header .logo h1{
    font-family:'Poppins',sans-serif;
    font-size:28px;
    font-weight:700;
    color:#333;
}
header nav a{
    margin-left:25px;
    font-weight:600;
    color:#333;
    transition:0.3s;
}
header nav a:hover{
    color:#2a8c8c;
    text-shadow:0 2px 5px rgba(0,0,0,0.2);
}
@media(max-width:768px){
    header{flex-direction:column;align-items:flex-start;}
    header nav{margin-top:10px;}
    header nav a{margin:5px 10px 0 0;}
}

/* Container */
.container{
    max-width:600px;
    margin:50px auto;
    padding:40px 30px;
    background: rgba(255,255,255,0.5);
    backdrop-filter: blur(15px);
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
}
.container h2{
    text-align:center;
    margin-bottom:25px;
    font-family:'Poppins',sans-serif;
    font-size:28px;
    font-weight:700;
    color:#333;
}

/* Labels & Inputs */
label{display:block;margin:10px 0 5px;font-weight:600;color:#333;}
.required{color:#2a8c8c;}
input{
    width:100%;
    padding:12px 20px;
    margin-bottom:15px;
    border-radius:50px;
    border:none;
    outline:none;
    font-size:16px;
    background:rgba(255,255,255,0.7);
    color:#333;
    transition:0.3s;
}
input::placeholder{color:#666;}
input:focus{
    background:rgba(255,255,255,0.9);
    box-shadow:0 4px 15px rgba(0,0,0,0.2);
}

/* Item Rows */
.item-row{
    display:flex;
    flex-direction:column; /* stack input & error vertically */
    gap:5px;
    margin-bottom:15px;
}
.item-input-wrapper input{
    flex:1;
}

/* Buttons */
.add-btn, .submit-btn{
    width:100%;
    padding:15px;
    border:none;
    border-radius:50px;
    font-weight:700;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;
}
.add-btn{
    background:linear-gradient(45deg,#A7E8E8,#C8F7DC);
    color:#333;
    margin-bottom:15px;
}
.add-btn:hover{
    background:linear-gradient(45deg,#C8F7DC,#A7E8E8);
    box-shadow:0 8px 25px rgba(0,0,0,0.2);
}
.submit-btn{
    background:linear-gradient(45deg,#A7E8E8,#C8F7DC);
    color:#333;
}
.submit-btn:hover{
    background:linear-gradient(45deg,#C8F7DC,#A7E8E8);
    box-shadow:0 8px 25px rgba(0,0,0,0.2);
}

/* Error */
.error{color:#b82e2e;font-size:14px;text-align:left;}

/* Footer */
footer{
    background: rgba(255,255,255,0.6);
    backdrop-filter: blur(10px);
    color:#333;
    padding:30px 15px;
    margin-top:50px;
    text-align:center;
    font-size:14px;
}
.footer-container{
    display:flex;
    justify-content:space-between;
    flex-wrap:wrap;
    max-width:1200px;
    margin:0 auto 15px auto;
}
.footer-container div{margin-bottom:15px;min-width:200px;}
.footer-container h3{
    margin-bottom:10px;
    font-size:16px;
    font-weight:600;
    color:#333;
}
.footer-container a{
    color:#2a8c8c;
    transition:0.3s;
}
.footer-container a:hover{
    text-decoration:underline;
}
</style>
</head>
<body>

<header>
    <div class="logo"><h1>Buzz Cart</h1></div>
    <nav>
        <a href="index.php">Home</a>
        <a href="add-product.php">Add Product</a>
        <a href="orders.php">Order</a>
        <a href="order_summary.php">Summary</a>
    </nav>
</header>

<div class="container">
<h2>Place Customer Order</h2>

<form id="orderForm" method="POST" novalidate>
    <label>Customer Name <span class="required">*</span></label>
    <input type="text" name="customer_name" id="customer_name" placeholder="Enter customer name">

    <label>Order Date <span class="required">*</span></label>
    <input type="date" name="order_date" id="order_date">

    <label>Items <span class="required">*</span></label>
    <div id="items-container">
        <div class="item-row">
            <div class="item-input-wrapper">
                <input type="text" name="item_name[]" placeholder="Item Name">
            </div>
        </div>
    </div>

    <button type="button" class="add-btn" onclick="addItem()">+ Add Item</button>
    <button type="submit" class="submit-btn">Submit Order</button>
</form>
</div>

<footer>
    <div class="footer-container">
        <div>
            <h3>Contact</h3>
            <p>Address: Sathy Road, Saravanampatti, Coimbatore</p>
            <p>Email: contact@buzzcart.com</p>
            <p>Phone: +91 9876543210</p>
        </div>
        <div>
            <h3>Follow Us</h3>
            <p>
                <a href="#">Facebook</a> | 
                <a href="#">Twitter</a> | 
                <a href="#">Instagram</a>
            </p>
        </div>
    </div>
    <p>&copy; <?= date('Y') ?> Buzz Cart. All rights reserved.</p>
</footer>

<script>
function addItem(){
    const container = document.getElementById('items-container');
    const div = document.createElement('div');
    div.className = 'item-row';
    div.innerHTML = `<div class="item-input-wrapper"><input type="text" name="item_name[]" placeholder="Item Name"></div>`;
    container.appendChild(div);
}

$(document).ready(function(){
    // Focus first field
    $('#customer_name').focus();

    // Customer name validation & clear error dynamically
    $('#customer_name').on('input', function(){
        let val = $(this).val();
        val = val.replace(/[^a-zA-Z ]/g,'');
        if(val.length>15) val = val.substring(0,15);
        $(this).val(val);

        if(val!==''){
            $(this).next('.error').remove();
        }
    });

    // Order date dynamic clear
    $('#order_date').on('change input', function(){
        if($(this).val()!==''){
            $(this).next('.error').remove();
        }
    });

    // Item name validation
    $(document).on('input','input[name="item_name[]"]',function(){
        let val = $(this).val();
        val = val.replace(/[^a-zA-Z0-9 ]/g,''); // Remove special chars
        if(val.length>20) val = val.substring(0,20);
        $(this).val(val);

        let wrapper = $(this).parent();
        wrapper.find('.error').remove();

        // Check if empty or only numbers
        if(val==='' || /^\d+$/.test(val)){
            wrapper.append('<span class="error">Enter valid Item name</span>');
        }
    });

    // Limit order date
    let today = new Date();
    let past = new Date(); past.setDate(today.getDate()-30);
    let future = new Date(); future.setDate(today.getDate()+30);
    function formatDate(d){
        let m = (d.getMonth()+1).toString().padStart(2,'0');
        let day = d.getDate().toString().padStart(2,'0');
        return `${d.getFullYear()}-${m}-${day}`;
    }
    $('#order_date').attr('min', formatDate(past));
    $('#order_date').attr('max', formatDate(future));

    // Form submit validation
    $('#orderForm').submit(function(e){
        e.preventDefault();
        $('.error').remove();
        let valid=true;

        let customer = $('#customer_name').val().trim();
        let date = $('#order_date').val();
        let items = $('input[name="item_name[]"]').map(function(){ return $(this).val().trim(); }).get();

        if(customer===''){ $('#customer_name').after('<span class="error">Enter valid customer name</span>'); valid=false; }
        if(date===''){ $('#order_date').after('<span class="error">Select a valid date</span>'); valid=false; }

        items.forEach(function(item,index){
            let wrapper = $('input[name="item_name[]"]').eq(index).parent();
            wrapper.find('.error').remove();
            if(item==='' || /^\d+$/.test(item)){
                wrapper.append('<span class="error">Enter valid Item name</span>');
                valid=false;
            }
        });

        if(valid) this.submit();
    });
});
</script>

</body>
</html>
