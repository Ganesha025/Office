<?php
session_start();
$orders = $_SESSION['orders'] ?? [];
// Reverse orders for LIFO display
$orders = array_reverse($orders);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Order Summary</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{
    font-family:'Roboto',sans-serif;
    background:linear-gradient(135deg,#C8F7DC,#A7E8E8);
    color:#333;
}
a{text-decoration:none;}
header,footer{width:100%;}

/* Header */
header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:20px 50px;
    background: linear-gradient(90deg,#C8F7DC,#A7E8E8);
    flex-wrap:wrap;
    box-shadow:0 5px 20px rgba(0,0,0,0.1);
}
header .logo h1{
    font-family:'Poppins',sans-serif;
    font-size:28px;
    font-weight:700;
    color:#333;
}
header nav a{
    margin-left:25px;
    font-weight:600;
    color:#333;
    transition:0.3s;
}
header nav a:hover{
    color:#2a8c8c;
    text-shadow:0 2px 5px rgba(0,0,0,0.2);
}
@media(max-width:768px){
    header{flex-direction:column;align-items:flex-start;}
    header nav{margin-top:10px;}
    header nav a{margin:5px 10px 0 0;}
}

/* Container */
.container{
    max-width:900px;
    margin:50px auto;
    padding:40px 30px;
    background: rgba(255,255,255,0.5);
    backdrop-filter: blur(15px);
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
}
.container h2{
    text-align:center;
    margin-bottom:25px;
    font-family:'Poppins',sans-serif;
    font-size:28px;
    font-weight:700;
    color:#333;
}

/* Table */
table{
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
}
th, td{
    border:1px solid #ccc;
    padding:12px 15px;
    text-align:left;
}
th{
    background:linear-gradient(45deg,#A7E8E8,#C8F7DC);
    color:#333;
}
tr:nth-child(even){
    background:rgba(255,255,255,0.3);
}

/* Items column without bullet points */
td ul{
    list-style:none;
    padding-left:0;
    margin:0;
}
td ul li{
    margin-bottom:4px;
}

/* Footer */
footer{
    background: rgba(255,255,255,0.6);
    backdrop-filter: blur(10px);
    color:#333;
    padding:30px 15px;
    margin-top:50px;
    text-align:center;
    font-size:14px;
}
.footer-container{
    display:flex;
    justify-content:space-between;
    flex-wrap:wrap;
    max-width:1200px;
    margin:0 auto 15px auto;
}
.footer-container div{margin-bottom:15px;min-width:200px;}
.footer-container h3{
    margin-bottom:10px;
    font-size:16px;
    font-weight:600;
    color:#333;
}
.footer-container a{
    color:#2a8c8c;
    transition:0.3s;
}
.footer-container a:hover{
    text-decoration:underline;
}

/* Back button */
.back-btn{
    display:inline-block;
    margin-top:20px;
    padding:10px 20px;
    background:linear-gradient(45deg,#A7E8E8,#C8F7DC);
    color:#333;
    text-decoration:none;
    border-radius:50px;
    font-weight:600;
    transition:0.3s;
}
.back-btn:hover{
    background:linear-gradient(45deg,#C8F7DC,#A7E8E8);
    box-shadow:0 6px 20px rgba(0,0,0,0.2);
}
</style>
</head>
<body>

<header>
    <div class="logo"><h1>Buzz Cart</h1></div>
    <nav>
        <a href="index.php">Home</a>
        <a href="add-product.php">Add Product</a>
        <a href="orders.php">Order</a>
        <a href="order_summary.php">Summary</a>
    </nav>
</header>

<div class="container">
<h2>Order Summary</h2>

<?php if(!empty($orders)): ?>
<table>
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Customer Name</th>
            <th>Order Date</th>
            <th>Items</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($orders as $i=>$order): ?>
        <tr>
            <td><?= $i+1 ?></td>
            <td><?= $order['customer_name'] ?></td>
            <td><?= $order['order_date'] ?></td>
            <td>
                <ul>
                    <?php foreach($order['items'] as $item): ?>
                        <li><?= $item ?></li>
                    <?php endforeach; ?>
                </ul>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php else: ?>
<p style="text-align:center;margin-top:20px;">No orders found.</p>
<?php endif; ?>

<a href="orders.php" class="back-btn">Place New Order</a>

</div>

<footer>
    <div class="footer-container">
        <div>
            <h3>Contact</h3>
            <p>Address: Sathy Road, Saravanampatti, Coimbatore</p>
            <p>Email: contact@buzzcart.com</p>
            <p>Phone: +91 9876543210</p>
        </div>
        <div>
            <h3>Follow Us</h3>
            <p>
                <a href="#">Facebook</a> | 
                <a href="#">Twitter</a> | 
                <a href="#">Instagram</a>
            </p>
        </div>
    </div>
    <p>&copy; <?= date('Y') ?> Buzz Cart. All rights reserved.</p>
</footer>

</body>
</html>
