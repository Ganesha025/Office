<?php
session_start();

// Default products
$defaultProducts = [
    ['name'=>'Wireless Mouse','price'=>499,'quantity'=>15,'image'=>'uploads/wireless_mouse.jpg'],
    ['name'=>'Bluetooth Headset','price'=>1299,'quantity'=>50,'image'=>'uploads/bluetooth_headset.jfif'],
    ['name'=>'Laptop Stand','price'=>799,'quantity'=>10,'image'=>'uploads/laptop_stand.jpg']
];

// Combine default + session products
$products = $defaultProducts;
if(isset($_SESSION['products'])) $products = array_merge($products,$_SESSION['products']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Buzz Cart</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Roboto:wght@400;700&display=swap" rel="stylesheet">

<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{
    font-family:'Roboto',sans-serif;
    background:linear-gradient(135deg,#C8F7DC,#A7E8E8);
    color:#333;
}
a{text-decoration:none;}
header,footer{width:100%;}

/* Header */
header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:20px 50px;
    background: linear-gradient(90deg,#C8F7DC,#A7E8E8);
    flex-wrap:wrap;
    box-shadow:0 5px 20px rgba(0,0,0,0.1);
}
header .logo h1{
    font-family:'Poppins',sans-serif;
    font-size:28px;
    font-weight:700;
    color:#333;
}
header nav a{
    margin-left:25px;
    font-weight:600;
    color:#333;
    transition:0.3s;
}
header nav a:hover{
    color:#006d5b;
    text-shadow:0 2px 5px rgba(0,0,0,0.2);
}
@media(max-width:768px){
    header{flex-direction:column;align-items:flex-start;}
    header nav{margin-top:10px;}
    header nav a{margin:5px 10px 0 0;}
}

/* Page container */
.page-container{
    max-width:1200px;
    margin:50px auto;
    padding:0 20px;
    text-align:center;
}

/* Add Product Button */
.add-product-btn{
    display:inline-block;
    margin-bottom:30px;
    padding:12px 25px;
    background:linear-gradient(45deg,#A7E8E8,#C8F7DC);
    color:#333;
    font-weight:600;
    border-radius:50px;
    border:1px solid rgba(0,0,0,0.1);
    transition:0.3s;
}
.add-product-btn:hover{
    background:linear-gradient(45deg,#C8F7DC,#A7E8E8);
    transform: translateY(-3px);
}

/* Products grid */
.products{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:30px;
}

/* Product card */
.product-card{
    background: rgba(255,255,255,0.7);
    backdrop-filter: blur(8px);
    border-radius:20px;
    overflow:hidden;
    box-shadow:0 10px 25px rgba(0,0,0,0.1);
    transition:transform 0.3s;
    display:flex;
    flex-direction:column;
    text-align:center;
    color:#333;
}
.product-card:hover{transform: translateY(-5px);}
.product-card img{
    width:100%;
    height:200px;
    object-fit:cover;
}
.product-info{padding:15px;}
.product-info h3{
    margin:10px 0;
    font-family:'Poppins',sans-serif;
    font-size:18px;
    color:#333;
}
.product-info p{
    margin:5px 0;
    font-size:15px;
    color:#444;
}
.low-stock{
    color:#b92c2c;
    font-weight:600;
}

/* Footer */
footer{
    background: rgba(255,255,255,0.5);
    backdrop-filter: blur(8px);
    color:#333;
    padding:30px 15px;
    margin-top:50px;
    text-align:center;
    font-size:14px;
}
.footer-container{
    display:flex;
    justify-content:space-between;
    flex-wrap:wrap;
    max-width:1200px;
    margin:0 auto 15px auto;
}
.footer-container div{
    margin-bottom:15px;
    min-width:200px;
}
.footer-container h3{
    margin-bottom:10px;
    font-size:16px;
    font-weight:600;
    color:#333;
}
.footer-container a{
    color:#006d5b;
    transition:0.3s;
}
.footer-container a:hover{
    text-decoration:underline;
}
</style>



</head>
<body>

<header>
    <div class="logo"><h1>Buzz Cart</h1></div>
    <nav>
        <a href="index.php">Home</a>
        <a href="add-product.php">Add Product</a>
        <a href="orders.php">Order</a>
        <a href="order_summary.php">Summary</a>
    </nav>
</header>

<div class="page-container">
    <a href="add-product.php" class="add-product-btn">Add New Product</a>
    <div class="products">
        <?php foreach($products as $product): ?>
        <div class="product-card">
            <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
            <div class="product-info">
                <h3><?= htmlspecialchars($product['name']) ?></h3>
                <p>Price: ₹<?= number_format($product['price']) ?></p>
                <p>Quantity: <?= $product['quantity'] ?> 
                    <?php if($product['quantity'] < 20): ?>
                        <span class="low-stock">(Low Stock)</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<footer>
    <div class="footer-container">
        <div>
            <h3>Contact</h3>
            <p>Address: Sathy Road, Saravanampatti, Coimbatore</p>
            <p>Email: contact@buzzcart.com</p>
            <p>Phone: +91 9876543210</p>
        </div>
        <div>
            <h3>Follow Us</h3>
            <p>
                <a href="#">Facebook</a> | 
                <a href="#">Twitter</a> | 
                <a href="#">Instagram</a>
            </p>
        </div>
    </div>
    <p>&copy; <?= date('Y') ?> Buzz Cart. All rights reserved.</p>
</footer>
</body>
</html>