<?php
session_start();

// Handle form submission
if($_SERVER['REQUEST_METHOD']==='POST'){
    $name = $_POST['name'] ?? '';
    $price = $_POST['price'] ?? '';
    $quantity = $_POST['quantity'] ?? '';
    $image = $_FILES['image'] ?? null;

    if($name && $price && $quantity && $image && $image['error']===0){
        $uploadsDir = 'uploads/';
        if(!is_dir($uploadsDir)) mkdir($uploadsDir,0777,true);
        $imageName = time().'_'.$image['name'];
        move_uploaded_file($image['tmp_name'],$uploadsDir.$imageName);

        $_SESSION['products'][] = [
            'name'=>htmlspecialchars($name),
            'price'=>(float)$price,
            'quantity'=>(int)$quantity,
            'image'=>$uploadsDir.$imageName
        ];

        header('Location: index.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Product</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- <style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Roboto',sans-serif;background:linear-gradient(135deg,#0D1B2A,#1B9AAA);color:#fff;}
a{text-decoration:none;}
header,footer{width:100%;}

/* Header */
header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:20px 50px;
    background: linear-gradient(90deg,#0D1B2A,#1B9AAA);
    flex-wrap:wrap;
    box-shadow:0 5px 20px rgba(0,0,0,0.3);
}
header .logo h1{font-family:'Poppins',sans-serif;font-size:28px;font-weight:700;}
header nav a{margin-left:25px;font-weight:600;color:#fff;transition:0.3s;}
header nav a:hover{color:#FFD700;text-shadow:0 2px 5px rgba(0,0,0,0.3);}
@media(max-width:768px){header{flex-direction:column;align-items:flex-start;}header nav{margin-top:10px;}header nav a{margin:5px 10px 0 0;}}

/* Form Container */
.container{
    max-width:500px;
    margin:50px auto;
    padding:40px 30px;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(15px);
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.3);
}
.container h2{text-align:center;margin-bottom:25px;font-family:'Poppins',sans-serif;font-size:28px;font-weight:700;}

/* Labels & Inputs */
label{display:block;margin:10px 0 5px;font-weight:600;}
.required{color:#FFD700;}
input{
    width:100%;
    padding:12px 20px;
    margin-bottom:15px;
    border-radius:50px;
    border:none;
    outline:none;
    font-size:16px;
    background:rgba(255,255,255,0.2);
    color:#fff;
    transition:0.3s;
}
input::placeholder{color:rgba(255,255,255,0.7);}
input:focus{background:rgba(255,255,255,0.3);box-shadow:0 4px 15px rgba(0,0,0,0.3);}
input::-webkit-inner-spin-button,input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0;}
input[type=number]{-moz-appearance:textfield;}

/* File input */
input[type=file]{padding:8px;}

/* Button */
button{
    width:100%;
    padding:15px;
    border:none;
    border-radius:50px;
    background:linear-gradient(45deg,#1B9AAA,#0D1B2A);
    color:#fff;
    font-weight:700;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;
}
button:hover{
    background:linear-gradient(45deg,#0D1B2A,#1B9AAA);
    transform: translateY(-3px);
    box-shadow:0 8px 25px rgba(0,0,0,0.3);
}

/* Error */
.error{color:#FF6B6B;font-size:14px;text-align:left;}

/* Footer */
footer{
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(10px);
    color:#fff;
    padding:30px 15px;
    margin-top:50px;
    text-align:center;
    font-size:14px;
}
.footer-container{
    display:flex;
    justify-content:space-between;
    flex-wrap:wrap;
    max-width:1200px;
    margin:0 auto 15px auto;
}
.footer-container div{margin-bottom:15px;min-width:200px;}
.footer-container h3{margin-bottom:10px;font-size:16px;font-weight:600;}
.footer-container a{color:#FFD700;transition:0.3s;}
.footer-container a:hover{text-decoration:underline;}
</style> -->

<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{
    font-family:'Roboto',sans-serif;
    background:linear-gradient(135deg,#C8F7DC,#A7E8E8);
    color:#333;
}
a{text-decoration:none;}
header,footer{width:100%;}

/* Header */
header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:20px 50px;
    background: linear-gradient(90deg,#C8F7DC,#A7E8E8);
    flex-wrap:wrap;
    box-shadow:0 5px 20px rgba(0,0,0,0.1);
}
header .logo h1{
    font-family:'Poppins',sans-serif;
    font-size:28px;
    font-weight:700;
    color:#333;
}
header nav a{
    margin-left:25px;
    font-weight:600;
    color:#333;
    transition:0.3s;
}
header nav a:hover{
    color:#2a8c8c;
    text-shadow:0 2px 5px rgba(0,0,0,0.2);
}
@media(max-width:768px){
    header{flex-direction:column;align-items:flex-start;}
    header nav{margin-top:10px;}
    header nav a{margin:5px 10px 0 0;}
}

/* Form Container */
.container{
    max-width:500px;
    margin:50px auto;
    padding:40px 30px;
    background: rgba(255,255,255,0.5);
    backdrop-filter: blur(15px);
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
}
.container h2{
    text-align:center;
    margin-bottom:25px;
    font-family:'Poppins',sans-serif;
    font-size:28px;
    font-weight:700;
    color:#333;
}

/* Labels & Inputs */
label{display:block;margin:10px 0 5px;font-weight:600;color:#333;}
.required{color:#2a8c8c;}
input{
    width:100%;
    padding:12px 20px;
    margin-bottom:15px;
    border-radius:50px;
    border:none;
    outline:none;
    font-size:16px;
    background:rgba(255,255,255,0.7);
    color:#333;
    transition:0.3s;
}
input::placeholder{color:#666;}
input:focus{
    background:rgba(255,255,255,0.9);
    box-shadow:0 4px 15px rgba(0,0,0,0.2);
}
input::-webkit-inner-spin-button,
input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0;}
input[type=number]{-moz-appearance:textfield;}

/* File input */
input[type=file]{padding:8px;}

/* Button */
button{
    width:100%;
    padding:15px;
    border:none;
    border-radius:50px;
    background:linear-gradient(45deg,#A7E8E8,#C8F7DC);
    color:#333;
    font-weight:700;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;
}
button:hover{
    background:linear-gradient(45deg,#C8F7DC,#A7E8E8);
    transform: translateY(-3px);
    box-shadow:0 8px 25px rgba(0,0,0,0.2);
}

/* Error */
.error{color:#b82e2e;font-size:14px;text-align:left;}

/* Footer */
footer{
    background: rgba(255,255,255,0.6);
    backdrop-filter: blur(10px);
    color:#333;
    padding:30px 15px;
    margin-top:50px;
    text-align:center;
    font-size:14px;
}
.footer-container{
    display:flex;
    justify-content:space-between;
    flex-wrap:wrap;
    max-width:1200px;
    margin:0 auto 15px auto;
}
.footer-container div{margin-bottom:15px;min-width:200px;}
.footer-container h3{
    margin-bottom:10px;
    font-size:16px;
    font-weight:600;
    color:#333;
}
.footer-container a{
    color:#2a8c8c;
    transition:0.3s;
}
.footer-container a:hover{
    text-decoration:underline;
}
</style>


</head>
<body>

<header>
    <div class="logo"><h1>Buzz Cart</h1></div>
    <nav>
        <a href="index.php">Home</a>
        <a href="add-product.php">Add Product</a>
        <a href="orders.php">Order</a>
        <a href="order_summary.php">Summary</a>
    </nav>
</header>

<div class="container">
<h2>Add New Product</h2>
<form id="addProductForm" method="post" enctype="multipart/form-data" novalidate>
    <label>Product Name <span class="required">*</span></label>
    <input type="text" id="name" name="name" placeholder="Product Name" maxlength="20">
    
    <label>Price (₹) <span class="required">*</span></label>
    <input type="number" id="price" name="price" placeholder="Price">
    
    <label>Quantity <span class="required">*</span></label>
    <input type="number" id="quantity" name="quantity" placeholder="Quantity">
    
    <label>Product Image <span class="required">*</span></label>
    <input type="file" id="image" name="image" accept="image/*">
    
    <button type="submit">Add Product</button>
</form>
</div>

<footer>
    <div class="footer-container">
        <div>
            <h3>Contact</h3>
            <p>Address: Sathy Road, Saravanampatti, Coimbatore</p>
            <p>Email: contact@buzzcart.com</p>
            <p>Phone: +91 9876543210</p>
        </div>
        <div>
            <h3>Follow Us</h3>
            <p>
                <a href="#">Facebook</a> | 
                <a href="#">Twitter</a> | 
                <a href="#">Instagram</a>
            </p>
        </div>
    </div>
    <p>&copy; <?= date('Y') ?> Buzz Cart. All rights reserved.</p>
</footer>

<script>
$(document).ready(function(){
    $('#name').focus();

    $('#name').on('input', function() {
    let val = $(this).val().trim();
    
    // Remove invalid characters (allow only letters, numbers, space)
    val = val.replace(/[^a-zA-Z0-9 ]/g, '');
    
    // Limit length to 20 characters
    if (val.length > 20) val = val.substring(0, 20);
    
    $(this).val(val);

    // Validation: disallow only numbers
    if (/^\d+$/.test(val)) {
        if ($(this).next('.error').length === 0) {
            $(this).after('<span class="error">The product name is invalid</span>');
        }
    } else {
        // Remove error if valid
        $(this).next('.error').remove();
    }
});


    $('#price').on('input',function(){
        let val=$(this).val().replace(/\D/g,'');
        if(val>9000000) val='9000000';
        $(this).val(val);
        if(val>=1 && val<=9000000) $(this).next('.error').remove();
    });

    $('#quantity').on('input',function(){
        let val=$(this).val().replace(/\D/g,'');
        if(val>9000) val='9000';
        $(this).val(val);
        if(val>=1 && val<=9000) $(this).next('.error').remove();
    });

    $('#image').on('change',function(){
        if($(this).val()!=='') $(this).next('.error').remove();
    });

    $('#addProductForm').submit(function(e){
        e.preventDefault();
        $('.error').remove();
        let valid=true;
        let name=$('#name').val().trim();
        let price=$('#price').val();
        let quantity=$('#quantity').val();
        let image=$('#image').val();

        if(name===''){ $('#name').after('<span class="error">Enter product name</span>'); valid=false; }
        if(price==='' || price<1){ $('#price').after('<span class="error">Enter valid price</span>'); valid=false; }
        if(quantity==='' || quantity<1){ $('#quantity').after('<span class="error">Enter valid quantity</span>'); valid=false; }
        if(image===''){ $('#image').after('<span class="error">Select product image</span>'); valid=false; }

        if(valid){ this.submit(); }
    });
});
</script>

</body>
</html>
