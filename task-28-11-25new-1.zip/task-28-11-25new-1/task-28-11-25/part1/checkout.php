<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Checkout Calculator</title>

    <!-- Tailwind CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        body {
            background: linear-gradient(135deg, #f0fdf4, #e0f7fa);
        }
    </style>
</head>
<body class="min-h-screen flex flex-col items-center py-10 px-4">

<h1 class="text-4xl font-bold text-slate-800 mb-8 drop-shadow-lg">
    Smart Checkout Calculator
</h1>

<?php
// Initialize variables
$finalPrice = $shippingCost = $totalPayable = null;

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // INPUTS
    $price = $_POST["price"];
    $premium = isset($_POST["premium"]);
    $destination = $_POST["destination"];
    $weight = $_POST["weight"];

    // -------------------------------
    // ASSESSMENT 1 — DISCOUNT SYSTEM
    // -------------------------------
    if ($premium) {
        $discountRate = 0.20;   // 20%
    } elseif ($price > 200) {
        $discountRate = 0.15;   // 15%
    } elseif ($price > 100) {
        $discountRate = 0.10;   // 10%
    } else {
        $discountRate = 0.05;   // 5%
    }

    $discountAmount = $price * $discountRate;
    $finalPrice = $price - $discountAmount;

    // -----------------------------------------
    // ASSESSMENT 2 — SHIPPING COST CALCULATION
    // -----------------------------------------
    if ($destination === "domestic" && $weight < 5) {
        $shippingCost = 10;
    } elseif ($destination === "domestic" && $weight >= 5) {
        $shippingCost = 20;
    } elseif ($destination === "international" && $weight < 5) {
        $shippingCost = 30;
    } else {
        $shippingCost = 50;
    }

    // Total payable amount
    $totalPayable = $finalPrice + $shippingCost;
}
?>

<!-- FORM CARD -->
<div class="bg-white shadow-lg rounded-xl p-8 w-full max-w-3xl border border-teal-200">

    <form method="POST" class="space-y-6">

        <!-- Product Price -->
        <div>
            <label class="block font-semibold mb-1">Product Price ($)</label>
            <input type="number" step="0.01" name="price" required
                class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-400">
        </div>

        <!-- Premium Member -->
        <div class="flex items-center space-x-3">
            <input type="checkbox" name="premium"
                class="w-5 h-5 text-teal-600 rounded">
            <label class="font-semibold">Premium Member (20% off)</label>
        </div>

        <!-- Destination -->
        <div>
            <label class="block font-semibold mb-1">Destination</label>
            <select name="destination" required
                class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-400">
                <option value="domestic">Domestic</option>
                <option value="international">International</option>
            </select>
        </div>

        <!-- Weight -->
        <div>
            <label class="block font-semibold mb-1">Package Weight (kg)</label>
            <input type="number" step="0.1" name="weight" required
                class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-400">
        </div>

        <!-- Submit Button -->
        <button type="submit"
            class="w-full bg-teal-500 text-white p-3 rounded-lg text-lg font-semibold hover:bg-teal-600 transition">
            Calculate Total
        </button>
    </form>
</div>

<!-- OUTPUT SECTION -->
<?php if ($finalPrice !== null): ?>
<div class="mt-10 bg-white shadow-lg rounded-xl p-8 w-full max-w-3xl border border-yellow-200">
    <h2 class="text-2xl font-bold text-yellow-600 mb-4">Checkout Summary</h2>

    <div class="space-y-2 text-lg">
        <p><strong>Original Price:</strong> $<?= number_format($price, 2); ?></p>
        <p><strong>Discount Applied:</strong> <?= $discountRate * 100; ?>%</p>
        <p><strong>Final Price After Discount:</strong> $<?= number_format($finalPrice, 2); ?></p>
        <hr class="my-3 border-yellow-300">
        <p><strong>Shipping Cost:</strong> $<?= number_format($shippingCost, 2); ?></p>
        <hr class="my-3 border-yellow-300">
        <p class="text-2xl font-bold text-green-700">
            Total Payable: $<?= number_format($totalPayable, 2); ?>
        </p>
    </div>
</div>
<?php endif; ?>

</body>
</html>   