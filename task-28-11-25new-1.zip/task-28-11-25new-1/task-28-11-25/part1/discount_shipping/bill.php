<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bill Receipt</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        body {
            background: linear-gradient(135deg, #fffbea, #fff4e6);
        }

        .bill-logo {
            width: 80px;
            height: auto;
        }

        .thank-you {
            font-style: italic;
            color: #d97706; /* Tailwind amber-600 */
        }
    </style>

    <script>
        // Redirect to checkout.php after page refresh
        if (performance.navigation.type === 1) {
            window.location.href = "checkout.php";
        }
    </script>
</head>

<body class="min-h-screen flex flex-col items-center py-10 px-4">

<!-- Brand Header -->
<div class="flex items-center mb-8 space-x-4">
    <img src="logo-orange.webp" alt="Brand Logo" class="bill-logo rounded-full border-2 border-orange-500">
    <h1 class="text-4xl font-bold text-orange-700 drop-shadow-lg">ShopIQ</h1>
</div>

<?php
// Retrieve POST data
$customerName   = $_POST["customerName"] ?? "Guest";
$price          = $_POST["price"] ?? 0;
$premium        = $_POST["premium"] ?? "no";
$destination    = $_POST["destination"] ?? "domestic";
$weight         = $_POST["weight"] ?? 0;
$date           = date("d-m-Y");

// Discount Calculation
if ($premium === "yes") {
    $discountRate = 0.20;
} elseif ($price > 200) {
    $discountRate = 0.15;
} elseif ($price > 100) {
    $discountRate = 0.10;
} else {
    $discountRate = 0.05;
}

$discountAmount = $price * $discountRate;
$finalPrice = $price - $discountAmount;

// Shipping Calculation
if ($destination === "domestic" && $weight < 5) {
    $shippingCost = 10;
} elseif ($destination === "domestic" && $weight >= 5) {
    $shippingCost = 20;
} elseif ($destination === "international" && $weight < 5) {
    $shippingCost = 30;
} else {
    $shippingCost = 50;
}

$totalPayable = $finalPrice + $shippingCost;
?>

<!-- BILL CARD -->
<div class="bg-white shadow-xl rounded-xl p-8 w-full max-w-2xl border border-orange-300">

    <h2 class="text-2xl font-bold text-orange-600 mb-4">Billing Summary</h2>

    <p class="text-lg"><strong>Date:</strong> <?= $date ?></p>
    <p class="text-lg"><strong>Customer Name:</strong> <?= htmlspecialchars($customerName); ?></p>

    <hr class="my-4 border-orange-400">

    <div class="space-y-2 text-lg">
        <p><strong>Original Price:</strong> ₹<?= number_format($price, 2); ?></p>
        <p><strong>Discount Applied:</strong> <?= $discountRate * 100; ?>%</p>
        <p><strong>Final Price:</strong> ₹<?= number_format($finalPrice, 2); ?></p>

        <p><strong>Destination:</strong> <?= ucfirst($destination); ?></p>
        <p><strong>Weight:</strong> <?= $weight ?> kg</p>
        <p><strong>Shipping Cost:</strong> ₹<?= number_format($shippingCost, 2); ?></p>

        <hr class="my-4 border-orange-400">

        <p class="text-2xl font-bold text-green-700">
            Total Payable: ₹<?= number_format($totalPayable, 2); ?>
        </p>
    </div>

    <hr class="my-4 border-orange-400">

    <p class="thank-you text-center mt-4">
        Thank you for shopping with <strong>ShopIQ</strong>!<br>
        We hope to see you again soon!
    </p>
</div>

</body>
</html>
