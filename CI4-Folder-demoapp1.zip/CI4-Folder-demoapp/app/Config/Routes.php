<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('exam/start', 'Exam::start');
$routes->post('exam/submit', 'Exam::submit');

