<!DOCTYPE html>
<html>
<head>
<title>Online Practical Exam</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
html, body {
    margin: 0;
    height: 100%;
}
#timer {
    position: fixed;
    top: 10px;
    right: 20px;
    font-size: 20px;
    font-weight: bold;
}
.btn{
    width: 100px;
    margin-left: 1332px;
}
.textarea{
    margin-top:100px;
    margin-left:150px;
    padding:10px;
}

    

</style>
<link rel="stylesheet" href="/argon/css/argon-dashboard.min.css" onload="console.log('Argon CSS loaded successfully')" onerror="console.error('Failed to load Argon CSS')">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/argon-design-system-free@1.2.0/assets/css/argon-design-system.min.css" rel="stylesheet">


<!-- JS -->
<script src="<?= base_url('argon/vendor/jquery/dist/jquery.min.js') ?>"></script>
<script src="<?= base_url('argon/vendor/bootstrap/dist/js/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= base_url('argon/js/argon-dashboard.min.js') ?>"></script>
</head>
<body>

<div id="timer"></div>

<form id="examForm" method="post" action="<?= base_url('exam/submit') ?>">
    <?= csrf_field() ?>
    <textarea name="code" class="textarea" rows="15" style="width:80%" placeholder="Write your code here..." autofocus></textarea>
    <br><br>
    
    <button class="btn btn-success">
    Submit 
</button>

</form>

<script>
/* ===== FORCE FULLSCREEN ===== */
document.documentElement.requestFullscreen();

/* ===== DISABLE COPY / PASTE / RIGHT CLICK ===== */
['copy','paste','cut','contextmenu'].forEach(evt =>
    document.addEventListener(evt, e => e.preventDefault())
);

/* ===== DISABLE REFRESH / KEYS ===== */
document.addEventListener('keydown', e => {
    if (
        e.key === 'F5' ||
        (e.ctrlKey && ['r','R','c','v','x','u','s'].includes(e.key))
    ) {
        e.preventDefault();
    }
});

/* ===== BLOCK BACK BUTTON ===== */
history.pushState(null, null, location.href);
window.onpopstate = () => history.go(1);

/* ===== TAB SWITCH DETECTION ===== */
document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
        // alert("This is a warning alert—check it out!");
        submitExam();
    }
});

/* ===== TIMER ===== */
let endTime = <?= session('exam_end_time') ?> * 1000;

setInterval(() => {
    let remaining = Math.floor((endTime - Date.now()) / 1000);
    if (remaining <= 0) submitExam();

    let m = Math.floor(remaining / 60);
    let s = remaining % 60;
    document.getElementById('timer').innerText = `Time Left: ${m}:${s}`;
}, 1000);

function submitExam(){
    document.getElementById("examForm").submit();
}
</script>

</body>
</html>
