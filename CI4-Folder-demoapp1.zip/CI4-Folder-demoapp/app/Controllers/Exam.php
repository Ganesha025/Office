<?php

namespace App\Controllers;

class Exam extends BaseController
{
    public function start()
    {
        session()->set([
            'exam_started' => true,
            'exam_end_time' => time() + (1 * 60) // 30 mins
        ]);

        return view('exam_screen');
    }

    public function submit()
    {
        if (!session()->has('exam_started')) {
            return redirect()->to('/');
        }

        // save answers here

        session()->destroy();
        return "Exam submitted successfully";
    }
}
