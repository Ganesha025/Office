<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "student_db";

$conn = mysqli_connect($host, $user, $pass);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS $db");
mysqli_select_db($conn, $db);


mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Departments (
    DepartmentID INT AUTO_INCREMENT PRIMARY KEY,
    DeptName VARCHAR(25) NOT NULL
)");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Students (
    StudentID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(25) NOT NULL,
    Age INT CHECK (Age > 15),
    Gender VARCHAR(25),
    DepartmentID INT,
    FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID)
)");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Courses (
    CourseID INT AUTO_INCREMENT PRIMARY KEY,
    CourseName VARCHAR(50) NOT NULL,
    DepartmentID INT,
    FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID)
)");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS Enrollments (
    EnrollmentID INT AUTO_INCREMENT PRIMARY KEY,
    StudentID INT,
    CourseID INT,
    Grade CHAR(1) CHECK (Grade IN ('A','B','C','D','F')),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
)");




$result = $conn->query("SELECT COUNT(*) AS cnt FROM Departments");
$row = $result->fetch_assoc();
if($row['cnt'] == 0){
    mysqli_query($conn, "INSERT INTO Departments (DeptName) VALUES
    ('CSE'), ('MECH'), ('EEE'), ('ECE'), ('CIVIL')");
}


$result = $conn->query("SELECT COUNT(*) AS cnt FROM Students");
$row = $result->fetch_assoc();
if($row['cnt'] == 0){
    mysqli_query($conn, "INSERT INTO Students (Name, Age, Gender, DepartmentID) VALUES
    ('Abirami', 19, 'Female', 1),
    ('Ravi', 20, 'Male', 2),
    ('Priya', 18, 'Female', 1),
    ('Suresh', 21, 'Male', 3),
    ('Keerthi', 19, 'Female', 4),
    ('Karthik', 22, 'Male', 5),
    ('Divya', 18, 'Female', 2),
    ('Arun', 20, 'Male', 3),
    ('Meena', 21, 'Female', 4),
    ('Vijay', 19, 'Male', 1)");
}


$result = $conn->query("SELECT COUNT(*) AS cnt FROM Courses");
$row = $result->fetch_assoc();
if($row['cnt'] == 0){
    mysqli_query($conn, "INSERT INTO Courses (CourseName, DepartmentID) VALUES
    ('DBMS', 1),
    ('Thermodynamics', 2),
    ('Circuit Theory', 3),
    ('Signals & Systems', 4),
    ('Structural Engg', 5),
    ('Operating Systems', 1)");
}


$result = $conn->query("SELECT COUNT(*) AS cnt FROM Enrollments");
$row = $result->fetch_assoc();
if($row['cnt'] == 0){
    mysqli_query($conn, "INSERT INTO Enrollments (StudentID, CourseID, Grade) VALUES
    (1, 1, 'A'),
    (1, 6, 'B'),
    (2, 2, 'A'),
    (3, 1, 'A'),
    (3, 6, 'C'),
    (4, 3, 'B'),
    (5, 4, 'A'),
    (6, 5, 'C'),
    (7, 2, 'B'),
    (8, 3, 'D'),
    (9, 4, 'A'),
    (10,1, 'B'),
    (10,6, 'A'),
    (2, 1, 'C'),
    (4, 6, 'B')");
}


?>
