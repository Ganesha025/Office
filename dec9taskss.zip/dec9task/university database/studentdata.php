<?php include 'db.php'; ?>

<h3>All Students with Department Names</h3>

<?php
$sql = "SELECT Students.Name AS StudentName, Departments.DeptName
        FROM Students 
        JOIN Departments  ON Students.DepartmentID = Departments.DepartmentID
        ORDER BY Students.StudentID";

$result1 = $conn->query($sql);

echo "<table border='1'><tr><th>Student</th><th>Department</th></tr>";
while($row = $result1->fetch_assoc()) {
    echo "<tr><td>".$row['StudentName']."</td><td>".$row['DeptName']."</td></tr>";
}
echo "</table><br>";

$sql = "SELECT Courses.CourseName, Departments.DeptName
        FROM Courses 
        LEFT JOIN Departments  ON Courses.DepartmentID = Departments.DepartmentID";

$result = $conn->query($sql);

echo "<table border='1'>
<tr><th>Course</th><th>Department</th></tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row['CourseName']."</td><td>".$row['DeptName']."</td></tr>";
}

echo "</table><br>";

$sql = "SELECT Students.Name AS StudentName, Courses.CourseName, Enrollments.Grade
        FROM Enrollments 
        JOIN Students  ON Enrollments.StudentID = Students.StudentID
        JOIN Courses  ON Enrollments.CourseID = Courses.CourseID
        ORDER BY Students.StudentID";

$result = $conn->query($sql);

echo "<table border='1'>
<tr><th>Student</th><th>Course</th><th>Grade</th></tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row['StudentName']."</td><td>".$row['CourseName']."</td><td>".$row['Grade']."</td></tr>";
}

echo "</table><br>";

$sql = "SELECT Courses.CourseName, COUNT(Enrollments.StudentID) AS Enrollments
        FROM Courses 
        LEFT JOIN Enrollments  ON Courses.CourseID = Enrollments.CourseID
        GROUP BY Courses.CourseID, Courses.CourseName";

$result = $conn->query($sql);

echo "<table border='1'>
<tr><th>Course</th><th>Enrollments</th></tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row['CourseName']."</td><td>".$row['Enrollments']."</td></tr>";
}

echo "</table><br>";


$sql = "SELECT Departments.DeptName, COUNT(Students.StudentID) AS TotalStudents
        FROM Departments 
        LEFT JOIN Students  ON Departments.DepartmentID = Students.DepartmentID
        GROUP BY Departments.DepartmentID, Departments.DeptName";

$result = $conn->query($sql);

echo "<table border='1'>
<tr><th>Department</th><th>Total Students</th></tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row['DeptName']."</td><td>".$row['TotalStudents']."</td></tr>";
}

echo "</table><br>";



$sql = "SELECT Departments.DeptName, ROUND(AVG(Students.Age), 2) AS AverageAge
        FROM Departments 
        JOIN Students  ON Departments.DepartmentID = Students.DepartmentID
        GROUP BY Departments.DepartmentID, Departments.DeptName";

$result = $conn->query($sql);

echo "<table border='1'>
<tr><th>Department</th><th>Average Age</th></tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row['DeptName']."</td><td>".$row['AverageAge']."</td></tr>";
}

echo "</table><br>";

$sql = "SELECT Courses.CourseName, COUNT(Enrollments.StudentID) AS StudentCount
        FROM Enrollments 
        JOIN Courses  ON Enrollments.CourseID = Courses.CourseID
        GROUP BY Courses.CourseID, Courses.CourseName
        HAVING COUNT(Enrollments.StudentID) > 2";

$result = $conn->query($sql);

echo "<table border='1'>
<tr><th>Course</th><th>Student Count</th></tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row['CourseName']."</td><td>".$row['StudentCount']."</td></tr>";
}

echo "</table><br>";

$sql = "SELECT Departments.DeptName,
        ROUND(AVG(
            CASE Enrollments.Grade
                WHEN 'A' THEN 4
                WHEN 'B' THEN 3
                WHEN 'C' THEN 2
                WHEN 'D' THEN 1
                WHEN 'F' THEN 0
            END
        ), 2) AS AverageGrade
        FROM Departments 
        JOIN Students  ON Departments.DepartmentID = Students.DepartmentID
        JOIN Enrollments  ON Students.StudentID = Enrollments.StudentID
        GROUP BY Departments.DepartmentID, Departments.DeptName";

$result = $conn->query($sql);

echo "<table border='1'>
<tr><th>Department</th><th>Average Grade</th></tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row['DeptName']."</td><td>".$row['AverageGrade']."</td></tr>";
}

echo "</table><br>";
 


$sql12 = "
SELECT c.CourseName,
       CASE MAX(
           CASE e.Grade
               WHEN 'A' THEN 4
               WHEN 'B' THEN 3
               WHEN 'C' THEN 2
               WHEN 'D' THEN 1
               WHEN 'F' THEN 0
           END
       )
       WHEN 4 THEN 'A'
       WHEN 3 THEN 'B'
       WHEN 2 THEN 'C'
       WHEN 1 THEN 'D'
       WHEN 0 THEN 'F'
       END AS HighestGrade
FROM Courses c
JOIN Enrollments e ON c.CourseID = e.CourseID
GROUP BY c.CourseID, c.CourseName
ORDER BY c.CourseID
";

$result12 = $conn->query($sql12);

echo "<table border='1'><tr><th>Course</th><th>Highest Grade</th></tr>";
while($row = $result12->fetch_assoc()){
    echo "<tr><td>".$row['CourseName']."</td><td>".$row['HighestGrade']."</td></tr>";
}
echo "</table><br>";

$sql = "
SELECT Departments.DeptName, COUNT(Enrollments.StudentID) AS TotalEnrollments
FROM Departments 
JOIN Students  ON Departments.DepartmentID = Students.DepartmentID
JOIN Enrollments  ON Students.StudentID = Enrollments.StudentID
GROUP BY Departments.DepartmentID, Departments.DeptName";

$result13 = $conn->query($sql);

echo "<table border='1'><tr><th>Department</th><th>Total Enrollments</th></tr>";
while($row = $result13->fetch_assoc()){
    echo "<tr><td>".$row['DeptName']."</td><td>".$row['TotalEnrollments']."</td></tr>";
}
echo "</table><br>";

$sql = "
    SELECT Students.Name AS StudentName
    FROM Students 
    LEFT JOIN Enrollments ON Students.StudentID = Enrollments.StudentID
    WHERE Enrollments.StudentID IS NULL;
";

$result = $conn->query($sql);
echo "<table border='1'><tr><th>Student</th></tr>";

 if($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row['StudentName']."</td></tr>";
}
else{
        echo"No Student Records Found";
    }

echo "</table><br>";



$sql15 = "
SELECT Students.Name AS StudentName
FROM Students 
WHERE NOT EXISTS (
    SELECT Courses.CourseID
    FROM Courses 
    WHERE Courses.DepartmentID = Students.DepartmentID
    AND Courses.CourseID NOT IN (
        SELECT Enrollments.CourseID
        FROM Enrollments 
        WHERE Enrollments.StudentID = Students.StudentID
    )
);
";

$result15 = $conn->query($sql15);

echo "<table border='1'><tr><th>Student</th></tr>";

if ($result15->num_rows > 0) {
    while ($row = $result15->fetch_assoc()) {
        echo "<tr><td>".$row['StudentName']."</td></tr>";
    }
} else {
    echo "<tr><td>No records found</td></tr>";
}

echo "</table><br>";
      

?>
