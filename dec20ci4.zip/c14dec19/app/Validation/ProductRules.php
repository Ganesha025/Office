<?php

namespace App\Validation;

use CodeIgniter\Validation\ValidationInterface;

class ProductRules
{
    /**
     * Custom validation to prevent negative stock
     *
     * @param string $value
     * @param string|null $params
     * @param ValidationInterface|null $validation
     * @return bool|string
     */
    public static function validateStock($value, string $params = null, ValidationInterface $validation = null)
    {
        if (!is_numeric($value) || $value < 0) {
            return false; // validation fails
        }

        return true; // valid stock
    }
}
