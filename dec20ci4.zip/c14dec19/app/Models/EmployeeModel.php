<?php
namespace App\Models;
use CodeIgniter\Model;

class EmployeeModel extends Model
{
    protected $table = 'employees';
    protected $primaryKey = 'id';
    protected $useSoftDeletes = true;
    protected $allowedFields = ['emp_name','email','department','role'];
    protected $useTimestamps = true;

    protected $validationRules = [
        'emp_name'   => 'required|min_length[3]|max_length[100]',
        'email'      => 'required|valid_email|is_unique[employees.email,id,{id}]',
        'department' => 'required|in_list[Sales,Finance]',
        'role'       => 'required|in_list[Staff,Manager,Admin]'
    ];

    protected $validationMessages = [
        'emp_name' => [
            'required' => 'Employee name required',
            'min_length' => 'At least 3 characters'
        ],
        'email' => [
            'required' => 'Email required',
            'valid_email' => 'Valid email required'
        ]
    ];
}
