<?php
namespace App\Models;
use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = ['username','email','password','role','department'];
    protected $useTimestamps = true;
    public function getRoleName($roleId) {
        switch ($roleId) {
            case 1:
                return 'Admin';
            case 2:
                return 'HR';
            case 3:
                return 'manager';
            default:
                return 'invalid';
        }
    }
}