<?php
namespace App\Models\inventory;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table = 'products';
    protected $primaryKey = 'id';
    protected $allowedFields = ['product_name','sku','price','stock'];
    protected $useTimestamps = true;
}
