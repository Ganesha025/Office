<?php
namespace App\Models\inventory;

use CodeIgniter\Model;

class StockLogModel extends Model
{
    protected $table = 'stock_logs';
    protected $primaryKey = 'id';
    protected $allowedFields = ['product_id','changed_stock','changed_by'];
    protected $useTimestamps = true;
}
