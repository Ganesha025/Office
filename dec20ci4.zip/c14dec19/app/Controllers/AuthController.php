<?php
namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class AuthController extends Controller
{
    public function login()
    {
        return view('auth/login');
    }

public function loginPost()
{
    $session = session();
    $userModel = model(UserModel::class);
    $email    = $this->request->getPost('email');
    $password = $this->request->getPost('password');
    //to

$userRow = $userModel->select('id, role')->where('email', $email)->first(); 
$role = $userRow['role'] ?? 4;

$fetchedrole = $userModel->getRoleName($role);


    $user = $userModel->where('email', $email)->first();

    if (!$user) {
        return redirect()->back()->with('error', 'Invalid email or password');
    }

    // 2️⃣ Password validation
    if ($password !== $user['password']) {
        return redirect()->back()->with('error', 'Invalid email or password');
    }

    // 3️⃣ Role validation (NULL or empty not allowed)
    if ($fetchedrole=='invalid') {
        return redirect()->back()->with(
            'error',
            'Your account has no role assigned. Contact admin.'
        );
    }

    // 4️⃣ Optional: Department check for HR
    if ($fetchedrole === 'HR' && empty($user['department'])) {
        return redirect()->back()->with(
            'error',
            'HR account must have a department assigned.'
        );
    }

    // 5️⃣ Set session
    $session->set([
        'user_id'    => $user['id'],
        'role'       => $fetchedrole,
        'department' => $user['department'],
        'isLoggedIn' => true
    ]);

    // 6️⃣ Redirect
    return redirect()->to('/employees');
}



    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
