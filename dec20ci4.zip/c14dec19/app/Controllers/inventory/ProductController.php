<?php
namespace App\Controllers\inventory;

use CodeIgniter\Controller;
use App\Models\inventory\ProductModel;
use App\Models\inventory\StockLogModel;

class ProductController extends Controller
{
    protected $productModel;
    protected $stockLogModel;

    public function __construct()
    {
        $this->productModel = new ProductModel();
        $this->stockLogModel = new StockLogModel();
    }

    // Display all products
    public function index()
    {
        $session = session();
        $role = $session->get('role');
        $products = $this->productModel->findAll();

        return view('products/index', [
            'products' => $products,
            'role' => $role
        ]);
    }

    // Create product form
    public function create()
    {
        $session = session();
        $role = $session->get('role');
        if (!in_array($role, ['Admin', 'StockManager'])) {
            return redirect()->to('/products')->with('error','Unauthorized');
        }

        return view('products/create');
    }

    // Store product
    public function store()
    {
        $session = session();
        $role = $session->get('role');
        if (!in_array($role, ['Admin', 'StockManager'])) {
            return redirect()->to('/products')->with('error','Unauthorized');
        }

        $data = $this->request->getPost();

        // Validation
        $validation = \Config\Services::validation();
        $validation->setRules([
            'product_name' => 'required|min_length[2]',
            'sku'          => 'required|is_unique[products.sku]',
            'price'        => 'required|numeric',
            'stock'        => 'required|integer|validateStock'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->with('errors', $validation->getErrors());
        }

        $db = \Config\Database::connect();
        $db->transStart();

        $productId = $this->productModel->insert($data,true);

        if (!$productId) {
            $db->transRollback();
            return redirect()->back()->with('error','Failed to add product');
        }

        $this->stockLogModel->insert([
            'product_id'    => $productId,
            'changed_stock' => $data['stock'],
            'changed_by'    => session()->get('user_id')
        ]);

        $db->transComplete();

        if ($db->transStatus() === false) {
            return redirect()->back()->with('error','Failed to add product');
        }

        return redirect()->to('/products')->with('success','Product added successfully');
    }

    // Edit product form
    public function edit($id)
    {
        $session = session();
        $role = $session->get('role');
        if (!in_array($role, ['Admin', 'StockManager'])) {
            return redirect()->to('/products')->with('error','Unauthorized');
        }

        $product = $this->productModel->find($id);
        if (!$product) return redirect()->to('/products')->with('error','Product not found');

        return view('products/edit', ['product' => $product]);
    }

    // Update product
    public function update($id)
    {
        $session = session();
        $role = $session->get('role');
        if (!in_array($role, ['Admin', 'StockManager'])) {
            return redirect()->to('/products')->with('error','Unauthorized');
        }

        $data = $this->request->getPost();

        // Validation
        $validation = \Config\Services::validation();
        $validation->setRules([
            'product_name' => 'required|min_length[2]',
            'sku'          => "required|is_unique[products.sku,id,{$id}]",
            'price'        => 'required|numeric',
            'stock'        => 'required|integer|validateStock'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->with('errors', $validation->getErrors());
        }

        $db = \Config\Database::connect();
        $db->transStart();

        $updateResult = $this->productModel->update($id, $data);

        if ($updateResult === false) {
            $db->transRollback();
            return redirect()->back()->with('error','Failed to update product');
        }

        // Log stock change
        $this->stockLogModel->insert([
            'product_id'    => $id,
            'changed_stock' => $data['stock'],
            'changed_by'    => session()->get('user_id')
        ]);

        $db->transComplete();

        if ($db->transStatus() === false) {
            return redirect()->back()->with('error','Failed to update product');
        }

        return redirect()->to('/products')->with('success','Product updated successfully');
    }

    // Delete product
    public function delete($id)
    {
        $session = session();
        if ($session->get('role') != 'Admin') {
            return redirect()->to('/products')->with('error','Unauthorized');
        }

        $this->productModel->delete($id);
        return redirect()->to('/products')->with('success','Product deleted successfully');
    }

    // Stock history
    public function history($id)
    {
        $logs = $this->stockLogModel->where('product_id', $id)->findAll();
        return view('products/stock_history', ['logs' => $logs]);
    }

    // Add to cart (Viewer only)
    public function addToCart($id)
    {
        $session = session();
        $cart = $session->get('cart') ?? [];
        if (!in_array($id, $cart)) {
            $cart[] = $id;
        }
        $session->set('cart', $cart);
        return redirect()->back()->with('success', 'Added to cart');
    }
}
