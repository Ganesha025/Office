<?php helper('form'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Stock History</title>
</head>
<body>
<h1>Stock History</h1>

<?php if(session()->getFlashdata('success')): ?>
    <div style="color:green"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
    <div style="color:red"><?= session()->getFlashdata('error') ?></div>
<?php endif; ?>

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Product ID</th>
        <th>Changed Stock</th>
        <th>Changed By (User ID)</th>
        <th>Timestamp</th>
    </tr>
    <?php foreach($logs as $log): ?>
    <tr>
        <td><?= $log['id'] ?></td>
        <td><?= $log['product_id'] ?></td>
        <td><?= $log['changed_stock'] ?></td>
        <td><?= $log['changed_by'] ?></td>
        <td><?= $log['created_at'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<a href="/products">Back to Product List</a>
</body>
</html>
