<?php helper('form'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
</head>
<body>
<h1>Products</h1>

<?php if(session()->getFlashdata('success')): ?>
    <div style="color:green"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>
<?php if(session()->getFlashdata('error')): ?>
    <div style="color:red"><?= session()->getFlashdata('error') ?></div>
<?php endif; ?>

<?php if($role != 'Viewer'): ?>
    <a href="/products/create">Add Product</a><br><br>
<?php endif; ?>

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>SKU</th>
        <th>Price</th>
        <th>Stock</th>
        <th>Actions</th>
    </tr>
    <?php foreach($products as $prod): ?>
    <tr>
        <td><?= $prod['id'] ?></td>
        <td><?= $prod['product_name'] ?></td>
        <td><?= $prod['sku'] ?></td>
        <td><?= $prod['price'] ?></td>
        <td><?= $prod['stock'] ?></td>
        <td>
            <?php if($role != 'Viewer'): ?>
                <a href="/products/edit/<?= $prod['id'] ?>">Edit</a> |
                <a href="/products/history/<?= $prod['id'] ?>">History</a>
            <?php endif; ?>
            <?php if($role == 'Admin'): ?>
                | <a href="/products/delete/<?= $prod['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php if($role == 'Viewer'): ?>
    <h3>Add to Cart</h3>
    <?php foreach($products as $prod): ?>
        <form action="/products/addtocart/<?= $prod['id'] ?>" method="post">
            <?= $prod['product_name'] ?> - <button type="submit">Add to Cart</button>
        </form>
    <?php endforeach; ?>
<?php endif; ?>

<br><a href="/logout">Logout</a>
</body>
</html>
