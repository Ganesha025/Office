<?php helper('form'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Product</title>
</head>
<body>
<h1>Create Product</h1>

<?php if(session()->getFlashdata('success')): ?>
    <div style="color:green"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
    <div style="color:red"><?= session()->getFlashdata('error') ?></div>
<?php endif; ?>

<?php if(isset($errors)): ?>
    <div style="color:red">
        <ul>
        <?php foreach($errors as $error): ?>
            <li><?= $error ?></li>
        <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form action="/products/store" method="post">
    <?= csrf_field() ?>
    <label>Product Name:</label><br>
    <input type="text" name="product_name" value="<?= set_value('product_name') ?>" required><br><br>

    <label>SKU:</label><br>
    <input type="text" name="sku" value="<?= set_value('sku') ?>" required><br><br>

    <label>Price:</label><br>
    <input type="number" step="0.01" name="price" value="<?= set_value('price') ?>" required><br><br>

    <label>Stock:</label><br>
    <input type="number" name="stock" value="<?= set_value('stock') ?>" required><br><br>

    <button type="submit">Create</button>
</form>

<a href="/products">Back to Product List</a>
</body>
</html>
