<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "credits_db";

$conn = mysqli_connect($host, $user, $pass);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS $db");
mysqli_select_db($conn, $db);

mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS course_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    roll_no VARCHAR(20) NOT NULL,
    course_code VARCHAR(20) NOT NULL,
    credits INT NOT NULL,
    status VARCHAR(10) NOT NULL, 
    created_on DATETIME DEFAULT CURRENT_TIMESTAMP
)
");
mysqli_query($conn,"
INSERT INTO course_records (roll_no, course_code, credits, status) VALUES
('CSE1234','CSE101',8,'PASS'),
('CSE1234','CSE102',7,'PASS'),
('CSE1234','CSE103',6,'PASS'),
('ECE5678','ECE101',4,'PASS'),
('ECE5678','ECE102',3,'FAIL'),
('ECE5678','ECE103',5,'PASS'),
('CIV0001','CIV101',5,'PASS'),
('CIV0001','CIV102',6,'PASS'),
('CIV0001','CIV103',4,'FAIL'),
('MECH4321','ME101',7,'PASS'),
('MECH4321','ME102',6,'PASS'),
('MECH4321','ME103',5,'PASS'),
('BIO1111','BIO101',4,'PASS'),
('BIO1111','BIO102',3,'PASS'),
('BIO1111','BIO103',5,'FAIL'),
('EEE2222','EEE101',6,'PASS'),
('EEE2222','EEE102',5,'PASS'),
('EEE2222','EEE103',4,'PASS')
");
?>