<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "hallticket_db";

$conn = mysqli_connect($host, $user, $pass);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS $db");
mysqli_select_db($conn, $db);

mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS students (
  reg_no VARCHAR(20) PRIMARY KEY,
  name VARCHAR(25) NOT NULL,
  dept VARCHAR(25),
  exam_date DATE,
  center VARCHAR(100),
  seat_no VARCHAR(20),
  subjects TEXT -- store as comma-separated for simplicity
)
");

mysqli_query($conn,"
   CREATE TABLE IF NOT EXISTS downloaded_tickets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  roll_no VARCHAR(20),
  hall_ticket_id VARCHAR(25),
  generated_on DATETIME DEFAULT CURRENT_TIMESTAMP
)
  ");
   
  mysqli_query($conn, "INSERT IGNORE INTO students (reg_no,name,dept,exam_date,center,seat_no,subjects) VALUES
('CSE1234','Abhishek','CSE','2025-12-15','Main Campus','A23','Maths,Physics'),
('ECE5678','Meera','ECE','2025-12-16','North Campus','B12','Electronics,Signals'),
('CIV0001','Ramesh','CIV','2025-12-18','South Campus','C05','Strength,Geo'),
('EEE4321','Ananya','EEE','2025-12-17','Main Campus','D10','Circuits,Signals'),
('MECH8765','Vikram','MECH','2025-12-19','West Campus','E15','Thermodynamics,Mechanics'),
('CSE9876','Priya','CSE','2025-12-20','North Campus','F05','DBMS,OS'),
('ECE3456','Arjun','ECE','2025-12-21','South Campus','G22','Digital Electronics,Signals'),
('CIV1122','Sakshi','CIV','2025-12-22','Main Campus','H11','Geotechnics,Structures'),
('MECH2233','Rohit','MECH','2025-12-23','West Campus','I30','Fluid Mechanics,Design')
");

?>
