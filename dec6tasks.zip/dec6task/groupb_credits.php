<?php
include("db1.php"); // Your database connection

// Initialize result and error messages
$credit_result = "";
$roll_error = $course_error = $credits_error = $status_error = "";
$qp_result = "";
$subject_error = "";

// Task 2: Credit System Validation
if(isset($_POST['credits_submit'])){
    $roll_no = trim($_POST['roll_no']);
    $course_codes = array_map('trim', explode(',', $_POST['course_codes']));
    $credits_arr = array_map('trim', explode(',', $_POST['credits']));
    $status_arr = array_map('trim', explode(',', $_POST['status']));

    $valid = true;

    // Roll number validation
    if(empty($roll_no)){
        $roll_error = "❌ Roll number is required.";
        $valid = false;
    } elseif(!preg_match("/^[a-zA-Z0-9]{8}$/", $roll_no)){
        $roll_error = "❌ Roll number must be 8 characters, letters & numbers only.";
        $valid = false;
    }

    // Course code validation
    if(empty($_POST['course_codes'])){
        $course_error = "❌ Course codes are required.";
        $valid = false;
    } elseif(count($course_codes) != 3){
        $course_error = "❌ Exactly 3 course codes required.";
        $valid = false;
    } else {
        foreach($course_codes as $c){
            if(!preg_match("/^[a-zA-Z]{3}[0-9]{3}$/", $c)){
                $course_error = "❌ Course codes must be like cse101.";
                $valid = false;
                break;
            }
        }
    }

    // Credits validation
    if(empty($_POST['credits'])){
        $credits_error = "❌ Credits are required.";
        $valid = false;
    } elseif(count($credits_arr) != 3){
        $credits_error = "❌ Exactly 3 credits required.";
        $valid = false;
    } else {
        foreach($credits_arr as $cr){
            if(!preg_match("/^[1-9]$|10$/", $cr)){
                $credits_error = "❌ Credits must be numbers 1-10 only.";
                $valid = false;
                break;
            }
        }
    }

    // Status validation
    if(empty($_POST['status'])){
        $status_error = "❌ Status is required.";
        $valid = false;
    } elseif(count($status_arr) != 3){
        $status_error = "❌ Exactly 3 status values required.";
        $valid = false;
    } else {
        foreach($status_arr as $st){
            if(!preg_match("/^[a-zA-Z]{1,20}$/", $st)){
                $status_error = "❌ Status must be letters only, max 20 characters.";
                $valid = false;
                break;
            }
        }
    }

    if($valid){
        // Calculate total credits
        $total_earned = 0;
        $stmt = mysqli_prepare($conn, "INSERT INTO course_records (roll_no, course_code, credits, status) VALUES (?, ?, ?, ?)");
        for($i=0; $i<3; $i++){
            $credit = intval($credits_arr[$i]);
            $status = strtoupper($status_arr[$i]);
            if($status == "PASS"){
                $total_earned += $credit;
            }
            mysqli_stmt_bind_param($stmt, "ssis", $roll_no, $course_codes[$i], $credit, $status);
            mysqli_stmt_execute($stmt);
        }

        $credit_result = ($total_earned < 20) ? 
            "<p style='color:red;'>❌ Not eligible to proceed. Total Earned Credits: $total_earned</p>" :
            "<p style='color:green;'>✅ Eligible to proceed. Total Earned Credits: $total_earned</p>";
    }
}

// Task 4: Question Paper Code Formatter
if(isset($_POST['qp_submit'])){
    $subjects_input = trim($_POST['subject_codes'] ?? '');
    $subjects = array_map('trim', explode(',', $subjects_input));
    if(empty($subjects_input)){
        $subject_error = "❌ Subject codes are required.";
    } elseif(count($subjects) != 3){
        $subject_error = "❌ Exactly 3 subject codes required.";
    } else {
        $valid = true;
        foreach($subjects as $s){
            if(!preg_match("/^[a-zA-Z]{3}[0-9]{3}$/", $s)){
                $subject_error = "❌ Subject codes must be like SUB101.";
                $valid = false;
                break;
            }
        }
        if($valid){
            $formatted_codes = [];
            foreach($subjects as $sub){
                $formatted_codes[] = "QP-" . strtoupper($sub);
            }
            $qp_result .= "<p><strong>Formatted Paper Codes:</strong> " . implode(', ', $formatted_codes) . "</p>";
            $qp_result .= "<p><strong>Total Subjects:</strong> " . count($subjects) . "</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Credits & Question Paper Formatter</title>
    <style>
    body { 
        font-family: Arial; 
        margin: 0;
        padding: 0;
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        background: #f3f8fc;
    }
    input, button { 
        padding: 10px; 
        margin: 8px 0; 
        width: 100%; 
        box-sizing: border-box;
        border-radius: 5px;
        border: 1px solid #ccc;
        font-size: 14px;
    }
    button {
        cursor: pointer;
        background-color: #006699;
        color: #fff;
        font-weight: bold;
        border: none;
    }
    .box { 
        border: 1px solid #ddd; 
        padding: 20px; 
        margin-bottom: 20px; 
        width: 450px; 
        background: #fff;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
    }
    .error { 
        color: red; 
        font-size: 14px; 
        height: 18px;
    }
    .required { 
        color: red; 
    }
    h1 { 
        color: #004d66; 
        margin-bottom: 20px; 
    }
    h2 { 
        color: #006699; 
        margin-bottom: 10px;
    }
</style>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // Focus on the first field
    const firstField = document.querySelector("input[name='roll_no']");
    firstField.focus();

    // Credit Form fields
    const creditFields = ['roll_no', 'course_codes', 'credits', 'status'];
    creditFields.forEach(function(name){
        const input = document.querySelector(`input[name='${name}']`);
        const errorDiv = input.nextElementSibling;
        input.addEventListener('input', function(){
            // Validate dynamically to hide error message
            if(input.value.trim() !== ''){
                errorDiv.textContent = '';
            }
        });
    });

    // Question Paper field
    const qpInput = document.querySelector("input[name='subject_codes']");
    const qpError = qpInput.nextElementSibling;
    qpInput.addEventListener('input', function(){
        if(qpInput.value.trim() !== ''){
            qpError.textContent = '';
        }
    });
});
</script>

</head>
<body>

<h1>Credits & Question Paper Formatter Portal</h1>

<div class="box">
    <h2> Credit System Validation</h2>
    <form method="post" action="" novalidate>
        <label>Roll Number <span class="required">*</span></label>
        <input type="text" name="roll_no" maxlength="8" placeholder="21ece603">
        <div class="error"><?php echo $roll_error; ?></div>

        <label>Course Codes (3 codes) <span class="required">*</span></label>
        <input type="text" name="course_codes" maxlength="20" placeholder="cse101,cse102,cse103">
        <div class="error"><?php echo $course_error; ?></div>

        <label>Credits (1-10) <span class="required">*</span></label>
        <input type="text" name="credits" maxlength="5" placeholder="4,3,2">
        <div class="error"><?php echo $credits_error; ?></div>

        <label>Status (PASS/FAIL) <span class="required">*</span></label>
        <input type="text" name="status" maxlength="20" placeholder="PASS,PASS,FAIL">
        <div class="error"><?php echo $status_error; ?></div>

        <button type="submit" name="credits_submit">Validate Credits</button>
    </form>
    <?php echo $credit_result; ?>
</div>

<div class="box">
    <h2> Question Paper Code Formatter</h2>
    <form method="post" action="">
        <label>Subject Codes (3 codes) <span class="required">*</span></label>
        <input type="text" name="subject_codes" maxlength="20" placeholder="SUB101,SUB102,SUB103">
        <div class="error"><?php echo $subject_error; ?></div>

        <button type="submit" name="qp_submit">Format Paper Codes</button>
    </form>
    <?php echo $qp_result; ?>
</div>

</body>
</html>
