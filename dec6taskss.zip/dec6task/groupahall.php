<?php include("db.php"); ?>
<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Hall Ticket Portal</title>
    <style>
        body {
            font-family: Arial;
            background: #d7e9f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background: white;
            padding: 25px;
            border-radius: 10px;
            width: 360px;
            box-shadow: 0px 0px 10px #0003;
            text-align: center;
        }

        input, button {
            padding: 10px;
            width: 94%;
            margin: 6px 0;
            font-size: 16px;
            border-radius: 6px;
            border: 1px solid #888;
            outline: none;
        }

        /* Remove number spinner arrows */
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
        }

        input[type=number] {
            -moz-appearance: textfield;
        }

        label span {
            color: red;
            font-weight: bold;
        }

        button {
            background: #0077cc;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 17px;
        }

        .ticket-box {
            margin-top: 20px;
            padding: 15px;
            background: #eef;
            border: 2px solid #0077cc;
            border-radius: 8px;
            text-align: left;
        }

        .error-message {
            color: red;
            font-size: 13px;
            margin-bottom: 5px;
            text-align: left;
        }

        .success-message {
            color: green;
            font-weight: bold;
        }

    </style>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {

    $("#reg_no").focus();

    /** -------------------------------
     *  Block alphabets & special characters
     *  Allow only numbers 0–9
     --------------------------------*/
    $("#attendance, #marks").on("keypress", function (e) {
        let char = e.which;

        // Allow only digits (0–9)
        if (char < 48 || char > 57) {
            e.preventDefault();
        }
    });

    /** -------------------------------
     *  Prevent pasting non-numeric values
     --------------------------------*/
    $("#attendance, #marks").on("paste", function (e) {
        let pasteData = e.originalEvent.clipboardData.getData('text');
        if (!/^[0-9]+$/.test(pasteData)) {
            e.preventDefault();
        }
    });

    /** -------------------------------
     *  Restrict values between 1–100
     --------------------------------*/
    $("#attendance, #marks").on("input", function () {
        let val = parseInt($(this).val());

        if (val > 100) $(this).val(100);
        if (val < 1) $(this).val('');
        if (isNaN(val)) $(this).val('');
    });

    /** -------------------------------
     *  Clear errors on typing
     --------------------------------*/
    function clearError(input) {
        $(input).next(".error-message").remove();
    }

    function showError(input, message) {
        clearError(input);
        $(input).after("<div class='error-message'>" + message + "</div>");
    }

    $("input").on("input", function () {
        clearError(this);
    });

    /** -------------------------------
     *  Semester: only 1–8 allowed
     --------------------------------*/
    $("#semester").on("input", function () {
        let v = $(this).val();
        if (v < 1 || v > 8 || isNaN(v)) {
            $(this).val('');
        }
    });

    /** -------------------------------
     *  Form Validation
     --------------------------------*/
    $("form").on("submit", function(e){
        let valid = true;

        if($("#reg_no").val() === ""){
            showError("#reg_no", "Register number required");
            valid = false;
        }

        if($("#attendance").val() === ""){
            showError("#attendance", "Attendance required");
            valid = false;
        }

        if($("#marks").val() === ""){
            showError("#marks", "Internal marks required");
            valid = false;
        }

        if($("#semester").val() === ""){
            showError("#semester", "Semester required (1 - 8)");
            valid = false;
        }

        if(!valid){
            e.preventDefault();
        }
    });

});
</script>

</head>

<body>

<div class="form-container">
    <h2>Hall Ticket Request</h2>

    <form method="POST" novalidate>
        <label>Register Number<span>*</span></label>
        <input type="text" name="reg_no" id="reg_no" maxlength="10" placeholder="e.g. CSE123456" required><br>

        <label>Attendance %<span>*</span></label>
        <input type="number" name="attendance" id="attendance" placeholder="1 - 100" required><br>

        <label>Internal Marks<span>*</span></label>
        <input type="number" name="marks" id="marks" placeholder="1 - 100" required><br>

        <label>Semester<span>*</span></label>
        <input type="number" name="semester" id="semester" min="1" max="8" placeholder="1 - 8" required><br>

        <button type="submit" name="submit">Generate Hall Ticket</button>
    </form>

<?php

// BACKEND PROCESS
if(isset($_POST['submit'])){

    $reg_no = trim($_POST['reg_no']);
    $attendance = intval($_POST['attendance']);
    $marks = intval($_POST['marks']);
    $semester = intval($_POST['semester']);

    // Eligibility check
    if($attendance < 75 || $marks < 40){
        echo "<p class='error-message'>❌ Not Eligible (Low Attendance or Marks)</p>";
        return;
    }

    // Check student
    $q = mysqli_query($conn, "SELECT * FROM students WHERE reg_no='$reg_no'");
    if(!$q || mysqli_num_rows($q) == 0){
        echo "<p class='error-message'>❌ Register Number Not Found!</p>";
        return;
    }

    $data = mysqli_fetch_assoc($q);
    $hall_id = "HT-" . $semester . "-" . $reg_no;

    // Check existing hall ticket
    $checkTicket = mysqli_query($conn, "SELECT * FROM downloaded_tickets WHERE hall_ticket_id='$hall_id'");
    if(mysqli_num_rows($checkTicket) > 0){
        echo "<p class='error-message'>⚠️ Hall Ticket Already Generated!</p>";
        return;
    } else {
        mysqli_query($conn, "INSERT INTO downloaded_tickets (roll_no, hall_ticket_id) VALUES ('$reg_no','$hall_id')");
        echo "<p class='success-message'>✅ Hall Ticket Generated Successfully!</p>";
    }

    // Display ticket
    $subjects = explode(",", $data['subjects']);
    echo "<div class='ticket-box'>
            <h3>Hall Ticket Details</h3>
            <strong>Hall Ticket ID:</strong> $hall_id <br>
            <strong>Name:</strong> {$data['name']} <br>
            <strong>Roll No:</strong> {$data['reg_no']} <br>
            <strong>Department:</strong> {$data['dept']} <br>
            <strong>Exam Date:</strong> {$data['exam_date']} <br>
            <strong>Center:</strong> {$data['center']} <br>
            <strong>Seat No:</strong> {$data['seat_no']} <br><br>
            <strong>Subjects:</strong><br>";

    foreach($subjects as $s){
        echo "- $s <br>";
    }

    echo "</div>";
}

?>
</div>

</body>
</html>
