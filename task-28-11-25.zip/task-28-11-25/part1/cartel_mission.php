<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mission Control Dashboard</title>

    <!-- Tailwind CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        body {
            background: linear-gradient(135deg, #f7fafc, #e6fffa);
        }
    </style>

    <script>
        function toggleBox(id) {
            const element = document.getElementById(id);
            element.classList.toggle("hidden");
        }
    </script>
</head>
<body class="min-h-screen flex flex-col items-center py-10 px-4">

<?php
/* --------------------------------
    DATA FOR THE SCENARIO
---------------------------------*/
$safeHouses = ["Juarez", "El Paso", "Nogales"];
$interrogationQuestions = [
    "Where is the cartel leader?",
    "What is the mission objective?",
    "Who is supplying weapons?"
];

$missionSupplies = ["weapons", "communication gear", "medical supplies"];
$isPacked = [true, false, true]; // Example flags

$cartelMessage = "lbh zhphv"; // Encrypted message
$shift = 3;

/* --------------------------------
   CAESAR DECRYPT FUNCTION
---------------------------------*/
function decryptCaesar($text, $shift) {
    $result = "";
    $alphabet = range('a', 'z');

    for ($i = 0; $i < strlen($text); $i++) {
        $char = $text[$i];

        if ($char === " ") {
            $result .= " ";
            continue;
        }

        $pos = array_search($char, $alphabet);
        $newPos = ($pos - $shift + 26) % 26;

        $result .= $alphabet[$newPos];
    }
    return $result;
}

$decryptedMessage = decryptCaesar($cartelMessage, $shift);
?>

<!-- MAIN TITLE -->
<h1 class="text-4xl font-bold text-slate-800 mb-10 drop-shadow-lg">
    Mission Control Dashboard
</h1>

<!-- GRID LAYOUT -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-5xl">

    <!-- SAFE HOUSES BOX -->
    <div class="bg-white p-6 rounded-xl shadow-md border border-teal-200 text-center">
        <button onclick="toggleBox('safeHousesBox')" 
                class="bg-teal-500 text-white px-6 py-2 rounded-lg shadow hover:bg-teal-600 transition">
            Safe Houses
        </button>

        <div id="safeHousesBox" class="hidden mt-4 text-left">
            <ul class="space-y-2">
                <?php for ($i = 0; $i < count($safeHouses); $i++): ?>
                    <li class="bg-teal-50 p-3 rounded-lg shadow-sm"><?= $safeHouses[$i]; ?></li>
                <?php endfor; ?>
            </ul>
        </div>
    </div>

    <!-- INTERROGATION QUESTIONS BOX -->
    <div class="bg-white p-6 rounded-xl shadow-md border border-rose-200 text-center">
        <button onclick="toggleBox('questionsBox')"
                class="bg-rose-500 text-white px-6 py-2 rounded-lg shadow hover:bg-rose-600 transition">
            Interrogation Questions
        </button>

        <div id="questionsBox" class="hidden mt-4 text-left">
            <ul class="space-y-2">
                <?php foreach ($interrogationQuestions as $q): ?>
                    <li class="bg-rose-50 p-3 rounded-lg shadow-sm"><?= $q; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <!-- MISSION SUPPLIES BOX -->
    <div class="bg-white p-6 rounded-xl shadow-md border border-indigo-200 text-center">
        <button onclick="toggleBox('suppliesBox')"
                class="bg-indigo-500 text-white px-6 py-2 rounded-lg shadow hover:bg-indigo-600 transition">
            Mission Supplies
        </button>

        <div id="suppliesBox" class="hidden mt-4 text-left">
            <ul class="space-y-2">
                <?php 
                    $i = 0;
                    while ($i < count($missionSupplies)): 
                ?>
                <li class="bg-indigo-50 p-3 rounded-lg shadow-sm flex justify-between">
                    <span><?= $missionSupplies[$i]; ?></span>
                    <span class="<?= $isPacked[$i] ? 'text-green-600' : 'text-red-600' ?>">
                        <?= $isPacked[$i] ? 'Packed ✔' : 'Not Packed ✖'; ?>
                    </span>
                </li>
                <?php $i++; endwhile; ?>
            </ul>
        </div>
    </div>

    <!-- DECRYPTED MESSAGE BOX -->
    <div class="bg-white p-6 rounded-xl shadow-md border border-yellow-200 text-center">
        <button onclick="toggleBox('decryptBox')"
                class="bg-yellow-500 text-white px-6 py-2 rounded-lg shadow hover:bg-yellow-600 transition">
            Decrypted Message
        </button>

        <div id="decryptBox" class="hidden mt-4 text-left">
            <p class="bg-yellow-50 p-4 rounded-lg shadow-inner text-lg">
                <strong>Encrypted:</strong> <?= $cartelMessage; ?><br>
                <strong>Shift:</strong> <?= $shift; ?><br>
                <strong>Decrypted:</strong> 
                <span class="text-green-700"><?= $decryptedMessage; ?></span>
            </p>
        </div>
    </div>

</div>

</body>
</html>
