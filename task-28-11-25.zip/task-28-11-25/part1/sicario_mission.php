<?php
session_start();

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['mission'] = [
        'name' => htmlspecialchars($_POST['name']),
        'age' => intval($_POST['age']),
        'codeName' => htmlspecialchars($_POST['codeName']),
        'location' => htmlspecialchars($_POST['location']),
        'target' => htmlspecialchars($_POST['target']),
        'currentDay' => intval($_POST['currentDay']),
        'daysUntilMission' => intval($_POST['daysUntilMission']),
    ];
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Prepare mission summary if session exists
$missionSummary = '';
if(isset($_SESSION['mission'])){
    $m = $_SESSION['mission'];
    $missionDay = $m['currentDay'] + $m['daysUntilMission'];
    $missionSummary = "
    <div class='mission-summary'>
        <p>Greetings <span class='highlight'>{$m['name']}</span>, age <span class='highlight'>{$m['age']}</span>!</p>
        <h2>Mission Brief</h2>
        <p>Code Name: <span class='highlight'>{$m['codeName']}</span></p>
        <p>Location: <span class='highlight'>{$m['location']}</span></p>
        <p>Target: <span class='highlight'>{$m['target']}</span></p>
        <p>Mission starts in <span class='highlight'>{$m['daysUntilMission']}</span> days, on day <span class='highlight'>$missionDay</span>.</p>
    </div>";
    unset($_SESSION['mission']); // Remove it so refresh won't show again
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sicario Mission Dashboard</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0f0f1f, #1a1a2e);
            color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            background: rgba(0,0,0,0.85);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 0 30px rgba(0,255,255,0.2);
            max-width: 600px;
            width: 100%;
            text-align: center;
        }
        h1 { font-size: 2.5em; margin-bottom: 20px; color: #ff4c00; }
        h2 { margin-top: 20px; color: #00ffcc; }
        p { font-size: 1.1em; margin: 10px 0; }
        .highlight { color: #ffcc00; font-weight: bold; }
        .mission-summary {
            background: rgba(255,255,255,0.05);
            padding: 20px;
            border-radius: 15px;
            margin-top: 20px;
        }
        form { margin-top: 20px; display: flex; flex-direction: column; gap: 15px; }
        label { display: flex; flex-direction: column; text-align: left; font-size: 0.95em; }
        .required-star {
            color: red;
            display: inline-block;
            margin-left: 5px;
        vertical-align: super;
        }
        input[type="text"], input[type="number"], select {
            padding: 10px 15px;
            border-radius: 10px;
            border: none;
            font-size: 1em;
            outline: none;
            width: 100%;
        }
        input[type="submit"] {
            padding: 12px;
            border-radius: 10px;
            border: none;
            font-size: 1.1em;
            background: linear-gradient(45deg, #ff4c00, #ff9000);
            color: #fff;
            cursor: pointer;
            transition: transform 0.2s;
        }
        input[type="submit"]:hover { transform: scale(1.05); }
        /* Remove arrows from number inputs */
        input[type=number]::-webkit-outer-spin-button,
        input[type=number]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        input[type=number] { -moz-appearance:textfield; }
        .error { color: #ff4c00; font-size: 0.85em; margin-top: 5px; display: none; }
        @media (max-width: 600px) { .container { padding: 30px 20px; } h1 { font-size: 2em; } }
    </style>
</head>
<body>
<div class="container">
    <h1>Sicario Mission Dashboard</h1>

    <form id="missionForm" method="POST" novalidate>
        <label>Character Name <span class="required-star">*</span>
            <input type="text" name="name" id="name">
            <span class="error" id="nameError">Only letters and spaces, max 15 characters.</span>
        </label>

        <label>Age <span class="required-star">*</span>
            <input type="number" name="age" id="age" min="1" max="99">
            <span class="error" id="ageError">Please enter a number (1-99).</span>
        </label>

        <label>Mission Code Name <span class="required-star">*</span>
            <select name="codeName" id="codeName">
                <option value="" selected>Select Code Name</option>
                <option value="Sol">Sol</option>
                <option value="Luna">Luna</option>
                <option value="Shadow">Shadow</option>
                <option value="Fenix">Fenix</option>
                <option value="Viper">Viper</option>
            </select>
            <span class="error" id="codeError">Please select a code name.</span>
        </label>

        <label>Mission Location <span class="required-star">*</span>
            <select name="location" id="location">
                <option value="" selected>Select Location</option>
                <option value="Juarez">Juarez</option>
                <option value="Monterrey">Monterrey</option>
                <option value="Tijuana">Tijuana</option>
                <option value="Ciudad de Mexico">Ciudad de Mexico</option>
                <option value="Cancun">Cancun</option>
            </select>
            <span class="error" id="locationError">Please select a location.</span>
        </label>

        <label>Mission Target <span class="required-star">*</span>
            <select name="target" id="target">
                <option value="" selected>Select Target</option>
                <option value="Capo">Capo</option>
                <option value="Lieutenant">Lieutenant</option>
                <option value="Kingpin">Kingpin</option>
                <option value="Smuggler">Smuggler</option>
                <option value="Informant">Informant</option>
            </select>
            <span class="error" id="targetError">Please select a target.</span>
        </label>

        <label>Current Day <span class="required-star">*</span>
            <input type="number" name="currentDay" id="currentDay" min="1" max="99">
            <span class="error" id="currentDayError">Please enter a number (1-99).</span>
        </label>

        <label>Days Until Mission <span class="required-star">*</span>
            <input type="number" name="daysUntilMission" id="daysUntilMission" min="1" max="99">
            <span class="error" id="daysError">Please enter a number (1-99).</span>
        </label>

        <input type="submit" value="Launch Mission">
    </form>

    <?= $missionSummary ?>
</div>

<script>
$(document).ready(function(){
    // Reset the form on page load
    $('#missionForm')[0].reset();

    // Form submission validation
    $('#missionForm').submit(function(e){
        let valid = true;

        // Character Name
        let name = $('#name').val().trim();
        if(name === "" || !/^[A-Za-z\s]{1,15}$/.test(name)){
            $('#nameError').show(); valid = false;
        } else { $('#nameError').hide(); }

        // Age
        let age = $('#age').val();
        if(age === "" || isNaN(age) || age < 1 || age > 99){
            $('#ageError').show(); valid = false;
        } else { $('#ageError').hide(); }

        // Code Name
        if($('#codeName').val() === ""){ $('#codeError').show(); valid = false; } 
        else { $('#codeError').hide(); }

        // Location
        if($('#location').val() === ""){ $('#locationError').show(); valid = false; } 
        else { $('#locationError').hide(); }

        // Target
        if($('#target').val() === ""){ $('#targetError').show(); valid = false; } 
        else { $('#targetError').hide(); }

        // Current Day
        let currentDay = $('#currentDay').val();
        if(currentDay === "" || isNaN(currentDay) || currentDay < 1 || currentDay > 99){
            $('#currentDayError').show(); valid = false;
        } else { $('#currentDayError').hide(); }

        // Days Until Mission
        let daysUntilMission = $('#daysUntilMission').val();
        if(daysUntilMission === "" || isNaN(daysUntilMission) || daysUntilMission < 1 || daysUntilMission > 99){
            $('#daysError').show(); valid = false;
        } else { $('#daysError').hide(); }

        if(!valid) e.preventDefault();
    });

    // Real-time validation for inputs
    $('#name').on('input', function(){
        let val = $(this).val().replace(/[^A-Za-z\s]/g,'').substring(0,15);
        $(this).val(val);
        if(/^[A-Za-z\s]{1,15}$/.test(val)) $('#nameError').hide();
    });

    $('#age, #currentDay, #daysUntilMission').on('input', function(){
        let val = $(this).val().replace(/\D/g,'').substring(0,2);
        $(this).val(val);
        if(val >= 1 && val <= 99){
            if(this.id === 'age') $('#ageError').hide();
            if(this.id === 'currentDay') $('#currentDayError').hide();
            if(this.id === 'daysUntilMission') $('#daysError').hide();
        }
    });

    $('#codeName').on('change', function(){ if($(this).val() !== "") $('#codeError').hide(); });
    $('#location').on('change', function(){ if($(this).val() !== "") $('#locationError').hide(); });
    $('#target').on('change', function(){ if($(this).val() !== "") $('#targetError').hide(); });
});
</script>
</body>
</html>
