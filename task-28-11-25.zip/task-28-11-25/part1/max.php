<!DOCTYPE html>
<html>
<head>
    <title>Find Maximum of Three Numbers</title>

    <!-- Tailwind CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        input::-webkit-inner-spin-button,
        input::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        input[type=number] {
            -moz-appearance: textfield;
        }
    </style>

</head>

<body class="bg-gradient-to-br from-blue-900 to-gray-800 min-h-screen flex items-center justify-center p-5">

<div class="bg-white/10 backdrop-blur-lg shadow-xl rounded-2xl p-8 max-w-md w-full text-white">
    
    <h2 class="text-2xl font-bold text-center mb-6">Find Maximum of Three Numbers</h2>

    <form method="post" id="maxForm" novalidate class="space-y-6">

        <div>
            <label class="block mb-1 font-medium">
                Number 1 <span class="text-red-400">*</span>
            </label>
            <input type="text" id="num1" name="num1" maxlength="3"
                   class="numberField w-full px-4 py-2 rounded-lg bg-white/20 text-white">
            <p class="text-red-400 text-sm mt-1 error-msg hidden"></p>
        </div>

        <div>
            <label class="block mb-1 font-medium">
                Number 2 <span class="text-red-400">*</span>
            </label>
            <input type="text" id="num2" name="num2" maxlength="3"
                   class="numberField w-full px-4 py-2 rounded-lg bg-white/20 text-white">
            <p class="text-red-400 text-sm mt-1 error-msg hidden"></p>
        </div>

        <div>
            <label class="block mb-1 font-medium">
                Number 3 <span class="text-red-400">*</span>
            </label>
            <input type="text" id="num3" name="num3" maxlength="3"
                   class="numberField w-full px-4 py-2 rounded-lg bg-white/20 text-white">
            <p class="text-red-400 text-sm mt-1 error-msg hidden"></p>
        </div>

        <button type="submit" 
            class="w-full py-3 rounded-lg bg-gradient-to-r from-yellow-400 to-pink-500 text-black font-semibold">
            Find Maximum
        </button>

    </form>

    <?php
    session_start();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $n1 = $_POST['num1'];
        $n2 = $_POST['num2'];
        $n3 = $_POST['num3'];

        $_SESSION["result"] = max($n1, $n2, $n3);

        // Redirect to remove POST data and reset page on refresh
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    if (isset($_SESSION["result"])) {
        echo "<h3 class='mt-6 text-xl font-semibold text-center text-yellow-300'>
                Maximum Value: " . $_SESSION["result"] . "
              </h3>";

        // Delete result so refresh doesn't show it
        unset($_SESSION["result"]);
    }
    ?>

</div>

<script>
$(document).ready(function () {

    $('#num1').focus();

    $('.numberField').on('input', function() {
        let val = $(this).val().replace(/\D/g, "");
        if (val.length > 3) val = val.substring(0, 3);
        $(this).val(val);

        if (val.length > 0) {
            $(this).next('.error-msg').addClass('hidden').text("");
        }
    });

    $('#maxForm').submit(function(e) {
        e.preventDefault();

        let isValid = true;

        $('.error-msg').text("").addClass("hidden");

        $('.numberField').each(function() {
            if ($(this).val().trim() === "") {
                $(this).next('.error-msg')
                    .text("This field is required.")
                    .removeClass("hidden");
                isValid = false;
            }
        });

        if (isValid) {
            this.submit();
        }
    });
});
</script>

</body>
</html>
