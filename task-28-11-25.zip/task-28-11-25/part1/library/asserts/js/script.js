$(document).ready(function(){

    // Borrow Form Validation
    $('#borrowForm').submit(function(e){
        e.preventDefault();
        let valid = true;
        $('.error').text('');

        if($('#user').val().trim() === ''){
            $('#userError').text('Name is required');
            valid = false;
        }
        if($('#department').val().trim() === ''){
            $('#deptError').text('Department is required');
            valid = false;
        }

        if(valid) this.submit();
    });

    // Add Book Validation
    $('#addBookForm').submit(function(e){
        e.preventDefault();
        let valid = true;
        $('.error').text('');

        if($('#title').val().trim() === ''){
            $('#titleError').text('Title is required');
            valid = false;
        }
        if($('#author').val().trim() === ''){
            $('#authorError').text('Author is required');
            valid = false;
        }
        if($('#year').val().trim() === ''){
            $('#yearError').text('Year is required');
            valid = false;
        }

        if(valid) this.submit();
    });

});
