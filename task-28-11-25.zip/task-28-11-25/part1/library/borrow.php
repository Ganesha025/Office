<?php
session_start();

// Get book ID from query
$book_id = $_GET['id'] ?? null;
if (!$book_id) {
    header("Location: index.php");
    exit;
}

// Find book
$book = null;
foreach($_SESSION['books'] as $b) {
    if ($b['id'] == $book_id) $book = $b;
}
if (!$book) {
    header("Location: index.php");
    exit;
}

// Handle borrow form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_POST['user'];
    $department = $_POST['department'];
    $borrow_date = $_POST['borrow_date'];
    $return_date = $_POST['return_date'];

    $_SESSION['borrowed_books'][] = [
        'book_id' => $book['id'],
        'title' => $book['title'],
        'user' => $user,
        'department' => $department,
        'borrow_date' => $borrow_date,
        'return_date' => $return_date
    ];

    header("Location: borrowed_books.php");
    exit;
}

// Navigation bar
function navbar() {
    echo '<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
            <div class="container">
              <a class="navbar-brand" href="index.php">Library</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                  <li class="nav-item"><a class="nav-link" href="index.php">Books</a></li>
                  <li class="nav-item"><a class="nav-link" href="add_book.php">Add Book</a></li>
                  <li class="nav-item"><a class="nav-link" href="borrowed_books.php">Borrowed Books</a></li>
                </ul>
              </div>
            </div>
          </nav>';
}

$today = date('Y-m-d');
$return_default = date('Y-m-d', strtotime('+10 days'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Borrow Book</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php navbar(); ?>

<div class="container">
    <h2 class="mb-4">Borrow Book</h2>
    <form id="borrowForm" method="POST" class="w-50">
        <div class="mb-3">
            <label class="form-label">Book Title</label>
            <input type="text" class="form-control" name="title" value="<?= $book['title'] ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Author</label>
            <input type="text" class="form-control" name="author" value="<?= $book['author'] ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Year</label>
            <input type="text" class="form-control" name="year" value="<?= $book['year'] ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Your Name</label>
            <input type="text" class="form-control" name="user" id="user">
            <div class="error text-danger" id="userError"></div>
        </div>
        <div class="mb-3">
            <label class="form-label">Department</label>
            <input type="text" class="form-control" name="department" id="department">
            <div class="error text-danger" id="deptError"></div>
        </div>
        <div class="mb-3">
            <label class="form-label">Borrow Date</label>
            <input type="date" class="form-control" name="borrow_date" value="<?= $today ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Return Date</label>
            <input type="date" class="form-control" name="return_date" value="<?= $return_default ?>" readonly>
        </div>
        <button type="submit" class="btn btn-success w-100">Borrow</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>
