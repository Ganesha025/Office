<?php
session_start();
session_unset();

// Initialize default books with images
if (!isset($_SESSION['books'])) {
    $_SESSION['books'] = [
        ['id' => 1, 'title' => 'Moby-Dick', 'author' => 'Herman Melville', 'year' => 1851, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'],
        ['id' => 2, 'title' => 'The Chronicles of Narnia', 'author' => 'C.S. Lewis', 'year' => 1950, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'],
        ['id' => 3, 'title' => 'The Alchemist', 'author' => 'Paulo Coelho', 'year' => 1988, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'],
        ['id' => 4, 'title' => 'The Lord of the Rings', 'author' => 'J.R.R. Tolkien', 'year' => 1954, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'],
        ['id' => 5, 'title' => 'Fahrenheit 451', 'author' => 'Ray Bradbury', 'year' => 1953, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png'],
        ['id' => 6, 'title' => '1984', 'author' => 'George Orwell', 'year' => 1949, 'image' => 'https://png.pngtree.com/png-vector/20240515/ourmid/pngtree-open-book-logo-png-image_12467719.png']
    ];
}

// Navigation bar HTML
function navbar() {
    echo '<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-5">
            <div class="container">
              <a class="navbar-brand" href="index.php">Library</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                  <li class="nav-item"><a class="nav-link" href="index.php">Books</a></li>
                  <li class="nav-item"><a class="nav-link" href="add_book.php">Add Book</a></li>
                  <li class="nav-item"><a class="nav-link" href="borrowed_books.php">Borrowed Books</a></li>
                </ul>
              </div>
            </div>
          </nav>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Library Books</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background-color: #f8f9fa;
    }
    .card {
        border-radius: 15px;
        transition: transform 0.2s;
    }
    .card:hover {
        transform: scale(1.05);
    }
    .card-img-top {
        height: 220px;
        object-fit: cover;
        border-top-left-radius: 15px;
        border-top-right-radius: 15px;
    }
    .card-title {
        font-size: 1.25rem;
        font-weight: 600;
    }
    .btn-borrow {
        background-color: #0d6efd;
        border: none;
    }
    .btn-borrow:hover {
        background-color: #0b5ed7;
    }
</style>
</head>
<body>
<?php navbar(); ?>

<div class="container">
    <h2 class="mb-4 text-center">Available Books</h2>
    <div class="row g-4">
        <?php foreach($_SESSION['books'] as $book): ?>
            <div class="col-md-4 col-lg-3">
                <div class="card h-100 shadow-sm">
                   <img src="<?= htmlspecialchars($book['image'] ?? 'images/bookr.png') ?>" 
                    onerror="this.src='images/bookr.jpg'" 
                    class="card-img-top" 
                    alt="<?= htmlspecialchars($book['title']) ?>">
                   <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?= htmlspecialchars($book['title']) ?></h5>
                        <p class="card-text mb-1"><strong>Author:</strong> <?= htmlspecialchars($book['author']) ?></p>
                        <p class="card-text mb-3"><strong>Year:</strong> <?= htmlspecialchars($book['year']) ?></p>
                        <a href="borrow.php?id=<?= $book['id'] ?>" class="btn btn-borrow mt-auto w-100">Borrow</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
