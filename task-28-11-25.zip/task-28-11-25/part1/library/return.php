<?php
session_start();

$book_id = $_GET['id'] ?? null;
if (!$book_id) {
    header("Location: borrowed_books.php");
    exit;
}

// Find borrowed book
$borrowed_book = null;
foreach($_SESSION['borrowed_books'] as $key => $b) {
    if ($b['book_id'] == $book_id) {
        $borrowed_book = $b;
        $borrow_key = $key;
        break;
    }
}
if (!$borrowed_book) {
    header("Location: borrowed_books.php");
    exit;
}

$today = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $actual_return = $_POST['actual_return'];
    $expected_return = $borrowed_book['return_date'];

    $penalty = 0;
    if(strtotime($actual_return) > strtotime($expected_return)){
        $days_late = (strtotime($actual_return) - strtotime($expected_return))/86400;
        $penalty = $days_late * 5;
    }

    // Remove from borrowed books
    unset($_SESSION['borrowed_books'][$borrow_key]);
    $_SESSION['borrowed_books'] = array_values($_SESSION['borrowed_books']);

    header("Location: borrowed_books.php");
    exit;
}

// Navbar
function navbar() {
    echo '<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
            <div class="container">
              <a class="navbar-brand" href="index.php">Library</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                  <li class="nav-item"><a class="nav-link" href="index.php">Books</a></li>
                  <li class="nav-item"><a class="nav-link" href="add_book.php">Add Book</a></li>
                  <li class="nav-item"><a class="nav-link" href="borrowed_books.php">Borrowed Books</a></li>
                </ul>
              </div>
            </div>
          </nav>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Return Book</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php navbar(); ?>

<div class="container">
    <h2 class="mb-4">Return Book</h2>
    <form method="POST" class="w-50">
        <div class="mb-3">
            <label class="form-label">Book Title</label>
            <input type="text" class="form-control" value="<?= $borrowed_book['title'] ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">User Name</label>
            <input type="text" class="form-control" value="<?= $borrowed_book['user'] ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Department</label>
            <input type="text" class="form-control" value="<?= $borrowed_book['department'] ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Borrow Date</label>
            <input type="date" class="form-control" value="<?= $borrowed_book['borrow_date'] ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Expected Return Date</label>
            <input type="date" class="form-control" value="<?= $borrowed_book['return_date'] ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Actual Return Date</label>
            <input type="date" class="form-control" name="actual_return" value="<?= $today ?>">
        </div>
        <button type="submit" class="btn btn-success w-100">Return Book</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>
