<?php
session_start();

// Initialize borrowed books if not set
if (!isset($_SESSION['borrowed_books'])) {
    $_SESSION['borrowed_books'] = [
        ['book_id'=>1,'title'=>'Book A','user'=>'John','department'=>'CS','borrow_date'=>'2025-11-20','return_date'=>'2025-11-30'],
        ['book_id'=>2,'title'=>'Book B','user'=>'Jane','department'=>'EE','borrow_date'=>'2025-11-18','return_date'=>'2025-11-28'],
        ['book_id'=>3,'title'=>'Book C','user'=>'Alex','department'=>'ME','borrow_date'=>'2025-11-22','return_date'=>'2025-12-02'],
        ['book_id'=>4,'title'=>'Book D','user'=>'Maria','department'=>'CE','borrow_date'=>'2025-11-21','return_date'=>'2025-12-01']
    ];
}

// Navbar
function navbar() {
    echo '<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
            <div class="container">
              <a class="navbar-brand" href="index.php">Library</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                  <li class="nav-item"><a class="nav-link" href="index.php">Books</a></li>
                  <li class="nav-item"><a class="nav-link" href="add_book.php">Add Book</a></li>
                  <li class="nav-item"><a class="nav-link" href="borrowed_books.php">Borrowed Books</a></li>
                </ul>
              </div>
            </div>
          </nav>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Borrowed Books</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php navbar(); ?>

<div class="container">
    <h2 class="mb-4">Borrowed Books</h2>
    <div class="row">
        <?php if (empty($_SESSION['borrowed_books'])): ?>
            <p>No borrowed books.</p>
        <?php else: ?>
            <?php foreach($_SESSION['borrowed_books'] as $borrow): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($borrow['title']) ?></h5>
                            <p><strong>User:</strong> <?= htmlspecialchars($borrow['user']) ?></p>
                            <p><strong>Dept:</strong> <?= htmlspecialchars($borrow['department']) ?></p>
                            <p><strong>Borrowed:</strong> <?= $borrow['borrow_date'] ?></p>
                            <p><strong>Return by:</strong> <?= $borrow['return_date'] ?></p>
                            <a href="return.php?id=<?= $borrow['book_id'] ?>" class="btn btn-warning w-100">Return</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>
