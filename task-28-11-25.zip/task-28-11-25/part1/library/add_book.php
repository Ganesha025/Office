<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $year = $_POST['year'];

    $new_id = end($_SESSION['books'])['id'] + 1;
    $_SESSION['books'][] = ['id'=>$new_id,'title'=>$title,'author'=>$author,'year'=>$year];
    header("Location: index.php");
    exit;
}

// Navbar
function navbar() {
    echo '<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
            <div class="container">
              <a class="navbar-brand" href="index.php">Library</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                  <li class="nav-item"><a class="nav-link" href="index.php">Books</a></li>
                  <li class="nav-item"><a class="nav-link" href="add_book.php">Add Book</a></li>
                  <li class="nav-item"><a class="nav-link" href="borrowed_books.php">Borrowed Books</a></li>
                </ul>
              </div>
            </div>
          </nav>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Book</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php navbar(); ?>

<div class="container">
    <h2 class="mb-4">Add New Book</h2>
    <form id="addBookForm" method="POST" class="w-50">
        <div class="mb-3">
            <label class="form-label">Book Title</label>
            <input type="text" class="form-control" name="title" id="title">
            <div class="error text-danger" id="titleError"></div>
        </div>
        <div class="mb-3">
            <label class="form-label">Author</label>
            <input type="text" class="form-control" name="author" id="author">
            <div class="error text-danger" id="authorError"></div>
        </div>
        <div class="mb-3">
            <label class="form-label">Year</label>
            <input type="number" class="form-control" name="year" id="year">
            <div class="error text-danger" id="yearError"></div>
        </div>
        <button type="submit" class="btn btn-success w-100">Add Book</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>
