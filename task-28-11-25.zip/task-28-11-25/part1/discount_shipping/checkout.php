<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Checkout Calculator</title>

    <!-- Tailwind CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        body {
            background: linear-gradient(135deg, #f0fdf4, #e0f7fa);
        }

        /* Remove arrows from number fields */
        input::-webkit-inner-spin-button,
        input::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        input[type="number"] {
            -moz-appearance: textfield;
        }
    </style>
</head>

<body class="min-h-screen flex flex-col items-center py-10 px-4">

<h1 class="text-4xl font-bold text-slate-800 mb-8 drop-shadow-lg">
    Smart Checkout Calculator
</h1>

<?php
$finalPrice = $shippingCost = $totalPayable = null;

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $customerName = $_POST["customerName"];
    $price        = $_POST["price"];
    $premium      = $_POST["premium"];
    $destination  = $_POST["destination"];
    $weight       = $_POST["weight"];

    // Discount Logic
    if ($premium === "yes") {
        $discountRate = 0.20;
    } elseif ($price > 200) {
        $discountRate = 0.15;
    } elseif ($price > 100) {
        $discountRate = 0.10;
    } else {
        $discountRate = 0.05;
    }

    $discountAmount = $price * $discountRate;
    $finalPrice = $price - $discountAmount;

    // Shipping Logic
    if ($destination === "domestic" && $weight < 5) {
        $shippingCost = 10;
    } elseif ($destination === "domestic") {
        $shippingCost = 20;
    } elseif ($destination === "international" && $weight < 5) {
        $shippingCost = 30;
    } else {
        $shippingCost = 50;
    }

    $totalPayable = $finalPrice + $shippingCost;
}
?>

<!-- FORM CARD -->
<div class="bg-white shadow-lg rounded-xl p-8 w-full max-w-3xl border border-teal-200">

    <form id="checkoutForm" method="POST" action="bill.php" class="space-y-6" novalidate>

        <!-- Customer Name -->
        <div>
            <label class="block font-semibold mb-1">
                Customer Name <span class="text-red-500">*</span>
            </label>
            <input type="text" id="customerName" name="customerName"
                class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-400">
            <p id="nameError" class="text-red-600 text-sm mt-1 hidden"></p>
        </div>

        <!-- Price -->
        <div>
            <label class="block font-semibold mb-1">
                Product Price (₹) <span class="text-red-500">*</span>
            </label>
            <input type="number" id="price" name="price"
                class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-400">
            <p id="priceError" class="text-red-600 text-sm mt-1 hidden"></p>
        </div>

        <!-- Premium Member -->
        <div>
            <label class="block font-semibold mb-1">
                Premium Member <span class="text-red-500">*</span>
            </label>
            <select id="premium" name="premium"
                class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-400">
                <option value="">Select</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
            </select>
            <p id="premiumError" class="text-red-600 text-sm mt-1 hidden"></p>
        </div>

        <!-- Destination -->
        <div>
            <label class="block font-semibold mb-1">
                Destination <span class="text-red-500">*</span>
            </label>
            <select id="destination" name="destination"
                class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-400">
                <option value="">Select</option>
                <option value="domestic">Domestic</option>
                <option value="international">International</option>
            </select>
            <p id="destinationError" class="text-red-600 text-sm mt-1 hidden"></p>
        </div>

        <!-- Weight -->
        <div>
            <label class="block font-semibold mb-1">
                Package Weight (kg) <span class="text-red-500">*</span>
            </label>
            <input type="number" id="weight" name="weight"
                class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-400">
            <p id="weightError" class="text-red-600 text-sm mt-1 hidden"></p>
        </div>

        <!-- Submit Button -->
        <button type="submit"
            class="w-full bg-teal-500 text-white p-3 rounded-lg text-lg font-semibold hover:bg-teal-600 transition">
            Calculate Total
        </button>
    </form>
</div>

<script>
$(document).ready(function(){

    $("#customerName").focus(); // focus first field

    // // --- Prevent typing numbers & special chars ---
    // $("#customerName").on("input", function () {
    //     this.value = this.value.replace(/[^A-Za-z ]/g, ""); // Remove invalid characters
    // });

    // --- Prevent typing numbers, special chars & limit to 15 chars ---
$("#customerName").on("input", function () {
    // Remove invalid characters
    let cleaned = this.value.replace(/[^A-Za-z ]/g, "");

    // Limit to 15 characters
    if (cleaned.length > 15) {
        cleaned = cleaned.substring(0, 15);
    }

    this.value = cleaned;
});


    function validateName() {
        const name = $("#customerName").val().trim();

        if (name === "") {
            $("#nameError").text("This field is required.").removeClass("hidden");
            return false;
        }

        const regex = /^[A-Za-z ]{1,15}$/;
        if (!regex.test(name)) {
            $("#nameError").text("Only letters & spaces allowed (max 15 chars).").removeClass("hidden");
            return false;
        }

        $("#nameError").addClass("hidden");
        return true;
    }


    function validatePrice() {
        let price = $("#price").val();

        if (price === "") {
            $("#priceError").text("This field is required.").removeClass("hidden");
            return false;
        }

        if (price > 9000000) {
            $("#price").val(9000000);
        }

        if (price < 1) {
            $("#priceError").text("Enter price between ₹1 and ₹9000000.").removeClass("hidden");
            return false;
        }

        $("#priceError").addClass("hidden");
        return true;
    }


    function validatePremium() {
        if ($("#premium").val() === "") {
            $("#premiumError").text("This field is required.").removeClass("hidden");
            return false;
        }
        $("#premiumError").addClass("hidden");
        return true;
    }


    function validateDestination() {
        if ($("#destination").val() === "") {
            $("#destinationError").text("This field is required.").removeClass("hidden");
            return false;
        }
        $("#destinationError").addClass("hidden");
        return true;
    }


    function validateWeight() {
        let weight = $("#weight").val();

        if (weight === "") {
            $("#weightError").text("This field is required.").removeClass("hidden");
            return false;
        }

        if (weight > 50) {
            $("#weight").val(50);
            weight = 50;
        }

        if (weight < 1) {
            $("#weightError").text("Weight must be between 1 and 50 kg.").removeClass("hidden");
            return false;
        }

        $("#weightError").addClass("hidden");
        return true;
    }

    // real-time validation
    $("#customerName").on("keyup input", validateName);
    $("#price").keyup(validatePrice);
    $("#weight").keyup(validateWeight);
    $("#premium").change(validatePremium);
    $("#destination").change(validateDestination);

    // submit validation
    $("#checkoutForm").submit(function(e){

        let valid =
            validateName() &
            validatePrice() &
            validatePremium() &
            validateDestination() &
            validateWeight();

        if (!valid) {
            e.preventDefault();
        }
    });

});
</script>


</body>
</html>
