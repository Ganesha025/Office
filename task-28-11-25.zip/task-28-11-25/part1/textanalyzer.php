<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Save form inputs in session
    $_SESSION['text'] = $_POST['text'];
    $_SESSION['find'] = $_POST['find'];
    $_SESSION['replace'] = $_POST['replace'];

    // Redirect to same page to prevent form resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Retrieve values if available
$text = $_SESSION['text'] ?? '';
$find = $_SESSION['find'] ?? '';
$replace = $_SESSION['replace'] ?? '';

// Clear session on GET (refresh)
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    unset($_SESSION['text'], $_SESSION['find'], $_SESSION['replace']);
}

$isSubmitted = $text !== '' && $find !== '' && $replace !== '';

function wordCountCustom($text) {
    return str_word_count($text);
}

function characterCountNoSpaces($text) {
    return strlen(str_replace(' ', '', $text));
}

function findAndReplaceWord($text, $find, $replace) {
    return str_ireplace($find, $replace, $text);
}

function convertToUppercase($text) {
    return strtoupper($text);
}

function extractSentences($text) {
    return preg_split('/(?<=[.!?])\s+/', trim($text));
}

function wordFrequency($text) {
    $text = strtolower(preg_replace('/[^a-z0-9\s]/i', '', $text));
    $words = str_word_count($text, 1);
    return array_count_values($words);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Advanced PHP Text Analyzer</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: "Inter", sans-serif;
    background: #0f0f17;
    color: white;
    display: flex;
    justify-content: center;
    padding: 20px 10px;
   /* min-height: 100vh; */}

.container {
    width: 100%;
    max-width: 900px;
    background: rgba(25, 25, 40, 0.95);
    padding: 25px 20px;
    border-radius: 16px;
    box-shadow: 0 0 35px rgba(0,255,200,0.15);
    border: 1px solid rgba(0,255,200,0.2);
    animation: fadeIn 0.8s ease-in-out;
    height: auto;
    min-height: 300px;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

h1 {
    text-align: center;
    margin-bottom: 25px;
    color: #00f7c7;
    letter-spacing: 2px;
    font-size: 1.8rem;
}

label {
    font-weight: 600;
    margin-top: 15px;
    display: block;
    font-size: 1rem;
}

.star {
    color: #ff4a6b;
    margin-left: 4px;
}

input, textarea {
    width: 100%;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.2);
    color: #fff;
    padding: 12px;
    border-radius: 8px;
    margin-top: 6px;
    font-size: 16px;
    transition: 0.25s;
    resize: vertical;
}

input:focus, textarea:focus {
    border-color: #00f7c7;
    box-shadow: 0 0 8px #00f7c7;
    outline: none;
}

.error {
    color: #ff4a6b;
    font-size: 0.9rem;
    display: none;
    margin-top: 5px;
}

button {
    width: 100%;
    margin-top: 20px;
    padding: 14px;
    background: linear-gradient(45deg, #00f7c7, #00a3ff);
    color: #000;
    border: none;
    border-radius: 10px;
    font-size: 18px;
    cursor: pointer;
    font-weight: 600;
    transition: 0.3s;
}

button:hover {
    transform: scale(1.03);
    box-shadow: 0 0 15px rgba(0,255,200,0.5);
}

.results {
    margin-top: 35px;
    background: rgba(0, 255, 200, 0.05);
    padding: 25px;
    border-radius: 16px;
    border: 1px solid rgba(0,255,200,0.25);
    word-break: break-word;
}

.results h3 {
    margin-top: 20px;
    margin-bottom: 8px;
    color: #00f7c7;
    font-size: 1.1rem;
}

.results p, .results ul {
    margin-left: 15px;
    line-height: 1.6;
}

.sentence-box {
    background: rgba(0,255,200,0.1);
    padding: 12px;
    border-radius: 10px;
    margin-bottom: 10px;
}

.frequency-columns {
    display: flex;
    flex-wrap: wrap;
    gap: 30px; /* space between columns */
}

.frequency-columns ul {
    list-style-type: none;
    padding: 0;
    margin: 0;
    min-width: 120px;
}



/* Responsive adjustments */
@media (max-width: 768px) {
    h1 { font-size: 1.6rem; }
    button { font-size: 16px; padding: 12px; }
    .container { padding: 20px 15px; }
}
@media (max-width: 480px) {
    h1 { font-size: 1.4rem; }
    label { font-size: 0.95rem; }
    button { font-size: 15px; padding: 10px; }
    .container { padding: 15px 10px; }
}
@media (max-width: 600px) {
    .frequency-columns {
        flex-direction: column;
        gap: 15px;
    }
}

</style>
</head>
<body>

<div class="container">
    <h1>ADVANCED TEXT ANALYZER</h1>

    <form method="POST" id="analyzerForm" autocomplete="off">

        <label>Enter Your Text <span class="star">*</span></label>
        <textarea id="text" name="text" rows="6" placeholder="Type your paragraph (max 400 characters)..."><?= htmlspecialchars($text) ?></textarea>
        <div class="error" id="textError"></div>

        <label>Find Word <span class="star">*</span></label>
        <input type="text" id="find" name="find" value="<?= htmlspecialchars($find) ?>">
        <div class="error" id="findError"></div>

        <label>Replace Word <span class="star">*</span></label>
        <input type="text" id="replace" name="replace" value="<?= htmlspecialchars($replace) ?>">
        <div class="error" id="replaceError"></div>

        <button type="submit">Analyze Text</button>
    </form>

    <?php if($isSubmitted): 
        $wordCount = wordCountCustom($text);
        $charCount = characterCountNoSpaces($text);
        $upperText = convertToUppercase($text);
        $sentences = extractSentences($text);
        $frequency = wordFrequency($text);

        // Check if the find word exists
        if (stripos($text, $find) === false) {
            $findErrorMessage = "The word '<strong>" . htmlspecialchars($find) . "</strong>' was not found in the paragraph.";
            $replacedText = $text; // no change
        } else {
            $findErrorMessage = '';
            $replacedText = findAndReplaceWord($text, $find, $replace);
        }
    ?>

    <div class="results">
    <h2 style="color:#00f7c7;">Analysis Results</h2>

    <h3>Original Text:</h3>
    <p><?= nl2br(htmlspecialchars($text)) ?></p>

    <h3>Word Count:</h3>
    <p><?= $wordCount ?> words</p>

    <h3>Character Count (no spaces):</h3>
    <p><?= $charCount ?> characters</p>

    <?php if(!empty($findErrorMessage)): ?>
    <div style="background:#ff4a6b; color:#fff; padding:10px; border-radius:8px; margin-bottom:15px;">
        <?= $findErrorMessage ?>
    </div>
    <?php endif; ?>


    <h3>Find & Replace:</h3>
    <p><?= nl2br(htmlspecialchars($replacedText)) ?></p>

    <h3>Uppercase:</h3>
    <p><?= nl2br(htmlspecialchars($upperText)) ?></p>

    <h3>Sentences:</h3>
    <?php foreach($sentences as $s): ?>
        <div class="sentence-box"><?= htmlspecialchars($s) ?></div>
    <?php endforeach; ?>

    <h3>Word Frequency:</h3>
    <div class="frequency-columns">
    <?php
    $chunks = array_chunk($frequency, 10, true); // 10 words per column
    foreach($chunks as $chunk):
    ?>
        <ul>
            <?php foreach($chunk as $word => $count): ?>
                <li><strong><?= htmlspecialchars($word) ?></strong>: <?= $count ?> times</li>
            <?php endforeach; ?>
        </ul>
    <?php endforeach; ?>
</div>


</div>

<?php endif; ?>

</div>

<script>
$(document).ready(function () {

    // Auto focus
    $("#text").focus();

    // Textarea limit to 400 chars
    $("#text").on("input", function () {
        let text = $(this).val();

        // Only allow paragraphs containing letters
        if (/^[^a-zA-Z]+$/.test(text)) {
            $("#textError").text("Paragraph cannot contain only numbers or symbols.").fadeIn();
        } else {
            $("#textError").fadeOut();
        }

        // Prevent typing more than 400 characters
        if (text.length > 400) {
            $(this).val(text.substring(0, 400));
        }
    });

    // Find & Replace fields limit
    $("#find, #replace").on("input", function () {
        if ($(this).val().length > 20) {
            $(this).val($(this).val().substring(0, 20));
        }
        $(this).next(".error").fadeOut();
    });

    // Form validation
    $("#analyzerForm").on("submit", function (e) {
        let valid = true;
        $(".error").hide();

        let text = $("#text").val().trim();
        if (text.length < 20) {
            $("#textError").text("Paragraph must contain at least 20 characters.").fadeIn();
            valid = false;
        }
        if (/^[^a-zA-Z]+$/.test(text)) {
            $("#textError").text("Enter a valid paragraph with letters.").fadeIn();
            valid = false;
        }

        let find = $("#find").val().trim();
        if (find === "") {
            $("#findError").text("This field is required.").fadeIn();
            valid = false;
        }

        let replace = $("#replace").val().trim();
        if (replace === "") {
            $("#replaceError").text("This field is required.").fadeIn();
            valid = false;
        }

        if (!valid) e.preventDefault();
    });
});
</script>

</body>
</html>
