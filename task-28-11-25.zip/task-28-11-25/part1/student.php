<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Management & Grade System</title>
    <!-- Tailwind CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .error-msg { display: none; }
        input::-webkit-inner-spin-button,
        input::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        input[type=number] {
            -moz-appearance: textfield;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-100 to-pink-100 min-h-screen flex items-start justify-center py-10">

<div class="bg-white/80 backdrop-blur-lg shadow-2xl rounded-2xl p-8 max-w-4xl w-full text-gray-800">

    <h1 class="text-3xl font-bold text-center mb-8 text-blue-700">Student Management & Grade System</h1>

    <!-- STUDENT FORM -->
    <form id="studentForm" class="space-y-4 bg-white/50 p-6 rounded-lg">
        <h2 class="text-xl font-semibold mb-4 text-yellow-600">Add Student</h2>

        <div>
            <label class="block mb-1 font-medium">Name <span class="text-red-500">*</span></label>
            <input type="text" id="name" name="name" maxlength="15" class="w-full px-4 py-2 rounded-lg bg-white/30 text-gray-800 border border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300">
            <p class="text-red-500 text-sm mt-1 error-msg">Name is required, max 15 letters, only letters and spaces.</p>
        </div>

        <div>
            <label class="block mb-1 font-medium">Age <span class="text-red-500">*</span></label>
            <input type="text" id="age" name="age" maxlength="2" class="w-full px-4 py-2 rounded-lg bg-white/30 text-gray-800 border border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300 ">
            <p class="text-red-500 text-sm mt-1 error-msg">Valid age is required.</p>
        </div>

        <div>
            <label class="block mb-1 font-medium">Math Marks <span class="text-red-500">*</span></label>
            <input type="text" id="math" name="math" maxlength="3" class="w-full px-4 py-2 rounded-lg bg-white/30 text-gray-800 border border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300">
            <p class="text-red-500 text-sm mt-1 error-msg">Marks 1-100 required.</p>
        </div>

        <div>
            <label class="block mb-1 font-medium">Science Marks <span class="text-red-500">*</span></label>
            <input type="text" id="science" name="science" maxlength="3" class="w-full px-4 py-2 rounded-lg bg-white/30 text-gray-800 border border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300">
            <p class="text-red-500 text-sm mt-1 error-msg">Marks 1-100 required.</p>
        </div>

        <div>
            <label class="block mb-1 font-medium">English Marks <span class="text-red-500">*</span></label>
            <input type="text" id="english" name="english" maxlength="3" class="w-full px-4 py-2 rounded-lg bg-white/30 text-gray-800  border border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300">
            <p class="text-red-500 text-sm mt-1 error-msg">Marks 1-100 required.</p>
        </div>

        <div>
            <label class="block mb-1 font-medium">History Marks <span class="text-red-500">*</span></label>
            <input type="text" id="history" name="history" maxlength="3" class="w-full px-4 py-2 rounded-lg bg-white/30 text-gray-800 border border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300">
            <p class="text-red-500 text-sm mt-1 error-msg">Marks 1-100 required.</p>
        </div>

        <div>
            <label class="block mb-1 font-medium">Computer Marks <span class="text-red-500">*</span></label>
            <input type="text" id="computer" name="computer" maxlength="3" class="w-full px-4 py-2 rounded-lg bg-white/30 text-gray-800 border border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300">
            <p class="text-red-500 text-sm mt-1 error-msg">Marks 1-100 required.</p>
        </div>

        <button type="submit" class="w-full py-3 rounded-lg bg-gradient-to-r from-yellow-300 to-pink-300 text-gray-800 font-semibold hover:opacity-90 transition">Add Student</button>
    </form>

    <!-- SEARCH FORM -->
    <div class="mt-6">
        <input type="text" id="searchName" placeholder="Search student by name" class="w-full px-4 py-2 rounded-lg bg-white/30 text-gray-800 border border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300">
    </div>

    <!-- STUDENT TABLE -->
    <div class="mt-6 overflow-x-auto">
        <table class="min-w-full table-auto bg-white/50 rounded-lg">
            <thead>
                <tr class="bg-yellow-300 text-gray-800">
                    <th class="px-4 py-2">Name</th>
                    <th class="px-4 py-2">Age</th>
                    <th class="px-4 py-2">Math</th>
                    <th class="px-4 py-2">Science</th>
                    <th class="px-4 py-2">English</th>
                    <th class="px-4 py-2">History</th>
                    <th class="px-4 py-2">Computer</th>
                    <th class="px-4 py-2">Grade</th>
                </tr>
            </thead>
            <tbody id="studentTable">
                <!-- Students added here dynamically -->
            </tbody>
        </table>
    </div>

    <h3 class="mt-4 text-lg font-semibold">Average Age: <span id="avgAge">0</span></h3>

</div>

<script>
$(document).ready(function(){

    // Focus on the first field (Name) when page loads
    $('#name').focus();

    let students = [];

    function calculateGrade(marks) {
        let total = 0;
        let count = 0;
        for (let subject in marks) {
            total += parseInt(marks[subject]);
            count++;
        }
        let avg = total / count;
        if (avg >= 90) return "A";
        if (avg >= 80) return "B";
        if (avg >= 70) return "C";
        if (avg >= 60) return "D";
        return "F";
    }

    function updateTable() {
        let tbody = $('#studentTable');
        tbody.empty();
        let sumAge = 0;

        students.forEach(student => {
            sumAge += parseInt(student.age);
            tbody.append(`<tr>
                <td class="px-4 py-2">${student.name}</td>
                <td class="px-4 py-2">${student.age}</td>
                <td class="px-4 py-2">${student.marks.Math}</td>
                <td class="px-4 py-2">${student.marks.Science}</td>
                <td class="px-4 py-2">${student.marks.English}</td>
                <td class="px-4 py-2">${student.marks.History}</td>
                <td class="px-4 py-2">${student.marks.Computer}</td>
                <td class="px-4 py-2">${student.grade}</td>
            </tr>`);
        });

        $('#avgAge').text(students.length ? (sumAge / students.length).toFixed(2) : 0);
    }

    function validateInput() {
        let valid = true;
        $('#studentForm .error-msg').hide();

        let name = $('#name').val().trim();
        let age = $('#age').val().trim();
        let math = $('#math').val().trim();
        let science = $('#science').val().trim();
        let english = $('#english').val().trim();
        let history = $('#history').val().trim();
        let computer = $('#computer').val().trim();

        let nameRegex = /^[A-Za-z ]{1,15}$/;

        if (!name || !nameRegex.test(name)) { $('#name').next('.error-msg').show(); valid = false; }
        if (!age || !/^\d+$/.test(age)) { $('#age').next('.error-msg').show(); valid = false; }

        function checkMarks(selector, value) {
            if (!value || !/^\d+$/.test(value) || value < 1 || value > 100) {
                $(selector).next('.error-msg').show();
                return false;
            }
            return true;
        }

        valid = checkMarks('#math', math) && valid;
        valid = checkMarks('#science', science) && valid;
        valid = checkMarks('#english', english) && valid;
        valid = checkMarks('#history', history) && valid;
        valid = checkMarks('#computer', computer) && valid;

        return valid;
    }

    // Prevent invalid characters in Name and limit length
    $('#name').on('input', function(){
        let val = $(this).val();
        $(this).val(val.replace(/[^A-Za-z ]/g,'').substring(0,15));
        $(this).next('.error-msg').hide();
    });

    // Prevent non-numbers and values >100 for marks and age
    $('#age, #math, #science, #english, #history, #computer').on('input', function(){
        let val = $(this).val().replace(/\D/g,'');
        if (val !== "" && parseInt(val) > 100) val = "100";
        $(this).val(val);
        $(this).next('.error-msg').hide();
    });

    $('#studentForm').submit(function(e){
        e.preventDefault();
        if (!validateInput()) return;

        let student = {
            name: $('#name').val().trim(),
            age: $('#age').val().trim(),
            marks: {
                Math: $('#math').val().trim(),
                Science: $('#science').val().trim(),
                English: $('#english').val().trim(),
                History: $('#history').val().trim(),
                Computer: $('#computer').val().trim()
            }
        };
        student.grade = calculateGrade(student.marks);
        students.push(student);

        $('#studentForm')[0].reset();
        $('#name').focus(); // Return focus to Name after submit
        updateTable();
    });

    $('#searchName').on('input', function(){
        let search = $(this).val().toLowerCase();
        $('#studentTable tr').each(function(){
            let name = $(this).find('td:first').text().toLowerCase();
            $(this).toggle(name.includes(search));
        });
    });

});
</script>

</body>
</html>
