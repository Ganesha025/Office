<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', function() {
    return view('welcome_message');  // loads dashboard.php from app/Views/
});
$routes->get('/students', 'task1\StudentController::index');
$routes->post('/students/save', 'task1\StudentController::save');
$routes->get('/students/list', 'task1\StudentController::list');

$routes->get('/employees/create', 'task1\EmployeeController::create');
$routes->post('/employees/store', 'task1\EmployeeController::store'); 
$routes->get('/employees', 'task1\EmployeeController::index');   


$routes->get('/courses/create', 'task1\CourseController::create'); 
$routes->post('/courses/store', 'task1\CourseController::store'); 
$routes->get('/courses', 'task1\CourseController::index');   

$routes->get('/products/create', 'task1\ProductController::create');
$routes->post('/products/store', 'task1\ProductController::store');
$routes->get('/products', 'task1\ProductController::index');

$routes->get('/incidents/add', 'task1\IncidentController::add');
$routes->post('/incidents/save', 'task1\IncidentController::saveIncident');
$routes->get('/incidents', 'task1\IncidentController::viewIncidents');





  



