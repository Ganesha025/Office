<?php
namespace App\Controllers\task1;
use CodeIgniter\Controller;
use App\Models\task1\EmployeeModel;

class EmployeeController extends Controller
{
    
    public function create()
    {
        return view('task1/employee_form');
    }

    
    public function store()
    {
        $model = new EmployeeModel();

        $data = [
            'emp_name' => $this->request->getPost('emp_name'),
            'department'    => $this->request->getPost('department'),
            'salary'        => $this->request->getPost('salary'),
            'email'         => $this->request->getPost('email'),
            'date_of_joining'=> $this->request->getPost('date_of_joining')
        ];

        $model->insert($data); 

        return redirect()->to('/employees');
    }

    
    public function index()
    {
        $model = new EmployeeModel();
        $data['employees'] = $model->findAll(); 
        return view('task1/employee_list', $data);
    }
}