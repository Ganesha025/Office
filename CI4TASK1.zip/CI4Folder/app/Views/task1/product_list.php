<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:90%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#343a40; color:#fff; }
    </style>
</head>
<body>

<h2 style="text-align:center;">Product List</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Product Name</th>
        <th>Category</th>
        <th>Price</th>
        <th>Stock</th>
        <th>Description</th>
    </tr>

    <?php foreach ($products as $row): ?>
    <tr>
        <td><?= $row['product_id'] ?></td>
        <td><?= $row['product_name'] ?></td>
        <td><?= $row['category'] ?></td>
        <td><?= $row['price'] ?></td>
        <td><?= $row['stock_quantity'] ?></td>
        <td><?= $row['description'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>

</body>
</html>
