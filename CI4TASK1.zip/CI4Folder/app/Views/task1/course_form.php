<!DOCTYPE html>
<html>
<head>
    <title>Course Registration</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        form { width:400px; margin:40px auto; padding:20px; background:#fff; }
        input { width:100%; padding:8px; margin:8px 0; }
        button { padding:10px; width:100%; background:#ffc107; color:#000; border:none; }
    </style>
</head>
<body>

<form method="post" action="<?= base_url('/courses/store') ?>">
    <h2>Course Registration</h2>

    <input type="text" name="student_name" placeholder="Student Name" required>
    <input type="text" name="course_name" placeholder="Course Name" required>
    <input type="text" name="semester" placeholder="Semester">
    <input type="text" name="fees" placeholder="Fees">
    <input type="email" name="email" placeholder="Email">

    <button type="submit">Register</button>
</form>

</body>
</html>
