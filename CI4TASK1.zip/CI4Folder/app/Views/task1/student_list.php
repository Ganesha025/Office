<!DOCTYPE html>
<html>
<head>
    <title>Student List</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:80%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#007bff; color:#fff; }
    </style>
</head>
<body>

<h2 style="text-align:center;">Registered Students</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Course</th>
        <th>City</th>
    </tr>

    <?php foreach ($students as $row): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['student_name'] ?></td>
        <td><?= $row['email'] ?></td>
        <td><?= $row['phone'] ?></td>
        <td><?= $row['course'] ?></td>
        <td><?= $row['city'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>

</body>
</html>
