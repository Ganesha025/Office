<!DOCTYPE html>
<html>
<head>
    <title>Employee List</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:90%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#28a745; color:#fff; }
    </style>
</head>
<body>

<h2 style="text-align:center;">Employees</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Department</th>
        <th>Salary</th>
        <th>Email</th>
        <th>Date of Joining</th>
    </tr>

    <?php foreach ($employees as $row): ?>
    <tr>
        <td><?= $row['emp_id'] ?></td>
        <td><?= $row['emp_name'] ?></td>
        <td><?= $row['department'] ?></td>
        <td><?= $row['salary'] ?></td>
        <td><?= $row['email'] ?></td>
        <td><?= $row['date_of_joining'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>

</body>
</html>
