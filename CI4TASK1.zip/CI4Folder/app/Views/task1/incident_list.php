<!DOCTYPE html>
<html>
<head>
    <title>Incident List</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:95%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#dc3545; color:#fff; }
    </style>
</head>
<body>

<h2 style="text-align:center;">Incident Reports (Admin)</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Description</th>
        <th>Department</th>
        <th>Priority</th>
        <th>Date</th>
    </tr>

    <?php foreach ($incidents as $row): ?>
    <tr>
        <td><?= $row['incident_id'] ?></td>
        <td><?= $row['title'] ?></td>
        <td><?= $row['description'] ?></td>
        <td><?= $row['department'] ?></td>
        <td><?= $row['priority'] ?></td>
        <td><?= $row['incident_date'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>

</body>
</html>
