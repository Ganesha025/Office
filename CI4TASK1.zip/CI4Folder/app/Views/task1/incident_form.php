<!DOCTYPE html>
<html>
<head>
    <title>Log Incident</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        form { width:450px; margin:40px auto; padding:20px; background:#fff; }
        input, textarea, select { width:100%; padding:8px; margin:8px 0; }
        button { padding:10px; width:100%; background:#dc3545; color:#fff; border:none; }
    </style>
</head>
<body>

<form method="post" action="<?= base_url('/incidents/save') ?>">
    <h2>Incident / Complaint Log</h2>

    <input type="text" name="title" placeholder="Title" required>
    <textarea name="description" placeholder="Description" required></textarea>
    <input type="text" name="department" placeholder="Department">

    <select name="priority">
        <option value="Low">Low</option>
        <option value="Medium">Medium</option>
        <option value="High">High</option>
    </select>

    <input type="date" name="incident_date">

    <button type="submit">Submit Incident</button>
</form>

</body>
</html>
