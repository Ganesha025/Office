<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        form { width:420px; margin:40px auto; padding:20px; background:#fff; }
        input, textarea { width:100%; padding:8px; margin:8px 0; }
        button { padding:10px; width:100%; background:#343a40; color:#fff; border:none; }
        .error { color:red; }
    </style>
</head>
<body>

<form method="post" action="<?= base_url('/products/store') ?>">
    <h2>Add Product</h2>

    <?php if (isset($errors)): ?>
        <?php foreach ($errors as $err): ?>
            <p class="error"><?= $err ?></p>
        <?php endforeach; ?>
    <?php endif; ?>

    <input type="text" name="product_name" placeholder="Product Name" required>
    <input type="text" name="category" placeholder="Category" required>
    <input type="text" name="price" placeholder="Price">
    <input type="number" name="stock_quantity" placeholder="Stock Quantity">
    <textarea name="description" placeholder="Description"></textarea>

    <button type="submit">Add Product</button>
</form>

</body>
</html>
