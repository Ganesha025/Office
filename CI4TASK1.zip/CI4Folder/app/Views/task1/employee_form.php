<!DOCTYPE html>
<html>
<head>
    <title>Add Employee</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        form { width:400px; margin:40px auto; padding:20px; background:#fff; }
        input { width:100%; padding:8px; margin:8px 0; }
        button { padding:10px; width:100%; background:#28a745; color:#fff; border:none; }
    </style>
</head>
<body>

<form method="post" action="<?= base_url('/employees/store') ?>">
    <h2>Add Employee</h2>

    <input type="text" name="emp_name" placeholder="Employee Name" required>
    <input type="text" name="department" placeholder="Department" required>
    <input type="text" name="salary" placeholder="Salary">
    <input type="email" name="email" placeholder="Email">
    <input type="date" name="date_of_joining" placeholder="Date of Joining">

    <button type="submit">Save Employee</button>
</form>

</body>
</html>
