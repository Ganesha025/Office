<!DOCTYPE html>
<html>
<head>
    <title>CI4 Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 30px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .dashboard {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .dashboard a {
            text-decoration: none;
            color: #007bff;
            border: 1px solid #007bff;
            padding: 10px 15px;
            border-radius: 4px;
            width: 150px;
            text-align: center;
            transition: all 0.3s;
        }

        .dashboard a:hover {
            background: #007bff;
            color: #fff;
        }
    </style>
</head>
<body>

<h2>CI4 Dashboard - Task 1</h2>

<div class="dashboard">
    <!-- Student -->
    <a href="<?= base_url('/students') ?>">Add Student</a>
    <a href="<?= base_url('/students/list') ?>">Student List</a>

    <!-- Employee -->
    <a href="<?= base_url('/employees/create') ?>">Add Employee</a>
    <a href="<?= base_url('/employees') ?>">Employee List</a>

    <!-- Course -->
    <a href="<?= base_url('/courses/create') ?>">Add Course</a>
    <a href="<?= base_url('/courses') ?>">Course List</a>

    <!-- Product -->
    <a href="<?= base_url('/products/create') ?>">Add Product</a>
    <a href="<?= base_url('/products') ?>">Product List</a>

    <!-- Incident -->
    <a href="<?= base_url('/incidents/add') ?>">Add Incident</a>
    <a href="<?= base_url('/incidents') ?>">Incident List</a>
</div>

</body>
</html>
