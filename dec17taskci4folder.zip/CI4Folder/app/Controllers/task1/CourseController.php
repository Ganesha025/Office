<?php

namespace App\Controllers\task1;

use CodeIgniter\Controller;
use App\Models\task1\CourseModel;

class CourseController extends Controller
{
    
    public function create()
    {
        return view('task1/course_form');
    }

    
    public function store()
    {
        $model = new CourseModel();

        $data = [
            'student_name' => $this->request->getPost('student_name'),
            'course_name'  => $this->request->getPost('course_name'),
            'semester'     => $this->request->getPost('semester'),
            'fees'         => $this->request->getPost('fees'),
            'email'        => $this->request->getPost('email')
        ];

        $model->insert($data);

        return redirect()->to('/courses'); 
    }

    
    public function index()
    {
        $model = new CourseModel();
        $data['registrations'] = $model->findAll();
        return view('task1/course_list', $data);
    }
}
