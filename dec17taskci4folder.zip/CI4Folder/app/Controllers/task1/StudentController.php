<?php
namespace App\Controllers\task1;
use CodeIgniter\Controller;
use App\Models\task1\StudentModel;
class StudentController extends Controller

{
    public function index()
    {
        return view("task1\student_form");
        }
    public function save()
    {
        $model= new StudentModel();
        $data =[
            'student_name'=>$this->request->getPost('student_name'),
            'email'=> $this->request->getPost('email'),
            'phone'=> $this->request->getPost('phone'),
            'course' => $this->request->getPost('course'),
            'city'  => $this->request->getPost('city'),
        ];
        $model->insert($data);
         return redirect()->to('/students/list');


    }
    public function list()
    {
        $model = new StudentModel();

        $data['students'] = $model->findAll();  

        return view('task1\student_list', $data);
    }
}

