<!DOCTYPE html>
<html>
<head>
    <title>Registered Courses</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:90%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#ffc107; color:#000; }
    </style>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
</head>
<body>

<h2 style="text-align:center;">Registered Students</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Student Name</th>
        <th>Course Name</th>
        <th>Semester</th>
        <th>Fees</th>
        <th>Email</th>
    </tr>

    <?php foreach ($registrations as $row): ?>
    <tr>
        <td><?= $row['course_id'] ?></td>
        <td><?= $row['student_name'] ?></td>
        <td><?= $row['course_name'] ?></td>
        <td><?= $row['semester'] ?></td>
        <td><?= $row['fees'] ?></td>
        <td><?= $row['email'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>

</body>
</html>
