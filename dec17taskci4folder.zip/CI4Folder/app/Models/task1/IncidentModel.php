<?php

namespace App\Models\task1;

use CodeIgniter\Model;

class IncidentModel extends Model
{
    protected $table = 'incident_logs';
    protected $primaryKey = 'incident_id';

    protected $allowedFields = [
        'title',
        'description',
        'department',
        'priority',
        'incident_date'
    ];
}
