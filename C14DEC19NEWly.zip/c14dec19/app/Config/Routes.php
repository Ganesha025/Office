<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
/*$routes->get('/', 'AuthController::login');   // default page
$routes->get('login', 'AuthController::login');
$routes->post('loginPost', 'AuthController::loginPost');
$routes->get('logout', 'AuthController::logout');



$routes->group('', ['filter' => 'role:Admin,HR,Manager'], function($routes) {

   
    $routes->get('employees', 'EmployeeController::index');

    
    $routes->get('employees/create', 'EmployeeController::create', ['filter' => 'role:Admin,HR']);
    $routes->post('employees/store', 'EmployeeController::store', ['filter' => 'role:Admin,HR']);

    $routes->get('employees/edit/(:num)', 'EmployeeController::edit/$1', ['filter' => 'role:Admin,HR']);
    $routes->post('employees/update/(:num)', 'EmployeeController::update/$1', ['filter' => 'role:Admin,HR']);

    $routes->get('employees/delete/(:num)', 'EmployeeController::delete/$1', ['filter' => 'role:Admin,HR']);
});*/
    
$routes->get('/', 'inventory\AuthController::login');

// Login / Logout
$routes->get('login', 'inventory\AuthController::login');
$routes->post('loginPost', 'inventory\AuthController::loginPost');
$routes->get('logout', 'inventory\AuthController::logout');

// Group routes with role-based filter
$routes->group('', ['filter' => 'role:Admin,StockManager,HR,Viewer'], function($routes) {

    // Product List (All roles)
    $routes->get('products', 'inventory\ProductController::index');

    // Create Product (Admin, StockManager, HR)
    $routes->get('products/create', 'inventory\ProductController::create', ['filter' => 'role:Admin,StockManager,HR']);
    $routes->post('products/store', 'inventory\ProductController::store', ['filter' => 'role:Admin,StockManager,HR']);

    // Edit Product (Admin, StockManager, HR)
    $routes->get('products/edit/(:num)', 'inventory\ProductController::edit/$1', ['filter' => 'role:Admin,StockManager,HR']);
    $routes->post('products/update/(:num)', 'inventory\ProductController::update/$1', ['filter' => 'role:Admin,StockManager,HR']);

    // Delete Product (Admin only)
    $routes->get('products/delete/(:num)', 'inventory\ProductController::delete/$1', ['filter' => 'role:Admin']);

    // Stock History (Admin, StockManager, HR)
    $routes->get('products/history/(:num)', 'inventory\ProductController::history/$1', ['filter' => 'role:Admin,StockManager,HR']);

    // Add to Cart (Viewer only)
    $routes->post('products/addtocart/(:num)', 'inventory\ProductController::addToCart/$1', ['filter' => 'role:Viewer']);
});$routes->get('cart', 'inventory\ProductController::viewCart', ['filter' => 'role:Viewer']);