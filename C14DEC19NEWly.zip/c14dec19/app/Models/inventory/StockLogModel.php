<?php
namespace App\Models\inventory;

use CodeIgniter\Model;

class StockLogModel extends Model
{
    protected $table = 'stock_logs';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'product_id',
        'change_qty',
        'stock_before',
        'stock_after',
        'changed_by'
    ];

    // ✅ ENABLE timestamps
    protected $useTimestamps = true;

    protected $createdField  = 'created_at';
}
