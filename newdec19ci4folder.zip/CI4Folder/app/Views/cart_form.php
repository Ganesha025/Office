<?php helper(['form','url']); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Products</title>

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1f4037, #99f2c8);
            margin: 0;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #fff;
            margin-bottom: 30px;
            letter-spacing: 1px;
        }

        .product-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            max-width: 1000px;
            margin: auto;
        }

        .product-card {
            background: #ffffff;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.25);
        }

        .product-name {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }

        .price {
            font-size: 18px;
            color: #27ae60;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .qty-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
        }

        .qty-group label {
            font-size: 14px;
            color: #555;
        }

        input[type="number"] {
            width: 70px;
            padding: 8px;
            border-radius: 6px;
            border: 1px solid #ccc;
            text-align: center;
            font-size: 15px;
        }

        /* REMOVE SPINNER ARROWS */
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type=number] {
            -moz-appearance: textfield;
        }

        button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #ff512f, #dd2476);
            border: none;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        button:hover {
            transform: scale(1.03);
            background: linear-gradient(135deg, #dd2476, #ff512f);
        }

        .view-cart {
            display: block;
            width: fit-content;
            margin: 40px auto 0;
            padding: 12px 25px;
            background: #2c3e50;
            color: #fff;
            border-radius: 25px;
            text-decoration: none;
            font-weight: bold;
            letter-spacing: 0.5px;
            transition: background 0.3s ease;
        }

        .view-cart:hover {
            background: #000;
        }
    </style>
</head>
<body>

<h2>🛍️ Our Products</h2>

<div class="product-container">

<?php foreach ($products as $p): ?>

    <div class="product-card">

        <?= form_open('add-cart') ?>

        <input type="hidden" name="product_name" value="<?= esc($p['product_name']) ?>">
        <input type="hidden" name="price" value="<?= esc($p['price']) ?>">

        <div class="product-name"><?= esc($p['product_name']) ?></div>

        <div class="price">₹ <?= esc($p['price']) ?></div>

        <div class="qty-group">
            <label>Qty</label>
            <input type="number" name="quantity" value="1" min="1">
        </div>

        <button type="submit">Add to Cart 🛒</button>

        <?= form_close() ?>

    </div>

<?php endforeach; ?>

</div>

<a class="view-cart" href="<?= site_url('cart') ?>">View Cart</a>

</body>
</html>
