<?php helper(['form','url']); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <style>
        body{
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .login-box{
            width: 360px;
            margin: 100px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            position: relative;
        }

        h2{
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        input{
            width: 100%;
            padding: 12px 15px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
            font-size: 15px;
        }

        input:focus{
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 5px rgba(0,123,255,0.3);
        }

        .password-container{
            position: relative;
        }

        .toggle-password{
            position: absolute;
            top: 50%;
            right: 15px;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 14px;
            color: #007bff;
            user-select: none;
        }

        button{
            width: 100%;
            padding: 12px;
            margin-top: 15px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }

        button:hover{
            background: #0056b3;
        }

        .error{
            color: red;
            text-align: center;
            margin-bottom: 10px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<div class="login-box">
    <h2>Login</h2>

    <?php if(session()->getFlashdata('error')): ?>
        <p class="error"><?= session()->getFlashdata('error') ?></p>
    <?php endif; ?>

    <?= form_open('/setRole') ?>
        <input type="email" name="email" placeholder="Email" required>

        <div class="password-container">
            <input type="password" name="password" id="password" placeholder="Password" required>
            <span class="toggle-password">Show</span>
        </div>

        <button type="submit">Login</button>
    <?= form_close() ?>
</div>

<script>
    $(document).ready(function(){
        $('.toggle-password').click(function(){
            let passwordField = $('#password');
            let type = passwordField.attr('type') === 'password' ? 'text' : 'password';
            passwordField.attr('type', type);
            $(this).text(type === 'password' ? 'Show' : 'Hide');
        });
    });
</script>

</body>
</html>
