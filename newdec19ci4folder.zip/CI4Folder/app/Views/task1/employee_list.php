<!DOCTYPE html>
<html>
<head>
    <title>Employee List</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:90%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#28a745; color:#fff; }
    </style>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
</head>
<body>

<h2 style="text-align:center;">Employees</h2>

<table id="employeeslist">
    <thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Department</th>
        <th>Salary</th>
        <th>Email</th>
        <th>Date of Joining</th>
    </tr>
    </thead>
<tbody>
    <?php foreach ($employees as $row): ?>
    <tr>
        <td><?= $row['emp_id'] ?></td>
        <td><?= $row['emp_name'] ?></td>
        <td><?= $row['department'] ?></td>
        <td><?= $row['salary'] ?></td>
        <td><?= $row['email'] ?></td>
        <td><?= $row['date_of_joining'] ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<script>
$(document).ready(function () {
    $('#employeeslist').DataTable({
        paging: true,
        searching: true,
        ordering: true,
        info: true
    });
});
</script>

</body>
</html>
