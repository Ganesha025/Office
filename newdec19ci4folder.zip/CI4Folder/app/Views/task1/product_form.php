<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 420px;
            margin: 50px auto;
            background: #fff;
            padding: 30px 35px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        form input,
        form textarea {
            width: 100%;
            padding: 12px 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
        }

        form textarea {
            resize: none;
            height: 90px;
        }

        form button {
            width: 100%;
            padding: 12px;
            background: #343a40;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 15px;
            transition: background 0.3s;
        }

        form button:hover {
            background: #23272b;
        }

        .error {
            color: red;
            font-size: 14px;
            margin: 5px 0;
        }
    </style>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Common Validation -->
    <script src="<?= base_url('assets/js/jqueryvalidation.js') ?>"></script>
</head>
<body>

<div class="container">

    <script>
        $(document).ready(function () {
            $("#product").focus();
        });
    </script>

    <form method="post" action="<?= base_url('/products/store') ?>">
        <h2>Add Product</h2>

        <?php if (isset($errors)): ?>
            <?php foreach ($errors as $err): ?>
                <p class="error"><?= $err ?></p>
            <?php endforeach; ?>
        <?php endif; ?>

        <input type="text" name="product_name" placeholder="Product Name" id="product" class="name" required>

        <input type="text" name="category" placeholder="Category" class="name" required>

        <input type="text" name="price" placeholder="Price" class="salary-range">

        <input type="number" name="stock_quantity" placeholder="Stock Quantity" class="stock-range">

        <textarea name="description" placeholder="Description"></textarea>

        <button type="submit">Add Product</button>
    </form>

</div>

</body>
</html>
