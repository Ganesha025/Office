<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class RoleController extends Controller
{
    public function login()
    {
        helper(['form','url']);
        return view('auth/login'); 
    }

    public function setRole()
    {
        helper(['form','url']);
        $session = session();

        
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

       
        $model = new UserModel();

       
        $user = $model->where('email', $email)->first();

       
        if($user && $password == $user['password']) { 
            
            $session->set([
                'email' => $user['email'],
                'role' => $user['role'], 
                'isLoggedIn' => true
            ]);

            
            if($user['role'] == 'admin') {
                return redirect()->to('/adminPage');
            } else {
                return redirect()->to('/userPage');
            }
        } else {
            
            $session->setFlashdata('error','Invalid Email or Password');
            return redirect()->to('/login');
        }
    }

    public function adminPage()
    {
        $session = session();
        if(!$session->get('isLoggedIn') || $session->get('role') != 'admin'){
            return redirect()->to('/login');
        }

        return view('admin/adminPage');
    }

    public function userPage()
    {
        $session = session();
        if(!$session->get('isLoggedIn') || $session->get('role') != 'user'){
            return redirect()->to('/login');
        }

        return view('user1/userPage');
    }

    public function logout()
    {
        session()->destroy();
        return view('auth/login');
        
    }
}
