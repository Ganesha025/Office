<?php
namespace App\Controllers;

use App\Models\ProductModel;
use CodeIgniter\Controller;

class CartController extends Controller
{
    // Show products from database
    public function showForm()
    {
        helper(['form','url']);

        $model = new ProductModel();
        $data['products'] = $model->findAll();

        return view('cart_form', $data);
    }

    // ✅ ADD TO CART USING session()->push()
    public function addToCart()
    {
        helper(['form','url']);
        $session = session();

        $item = [
            'name'     => $this->request->getPost('product_name'),
            'price'    => (int)$this->request->getPost('price'),
            'quantity' => (int)$this->request->getPost('quantity')
        ];

        // If cart not exists, create empty cart
        if (!$session->has('cart')) {
            $session->set('cart', []);
        }

        // ✅ PUSH ITEM INTO SESSION ARRAY
        $session->push('cart', $item);

        return redirect()->to('/cart');
    }

    // View Cart
    public function viewCart()
    {
        helper(['url']);

        $data['cart'] = session()->get('cart') ?? [];

        return view('cart_view', $data);
    }

    // ✅ REMOVE ITEM USING session()->remove()
    public function removeItem($key)
    {
        $session = session();
        $cart = $session->get('cart');

        if (isset($cart[$key])) {
            unset($cart[$key]);
            $cart = array_values($cart); // reindex array
        }

        // If cart is empty, remove session completely
        if (empty($cart)) {
            // ✅ REMOVE SESSION KEY
            $session->remove('cart');
        } else {
            $session->set('cart', $cart);
        }

        return redirect()->to('/cart');
    }
}
