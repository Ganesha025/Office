<?php
$name = $_GET['name'] ?? '';
$reg = $_GET['reg'] ?? '';
$dept = $_GET['dept'] ?? '';
$sem = $_GET['sem'] ?? '';
$date = $_GET['date'] ?? date('d-m-Y');

$subjects = [];
$credits = [];
for($i=1;$i<=6;$i++){
    if(isset($_GET['sub'.$i])) $subjects[] = $_GET['sub'.$i];
    if(isset($_GET['credit'.$i])) $credits[] = $_GET['credit'.$i];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Hall Ticket</title>

<style>
    body{
        font-family:'Segoe UI',Arial,sans-serif;
        background:#e9ecef;
        padding:20px;
        display:flex;
        justify-content:center;
    }

    .ticket{
        width:750px;
        background:white;
        padding:25px 35px;
        border:4px solid #000;
        border-radius:8px;
        position:relative;
        box-shadow:0px 4px 15px rgba(0,0,0,0.1);
    }

    .header{
        text-align:center;
        border-bottom:3px solid #000;
        padding-bottom:12px;
        margin-bottom:20px;
    }

    .header h2{
        margin:0;
        font-size:28px;
        font-weight:700;
        text-transform:uppercase;
    }

    .header p{
        margin:5px 0;
        font-size:14px;
        color:#444;
    }

    .details p{
        font-size:16px;
        margin:6px 0;
    }

    .details strong{
        width:170px;
        display:inline-block;
        font-weight:600;
        color:#000;
    }

    table{
        width:100%;
        border-collapse:collapse;
        margin-top:15px;
    }

    th, td{
        border:2px solid #000;
        padding:10px;
        font-size:16px;
        text-align:center;
    }

    th{
        background:#f1f1f1;
        font-weight:700;
    }

    .footer{
        margin-top:20px;
        display:flex;
        justify-content:space-between;
    }

    .sign{
        text-align:center;
        width:45%;
        border-top:2px solid #000;
        padding-top:5px;
        font-weight:600;
    }

    button{
        margin-top:20px;
        background:#000;
        color:white;
        border:none;
        padding:10px 22px;
        cursor:pointer;
        font-size:16px;
        border-radius:5px;
    }

    button:hover{
        background:#444;
    }

    @media print {
        button{ display:none; }
        body{ background:white; }
        .ticket{ box-shadow:none; }
    }
</style>

</head>
<body>

<div class="ticket">

    <div class="header">
        <h2>College Hall Ticket</h2>
        <p>Approved by AICTE | Affiliated to Anna University</p>
        <p>Coimbatore, Tamil Nadu - 641005</p>
    </div>

    <div class="details">
        <p><strong>Student Name:</strong> <?=htmlspecialchars($name)?></p>
        <p><strong>Register Number:</strong> <?=htmlspecialchars($reg)?></p>
        <p><strong>Department:</strong> <?=htmlspecialchars($dept)?></p>
        <p><strong>Semester:</strong> <?=htmlspecialchars($sem)?></p>
        <p><strong>Date of Issue:</strong> <?=htmlspecialchars($date)?></p>
    </div>

    <table>
        <tr>
            <th>S.No</th>
            <th>Subject Name</th>
            <th>Credits</th>
        </tr>
        <?php
        for($i=0;$i<count($subjects);$i++){
            echo "<tr><td>".($i+1)."</td><td>".htmlspecialchars($subjects[$i])."</td><td>".htmlspecialchars($credits[$i])."</td></tr>";
        }
        ?>
    </table>

    <div class="footer">
        <div class="sign">Student Signature</div>
        <div class="sign">Controller of Examinations</div>
    </div>

    <center><button onclick="window.print()">Print Hall Ticket</button></center>

</div>

</body>
</html>
