<?php
$submitted = false;
$errors = [];
$marksInput = "";
$marksArray = [];
$average = $highest = $lowest = $passPercent = 0;

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $submitted = true;
    $marksInput = trim($_POST['marks']);

    if($marksInput === ""){
        $errors['marks'] = "Enter student marks separated by commas";
    } else {
        // Split marks and validate 1-100
        $marksArray = array_map('trim', explode(',', $marksInput));
        if(count($marksArray) > 60){
            $errors['marks'] = "You can enter a maximum of 60 marks";
        } else {
            foreach($marksArray as $mark){
                if(!is_numeric($mark) || $mark < 1 || $mark > 100){
                    $errors['marks'] = "All marks must be numbers between 1 and 100";
                    break;
                }
            }
        }
    }

    if(empty($errors)){
        $marksArray = array_map('intval', $marksArray);
        $totalStudents = count($marksArray);
        $sum = array_sum($marksArray);
        $average = round($sum / $totalStudents, 2);
        $highest = max($marksArray);
        $lowest = min($marksArray);
        $passCount = count(array_filter($marksArray, function($m){ return $m >= 40; }));
        $passPercent = round(($passCount / $totalStudents) * 100, 2);

        session_start();
        $_SESSION['marksArray'] = $marksArray;
        $_SESSION['average'] = $average;
        $_SESSION['highest'] = $highest;
        $_SESSION['lowest'] = $lowest;
        $_SESSION['passPercent'] = $passPercent;

        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }
}

// Retrieve session data after redirect
session_start();
if(isset($_SESSION['marksArray'])){
    $submitted = true;
    $marksArray = $_SESSION['marksArray'];
    $average = $_SESSION['average'];
    $highest = $_SESSION['highest'];
    $lowest = $_SESSION['lowest'];
    $passPercent = $_SESSION['passPercent'];

    unset($_SESSION['marksArray'], $_SESSION['average'], $_SESSION['highest'], $_SESSION['lowest'], $_SESSION['passPercent']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Semester Result Analysis Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
.bar-container{
    display:flex;
    align-items:flex-end;
    gap:8px;
    height:220px;
    margin-top:20px;
    border-bottom:2px solid #333;
    padding-bottom:5px;
    overflow-x:auto;
}
.bar{
    width:25px;
    text-align:center;
    color:white;
    font-size:12px;
    border-radius:4px 4px 0 0;
    transform: scaleY(0);
    transform-origin: bottom;
    animation: grow 1s forwards;
}
@keyframes grow{
    to{ transform: scaleY(1); }
}
</style>
</head>
<body class="bg-gradient-to-r from-green-100 to-blue-200 min-h-screen flex items-center justify-center p-6">
<div class="bg-white shadow-2xl rounded-2xl p-8 w-full max-w-4xl">
<h2 class="text-2xl font-bold text-center mb-6 text-gray-800">Semester Result Analysis Dashboard</h2>

<form id="marksForm" method="post" class="space-y-4"novalidate>
    <div>
        <label class="block font-semibold text-gray-700">Student Marks (comma separated, 1-100, max 60 students) <span class="text-red-500">*</span></label>
        <textarea name="marks" id="marks" rows="3" 
        class="mt-1 w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500" 
        placeholder="Example: 45, 78, 90, 66, 55"><?php echo htmlspecialchars($marksInput); ?></textarea>
        <div class="text-red-600 text-sm mt-1" id="errMarks"><?php echo $errors['marks'] ?? ''; ?></div>
    </div>

    <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg mt-2">Analyze Results</button>
</form>

<?php if($submitted && empty($errors)): ?>
<div class="mt-6 text-center space-y-3">
    <p class="font-semibold text-gray-800">Average Marks: <?php echo $average; ?></p>
    <p class="font-semibold text-gray-800">Highest Marks: <?php echo $highest; ?></p>
    <p class="font-semibold text-gray-800">Lowest Marks: <?php echo $lowest; ?></p>
    <p class="font-semibold text-gray-800">Pass %: <?php echo $passPercent; ?>%</p>
</div>

<div class="bar-container">
    <?php foreach($marksArray as $m): 
        $color = $m < 40 ? '#ef4444' : ($m <= 60 ? '#facc15' : '#22c55e'); ?>
        <div class="bar" style="height:<?php echo $m*2; ?>px; background-color:<?php echo $color; ?>;" title="<?php echo $m; ?>"><?php echo $m; ?></div>
    <?php endforeach; ?>
</div>

<script>
    setTimeout(function(){
        $("#marksForm")[0].reset();
        $("#marks").focus();
    },100);
</script>
<?php endif; ?>

<script>
$(document).ready(function(){
    $("#marks").focus();

    // Input validation: only numbers, commas, spaces, max 60 numbers, range 1-100
    $("#marks").on("input", function(){
        let val = this.value.replace(/[^0-9, ]/g,'');
        let arr = val.split(',').map(m=>m.trim());
        if(arr.length > 60) arr = arr.slice(0,60);
        for(let i=0;i<arr.length;i++){
            if(arr[i] !== ""){
                if(parseInt(arr[i]) > 100) arr[i] = 100;
                if(parseInt(arr[i]) < 1) arr[i] = 1;
            }
        }
        this.value = arr.join(', ');
        if(this.value.length > 0) $("#errMarks").text('');
    });
});
</script>

</div>
</body>
</html>
