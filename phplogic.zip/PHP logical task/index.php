<?php
session_start();

// Clear previous session data
unset($_SESSION['formData'], $_SESSION['errors']);
$errors = [];
$formData = [
    'studentName' => '',
    'tuition' => '',
    'exam' => '',
    'lab' => '',
    'category' => '',
    'mess' => '',
    'hostel' => ''
];

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    // Collect input
    $formData = [
        'studentName' => trim($_POST['studentName'] ?? ''),
        'tuition' => trim($_POST['tuition'] ?? ''),
        'exam' => trim($_POST['exam'] ?? ''),
        'lab' => trim($_POST['lab'] ?? ''),
        'category' => $_POST['category'] ?? '',
        'mess' => trim($_POST['mess'] ?? ''),
        'hostel' => trim($_POST['hostel'] ?? '')
    ];

    // Validation
    if($formData['studentName'] === "" || !preg_match("/^[A-Za-z ]{1,20}$/", $formData['studentName'])){
        $errors['studentName'] = "Enter valid name (letters & spaces only, max 20)";
    }
    if($formData['tuition']==="" || !is_numeric($formData['tuition']) || $formData['tuition']<10000 || $formData['tuition']>100000){
        $errors['tuition'] = "Tuition Fee must be 10,000 - 1,00,000";
    }
    if($formData['exam']==="" || !is_numeric($formData['exam']) || $formData['exam']<2000 || $formData['exam']>10000){
        $errors['exam'] = "Exam Fee must be 2,000 - 10,000";
    }
    if($formData['lab']==="" || !is_numeric($formData['lab']) || $formData['lab']<1000 || $formData['lab']>5000){
        $errors['lab'] = "Lab Fee must be 1,000 - 5,000";
    }
    if($formData['category']===""){
        $errors['category'] = "Select a category";
    }
    if($formData['category'] === "Hosteller"){
        if($formData['mess']==="" || !is_numeric($formData['mess']) || $formData['mess']<1000 || $formData['mess']>10000){
            $errors['mess'] = "Mess Fee must be 1,000 - 10,000";
        }
        if($formData['hostel']==="" || !is_numeric($formData['hostel']) || $formData['hostel']<10000 || $formData['hostel']>100000){
            $errors['hostel'] = "Hostel Fee must be 10,000 - 1,00,000";
        }
    }

    // If no errors, save to session and redirect to slip page
    if(empty($errors)){
        $_SESSION['formData'] = $formData;
        header("Location: slip.php");
        exit();
    } else {
        $_SESSION['errors'] = $errors;
    }
}
$errors = $_SESSION['errors'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Dynamic Fee Slip Generator</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
body{font-family: 'Roboto',sans-serif;background:#eef3f8;display:flex;justify-content:center;padding:30px;}
.container{width:470px;background:#fff;padding:30px;border-radius:12px;box-shadow:0 0 18px rgba(0,0,0,0.15);}
h2{text-align:center;color:#2b4c7e;margin-bottom:20px;}
.field{margin-bottom:15px;}
label{font-weight:600;display:block;margin-bottom:5px;}
input, select{width:100%;height:42px;padding:10px;border:2px solid #c6ccd4;border-radius:8px;font-size:15px;box-sizing:border-box;}
input:focus, select:focus{border-color:#2b4c7e;}
.error{color:#d10000;font-size:14px;margin-top:3px;font-weight:600;}
button{width:100%;padding:12px;background:#2b4c7e;border:none;border-radius:8px;color:#fff;font-size:17px;cursor:pointer;font-weight:600;}
button:hover{background:#1e375b;}
.hostel-group{display:<?=($formData['category']==='Hosteller')?'block':'none'?>;}
</style>
<script>
$(function(){
    $("#studentName").focus();
    function toggleHostel(){ $(".hostel-group").toggle($("#category").val()==="Hosteller"); }
    toggleHostel();
    $("#category").change(toggleHostel);

    $("#studentName").on("input",function(){this.value=this.value.replace(/[^A-Za-z ]/g,'').substring(0,20);});
    const rangeInput=(selector,max)=>$(selector).on("input",function(){this.value=this.value.replace(/[^0-9]/g,''); if(Number(this.value)>max)this.value=max;});
    rangeInput("#tuition",100000); rangeInput("#exam",10000); rangeInput("#lab",5000); rangeInput("#mess",10000); rangeInput("#hostel",100000);

    $("input, select").on("input change", function(){ $(this).siblings(".error").text(""); });
});
</script>
</head>
<body>
<div class="container">
<h2>Dynamic Fee Slip Generator</h2>
<form method="POST" novalidate>
    <div class="field">
        <label>Student Name *</label>
        <input type="text" name="studentName" id="studentName" placeholder="Max 20 letters" value="<?=$formData['studentName']?>">
        <div class="error"><?=$errors['studentName']??''?></div>
    </div>
    <div class="field">
        <label>Tuition Fee *</label>
        <input type="text" name="tuition" id="tuition" placeholder="10000 - 100000" value="<?=$formData['tuition']?>">
        <div class="error"><?=$errors['tuition']??''?></div>
    </div>
    <div class="field">
        <label>Exam Fee *</label>
        <input type="text" name="exam" id="exam" placeholder="2000 - 10000" value="<?=$formData['exam']?>">
        <div class="error"><?=$errors['exam']??''?></div>
    </div>
    <div class="field">
        <label>Lab Fee *</label>
        <input type="text" name="lab" id="lab" placeholder="1000 - 5000" value="<?=$formData['lab']?>">
        <div class="error"><?=$errors['lab']??''?></div>
    </div>
    <div class="field">
        <label>Category *</label>
        <select name="category" id="category">
            <option value="">-- Select --</option>
            <option value="Day Scholar" <?=($formData['category']==='Day Scholar')?'selected':''?>>Day Scholar</option>
            <option value="Hosteller" <?=($formData['category']==='Hosteller')?'selected':''?>>Hosteller</option>
        </select>
        <div class="error"><?=$errors['category']??''?></div>
    </div>
    <div class="hostel-group">
        <div class="field">
            <label>Mess Fee *</label>
            <input type="text" name="mess" id="mess" placeholder="1000 - 10000" value="<?=$formData['mess']?>">
            <div class="error"><?=$errors['mess']??''?></div>
        </div>
        <div class="field">
            <label>Hostel Fee *</label>
            <input type="text" name="hostel" id="hostel" placeholder="10000 - 100000" value="<?=$formData['hostel']?>">
            <div class="error"><?=$errors['hostel']??''?></div>
        </div>
    </div>
    <button type="submit">Generate Fee Slip</button>
</form>
</div>
</body>
</html>
