<?php
session_start();
$submitted = false;
$errors = [];
$studentName = "";
$subjects = $credits = [];
$result = "";
$missingCredits = 0;

// Handle POST submission
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $submitted = true;

    // Validate student name
    $studentName = trim($_POST['studentName']);
    if($studentName === ""){
        $errors['studentName'] = "Enter student name";
    } elseif(!preg_match("/^[A-Za-z ]{1,20}$/", $studentName)){
        $errors['studentName'] = "Only letters/spaces allowed (max 20)";
    }

    // Collect subject names and credits
    for($i=1;$i<=6;$i++){
        $sub = trim($_POST["subject$i"]);
        $cred = trim($_POST["credit$i"]);

        if($sub === ""){
            $errors["subject$i"] = "Enter subject name";
        } elseif(!preg_match("/^[A-Za-z ]{1,20}$/", $sub)){
            $errors["subject$i"] = "Only letters/spaces allowed (max 20)";
        }

        if($cred === ""){
            $errors["credit$i"] = "Enter credits";
        } elseif(!preg_match("/^(?:[1-9]|[1-2][0-9]|30)$/", $cred)){
            $errors["credit$i"] = "Enter valid number (1-30)";
        }

        $subjects[$i] = $sub;
        $credits[$i] = $cred;
    }

    // Calculate total credits if no errors
    if(empty($errors)){
        $totalCredits = array_sum($credits);
        if($totalCredits >= 120){
            $result = "Eligible for Graduation ✅";
        } else {
            $missingCredits = 120 - $totalCredits;
            $result = "Pending ⚠️ (Missing {$missingCredits} credits)";
        }

        // Store result in session and redirect to clear POST
        $_SESSION['result'] = $result;
        $_SESSION['missingCredits'] = $missingCredits;
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }
}

// Retrieve result from session after redirect
if(isset($_SESSION['result'])){
    $submitted = true;
    $result = $_SESSION['result'];
    $missingCredits = $_SESSION['missingCredits'];
    unset($_SESSION['result'], $_SESSION['missingCredits']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Credit Eligibility Validator</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<style>
/* Remove arrows from number inputs */
input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
input[type=number] {
    -moz-appearance:textfield;
}
</style>
</head>
<body class="bg-gradient-to-r from-indigo-100 to-indigo-200 min-h-screen flex items-center justify-center p-6">
<div class="bg-white shadow-2xl rounded-2xl p-8 w-full max-w-xl">
<h2 class="text-3xl font-bold text-center mb-6 text-gray-800">Graduation Credit Validator</h2>

<form id="creditForm" method="post" class="space-y-4" novalidate>

    <!-- Student Name -->
    <div>
        <label class="block font-semibold text-gray-700">Student Name <span class="text-red-500">*</span></label>
        <input type="text" name="studentName" id="studentName" value="<?php echo htmlspecialchars($studentName); ?>"
        class="mt-1 w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
        placeholder="Enter student name" maxlength="20">
        <div class="text-red-600 text-sm mt-1" id="errStudent"><?php echo $errors['studentName'] ?? ''; ?></div>
    </div>

    <?php for($i=1;$i<=6;$i++): ?>
    <div class="flex flex-col md:flex-row md:space-x-4 space-y-2 md:space-y-0">
        <div class="flex-1">
            <label class="block font-semibold text-gray-700">Subject <?php echo $i; ?> <span class="text-red-500">*</span></label>
            <input type="text" name="subject<?php echo $i; ?>" id="subject<?php echo $i; ?>"
            value="<?php echo htmlspecialchars($subjects[$i] ?? ''); ?>"
            class="mt-1 w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder="Enter subject name" maxlength="20">
            <div class="text-red-600 text-sm mt-1" id="errSub<?php echo $i; ?>"><?php echo $errors["subject$i"] ?? ''; ?></div>
        </div>
        <div class="flex-1">
            <label class="block font-semibold text-gray-700">Credits <span class="text-red-500">*</span></label>
            <input type="number" name="credit<?php echo $i; ?>" id="credit<?php echo $i; ?>"
            value="<?php echo htmlspecialchars($credits[$i] ?? ''); ?>"
            class="mt-1 w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder="Enter earned credits" min="1" max="30">
            <div class="text-red-600 text-sm mt-1" id="errCred<?php echo $i; ?>"><?php echo $errors["credit$i"] ?? ''; ?></div>
        </div>
    </div>
    <?php endfor; ?>

    <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-lg mt-2">Check Eligibility</button>
</form>

<?php if($submitted && empty($errors)): ?>
<div class="mt-6 text-center p-4 border-2 border-gray-300 rounded-xl bg-indigo-50">
    <h3 class="text-xl font-semibold text-gray-800"><?php echo $result; ?></h3>
    <?php if($missingCredits > 0): ?>
    <p class="text-red-600 mt-2">You need <?php echo $missingCredits; ?> more credits to graduate.</p>
    <?php endif; ?>
</div>
<script>
    // Reset form after showing result
    setTimeout(function(){
        document.getElementById("creditForm").reset();
        document.getElementById("studentName").focus();
    }, 100);
</script>
<?php endif; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){

    $("#studentName").focus();

    // Student Name validation
    $("#studentName").on("input", function(){
        this.value = this.value.replace(/[^A-Za-z ]/g,'').slice(0,20);
        if(this.value.length>0) $("#errStudent").text('');
    });

    <?php for($i=1;$i<=6;$i++): ?>
    $("#subject<?php echo $i; ?>").on("input", function(){
        this.value = this.value.replace(/[^A-Za-z ]/g,'').slice(0,20);
        if(this.value.length>0) $("#errSub<?php echo $i; ?>").text('');
    });
    $("#credit<?php echo $i; ?>").on("input", function(){
        let val = this.value.replace(/[^0-9]/g,'');
        if(val != this.value) this.value = val;
        if(val > 30) val = 30;
        this.value = val;
        if(val.length > 0 && /^(?:[1-9]|[1-2][0-9]|30)$/.test(val)) $("#errCred<?php echo $i; ?>").text('');
    });
    <?php endfor; ?>

});
</script>
</div>
</body>
</html>
