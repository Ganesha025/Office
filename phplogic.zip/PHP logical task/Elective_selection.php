<?php
// elective_selection.php
$submitted = false;
$studentName = "";
$selectedElectives = [];
$errors = [];

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $submitted = true;
    $studentName = trim($_POST['studentName']);
    $selectedElectives = $_POST['electives'] ?? [];

    // Validate name
    if($studentName === ""){
        $errors['studentName'] = "Enter student name";
    } elseif(!preg_match("/^[A-Za-z ]{1,20}$/",$studentName)){
        $errors['studentName'] = "Name must contain only letters and spaces (max 20 chars)";
    }

    // Validate electives
    if(count($selectedElectives) === 0){
        $errors['electives'] = "Select at least one elective";
    } elseif(count($selectedElectives) > 3){
        $errors['electives'] = "Maximum 3 electives can be selected";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Elective Subject Selection</title>
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(120deg,#a1c4fd,#c2e9fb);
    display: flex;
    justify-content: center;
    padding: 20px;
}
.container {
    width: 700px;
    background: #fff;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 15px 30px rgba(0,0,0,0.2);
}
h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #333;
}
label span { color:red; }
input[type=text] {
    width: 100%;
    padding: 10px;
    border-radius: 8px;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
input[type=text]:focus {
    border-color: #007bff;
    outline: none;
    box-shadow: 0 0 5px rgba(0,123,255,0.5);
}
.checkbox-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px 40px;
    margin-top: 10px;
}
.checkbox-grid label {
    display: flex;
    align-items: center;
    gap: 5px;
}
.error {
    color:red;
    font-size: 13px;
    margin-top: 5px;
}
button {
    width: 100%;
    padding: 14px;
    border-radius: 10px;
    border: none;
    background: #007bff;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    margin-top: 15px;
}
button:hover { background: #0056b3; }
.result {
    margin-top: 20px;
    padding: 20px;
    background: #f1f1f1;
    border-radius: 10px;
}
ul { padding-left: 20px; }
</style>
</head>
<body>
<div class="container">
<h2>Elective Subject Selection</h2>

<form id="electiveForm" method="post" action="" novalidate>
<label>Student Name <span>*</span></label>
<input type="text" name="studentName" id="studentName" maxlength="20" placeholder="Enter student name">
<div class="error" id="nameError"><?php echo $errors['studentName'] ?? ''; ?></div>

<label>Select Electives (Max 3) <span>*</span></label>
<div class="checkbox-grid">
    <?php
    $electives = ["AI","ML","Cloud Computing","IoT","Blockchain","Cyber Security","Data Science","Web Dev","Mobile App","Big Data"];
    foreach($electives as $sub){
        echo "<label><input type='checkbox' name='electives[]' class='elective' value='$sub'> $sub</label>";
    }
    ?>
</div>
<div class="error" id="electiveError"><?php echo $errors['electives'] ?? ''; ?></div>

<button type="submit">Submit</button>
</form>

<?php if($submitted && empty($errors)): ?>
<div class="result" id="resultDiv">
    <h3>Selected Electives for <?php echo htmlspecialchars($studentName); ?></h3>
    <ul>
        <?php foreach($selectedElectives as $sub){ echo "<li>".htmlspecialchars($sub)."</li>"; } ?>
    </ul>
</div>
<?php endif; ?>

</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $("#studentName").focus();

    // Allow only letters and spaces in student name
    $("#studentName").on('input', function(){
        this.value = this.value.replace(/[^A-Za-z ]/g,'');
        if(this.value.length > 20) this.value = this.value.slice(0,20);
        if(this.value.length > 0) $("#nameError").text('');
    });

    // Max 3 checkboxes selection
    $(".elective").change(function(){
        let checkedCount = $(".elective:checked").length;
        if(checkedCount > 3){
            this.checked = false;
            $("#electiveError").text("Maximum 3 electives can be selected");
        } else {
            $("#electiveError").text('');
        }
    });

    $(".elective").on('change', function(){
        if($(".elective:checked").length > 0) $("#electiveError").text('');
    });

    // Clear form after submission
    <?php if($submitted && empty($errors)): ?>
        $("#electiveForm")[0].reset();
    <?php endif; ?>

    // Reset page completely on refresh
    window.onbeforeunload = function(){ window.scrollTo(0,0); return; };
});
</script>
</body>
</html>
