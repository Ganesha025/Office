<?php
$submitted = false;
$errors = [];
$studentName = "";
$subjects = $attendances = [];

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    // Collect data
    $submitted = true;
    $studentName = trim($_POST['studentName']);

    if($studentName === ""){
        $errors['studentName'] = "Enter student name";
    } elseif(!preg_match("/^[A-Za-z ]{1,20}$/", $studentName)){
        $errors['studentName'] = "Only letters/spaces allowed (max 20)";
    }

    for($i = 1; $i <= 5; $i++){
        $sub = trim($_POST["subject$i"]);
        $att = trim($_POST["attendance$i"]);

        if($sub === ""){
            $errors["subject$i"] = "Enter subject name";
        } elseif(!preg_match("/^[A-Za-z ]{1,20}$/", $sub)){
            $errors["subject$i"] = "Only letters/spaces allowed (max 20)";
        }

        if($att === ""){
            $errors["attendance$i"] = "Enter attendance %";
        } elseif(!preg_match("/^(100|[0-9]{1,2})$/", $att)){
            $errors["attendance$i"] = "Must be 0-100";
        }

        $subjects[$i] = $sub;
        $attendances[$i] = $att;
    }

    // If no errors, redirect to self using GET to prevent resubmission
    if(empty($errors)){
        // Store results in session temporarily
        session_start();
        $_SESSION['studentName'] = $studentName;
        $_SESSION['subjects'] = $subjects;
        $_SESSION['attendances'] = $attendances;

        // Redirect to GET
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }
}

// Check for session data (after redirect)
session_start();
if(isset($_SESSION['studentName'])){
    $submitted = true;
    $studentName = $_SESSION['studentName'];
    $subjects = $_SESSION['subjects'];
    $attendances = $_SESSION['attendances'];

    // Clear session immediately so refresh won't repeat
    unset($_SESSION['studentName'], $_SESSION['subjects'], $_SESSION['attendances']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Attendance Pattern Visualizer</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{font-family:Arial, sans-serif;background:linear-gradient(135deg,#74ebd5,#9face6);display:flex;justify-content:center;padding:30px;}
.container{width:850px;background:#fff;border-radius:12px;padding:25px;box-shadow:0 10px 25px rgba(0,0,0,0.2);}
h2{text-align:center;margin-bottom:20px;color:#222;}
label{font-weight:600;} label span{color:red;}
input[type=text],input[type=number]{padding:10px;width:100%;margin:5px 0 10px;border:1px solid #aaa;border-radius:8px;-moz-appearance:textfield;}
input::-webkit-outer-spin-button,input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0;}
input:focus{border-color:#007bff;}
.error{color:red;font-size:13px;margin-top:-7px;margin-bottom:7px;}
.row{display:flex;justify-content:space-between;gap:25px;}
.col{width:48%;}
button{width:100%;padding:12px;font-size:16px;border:none;border-radius:8px;background:#007bff;color:#fff;cursor:pointer;}
button:hover{background:#0056b3;}
table{width:100%;margin-top:20px;border-collapse:collapse;}
table,th,td{border:1px solid #444;}
th,td{padding:10px;text-align:center;}
.low{background:#ffb3b3;font-weight:bold;color:#b30000;}
.sort-btn{margin-top:10px;background:#28a745;}
.sort-btn:hover{background:#1f7a33;}
</style>
</head>
<body>
<div class="container">
<h2>Subject-Wise Attendance Visualizer</h2>

<form id="attendanceForm" method="post" novalidate>
<label>Student Name <span>*</span></label>
<input type="text" name="studentName" id="studentName" maxlength="20" value="<?php echo htmlspecialchars($studentName); ?>">
<div class="error" id="nameErr"><?php echo $errors['studentName'] ?? ''; ?></div>

<div class="row">
    <div class="col">
        <h4>📘 Subjects</h4>
        <?php for($i=1;$i<=5;$i++): ?>
        <label>Subject <?php echo $i; ?> <span>*</span></label>
        <input type="text" name="subject<?php echo $i; ?>" id="subject<?php echo $i; ?>" maxlength="20" value="<?php echo htmlspecialchars($subjects[$i] ?? ''); ?>">
        <div class="error" id="errSub<?php echo $i; ?>"><?php echo $errors["subject$i"] ?? ''; ?></div>
        <?php endfor; ?>
    </div>
    <div class="col">
        <h4>📊 Attendance %</h4>
        <?php for($i=1;$i<=5;$i++): ?>
        <label>% <?php echo $i; ?> <span>*</span></label>
        <input type="number" name="attendance<?php echo $i; ?>" id="attendance<?php echo $i; ?>" value="<?php echo htmlspecialchars($attendances[$i] ?? ''); ?>" min="0" max="100">
        <div class="error" id="errAtt<?php echo $i; ?>"><?php echo $errors["attendance$i"] ?? ''; ?></div>
        <?php endfor; ?>
    </div>
</div>

<button type="submit">Visualize Attendance</button>
</form>

<?php if($submitted && empty($errors)): ?>
<table id="dataTable">
<tr><th>Subject</th><th>Attendance %</th></tr>
<?php for($i=1;$i<=5;$i++): ?>
<tr class="<?php echo ($attendances[$i] < 75) ? 'low' : ''; ?>">
<td><?php echo htmlspecialchars($subjects[$i]); ?></td>
<td><?php echo htmlspecialchars($attendances[$i]); ?></td>
</tr>
<?php endfor; ?>
</table>
<button class="sort-btn" id="sortBtn">Sort by Attendance %</button>
<?php endif; ?>

</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){

    $("#studentName").focus();

    $("#studentName").on("input", function(){
        this.value = this.value.replace(/[^A-Za-z ]/g,'').slice(0,20);
        if(this.value.length>0) $("#nameErr").text('');
    });

    <?php for($i=1;$i<=5;$i++): ?>
    $("#subject<?php echo $i; ?>").on("input", function(){
        this.value = this.value.replace(/[^A-Za-z ]/g,'').slice(0,20);
        if(this.value.length>0) $("#errSub<?php echo $i; ?>").text('');
    });
    $("#attendance<?php echo $i; ?>").on("input", function(){
        let val = this.value.replace(/[^0-9]/g,'');
        if(val > 100) val = 100;
        this.value = val;
        if(this.value.length>0) $("#errAtt<?php echo $i; ?>").text('');
    });
    <?php endfor; ?>

    $("#sortBtn").click(function(){
        let rows = $("#dataTable tr").slice(1).toArray();
        rows.sort(function(a,b){
            return parseInt($(a).children().eq(1).text()) - parseInt($(b).children().eq(1).text());
        });
        $("#dataTable").append(rows);
    });

});
</script>

</body>
</html>
