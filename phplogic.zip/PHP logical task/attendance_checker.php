<?php
session_start();
$result = "";
$color = "";

if($_SERVER['REQUEST_METHOD'] === "POST"){
    $name = $_POST['name'] ?? '';
    $total = $_POST['total'] ?? '';
    $present = $_POST['present'] ?? '';

    $errors = [];

    // Validate student name
    if($name === '' || !preg_match("/^[a-zA-Z ]{1,20}$/", $name)){
        $errors['name'] = "Enter valid name (letters & spaces only, max 20)";
    }
    // Validate total days
    if($total === '' || !is_numeric($total) || $total < 1 || $total > 120){
        $errors['total'] = "Total working days must be 1-120";
    }
    // Validate present days
    if($present === '' || !is_numeric($present) || $present < 0 || $present > $total){
        $errors['present'] = "Present days must be 0-"+($total ?: 120);
    }

    if(empty($errors)){
        $percentage = ($present / $total) * 100;
        $result = "$name - ".round($percentage,2)."% - ".($percentage >= 75 ? "Eligible" : "Not Eligible");
        $color = $percentage >= 75 ? "green" : "red";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Attendance Eligibility Checker</title>
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(120deg, gray, #8fd3f4);
    display: flex;
    justify-content: center;
    padding: 30px;
}
.container {
    width: 400px;
    background: #fff;
    padding: 25px 30px;
    border-radius: 12px;
    box-shadow: 0px 10px 25px rgba(0,0,0,0.2);
}
h2 { text-align: center; margin-bottom: 20px; color: #333; }
label { font-weight: 600; display: block; margin-top: 15px; color: #555; }
label span { color: red; }
input {
    width: 100%;
    padding: 12px 10px;
    font-size: 16px;
    margin-top: 5px;
    border-radius: 8px;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
input:focus { border-color: #007bff; box-shadow: 0 0 5px rgba(0,123,255,0.5); outline: none; }
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
input[type=number] { -moz-appearance: textfield; }
.error { color: red; font-size: 13px; margin-top: 3px; }
button {
    width: 100%;
    background: #007bff;
    color: #fff;
    padding: 14px;
    font-size: 16px;
    margin-top: 20px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: 0.3s;
}
button:hover { background: #0056b3; }
#percentagePreview { margin-top: 15px; font-weight: bold; }
#result { margin-top: 20px; font-size: 18px; font-weight: bold; }
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $("#name").focus();
    function validateName(){
        let val = $("#name").val();
        if(val === "") { $("#nameError").text("Required"); return false; }
        if(!/^[a-zA-Z ]{1,20}$/.test(val)) { 
            $("#nameError").text("Letters & spaces only, max 20"); return false; 
        }
        $("#nameError").text(""); return true;
    }

    function validateTotal(){
        let val = $("#total").val();
        if(val === "") { $("#totalError").text("Required"); return false; }
        val = parseInt(val);
        if(isNaN(val) || val < 1 || val > 120) { 
            $("#totalError").text("1-120 only"); return false; 
        }
        $("#totalError").text(""); return true;
    }

    function validatePresent(){
        let total = parseInt($("#total").val()) || 120;
        let val = parseInt($("#present").val());
        if($("#present").val() === "") { $("#presentError").text("Required"); return false; }
        if(isNaN(val) || val < 0 || val > total) { 
            $("#presentError").text("0-"+total); return false; 
        }
        $("#presentError").text(""); return true;
    }

    function updatePreview(){
        let total = parseInt($("#total").val());
        let present = parseInt($("#present").val());
        if(isNaN(total) || isNaN(present) || total < 1 || present < 0 || present > total){
            $("#percentagePreview").text(""); return;
        }
        let percent = (present/total*100).toFixed(2);
        $("#percentagePreview").text("Attendance: "+percent+"%").css("color","blue");
    }

    $("#name").on("input blur", function(){
        // restrict letters and spaces only
        let val = $(this).val().replace(/[^a-zA-Z ]/g,'').substring(0,20);
        $(this).val(val);
        validateName();
    });

    $("#total").on("input blur", function(){
        let val = $(this).val().replace(/[^0-9]/g,'');
        if(val !== "" && parseInt(val) > 120) val = "120";
        $(this).val(val);
        validateTotal();
        updatePreview();
    });

    $("#present").on("input blur", function(){
        let val = $(this).val().replace(/[^0-9]/g,'');
        let maxVal = parseInt($("#total").val()) || 120;
        if(val !== "" && parseInt(val) > maxVal) val = maxVal;
        $(this).val(val);
        validatePresent();
        updatePreview();
    });

    $("#attendanceForm").on("submit", function(e){
        let valid = validateName() & validateTotal() & validatePresent();
        if(!valid) e.preventDefault(); // prevent submit if any invalid
    });

});
</script>
</head>
<body>
<div class="container">
<h2>Attendance Eligibility Checker</h2>
<form method="POST" id="attendanceForm" novalidate>
    <label>Student Name <span>*</span></label>
    <input type="text" name="name" id="name" placeholder="Enter Name">
    <span class="error" id="nameError"></span>

    <label>Total Working Days <span>*</span></label>
    <input type="number" name="total" id="total" min="1" max="120">
    <span class="error" id="totalError"></span>

    <label>Present Days <span>*</span></label>
    <input type="number" name="present" id="present" min="0" max="120">
    <span class="error" id="presentError"></span>

    <div id="percentagePreview"></div>

    <button type="submit">Check Eligibility</button>
</form>

<?php if($result!=""): ?>
<div id="result" style="color:<?=$color?>;"><?=htmlspecialchars($result)?></div>
<?php endif; ?>
</div>
</body>
</html>
