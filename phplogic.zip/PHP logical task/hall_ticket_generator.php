<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dynamic Hall Ticket Generator</title>
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(120deg, #f6d365, #fda085);
    display: flex;
    justify-content: center;
    align-items: flex-start;
    min-height: 100vh;
    padding: 20px;
}
.container {
    width: 550px;
    background: #fff;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0px 15px 30px rgba(0,0,0,0.2);
}
h2 { text-align: center; color: #333; margin-bottom: 20px; }
label { font-weight: 600; display: block; margin-top: 15px; color: #555; }
label span { color: red; }
input, select {
    width: 100%; padding: 12px 10px; font-size: 16px;
    margin-top: 5px; border-radius: 8px; border: 1px solid #ccc; box-sizing: border-box;
}
input:focus, select:focus { border-color: #007bff; box-shadow: 0 0 5px rgba(0,123,255,0.5); outline: none; }
.error { color: red; font-size: 13px; margin-top: 3px; }
button {
    width: 100%; background: #007bff; color: #fff; padding: 14px; font-size: 16px;
    margin-top: 20px; border: none; border-radius: 10px; cursor: pointer;
}
button:hover { background: #0056b3; }
#subjectsBox {
    border: 1px solid #888; padding: 10px; min-height: 80px; border-radius: 8px;
    background: #f0f0f0; margin-top: 5px; display: none;
}
ul { margin: 0; padding-left: 20px; }
</style>
</head>
<body>
<div class="container">
<h2>Hall Ticket Generator</h2>

<!-- Student Name -->
<label>Student Name <span>*</span></label>
<input type="text" id="studentName" maxlength="20" placeholder="Enter Student Name">
<span class="error" id="nameError"></span>

<label>Register Number <span>*</span></label>
<input type="text" id="regno" maxlength="8" placeholder="Ex: 22ECE023">
<span class="error" id="regError"></span>

<label>Department <span>*</span></label>
<select id="dept">
    <option value="">Select Department</option>
    <option value="ECE">ECE</option>
    <option value="CSE">CSE</option>
    <option value="EEE">EEE</option>
    <option value="MECH">MECH</option>
    <option value="CIVIL">CIVIL</option>
</select>
<span class="error" id="deptError"></span>

<label>Semester <span>*</span></label>
<select id="semester">
    <option value="">Select Semester</option>
    <?php for($i=1;$i<=8;$i++) echo "<option value='$i'>$i</option>"; ?>
</select>
<span class="error" id="semError"></span>

<label>Subjects</label>
<div id="subjectsBox">Select Department and Semester</div>

<button id="generate">Generate Hall Ticket</button>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$("#studentName").focus();

// All departments & semesters with subjects
let subjects = {
    ECE: {
        1:[{name:"Basic Electronics",credits:4},{name:"Maths I",credits:3},{name:"Physics",credits:3},{name:"Chemistry",credits:3},{name:"C Programming",credits:3},{name:"English",credits:2}],
        2:[{name:"Circuit Theory",credits:4},{name:"Maths II",credits:3},{name:"Digital Electronics",credits:3},{name:"Environmental Science",credits:2},{name:"Python",credits:3},{name:"Communication Skills",credits:2}],
        3:[{name:"Analog Devices",credits:4},{name:"Signals",credits:3},{name:"Maths III",credits:3},{name:"Data Structures",credits:3},{name:"Electromagnetics",credits:3},{name:"Control Systems",credits:3}],
        4:[{name:"Microprocessor",credits:4},{name:"Network Theory",credits:3},{name:"Probability",credits:3},{name:"OOPS",credits:3},{name:"Measurement",credits:3},{name:"Sensors",credits:3}],
        5:[{name:"Communication Systems",credits:4},{name:"VLSI",credits:3},{name:"DSP",credits:3},{name:"Power Electronics",credits:3},{name:"Antenna",credits:3},{name:"Embedded",credits:3}],
        6:[{name:"Wireless",credits:3},{name:"Optical",credits:3},{name:"Robotics",credits:3},{name:"IoT",credits:3},{name:"Elective-1",credits:3},{name:"Lab-1",credits:2}],
        7:[{name:"Satellite",credits:3},{name:"5G Tech",credits:3},{name:"Automotive",credits:3},{name:"EV Systems",credits:3},{name:"Elective-2",credits:3},{name:"Mini Project",credits:2}],
        8:[{name:"Project",credits:3},{name:"Internship",credits:2},{name:"Seminar",credits:2},{name:"Elective-3",credits:3},{name:"Elective-4",credits:3},{name:"Personality Dev",credits:2}]
    },
    CSE: {
        1:[{name:"Maths I",credits:3},{name:"C Programming",credits:3},{name:"Physics",credits:3},{name:"Chemistry",credits:3},{name:"English",credits:2},{name:"Engineering Drawing",credits:2}],
        2:[{name:"Maths II",credits:3},{name:"DSA",credits:3},{name:"OOPS",credits:3},{name:"DBMS",credits:3},{name:"EVS",credits:2},{name:"Digital Logic",credits:3}],
        3:[{name:"OS",credits:3},{name:"CN",credits:3},{name:"Algorithms",credits:3},{name:"DBMS-II",credits:3},{name:"TOC",credits:3},{name:"Java",credits:3}],
        4:[{name:"Cloud",credits:3},{name:"AI",credits:3},{name:"ML",credits:3},{name:"DAA",credits:3},{name:"Python",credits:3},{name:"Cyber Security",credits:3}],
        5:[{name:"Compiler",credits:3},{name:"Big Data",credits:3},{name:"BlockChain",credits:3},{name:"SE",credits:3},{name:"Elective-1",credits:3},{name:"Lab-1",credits:2}],
        6:[{name:"DL",credits:3},{name:"VR/AR",credits:3},{name:"Elective-2",credits:3},{name:"Mini Project",credits:2},{name:"Mobile Computing",credits:3},{name:"Lab-2",credits:2}],
        7:[{name:"Cloud Security",credits:3},{name:"OS-Advanced",credits:3},{name:"DS-Advanced",credits:3},{name:"Capstone",credits:2},{name:"Elective-3",credits:3},{name:"Project-I",credits:2}],
        8:[{name:"Internship",credits:2},{name:"Project-II",credits:3},{name:"Seminar",credits:2},{name:"Elective-4",credits:3},{name:"Elective-5",credits:3},{name:"Research",credits:2}]
    },
    EEE: {
        1:[{name:"Electrical Circuits I",credits:4},{name:"Maths I",credits:3},{name:"Physics",credits:3},{name:"Chemistry",credits:3},{name:"C Programming",credits:3},{name:"English",credits:2}],
        2:[{name:"Electrical Circuits II",credits:4},{name:"Maths II",credits:3},{name:"Electronics",credits:3},{name:"Environmental Science",credits:2},{name:"Python",credits:3},{name:"Communication Skills",credits:2}],
        3:[{name:"Control Systems",credits:3},{name:"Power Electronics",credits:3},{name:"Signals",credits:3},{name:"Maths III",credits:3},{name:"Machines",credits:3},{name:"Measurements",credits:3}],
        4:[{name:"Electrical Machines II",credits:4},{name:"Network Theory",credits:3},{name:"Probability",credits:3},{name:"OOPS",credits:3},{name:"Sensors",credits:3},{name:"Microprocessor",credits:3}],
        5:[{name:"Power Systems",credits:4},{name:"Renewable Energy",credits:3},{name:"Transmission Lines",credits:3},{name:"Protection Systems",credits:3},{name:"Elective-1",credits:3},{name:"Lab-1",credits:2}],
        6:[{name:"Electric Drives",credits:3},{name:"Robotics",credits:3},{name:"PLC",credits:3},{name:"IoT",credits:3},{name:"Elective-2",credits:3},{name:"Lab-2",credits:2}],
        7:[{name:"Smart Grid",credits:3},{name:"Power Quality",credits:3},{name:"High Voltage",credits:3},{name:"Project-I",credits:2},{name:"Elective-3",credits:3},{name:"Mini Project",credits:2}],
        8:[{name:"Internship",credits:2},{name:"Project-II",credits:3},{name:"Seminar",credits:2},{name:"Elective-4",credits:3},{name:"Elective-5",credits:3},{name:"Research",credits:2}]
    },
    MECH: {
        1:[{name:"Engineering Mechanics",credits:3},{name:"Maths I",credits:3},{name:"Physics",credits:3},{name:"Chemistry",credits:3},{name:"C Programming",credits:3},{name:"English",credits:2}],
        2:[{name:"Thermodynamics I",credits:3},{name:"Maths II",credits:3},{name:"Materials Science",credits:3},{name:"Environmental Science",credits:2},{name:"Python",credits:3},{name:"Communication Skills",credits:2}],
        3:[{name:"Fluid Mechanics",credits:3},{name:"Dynamics",credits:3},{name:"Maths III",credits:3},{name:"Manufacturing Processes",credits:3},{name:"Data Structures",credits:3},{name:"Control Systems",credits:3}],
        4:[{name:"Thermodynamics II",credits:4},{name:"Machine Design",credits:3},{name:"OOPS",credits:3},{name:"Mechanics of Materials",credits:3},{name:"Sensors",credits:3},{name:"Microprocessor",credits:3}],
        5:[{name:"Heat Transfer",credits:4},{name:"CAD/CAM",credits:3},{name:"Automobile Engg",credits:3},{name:"Robotics",credits:3},{name:"Elective-1",credits:3},{name:"Lab-1",credits:2}],
        6:[{name:"Mechatronics",credits:3},{name:"HVAC",credits:3},{name:"Industrial Engg",credits:3},{name:"IoT",credits:3},{name:"Elective-2",credits:3},{name:"Lab-2",credits:2}],
        7:[{name:"Automation",credits:3},{name:"Vehicle Dynamics",credits:3},{name:"Project-I",credits:2},{name:"Elective-3",credits:3},{name:"Elective-4",credits:3},{name:"Mini Project",credits:2}],
        8:[{name:"Internship",credits:2},{name:"Project-II",credits:3},{name:"Seminar",credits:2},{name:"Elective-5",credits:3},{name:"Research",credits:2},{name:"Personality Dev",credits:2}]
    },
    CIVIL: {
        1:[{name:"Engineering Mechanics",credits:3},{name:"Maths I",credits:3},{name:"Physics",credits:3},{name:"Chemistry",credits:3},{name:"Drawing",credits:2},{name:"English",credits:2}],
        2:[{name:"Surveying",credits:3},{name:"Maths II",credits:3},{name:"Materials Science",credits:3},{name:"Environmental Science",credits:2},{name:"Python",credits:3},{name:"Communication Skills",credits:2}],
        3:[{name:"Structural Analysis I",credits:3},{name:"Fluid Mechanics",credits:3},{name:"Maths III",credits:3},{name:"Construction Materials",credits:3},{name:"Mechanics",credits:3},{name:"CAD",credits:3}],
        4:[{name:"Structural Analysis II",credits:4},{name:"Concrete Technology",credits:3},{name:"OOPS",credits:3},{name:"Soil Mechanics",credits:3},{name:"Surveying Lab",credits:2},{name:"Microprocessor",credits:3}],
        5:[{name:"Transportation Engg",credits:4},{name:"Hydraulics",credits:3},{name:"Water Resources",credits:3},{name:"Building Design",credits:3},{name:"Elective-1",credits:3},{name:"Lab-1",credits:2}],
        6:[{name:"Construction Management",credits:3},{name:"Geotechnical Engg",credits:3},{name:"Structural Design",credits:3},{name:"Project Planning",credits:3},{name:"Elective-2",credits:3},{name:"Lab-2",credits:2}],
        7:[{name:"Environmental Engg",credits:3},{name:"Advanced Structures",credits:3},{name:"Project-I",credits:2},{name:"Elective-3",credits:3},{name:"Elective-4",credits:3},{name:"Mini Project",credits:2}],
        8:[{name:"Internship",credits:2},{name:"Project-II",credits:3},{name:"Seminar",credits:2},{name:"Elective-5",credits:3},{name:"Research",credits:2},{name:"Personality Dev",credits:2}]
    }
};

// Show subjects dynamically
function showSubjects(){
    let dept=$("#dept").val();
    let sem=$("#semester").val();
    if(subjects[dept] && subjects[dept][sem]){
        let html="<ul>";
        subjects[dept][sem].forEach(s=> html+=`<li>${s.name} (${s.credits} credits)</li>`);
        html+="</ul>";
        $("#subjectsBox").html(html).show();
    } else { $("#subjectsBox").hide(); }
}
$("#dept, #semester").change(showSubjects);

// Name validation
$("#studentName").on('input', function(){
    this.value=this.value.replace(/[^A-Za-z ]/g,'').slice(0,20);
    if(this.value.length>0) $("#nameError").text('');
});

// Generate Hall Ticket
$("#generate").click(function(){
    let name = $("#studentName").val().trim();
    let reg=$("#regno").val().toUpperCase(), dept=$("#dept").val(), sem=$("#semester").val();
    let valid=true;
    $(".error").text("");

    if(name===""){ valid=false; $("#nameError").text("Enter Student Name"); }
    if(!/^\d{2}[A-Z]{3}\d{3}$/.test(reg)){ valid=false; $("#regError").text("Enter valid Reg No (Ex: 22ECE023)"); }
    if(dept===""){ valid=false; $("#deptError").text("Select Department"); }
    if(sem===""){ valid=false; $("#semError").text("Select Semester"); }

    if(!valid) return;

    let list = subjects[dept][sem];
    let params = new URLSearchParams();
    params.append("name", name);
    params.append("reg", reg);
    params.append("dept", dept);
    params.append("sem", sem);
    params.append("date", new Date().toLocaleDateString());
    list.forEach((s,i)=>{ params.append("sub"+(i+1), s.name); params.append("credit"+(i+1), s.credits); });

    window.open("hall_ticket_print.php?"+params.toString(), "_blank");
});

// Hide errors dynamically
$("#regno").on('input', function(){ this.value=this.value.toUpperCase(); if(/^\d{2}[A-Z]{3}\d{3}$/.test(this.value)) $("#regError").text(""); });
$("#dept, #semester").change(function(){ if($(this).val()!="") $(this).next(".error").text(""); });
</script>
</body>
</html>
