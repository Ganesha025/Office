<?php
session_start();
if(!isset($_SESSION['formData'])){
    header("Location: index.php");
    exit();
}
$data = $_SESSION['formData'];
$total = $data['tuition'] + $data['exam'] + $data['lab'];
if($data['category']==='Hosteller'){
    $total += $data['mess'] + $data['hostel'];
}
// Clear session for next input
unset($_SESSION['formData']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Official Fee Slip</title>
<style>
body {
    font-family: 'Arial', sans-serif;
    background: #f5f5f5;
    display: flex;
    justify-content: center;
    padding: 20px;
}
.fee-slip {
    width: 600px;
    background: #fff;
    padding: 30px;
    border: 2px solid #333;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    position: relative;
}
.fee-slip::before {
    content: "INSTITUTE OF TECHNOLOGY";
    position: absolute;
    top: -25px;
    left: 0;
    width: 100%;
    text-align: center;
    font-size: 18px;
    font-weight: bold;
    color: #2b4c7e;
}
.fee-slip::after {
    content: "FEE SLIP";
    position: absolute;
    top: 10px;
    left: 0;
    width: 100%;
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    color: #2b4c7e;
}
.slip-header {
    text-align: center;
    margin-bottom: 20px;
    font-weight: bold;
    font-size: 16px;
    text-decoration: underline;
}
.slip-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}
.slip-table td, .slip-table th {
    padding: 10px;
    border: 1px solid #333;
}
.slip-table th {
    background: #2b4c7e;
    color: #fff;
    font-weight: bold;
}
.slip-table tr.total td {
    font-weight: bold;
    background: #f0f0f0;
}
.footer {
    margin-top: 30px;
    display: flex;
    justify-content: space-between;
}
.footer div {
    text-align: center;
}
.print-btn {
    margin-top: 20px;
    width: 100%;
    padding: 12px;
    background: #2b4c7e;
    color: #fff;
    font-size: 16px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
.print-btn:hover {
    background: #1e375b;
}
@media print {
    .print-btn { display: none; }
}
</style>
</head>
<body>
<div class="fee-slip">
    <table class="slip-table">
        <tr><th colspan="2">STUDENT INFORMATION</th></tr>
        <tr><td>Student Name</td><td><?=htmlspecialchars($data['studentName'])?></td></tr>
        <tr><td>Category</td><td><?=htmlspecialchars($data['category'])?></td></tr>
    </table>

    <table class="slip-table">
        <tr><th colspan="2">FEE DETAILS</th></tr>
        <tr><td>Tuition Fee</td><td><?=number_format($data['tuition'])?></td></tr>
        <tr><td>Exam Fee</td><td><?=number_format($data['exam'])?></td></tr>
        <tr><td>Lab Fee</td><td><?=number_format($data['lab'])?></td></tr>
        <?php if($data['category']==='Hosteller'): ?>
        <tr><td>Mess Fee</td><td><?=number_format($data['mess'])?></td></tr>
        <tr><td>Hostel Fee</td><td><?=number_format($data['hostel'])?></td></tr>
        <?php endif; ?>
        <tr class="total"><td>Total Fee</td><td><?=number_format($total)?></td></tr>
    </table>

    <div class="footer">
        <div>
            <p>__________________</p>
            <p>Student Signature</p>
        </div>
        <div>
            <p>__________________</p>
            <p>Account Officer</p>
        </div>
    </div>

    <button class="print-btn" onclick="window.print()">Print Fee Slip</button>
</div>
</body>
</html>
