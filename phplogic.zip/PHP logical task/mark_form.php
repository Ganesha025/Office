<?php
session_start();
$submitted = false;
$studentName = "";
$subjects = [
    ['name'=>'Mathematics','marks'=>'','credit'=>''],
    ['name'=>'Physics','marks'=>'','credit'=>''],
    ['name'=>'Chemistry','marks'=>'','credit'=>''],
    ['name'=>'English','marks'=>'','credit'=>''],
    ['name'=>'Computer Science','marks'=>'','credit'=>'']
];
$result = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submitted = true;
    $studentName = trim($_POST['studentName'] ?? '');
    $errors = [];

    if ($studentName === "" || !preg_match("/^[A-Za-z ]{1,20}$/", $studentName)) {
        $errors['studentName'] = "Enter valid student name (max 20 letters/spaces)";
    }

    $totalWeighted = 0;
    $totalCredits = 0;

    for ($i=0; $i<count($subjects); $i++) {
        $marks = trim($_POST["marks$i"] ?? '');
        $credit = trim($_POST["credit$i"] ?? '');

        if ($marks === "" || !preg_match("/^(?:[1-9][0-9]?|100)$/", $marks)) {
            $errors["marks$i"] = "Marks must be 1-100";
        }

        if ($credit === "" || !preg_match("/^[1-5]$/", $credit)) {
            $errors["credit$i"] = "Credit must be 1-5";
        }

        $subjects[$i]['marks'] = $marks;
        $subjects[$i]['credit'] = $credit;

        if(empty($errors)){
            $totalWeighted += $marks * $credit;
            $totalCredits += $credit;
        }
    }

    if(empty($errors)){
        $weightedAvg = $totalWeighted/$totalCredits;
        if($weightedAvg>=90) $grade='A';
        elseif($weightedAvg>=75) $grade='B';
        elseif($weightedAvg>=60) $grade='C';
        else $grade='Fail';
        $_SESSION['result'] = ['subjects'=>$subjects,'studentName'=>$studentName,'weightedAvg'=>$weightedAvg,'grade'=>$grade];
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    } else {
        $_SESSION['errors'] = $errors;
    }
}

if(isset($_SESSION['result'])){
    $submitted = true;
    $studentName = $_SESSION['result']['studentName'];
    $subjects = $_SESSION['result']['subjects'];
    $weightedAvg = $_SESSION['result']['weightedAvg'];
    $grade = $_SESSION['result']['grade'];
    unset($_SESSION['result'],$_SESSION['errors']);
}
$errors = $_SESSION['errors'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Professional Marksheet Generator</title>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
body {font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background:#e0f7fa; display:flex; justify-content:center; padding:20px;}
.container {width:750px; background:#ffffff; padding:30px; border-radius:12px; box-shadow:0 10px 25px rgba(0,0,0,0.2);}
h2 {text-align:center; color:#333; margin-bottom:20px;}
label span{color:red;}
input {padding:10px; border-radius:6px; border:1px solid #ccc; width:100%; box-sizing:border-box;}
input:focus {outline:none; border-color:#007bff; box-shadow:0 0 5px rgba(0,123,255,0.5);}
input::-webkit-inner-spin-button, input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0;}
input[type=number]{-moz-appearance:textfield;}
.form-row {display:flex; justify-content:space-between; margin-bottom:10px; gap:10px;}
.field-group {flex:1; display:flex; flex-direction:column;}
.error {color:red; font-size:13px; margin-top:2px;}
button {width:100%; padding:14px; border:none; border-radius:10px; background:#007bff; color:#fff; font-size:16px; cursor:pointer;}
button:hover{background:#0056b3;}
#marksheet {margin-top:20px; display:none;}
table{width:100%;border-collapse:collapse;}
th,td{border:1px solid #333;padding:8px;text-align:center;}
th{background:#007bff;color:#fff;}
.grade{margin-top:15px;font-weight:bold;text-align:center;font-size:18px;}
</style>
</head>
<body>
<div class="container">
<h2>Marksheet Generator</h2>
<form id="marksForm" method="post" novalidate>
<div class="form-row">
<div class="field-group">
<label>Student Name <span>*</span></label>
<input type="text" name="studentName" id="studentName" value="<?=htmlspecialchars($studentName)?>" maxlength="20" placeholder="Enter student name">
<div class="error" id="errName"><?=$errors['studentName']??''?></div>
</div>
</div>

<?php foreach($subjects as $i=>$sub): ?>
<div class="form-row">
<div class="field-group">
<label><?=$sub['name']?> Marks <span>*</span></label>
<input type="number" name="marks<?=$i?>" id="marks<?=$i?>" min="1" max="100" value="<?=$sub['marks']?>" placeholder="1-100">
<div class="error" id="err<?=$i?>"><?=$errors['marks'.$i]??''?></div>
</div>
<div class="field-group">
<label><?=$sub['name']?> Credits <span>*</span></label>
<input type="number" name="credit<?=$i?>" id="credit<?=$i?>" min="1" max="5" value="<?=$sub['credit']?>" placeholder="1-5">
<div class="error" id="errc<?=$i?>"><?=$errors['credit'.$i]??''?></div>
</div>
</div>
<?php endforeach; ?>

<button type="submit">Generate Marksheet</button>
</form>

<?php if($submitted && isset($weightedAvg)): ?>
<div id="marksheet">
<h3>Marksheet for <?=htmlspecialchars($studentName)?></h3>
<table>
<thead>
<tr>
<th>Subject</th><th>Marks</th><th>Credit</th><th>Weighted Contribution</th>
</tr>
</thead>
<tbody>
<?php foreach($subjects as $sub): ?>
<tr>
<td><?=$sub['name']?></td>
<td><?=$sub['marks']?></td>
<td><?=$sub['credit']?></td>
<td><?=($sub['marks']*$sub['credit'])?></td>
</tr>
<?php endforeach;?>
</tbody>
</table>
<p class="grade">Weighted Average: <?=round($weightedAvg,2)?> - Grade: <?=$grade?></p>
</div>
<script>
$(document).ready(function(){
    $('#marksheet').show();
    $('#marksForm')[0].reset();
    $('#studentName').focus();
});
</script>
<?php endif; ?>

<script>
$(document).ready(function(){
    $('#studentName').focus();
    $('#studentName').on('input',function(){
        this.value=this.value.replace(/[^A-Za-z ]/g,'').slice(0,20);
        if(this.value.length>0) $('#errName').text('');
    });
    $('input[type=number]').on('input',function(){
        let min=parseInt($(this).attr('min')), max=parseInt($(this).attr('max')), val=parseInt($(this).val());
        if(isNaN(val)) return;
        if(val<min) $(this).val(min);
        if(val>max) $(this).val(max);
        let id=$(this).attr('id');
        if(id.includes('marks')) $('#err'+id.replace(/\D/g,'')).text('');
        if(id.includes('credit')) $('#errc'+id.replace(/\D/g,'')).text('');
    });
});
</script>
</div>
</body>
</html>
