<?php
$submitted = false;
$errors = [];
$totalStudents = $seatsPerRoom = "";
$rooms = [];
$totalRooms = 0;

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $submitted = true;

    $totalStudents = trim($_POST['totalStudents']);
    $seatsPerRoom = trim($_POST['seatsPerRoom']);

    // Validate Total Students (1–1000)
    if($totalStudents === ""){
        $errors['totalStudents'] = "Enter total students";
    } elseif(!preg_match("/^[0-9]{1,4}$/", $totalStudents) || intval($totalStudents) < 1 || intval($totalStudents) > 1000){
        $errors['totalStudents'] = "Must be a number between 1 and 1000";
    }

    // Validate Seats per Room
    if($seatsPerRoom === ""){
        $errors['seatsPerRoom'] = "Enter seats per room";
    } elseif(!preg_match("/^(?:[1-9]|[1-9][0-9]|100)$/", $seatsPerRoom)){
        $errors['seatsPerRoom'] = "Must be a number between 1 and 100";
    }

    // Calculate rooms if valid
    if(empty($errors)){
        $totalRooms = ceil($totalStudents / $seatsPerRoom);
        $roll = 1;
        for($r=1; $r<=$totalRooms; $r++){
            $rooms[$r] = [];
            for($s=1; $s<=$seatsPerRoom && $roll <= $totalStudents; $s++){
                $rooms[$r][] = $roll++;
            }
        }

        session_start();
        $_SESSION['rooms'] = $rooms;
        $_SESSION['totalRooms'] = $totalRooms;
        $_SESSION['totalStudents'] = $totalStudents;
        $_SESSION['seatsPerRoom'] = $seatsPerRoom;

        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }
}

// Retrieve session data after redirect
session_start();
if(isset($_SESSION['rooms'])){
    $submitted = true;
    $rooms = $_SESSION['rooms'];
    $totalRooms = $_SESSION['totalRooms'];
    $totalStudents = $_SESSION['totalStudents'];
    $seatsPerRoom = $_SESSION['seatsPerRoom'];

    unset($_SESSION['rooms'], $_SESSION['totalRooms'], $_SESSION['totalStudents'], $_SESSION['seatsPerRoom']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Exam Seating Arrangement</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<style>
/* Remove number input arrows */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
input[type=number] {
  -moz-appearance: textfield;
}
</style>
</head>
<body class="bg-gradient-to-r from-blue-100 to-blue-200 min-h-screen flex items-center justify-center p-6">
<div class="bg-white shadow-xl rounded-xl p-8 w-full max-w-lg">
<h2 class="text-2xl font-bold text-center mb-6 text-gray-800">Exam Seating Arrangement</h2>

<form id="seatingForm" method="post" class="space-y-4" novalidate>
    <div>
        <label class="block font-semibold text-gray-700">Total Students <span class="text-red-500">*</span></label>
        <input type="number" name="totalStudents" id="totalStudents" value="<?php echo htmlspecialchars($totalStudents); ?>"
        class="mt-1 w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Enter total students">
        <div class="text-red-600 text-sm mt-1" id="errTotal"><?php echo $errors['totalStudents'] ?? ''; ?></div>
    </div>

    <div>
        <label class="block font-semibold text-gray-700">Seats per Room <span class="text-red-500">*</span></label>
        <input type="number" name="seatsPerRoom" id="seatsPerRoom" value="<?php echo htmlspecialchars($seatsPerRoom); ?>"
        class="mt-1 w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Enter seats per room">
        <div class="text-red-600 text-sm mt-1" id="errSeats"><?php echo $errors['seatsPerRoom'] ?? ''; ?></div>
    </div>

    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg mt-2">Generate Seating Arrangement</button>
</form>

<?php if($submitted && empty($errors)): ?>
<h3 class="mt-6 text-center font-semibold text-gray-800">Total Rooms Needed: <?php echo $totalRooms; ?></h3>
<div class="overflow-x-auto mt-4">
<table class="w-full border-collapse border border-gray-400">
<tr class="bg-blue-600 text-white">
<th class="border border-gray-400 p-2">Room No.</th>
<th class="border border-gray-400 p-2">Roll Numbers</th>
</tr>
<?php foreach($rooms as $roomNo => $rolls): ?>
<tr class="hover:bg-blue-50">
<td class="border border-gray-400 p-2 text-center"><?php echo $roomNo; ?></td>
<td class="border border-gray-400 p-2"><?php echo implode(", ", $rolls); ?></td>
</tr>
<?php endforeach; ?>
</table>
</div>

<script>
    // Reset form after output
    setTimeout(function(){
        document.getElementById("seatingForm").reset();
        document.getElementById("totalStudents").focus();
    }, 100);
</script>
<?php endif; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $("#totalStudents").focus();

    // Restrict Total Students input to 1–1000 dynamically
    $("#totalStudents").on("input", function(){
        let val = this.value.replace(/[^0-9]/g,'');
        if(val !== "") {
            if(parseInt(val) > 1000) val = "1000";
            if(parseInt(val) < 1) val = "1";
        }
        this.value = val;
        if(val.length > 0 && /^[0-9]{1,4}$/.test(val) && parseInt(val) <= 1000) $("#errTotal").text('');
    });

    // Restrict Seats per Room input to 1–100
    $("#seatsPerRoom").on("input", function(){
        let val = this.value.replace(/[^0-9]/g,'');
        if(val !== "") {
            if(parseInt(val) > 100) val = "100";
            if(parseInt(val) < 1) val = "1";
        }
        this.value = val;
        if(val.length > 0 && /^(?:[1-9]|[1-9][0-9]|100)$/.test(val)) $("#errSeats").text('');
    });
});
</script>

</div>
</body>
</html>
