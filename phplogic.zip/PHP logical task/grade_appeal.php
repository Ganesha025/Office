<?php
session_start();
$errors = [];
$appealResult = "";

// Handle POST submission
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = trim($_POST['name']);
    $regno = trim($_POST['regno']);
    $subject = trim($_POST['subject']);
    $currentGrade = trim($_POST['currentGrade']);
    $reason = trim($_POST['reason']);

    // Validation
    if($name === ""){
        $errors['name'] = "Enter student name";
    } elseif(!preg_match("/^[A-Za-z ]{1,20}$/", $name)){
        $errors['name'] = "Name must contain only letters and spaces (max 20 chars)";
    }

    if($regno === ""){
        $errors['regno'] = "Enter registration number";
    } elseif(!preg_match("/^\d{2}[A-Z]{3}\d{3}$/", $regno)){
        $errors['regno'] = "Enter valid Reg No (Ex: 22ECE023)";
    }

    if($subject === ""){
        $errors['subject'] = "Enter subject";
    } elseif(!preg_match("/^[A-Za-z ]{1,20}$/", $subject)){
        $errors['subject'] = "Subject must contain only letters and spaces (max 20 chars)";
    }

    if($currentGrade === ""){
        $errors['currentGrade'] = "Select current grade";
    }

    if($reason === ""){
        $errors['reason'] = "Enter reason for appeal";
    } elseif(!preg_match("/^[A-Za-z ]{1,100}$/", $reason)){
        $errors['reason'] = "Reason must contain only letters and spaces (max 100 chars)";
    }

    // Eligibility logic: Only B or below eligible
    if(empty($errors)){
        $eligibleGrades = ['B','C','D','F'];
        $appealResult = in_array(strtoupper($currentGrade), $eligibleGrades) 
            ? "Eligible for grade appeal." 
            : "Not eligible for grade appeal.";

        // Store appeal summary in session
        $_SESSION['appeal_summary'] = [
            'name'=>$name,
            'regno'=>$regno,
            'subject'=>$subject,
            'currentGrade'=>$currentGrade,
            'reason'=>$reason,
            'status'=>$appealResult
        ];

        // Redirect to clear POST and reset form
        header("Location: ".$_SERVER['PHP_SELF']."?submitted=1");
        exit;
    }
}

// Check if redirected after successful submission
$submitted = false;
if(isset($_GET['submitted']) && isset($_SESSION['appeal_summary'])){
    $submitted = true;
    $appealData = $_SESSION['appeal_summary'];
    unset($_SESSION['appeal_summary']); // Clear for next input
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Grade Appeal Form</title>
<style>

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #a8edea, #fed6e3); /* soft gradient background */
    display: flex;
    justify-content: center;
    padding: 20px;
}
.container {
    width: 650px;
    background: #ffffff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}
h2 { 
    text-align: center; 
    color: #004d40; /* dark teal color */
    margin-bottom: 20px; 
}
label { 
    font-weight: 600; 
    display: block; 
    margin-top: 10px; 
    color: #00695c; /* teal */
}
label span { color: red; }
input[type=text], textarea, select {
    width: 100%;
    padding: 10px;
    border-radius: 6px;
    border: 1px solid #b2dfdb; /* light teal border */
    box-sizing: border-box;
    margin-top: 5px;
}
input[type=text]:focus, textarea:focus, select:focus {
    border-color: #004d40;
    outline: none;
    box-shadow: 0 0 5px rgba(0,77,64,0.3);
}
textarea { resize: vertical; min-height: 60px; }
.error { color:red; font-size:13px; margin-top:3px; }
button {
    width: 100%;
    padding: 14px;
    margin-top: 15px;
    border-radius: 10px;
    border: none;
    background: #00796b; /* teal button */
    color: #fff;
    font-size: 16px;
    cursor: pointer;
}
button:hover { background: #004d40; }

/* Professional Appeal Summary Styling */
.appeal-summary {
    margin-top: 30px;
    padding: 20px 25px;
    border: 2px solid #00796b; /* teal border */
    border-radius: 12px;
    background: #e0f2f1; /* light teal background */
}
.appeal-summary h3 {
    text-align: center;
    margin-bottom: 20px;
    color: #004d40;
}
.appeal-summary p {
    font-size: 15px;
    line-height: 1.5;
    margin: 6px 0;
}
.appeal-summary p strong { width: 150px; display: inline-block; color: #004d40; }
.status {
    margin-top: 15px;
    font-weight: bold;
    color: #c62828; /* red for status */
    text-align: center;
    font-size: 16px;
}
</style>

</head>
<body>
<div class="container">
<h2>Grade Appeal Form</h2>

<form id="appealForm" method="post" action="" novalidate>
<label>Student Name <span>*</span></label>
<input type="text" name="name" id="name" maxlength="20" placeholder="Enter student name">
<div class="error" id="nameError"><?php echo $errors['name'] ?? ''; ?></div>

<label>Registration Number <span>*</span></label>
<input type="text" name="regno" id="regno" maxlength="8" placeholder="Ex: 22ECE023">
<div class="error" id="regError"><?php echo $errors['regno'] ?? ''; ?></div>

<label>Subject <span>*</span></label>
<input type="text" name="subject" id="subject" maxlength="20" placeholder="Enter subject">
<div class="error" id="subjectError"><?php echo $errors['subject'] ?? ''; ?></div>

<label>Current Grade <span>*</span></label>
<select name="currentGrade" id="currentGrade">
    <option value="">Select Grade</option>
    <option value="A" disabled>A</option>
    <option value="B">B</option>
    <option value="C">C</option>
    <option value="D">D</option>
    <option value="F">F</option>
</select>
<div class="error" id="gradeError"><?php echo $errors['currentGrade'] ?? ''; ?></div>

<label>Reason <span>*</span></label>
<textarea name="reason" id="reason" maxlength="100" placeholder="Reason for appeal"></textarea>
<div class="error" id="reasonError"><?php echo $errors['reason'] ?? ''; ?></div>

<button type="submit">Submit Appeal</button>
</form>

<?php if($submitted): ?>
<div class="appeal-summary">
    <h3>Grade Appeal Summary</h3>
    <p><strong>Student Name:</strong> <?php echo htmlspecialchars($appealData['name']); ?></p>
    <p><strong>Registration No:</strong> <?php echo htmlspecialchars($appealData['regno']); ?></p>
    <p><strong>Subject:</strong> <?php echo htmlspecialchars($appealData['subject']); ?></p>
    <p><strong>Current Grade:</strong> <?php echo htmlspecialchars($appealData['currentGrade']); ?></p>
    <p><strong>Reason for Appeal:</strong> <?php echo htmlspecialchars($appealData['reason']); ?></p>
    <p class="status"><strong>Status:</strong> <?php echo $appealData['status']; ?></p>
</div>
<?php endif; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $("#name").focus();

    // Allow only letters & spaces, limit characters
    $("#name").on('input', function(){
        this.value = this.value.replace(/[^A-Za-z ]/g,'').slice(0,20);
        if(this.value.length>0) $("#nameError").text('');
    });
    $("#regno").on('input', function(){
        this.value = this.value.toUpperCase();
        if(/^\d{2}[A-Z]{3}\d{3}$/.test(this.value)) $("#regError").text('');
    });
    $("#subject").on('input', function(){
        this.value = this.value.replace(/[^A-Za-z ]/g,'').slice(0,20);
        if(this.value.length>0) $("#subjectError").text('');
    });
    $("#currentGrade").change(function(){
        if($(this).val() != "") $("#gradeError").text('');
    });
    $("#reason").on('input', function(){
        this.value = this.value.replace(/[^A-Za-z ]/g,'').slice(0,100);
        if(this.value.length>0) $("#reasonError").text('');
    });

    <?php if($submitted): ?>
        $("#name").focus();
    <?php endif; ?>
});
</script>
</div>
</body>
</html>
