<?php
// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customerName = $_POST['customer_name'];
    $orderDate = $_POST['order_date'];
    $items = $_POST['items'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customer Order Management</title>

<style>
/* ----------- GLOBAL STYLES ----------- */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f7fb;
}

/* ----------- NAVBAR ----------- */
.navbar {
    background: #2c3e50;
    color: #fff;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.navbar h2 {
    margin: 0;
    font-size: 22px;
}

.navbar ul {
    list-style: none;
    display: flex;
    gap: 20px;
}

.navbar ul li {
    display: inline-block;
    font-size: 16px;
}

.navbar ul li a {
    text-decoration: none;
    color: #fff;
    font-weight: bold;
}

/* ----------- HEADER BANNER ----------- */
.header {
    text-align: center;
    padding: 50px 20px;
    background: #3498db;
    color: white;
}

.header h1 {
    font-size: 36px;
}

/* ----------- MAIN FORM CONTAINER ----------- */
.container {
    max-width: 850px;
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    margin: 40px auto;
    box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
}

h3 {
    text-align: center;
    margin-bottom: 20px;
    color: #444;
}

/* ----------- FORM INPUTS ----------- */
label {
    font-weight: bold;
    margin-top: 10px;
    display: block;
}

input {
    width: 100%;
    padding: 12px;
    margin-top: 6px;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 15px;
    background: #f9f9f9;
}

.item-group {
    display: flex;
    gap: 10px;
    margin-top: 10px;
}

.item-group input {
    width: 50%;
}

.add-btn, .submit-btn {
    padding: 12px 18px;
    border: none;
    cursor: pointer;
    margin-top: 20px;
    border-radius: 8px;
    font-size: 16px;
}

.add-btn {
    background: #3498db;
    color: white;
}

.submit-btn {
    background: #2ecc71;
    color: white;
    width: 100%;
}

.remove-btn {
    background: red;
    color: white;
    padding: 5px 10px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

/* ----------- ORDER SUMMARY ----------- */
.order-summary {
    background: #f1f4f7;
    padding: 20px;
    margin-top: 25px;
    border-radius: 10px;
}

.order-summary ul {
    padding: 0;
    list-style: none;
}

.order-summary li {
    padding: 8px 0;
    border-bottom: 1px solid #ccc;
}

/* ----------- FOOTER ----------- */
.footer {
    background: #2c3e50;
    color: #fff;
    text-align: center;
    padding: 15px;
    margin-top: 40px;
}

/* ----------- RESPONSIVE ----------- */
@media (max-width: 600px) {
    .item-group {
        flex-direction: column;
    }
    .item-group input {
        width: 100%;
    }
}
</style>

<script>
// Add Dynamic Item
function addItem() {
    let container = document.getElementById("itemContainer");

    let div = document.createElement("div");
    div.className = "item-group";

    div.innerHTML = `
        <input type="text" name="items[][name]" placeholder="Item Name" required>
        <input type="text" name="items[][print]" placeholder="Print Detail" required>
        <button type="button" class="remove-btn" onclick="this.parentElement.remove()">X</button>
    `;

    container.appendChild(div);
}
</script>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Order Manager</h2>
    <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Orders</a></li>
        <li><a href="#">Customers</a></li>
    </ul>
</div>

<!-- HEADER -->
<div class="header">
    <h1>Customer Order Management System</h1>
    <p>Manage customer orders easily and quickly</p>
</div>

<!-- MAIN FORM -->
<div class="container">
    <h3>Create New Order</h3>

    <form method="POST">

        <label>Customer Name:</label>
        <input type="text" name="customer_name" required>

        <label>Order Date:</label>
        <input type="date" name="order_date" required>

        <label>Order Items:</label>

        <div id="itemContainer">
            <div class="item-group">
                <input type="text" name="items[][name]" placeholder="Item Name" required>
                <input type="text" name="items[][print]" placeholder="Print Detail" required>
                <button type="button" class="remove-btn" onclick="this.parentElement.remove()">X</button>
            </div>
        </div>

        <button type="button" class="add-btn" onclick="addItem()">+ Add Item</button>

        <button type="submit" class="submit-btn">Submit Order</button>
    </form>

    <!-- SHOW SUMMARY -->
    <?php if (!empty($customerName)) { ?>
        <div class="order-summary">
            <h3>Order Summary</h3>
            <p><strong>Name:</strong> <?= $customerName ?></p>
            <p><strong>Date:</strong> <?= $orderDate ?></p>

            <h4>Items:</h4>
            <ul>
                <?php foreach ($items as $item) { ?>
                    <li>
                        <strong>Item:</strong> <?= $item['name'] ?>  
                        — <strong>Print:</strong> <?= $item['print'] ?>
                    </li>
                <?php } ?>
            </ul>
        </div>
    <?php } ?>
</div>

<!-- FOOTER -->
<div class="footer">
    © <?= date("Y") ?> Customer Order Management | All Rights Reserved
</div>

</body>
</html>
