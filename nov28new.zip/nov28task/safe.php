<?php
// Initialize arrays
$safeHouses = ["Juarez", "El Paso", "Nogales"];
$interrogationQuestions = ["Where is the cartel leader?", "What is the mission objective?"];
$missionSupplies = [
    ["item" => "weapons", "isPacked" => false],
    ["item" => "communication gear", "isPacked" => true],
    ["item" => "medical supplies", "isPacked" => false]
];
$cartelMessage = "";
$shift = 3;
$decryptedMessage = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Task 5: Decrypt Message
    $cartelMessage = $_POST['cartelMessage'] ?? '';
    $decryptedMessage = '';
    for ($i = 0; $i < strlen($cartelMessage); $i++) {
        $char = $cartelMessage[$i];
        if (ctype_alpha($char)) {
            $asciiOffset = ctype_upper($char) ? 65 : 97;
            $decryptedMessage .= chr((ord($char) - $asciiOffset - $shift + 26) % 26 + $asciiOffset);
        } else {
            $decryptedMessage .= $char;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cartel Mission Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">

<!-- Header -->
<header class="bg-indigo-700 text-white p-4 text-center text-2xl font-bold">
    Cartel Mission Dashboard
</header>

<!-- Main Container -->
<main class="flex-1 container mx-auto px-4 py-6">
    <!-- Safe Houses -->
    <section class="mb-6 bg-white shadow rounded p-4">
        <h2 class="text-xl font-semibold mb-2 text-indigo-700">Safe Houses</h2>
        <ul class="list-disc list-inside">
            <?php
            for ($i = 0; $i < count($safeHouses); $i++) {
                echo "<li>".htmlspecialchars($safeHouses[$i])."</li>";
            }
            ?>
        </ul>
    </section>

    <!-- Interrogation Questions -->
    <section class="mb-6 bg-white shadow rounded p-4">
        <h2 class="text-xl font-semibold mb-2 text-indigo-700">Interrogation Questions</h2>
        <ul class="list-decimal list-inside">
            <?php
            foreach ($interrogationQuestions as $question) {
                echo "<li>".htmlspecialchars($question)."</li>";
            }
            ?>
        </ul>
    </section>

    <!-- Mission Supplies -->
    <section class="mb-6 bg-white shadow rounded p-4">
        <h2 class="text-xl font-semibold mb-2 text-indigo-700">Mission Supplies Check</h2>
        <ul class="list-inside">
            <?php
            $index = 0;
            while ($index < count($missionSupplies)) {
                $item = $missionSupplies[$index];
                echo "<li>".$item['item']." - ".($item['isPacked'] ? "<span class='text-green-600 font-semibold'>Packed</span>" : "<span class='text-red-600 font-semibold'>Not Packed</span>")."</li>";
                $index++;
            }
            ?>
        </ul>
    </section>

    <!-- Decrypt Cartel Message -->
    <section class="bg-white shadow rounded p-4">
        <h2 class="text-xl font-semibold mb-2 text-indigo-700">Decrypt Cartel Message</h2>
        <form method="POST" class="mb-4">
            <label class="block mb-2 font-medium">Enter Encrypted Message:</label>
            <input type="text" name="cartelMessage" value="<?= htmlspecialchars($cartelMessage) ?>" class="w-full p-2 border rounded mb-2" placeholder="e.g., lbh zhphv">
            <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-500">Decrypt</button>
        </form>
        <?php if($decryptedMessage): ?>
            <div class="bg-gray-100 p-2 rounded border border-gray-300">
                <strong>Decrypted Message:</strong> <?= htmlspecialchars($decryptedMessage) ?>
            </div>
        <?php endif; ?>
    </section>
</main>

<!-- Footer -->
<footer class="bg-indigo-700 text-white p-4 text-center mt-auto">
    &copy; <?= date('Y') ?> Cartel Mission Control
</footer>

</body>
</html>
